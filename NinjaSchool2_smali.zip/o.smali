.class public final Lo;
.super Ljava/util/Vector;


# static fields
.field public static a:Lo;

.field public static b:Lo;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lo;

    invoke-direct {v0}, Lo;-><init>()V

    sput-object v0, Lo;->a:Lo;

    new-instance v0, Lo;

    invoke-direct {v0}, Lo;-><init>()V

    sput-object v0, Lo;->b:Lo;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/util/Vector;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 2

    const/16 v1, 0x17

    const/4 v0, 0x0

    invoke-static {v0}, Lh;->a(I)V

    const/4 v0, 0x1

    invoke-static {v0}, Lh;->a(I)V

    const/4 v0, 0x3

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0xa

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0xb

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0xc

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0xd

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0xe

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0xf

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x10

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x11

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x12

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x13

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x14

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x15

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x16

    invoke-static {v0}, Lh;->a(I)V

    invoke-static {v1}, Lh;->a(I)V

    invoke-static {v1}, Lh;->a(I)V

    const/16 v0, 0x18

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x19

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x1a

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x1b

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x1c

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x1d

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x1e

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x1f

    invoke-static {v0}, Lh;->a(I)V

    const/16 v0, 0x20

    invoke-static {v0}, Lh;->a(I)V

    return-void
.end method


# virtual methods
.method public final a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 4

    const/4 v0, 0x0

    move v1, v0

    :goto_2
    invoke-virtual {p0}, Ljava/util/Vector;->size()I

    move-result v0

    if-lt v1, v0, :cond_9

    return-void

    :cond_9
    invoke-virtual {p0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh;

    invoke-virtual {v0, p1}, Lh;->a(Ljavax/microedition/lcdui/Graphics;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_2
.end method

.method public final b()V
    .registers 3

    invoke-virtual {p0}, Ljava/util/Vector;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_7
    if-gez v1, :cond_a

    return-void

    :cond_a
    invoke-virtual {p0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh;

    invoke-virtual {v0}, Lh;->a()V

    iget-boolean v0, v0, Lh;->g:Z

    if-eqz v0, :cond_1a

    invoke-virtual {p0, v1}, Ljava/util/Vector;->removeElementAt(I)V

    :cond_1a
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_7
.end method
