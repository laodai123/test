.class public final Lg;
.super Ljava/lang/Object;


# static fields
.field public static A:Z

.field public static B:Z

.field public static C:Z

.field public static D:I

.field public static final E:[[[I

.field public static F:I

.field public static G:[[Ljava/lang/String;

.field public static H:Z

.field public static I:[Z

.field public static J:I

.field public static K:[I

.field public static L:[I

.field public static M:[I

.field public static N:[Ljavax/microedition/lcdui/Image;

.field public static O:Z

.field public static P:I

.field public static Q:I

.field public static R:I

.field public static S:I

.field public static T:I

.field public static U:I

.field public static V:I

.field public static W:I

.field public static X:I

.field public static Y:I

.field public static Z:I

.field public static a:I

.field public static aA:I

.field public static aB:I

.field public static aC:I

.field public static aD:I

.field public static aE:I

.field public static aF:I

.field public static aG:I

.field public static aH:I

.field public static aI:I

.field public static aJ:I

.field public static aK:I

.field public static aL:I

.field public static aM:I

.field public static aN:I

.field public static aO:I

.field public static aP:I

.field public static aQ:I

.field public static aR:I

.field public static aS:I

.field public static aT:I

.field public static aU:I

.field public static aV:I

.field public static aW:I

.field public static aX:I

.field public static aY:Z

.field public static aZ:Z

.field public static aa:I

.field public static ab:I

.field public static ac:I

.field public static ad:I

.field public static ae:I

.field public static af:I

.field public static ag:I

.field public static ah:I

.field public static ai:I

.field public static aj:I

.field public static ak:I

.field public static al:I

.field public static am:I

.field public static an:I

.field public static ao:I

.field public static ap:Z

.field public static aq:I

.field public static ar:I

.field public static as:I

.field public static at:I

.field public static au:I

.field public static av:I

.field public static aw:I

.field public static ax:I

.field public static ay:I

.field public static az:I

.field public static final b:[I

.field public static bA:I

.field public static bB:I

.field public static bC:I

.field public static bD:I

.field public static bE:I

.field public static bF:I

.field public static bG:I

.field public static bH:I

.field public static bI:I

.field public static bJ:I

.field public static bK:I

.field public static bL:I

.field private static bM:I

.field private static bN:[[[I

.field private static bO:[I

.field private static bP:[I

.field private static bQ:[[[I

.field private static bR:[I

.field private static bS:[I

.field private static bT:[I

.field private static bU:[I

.field private static bV:[I

.field private static bW:[I

.field private static bX:[I

.field private static bY:[I

.field private static bZ:[I

.field public static ba:Z

.field public static bb:Z

.field public static bc:I

.field public static bd:I

.field public static be:I

.field public static bf:Z

.field public static bg:Z

.field public static bh:I

.field public static bi:I

.field public static bj:I

.field public static bk:I

.field public static bl:I

.field public static bm:Z

.field public static bn:I

.field public static bo:I

.field public static bp:I

.field public static bq:I

.field public static br:I

.field public static bs:I

.field public static bt:I

.field public static bu:I

.field public static bv:I

.field public static bw:I

.field public static bx:I

.field public static by:I

.field public static bz:I

.field public static final c:[I

.field private static ca:[I

.field private static cb:[I

.field private static cc:[I

.field private static cd:[Ljavax/microedition/lcdui/Image;

.field private static ce:[Ljavax/microedition/lcdui/Image;

.field private static cf:[Ljavax/microedition/lcdui/Image;

.field private static cg:[Ljavax/microedition/lcdui/Image;

.field private static ch:[Ljavax/microedition/lcdui/Image;

.field private static ci:[Ljavax/microedition/lcdui/Image;

.field private static cj:[Ljavax/microedition/lcdui/Image;

.field private static ck:[[Ljavax/microedition/lcdui/Image;

.field private static cl:Z

.field private static cm:[Ljavax/microedition/lcdui/Image;

.field private static cn:[Ljavax/microedition/lcdui/Image;

.field private static co:[[Ljavax/microedition/lcdui/Image;

.field private static cp:[Ljavax/microedition/lcdui/Image;

.field private static cq:[Ljavax/microedition/lcdui/Image;

.field private static cr:[[Ljavax/microedition/lcdui/Image;

.field private static cs:[I

.field private static ct:[I

.field private static cu:I

.field private static cv:I

.field public static final d:[I

.field public static final e:[I

.field public static f:Z

.field public static g:Z

.field public static h:Z

.field public static i:Z

.field public static j:Z

.field public static k:Z

.field public static l:Z

.field public static m:Z

.field public static n:Z

.field public static o:Z

.field public static p:Z

.field public static q:Z

.field public static r:Z

.field public static s:Z

.field public static t:Z

.field public static u:Z

.field public static v:Z

.field public static w:Z

.field public static x:Z

.field public static y:Z

.field public static z:Z


# direct methods
.method static constructor <clinit>()V
    .registers 10

    const/16 v9, 0x20

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v0, -0x1

    sput v0, Lg;->a:I

    sput v1, Lg;->bM:I

    const/16 v0, 0x6b

    new-array v0, v0, [I

    fill-array-data v0, :array_7dc

    sput-object v0, Lg;->b:[I

    const/16 v0, 0x56

    new-array v0, v0, [I

    fill-array-data v0, :array_8b6

    sput-object v0, Lg;->c:[I

    const/16 v0, 0x5f

    new-array v0, v0, [I

    fill-array-data v0, :array_966

    sput-object v0, Lg;->d:[I

    const/16 v0, 0x5c

    new-array v0, v0, [I

    fill-array-data v0, :array_a28

    sput-object v0, Lg;->e:[I

    sput-boolean v1, Lg;->f:Z

    sput-boolean v1, Lg;->g:Z

    sput-boolean v1, Lg;->h:Z

    sput-boolean v1, Lg;->i:Z

    sput-boolean v1, Lg;->j:Z

    sput-boolean v1, Lg;->k:Z

    sput-boolean v1, Lg;->l:Z

    sput-boolean v1, Lg;->m:Z

    sput-boolean v1, Lg;->n:Z

    sput-boolean v1, Lg;->o:Z

    sput-boolean v7, Lg;->p:Z

    sput-boolean v7, Lg;->q:Z

    sput-boolean v1, Lg;->r:Z

    sput-boolean v1, Lg;->s:Z

    sput-boolean v1, Lg;->t:Z

    sput-boolean v1, Lg;->u:Z

    sput-boolean v1, Lg;->v:Z

    sput-boolean v1, Lg;->w:Z

    sput-boolean v1, Lg;->x:Z

    sput-boolean v1, Lg;->y:Z

    sput-boolean v1, Lg;->z:Z

    sput-boolean v1, Lg;->A:Z

    sput-boolean v1, Lg;->B:Z

    sput-boolean v1, Lg;->C:Z

    const/4 v0, -0x1

    sput v0, Lg;->D:I

    const/16 v0, 0x11

    new-array v0, v0, [[[I

    new-array v2, v6, [[I

    new-array v3, v6, [I

    const/16 v4, -0xd

    aput v4, v3, v7

    const/16 v4, 0x1f

    aput v4, v3, v8

    aput-object v3, v2, v1

    new-array v3, v6, [I

    const/4 v4, -0x7

    aput v4, v3, v7

    const/16 v4, 0x8

    aput v4, v3, v8

    aput-object v3, v2, v7

    new-array v3, v6, [I

    const/16 v4, -0xb

    aput v4, v3, v7

    const/16 v4, 0xe

    aput v4, v3, v8

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    new-array v2, v6, [[I

    new-array v3, v6, [I

    const/16 v4, -0xd

    aput v4, v3, v7

    aput v9, v3, v8

    aput-object v3, v2, v1

    new-array v3, v6, [I

    const/4 v4, -0x7

    aput v4, v3, v7

    const/16 v4, 0x8

    aput v4, v3, v8

    aput-object v3, v2, v7

    new-array v3, v6, [I

    const/16 v4, -0xb

    aput v4, v3, v7

    const/16 v4, 0xf

    aput v4, v3, v8

    aput-object v3, v2, v8

    aput-object v2, v0, v7

    new-array v2, v6, [[I

    new-array v3, v6, [I

    fill-array-data v3, :array_ae4

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_aee

    aput-object v3, v2, v7

    new-array v3, v6, [I

    const/4 v4, 0x6

    aput v4, v3, v1

    const/16 v4, -0x3e8

    aput v4, v3, v7

    aput-object v3, v2, v8

    aput-object v2, v0, v8

    new-array v2, v6, [[I

    new-array v3, v6, [I

    fill-array-data v3, :array_af8

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_b02

    aput-object v3, v2, v7

    new-array v3, v6, [I

    const/4 v4, 0x6

    aput v4, v3, v1

    const/16 v4, -0x3e8

    aput v4, v3, v7

    aput-object v3, v2, v8

    aput-object v2, v0, v6

    const/4 v2, 0x4

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_b0c

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b16

    aput-object v4, v3, v7

    new-array v4, v6, [I

    const/4 v5, 0x6

    aput v5, v4, v1

    const/16 v5, -0x3e8

    aput v5, v4, v7

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/4 v2, 0x5

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_b20

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b2a

    aput-object v4, v3, v7

    new-array v4, v6, [I

    const/4 v5, 0x6

    aput v5, v4, v1

    const/16 v5, -0x3e8

    aput v5, v4, v7

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/4 v2, 0x6

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_b34

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b3e

    aput-object v4, v3, v7

    new-array v4, v6, [I

    const/4 v5, 0x6

    aput v5, v4, v1

    const/16 v5, -0x3e8

    aput v5, v4, v7

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/4 v2, 0x7

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/4 v5, -0x8

    aput v5, v4, v7

    const/16 v5, 0x23

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b48

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_b52

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x8

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/4 v5, -0x8

    aput v5, v4, v7

    const/16 v5, 0x22

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b5c

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_b66

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x9

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/4 v5, -0x8

    aput v5, v4, v7

    const/16 v5, 0x1f

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b70

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_b7a

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xa

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_b84

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_b8e

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_b98

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xb

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_ba2

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_bac

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_bb6

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xc

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_bc0

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_bca

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_bd4

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xd

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_bde

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_be8

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_bf2

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xe

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_bfc

    aput-object v4, v3, v1

    new-array v4, v6, [I

    const/16 v5, 0x9

    aput v5, v4, v1

    const/16 v5, 0x16

    aput v5, v4, v8

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput v7, v4, v1

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xf

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_c06

    aput-object v4, v3, v1

    new-array v4, v6, [I

    const/16 v5, 0x9

    aput v5, v4, v1

    const/16 v5, 0x15

    aput v5, v4, v8

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput v7, v4, v1

    aput v7, v4, v8

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x10

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_c10

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_c1a

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput v7, v4, v1

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    sput-object v0, Lg;->bN:[[[I

    const/16 v0, 0x2e

    new-array v0, v0, [[[I

    new-array v2, v6, [[I

    new-array v3, v6, [I

    const/16 v4, -0xa

    aput v4, v3, v7

    aput v9, v3, v8

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_c24

    aput-object v3, v2, v7

    new-array v3, v6, [I

    fill-array-data v3, :array_c2e

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    new-array v2, v6, [[I

    new-array v3, v6, [I

    const/16 v4, -0xa

    aput v4, v3, v7

    const/16 v4, 0x21

    aput v4, v3, v8

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_c38

    aput-object v3, v2, v7

    new-array v3, v6, [I

    fill-array-data v3, :array_c42

    aput-object v3, v2, v8

    aput-object v2, v0, v7

    new-array v2, v6, [[I

    new-array v3, v6, [I

    fill-array-data v3, :array_c4c

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_c56

    aput-object v3, v2, v7

    new-array v3, v6, [I

    fill-array-data v3, :array_c60

    aput-object v3, v2, v8

    aput-object v2, v0, v8

    new-array v2, v6, [[I

    new-array v3, v6, [I

    fill-array-data v3, :array_c6a

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_c74

    aput-object v3, v2, v7

    new-array v3, v6, [I

    fill-array-data v3, :array_c7e

    aput-object v3, v2, v8

    aput-object v2, v0, v6

    const/4 v2, 0x4

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_c88

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_c92

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_c9c

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/4 v2, 0x5

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_ca6

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_cb0

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_cba

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/4 v2, 0x6

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_cc4

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_cce

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_cd8

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/4 v2, 0x7

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0x9

    aput v5, v4, v7

    const/16 v5, 0x24

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_ce2

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_cec

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x8

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_cf6

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x9

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_d00

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xa

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_d0a

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xb

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_d14

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xc

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0x9

    aput v5, v4, v7

    const/16 v5, 0x23

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_d1e

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_d28

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xd

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0x9

    aput v5, v4, v7

    aput v9, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_d32

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_d3c

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xe

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_d46

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_d50

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_d5a

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0xf

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_d64

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_d6e

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_d78

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x10

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_d82

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_d8c

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_d96

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x11

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0xb

    aput v5, v4, v7

    aput v9, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_da0

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_daa

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x12

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_db4

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_dbe

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_dc8

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x13

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_dd2

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_ddc

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_de6

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x14

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_df0

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_dfa

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_e04

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x15

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_e0e

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_e18

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_e22

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x16

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0xa

    aput v5, v4, v7

    const/16 v5, 0x1c

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_e2c

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x17

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0x9

    aput v5, v4, v7

    const/16 v5, 0x23

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_e36

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_e40

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x18

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0xa

    aput v5, v4, v7

    const/16 v5, 0x21

    aput v5, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x19

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_e4a

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x1a

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_e54

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x1b

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0x9

    aput v5, v4, v7

    aput v9, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_e5e

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_e68

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x1c

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_e72

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_e7c

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_e86

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x1d

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_e90

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_e9a

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_ea4

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x1e

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_eae

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_eb8

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_ec2

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x1f

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0xb

    aput v5, v4, v7

    aput v9, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_ecc

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_ed6

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    new-array v2, v6, [[I

    new-array v3, v6, [I

    fill-array-data v3, :array_ee0

    aput-object v3, v2, v1

    new-array v3, v6, [I

    fill-array-data v3, :array_eea

    aput-object v3, v2, v7

    new-array v3, v6, [I

    fill-array-data v3, :array_ef4

    aput-object v3, v2, v8

    aput-object v2, v0, v9

    const/16 v2, 0x21

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_efe

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_f08

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_f12

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x22

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_f1c

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_f26

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_f30

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x23

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0x9

    aput v5, v4, v7

    aput v9, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_f3a

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_f44

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x24

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_f4e

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_f58

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_f62

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x25

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_f6c

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_f76

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_f80

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x26

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_f8a

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_f94

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_f9e

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x27

    new-array v3, v6, [[I

    new-array v4, v6, [I

    const/16 v5, -0xb

    aput v5, v4, v7

    aput v9, v4, v8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_fa8

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_fb2

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x28

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_fbc

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_fc6

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_fd0

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x29

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_fda

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_fe4

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_fee

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x2a

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_ff8

    aput-object v4, v3, v1

    new-array v4, v6, [I

    fill-array-data v4, :array_1002

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_100c

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x2b

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_1016

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_1020

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x2c

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_102a

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_1034

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    const/16 v2, 0x2d

    new-array v3, v6, [[I

    new-array v4, v6, [I

    fill-array-data v4, :array_103e

    aput-object v4, v3, v1

    new-array v4, v6, [I

    aput-object v4, v3, v7

    new-array v4, v6, [I

    fill-array-data v4, :array_1048

    aput-object v4, v3, v8

    aput-object v3, v0, v2

    sput-object v0, Lg;->E:[[[I

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_1052

    sput-object v0, Lg;->bO:[I

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_106c

    sput-object v0, Lg;->bP:[I

    sget-object v0, Lg;->E:[[[I

    array-length v0, v0

    filled-new-array {v0, v6, v6}, [I

    move-result-object v0

    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[[I

    sput-object v0, Lg;->bQ:[[[I

    move v0, v1

    :goto_75d
    sget-object v2, Lg;->E:[[[I

    array-length v2, v2

    if-lt v0, v2, :cond_79c

    sput-boolean v1, Lg;->O:Z

    const/4 v0, -0x1

    sput v0, Lg;->Q:I

    sput-boolean v7, Lg;->aY:Z

    const/4 v0, 0x5

    new-array v0, v0, [I

    sput-object v0, Lg;->cs:[I

    aput v7, v0, v1

    sget-object v0, Lg;->cs:[I

    aput v8, v0, v7

    sget-object v0, Lg;->cs:[I

    aput v1, v0, v8

    sget-object v0, Lg;->cs:[I

    aput v8, v0, v6

    sget-object v0, Lg;->cs:[I

    const/4 v2, 0x4

    aput v8, v0, v2

    const/4 v0, 0x4

    new-array v0, v0, [I

    sput-object v0, Lg;->ct:[I

    aput v8, v0, v1

    sget-object v0, Lg;->ct:[I

    aput v8, v0, v7

    sget-object v0, Lg;->ct:[I

    aput v8, v0, v8

    sget-object v0, Lg;->ct:[I

    aput v7, v0, v6

    sput-boolean v1, Lg;->bm:Z

    const/4 v0, -0x1

    sput v0, Lg;->bn:I

    sput v1, Lg;->bL:I

    return-void

    :cond_79c
    move v3, v1

    :goto_79d
    if-lt v3, v6, :cond_7a2

    add-int/lit8 v0, v0, 0x1

    goto :goto_75d

    :cond_7a2
    move v2, v1

    :goto_7a3
    if-lt v2, v6, :cond_7a9

    add-int/lit8 v2, v3, 0x1

    move v3, v2

    goto :goto_79d

    :cond_7a9
    sget-object v4, Lg;->bQ:[[[I

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    sget-object v5, Lg;->E:[[[I

    aget-object v5, v5, v0

    aget-object v5, v5, v3

    aget v5, v5, v2

    aput v5, v4, v2

    if-nez v3, :cond_7d0

    if-nez v2, :cond_7d0

    sget-object v4, Lg;->E:[[[I

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    aget v4, v4, v2

    packed-switch v4, :pswitch_data_1086

    sget-object v4, Lg;->bQ:[[[I

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    aput v1, v4, v2

    :cond_7d0
    :goto_7d0
    add-int/lit8 v2, v2, 0x1

    goto :goto_7a3

    :pswitch_7d3  #0x1, 0x2
    sget-object v4, Lg;->bQ:[[[I

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    aput v7, v4, v2

    goto :goto_7d0

    :array_7dc
    .array-data 4
        0x6
        0x6
        0x6
        0x8
        0x8
        0x8
        0xa
        0xa
        0xa
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
        0xe
        0xe
        0xe
        0xe
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x14
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
        0x1a
    .end array-data

    :array_8b6
    .array-data 4
        0x50
        0x96
        0xf0
        0x190
        0x258
        0x320
        0x3e8
        0x5dc
        0x7d0
        0xbb8
        0x1388
        0x1b58
        0x2328
        0x2ee0
        0x3a98
        0x4a38
        0x6590
        0x7d00
        0x9c40
        0xc350
        0xea60
        0x11170
        0x13880
        0x15f90
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x186a0
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
        0x19a28
    .end array-data

    :array_966
    .array-data 4
        0x28
        0x28
        0x28
        0x28
        0x3c
        0x3c
        0x3c
        0x50
        0x50
        0x64
        0x78
        0x8c
        0xa0
        0xa0
        0xb4
        0xb4
        0xc8
        0xf0
        0x104
        0x12c
        0x140
        0x154
        0x168
        0x17c
        0x190
        0x1a4
        0x1b8
        0x1f4
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x258
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
        0x2bc
    .end array-data

    :array_a28
    .array-data 4
        0x14
        0x14
        0x14
        0x14
        0x1e
        0x1e
        0x1e
        0x28
        0x28
        0x32
        0x3c
        0x46
        0x50
        0x50
        0x5a
        0x5a
        0x64
        0x78
        0x82
        0x96
        0xa0
        0xaa
        0xb4
        0xbe
        0xc8
        0xd2
        0xdc
        0xfa
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x12c
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
        0x15e
    .end array-data

    :array_ae4
    .array-data 4
        0x1
        -0xb
        0x1f
    .end array-data

    :array_aee
    .array-data 4
        0x1
        -0x9
        0x10
    .end array-data

    :array_af8
    .array-data 4
        0x2
        -0xb
        0x20
    .end array-data

    :array_b02
    .array-data 4
        0x2
        -0xa
        0x10
    .end array-data

    :array_b0c
    .array-data 4
        0x1
        -0xb
        0x1f
    .end array-data

    :array_b16
    .array-data 4
        0x3
        -0x8
        0x10
    .end array-data

    :array_b20
    .array-data 4
        0x2
        -0xa
        0x20
    .end array-data

    :array_b2a
    .array-data 4
        0x7
        -0x9
        0x11
    .end array-data

    :array_b34
    .array-data 4
        0x1
        -0xa
        0x1f
    .end array-data

    :array_b3e
    .array-data 4
        0x8
        -0x8
        0x10
    .end array-data

    :array_b48
    .array-data 4
        0x4
        -0x5
        0xf
    .end array-data

    :array_b52
    .array-data 4
        0x2
        -0xa
        0x15
    .end array-data

    :array_b5c
    .array-data 4
        0x4
        -0x6
        0xd
    .end array-data

    :array_b66
    .array-data 4
        0x3
        -0xb
        0x16
    .end array-data

    :array_b70
    .array-data 4
        0x6
        -0xd
        0x9
    .end array-data

    :array_b7a
    .array-data 4
        0x4
        -0xa
        0x12
    .end array-data

    :array_b84
    .array-data 4
        0x1
        -0x8
        0x1e
    .end array-data

    :array_b8e
    .array-data 4
        0x6
        -0xd
        0x9
    .end array-data

    :array_b98
    .array-data 4
        0x5
        -0x8
        0x11
    .end array-data

    :array_ba2
    .array-data 4
        0x2
        -0xa
        0x1e
    .end array-data

    :array_bac
    .array-data 4
        0x6
        -0xd
        0x9
    .end array-data

    :array_bb6
    .array-data 4
        0x6
        -0x8
        0x10
    .end array-data

    :array_bc0
    .array-data 4
        0x2
        -0xa
        0x1d
    .end array-data

    :array_bca
    .array-data 4
        0x6
        -0xd
        0x9
    .end array-data

    :array_bd4
    .array-data 4
        0x7
        -0xb
        0x11
    .end array-data

    :array_bde
    .array-data 4
        0x3
        -0xb
        0x21
    .end array-data

    :array_be8
    .array-data 4
        0x8
        -0x4
        0xd
    .end array-data

    :array_bf2
    .array-data 4
        0x8
        -0xf
        0x19
    .end array-data

    :array_bfc
    .array-data 4
        0x1
        -0x6
        0x27
    .end array-data

    :array_c06
    .array-data 4
        0x1
        -0x6
        0x26
    .end array-data

    :array_c10
    .array-data 4
        0x1
        -0x8
        0x2b
    .end array-data

    :array_c1a
    .array-data 4
        0x9
        -0x2
        0x1a
    .end array-data

    :array_c24
    .array-data 4
        0x1
        -0x7
        0x7
    .end array-data

    :array_c2e
    .array-data 4
        0x1
        -0xb
        0xf
    .end array-data

    :array_c38
    .array-data 4
        0x1
        -0x7
        0x7
    .end array-data

    :array_c42
    .array-data 4
        0x1
        -0xb
        0x10
    .end array-data

    :array_c4c
    .array-data 4
        0x1
        -0xa
        0x21
    .end array-data

    :array_c56
    .array-data 4
        0x2
        -0xa
        0xb
    .end array-data

    :array_c60
    .array-data 4
        0x2
        -0x9
        0x10
    .end array-data

    :array_c6a
    .array-data 4
        0x1
        -0xa
        0x20
    .end array-data

    :array_c74
    .array-data 4
        0x3
        -0xb
        0x9
    .end array-data

    :array_c7e
    .array-data 4
        0x3
        -0xb
        0x10
    .end array-data

    :array_c88
    .array-data 4
        0x1
        -0xa
        0x22
    .end array-data

    :array_c92
    .array-data 4
        0x4
        -0x9
        0x9
    .end array-data

    :array_c9c
    .array-data 4
        0x4
        -0x8
        0x10
    .end array-data

    :array_ca6
    .array-data 4
        0x1
        -0xa
        0x22
    .end array-data

    :array_cb0
    .array-data 4
        0x5
        -0xb
        0xb
    .end array-data

    :array_cba
    .array-data 4
        0x5
        -0xa
        0x11
    .end array-data

    :array_cc4
    .array-data 4
        0x1
        -0xa
        0x21
    .end array-data

    :array_cce
    .array-data 4
        0x6
        -0x9
        0x9
    .end array-data

    :array_cd8
    .array-data 4
        0x6
        -0x8
        0x10
    .end array-data

    :array_ce2
    .array-data 4
        0x7
        -0x5
        0xf
    .end array-data

    :array_cec
    .array-data 4
        0x7
        -0xa
        0x15
    .end array-data

    :array_cf6
    .array-data 4
        0x4
        -0xd
        0x1a
    .end array-data

    :array_d00
    .array-data 4
        0x5
        -0xd
        0x19
    .end array-data

    :array_d0a
    .array-data 4
        0x6
        -0xc
        0x1a
    .end array-data

    :array_d14
    .array-data 4
        0x7
        -0xd
        0x19
    .end array-data

    :array_d1e
    .array-data 4
        0x8
        -0x4
        0xd
    .end array-data

    :array_d28
    .array-data 4
        0x8
        -0xe
        0x1b
    .end array-data

    :array_d32
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_d3c
    .array-data 4
        0xa
        -0xa
        0x12
    .end array-data

    :array_d46
    .array-data 4
        0x2
        -0x7
        0x22
    .end array-data

    :array_d50
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_d5a
    .array-data 4
        0xb
        -0x8
        0x10
    .end array-data

    :array_d64
    .array-data 4
        0x2
        -0x8
        0x21
    .end array-data

    :array_d6e
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_d78
    .array-data 4
        0xc
        -0x8
        0xf
    .end array-data

    :array_d82
    .array-data 4
        0x2
        -0x7
        0x21
    .end array-data

    :array_d8c
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_d96
    .array-data 4
        0xd
        -0xc
        0x10
    .end array-data

    :array_da0
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_daa
    .array-data 4
        0xe
        -0xf
        0x13
    .end array-data

    :array_db4
    .array-data 4
        0x2
        -0x9
        0x21
    .end array-data

    :array_dbe
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_dc8
    .array-data 4
        0xf
        -0xd
        0x14
    .end array-data

    :array_dd2
    .array-data 4
        0x2
        -0x9
        0x20
    .end array-data

    :array_ddc
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_de6
    .array-data 4
        0x10
        -0x7
        0x17
    .end array-data

    :array_df0
    .array-data 4
        0x2
        -0x9
        0x21
    .end array-data

    :array_dfa
    .array-data 4
        0x9
        -0xb
        0x9
    .end array-data

    :array_e04
    .array-data 4
        0x11
        -0xb
        0x13
    .end array-data

    :array_e0e
    .array-data 4
        0x3
        -0xc
        0x22
    .end array-data

    :array_e18
    .array-data 4
        0x8
        -0x4
        0xd
    .end array-data

    :array_e22
    .array-data 4
        0x8
        -0xf
        0x19
    .end array-data

    :array_e2c
    .array-data 4
        0x13
        -0x8
        0xc
    .end array-data

    :array_e36
    .array-data 4
        0x8
        -0x4
        0xd
    .end array-data

    :array_e40
    .array-data 4
        0x9
        -0x9
        0x16
    .end array-data

    :array_e4a
    .array-data 4
        0x9
        -0x4
        0x18
    .end array-data

    :array_e54
    .array-data 4
        0xa
        -0x4
        0x16
    .end array-data

    :array_e5e
    .array-data 4
        0x8
        -0x4
        0x9
    .end array-data

    :array_e68
    .array-data 4
        0xa
        -0xa
        0x12
    .end array-data

    :array_e72
    .array-data 4
        0x2
        -0x7
        0x22
    .end array-data

    :array_e7c
    .array-data 4
        0x8
        -0x4
        0x9
    .end array-data

    :array_e86
    .array-data 4
        0xb
        -0x8
        0x10
    .end array-data

    :array_e90
    .array-data 4
        0x2
        -0x8
        0x21
    .end array-data

    :array_e9a
    .array-data 4
        0x8
        -0x4
        0x9
    .end array-data

    :array_ea4
    .array-data 4
        0xc
        -0x8
        0xf
    .end array-data

    :array_eae
    .array-data 4
        0x2
        -0x7
        0x21
    .end array-data

    :array_eb8
    .array-data 4
        0x8
        -0x4
        0x9
    .end array-data

    :array_ec2
    .array-data 4
        0xd
        -0xc
        0x10
    .end array-data

    :array_ecc
    .array-data 4
        0x7
        -0x5
        0x9
    .end array-data

    :array_ed6
    .array-data 4
        0xe
        -0xf
        0x13
    .end array-data

    :array_ee0
    .array-data 4
        0x2
        -0x9
        0x21
    .end array-data

    :array_eea
    .array-data 4
        0x7
        -0x5
        0x9
    .end array-data

    :array_ef4
    .array-data 4
        0xf
        -0xd
        0x14
    .end array-data

    :array_efe
    .array-data 4
        0x2
        -0x9
        0x20
    .end array-data

    :array_f08
    .array-data 4
        0x7
        -0x5
        0x9
    .end array-data

    :array_f12
    .array-data 4
        0x10
        -0x7
        0x17
    .end array-data

    :array_f1c
    .array-data 4
        0x2
        -0x9
        0x21
    .end array-data

    :array_f26
    .array-data 4
        0x7
        -0x5
        0x9
    .end array-data

    :array_f30
    .array-data 4
        0x11
        -0xb
        0x13
    .end array-data

    :array_f3a
    .array-data 4
        0x2
        -0xa
        0xb
    .end array-data

    :array_f44
    .array-data 4
        0xa
        -0xa
        0x12
    .end array-data

    :array_f4e
    .array-data 4
        0x2
        -0x7
        0x22
    .end array-data

    :array_f58
    .array-data 4
        0x3
        -0xb
        0x9
    .end array-data

    :array_f62
    .array-data 4
        0xb
        -0x8
        0x10
    .end array-data

    :array_f6c
    .array-data 4
        0x2
        -0x8
        0x21
    .end array-data

    :array_f76
    .array-data 4
        0x4
        -0x9
        0x9
    .end array-data

    :array_f80
    .array-data 4
        0xc
        -0x8
        0xf
    .end array-data

    :array_f8a
    .array-data 4
        0x2
        -0x7
        0x21
    .end array-data

    :array_f94
    .array-data 4
        0x5
        -0xb
        0xb
    .end array-data

    :array_f9e
    .array-data 4
        0xd
        -0xc
        0x10
    .end array-data

    :array_fa8
    .array-data 4
        0x2
        -0xa
        0xb
    .end array-data

    :array_fb2
    .array-data 4
        0xe
        -0xf
        0x13
    .end array-data

    :array_fbc
    .array-data 4
        0x2
        -0x9
        0x21
    .end array-data

    :array_fc6
    .array-data 4
        0x3
        -0xb
        0x9
    .end array-data

    :array_fd0
    .array-data 4
        0xf
        -0xd
        0x14
    .end array-data

    :array_fda
    .array-data 4
        0x2
        -0x9
        0x20
    .end array-data

    :array_fe4
    .array-data 4
        0x4
        -0x9
        0x9
    .end array-data

    :array_fee
    .array-data 4
        0x10
        -0x7
        0x17
    .end array-data

    :array_ff8
    .array-data 4
        0x2
        -0x9
        0x21
    .end array-data

    :array_1002
    .array-data 4
        0x5
        -0xb
        0xb
    .end array-data

    :array_100c
    .array-data 4
        0x11
        -0xb
        0x13
    .end array-data

    :array_1016
    .array-data 4
        0x1
        -0x8
        0x27
    .end array-data

    :array_1020
    .array-data 4
        0x12
        -0x8
        0x16
    .end array-data

    :array_102a
    .array-data 4
        0x1
        -0x8
        0x26
    .end array-data

    :array_1034
    .array-data 4
        0x12
        -0x8
        0x15
    .end array-data

    :array_103e
    .array-data 4
        0x1
        -0xa
        0x2b
    .end array-data

    :array_1048
    .array-data 4
        0x12
        -0xb
        0x1a
    .end array-data

    :array_1052
    .array-data 4
        -0x2
        -0x6
        0x16
        0x15
        0x13
        0x16
        0xa
        -0x2
        -0x2
        0x5
        0x13
    .end array-data

    :array_106c
    .array-data 4
        0x9
        0x16
        0x19
        0x11
        0x1a
        0x25
        0x24
        0x31
        0x32
        0x34
        0x24
    .end array-data

    :pswitch_data_1086
    .packed-switch 0x1
        :pswitch_7d3  #00000001
        :pswitch_7d3  #00000002
    .end packed-switch
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a(III)I
    .registers 13

    sget v0, Lg;->au:I

    sget v1, Lg;->aA:I

    sub-int/2addr v0, v1

    add-int/lit8 v8, v0, -0x1e

    const/4 v1, 0x0

    sget v0, Lg;->au:I

    add-int/lit8 v9, v0, 0x5

    const/4 v0, 0x0

    move v6, v0

    :goto_e
    sget v0, La;->c:I

    if-lt v6, v0, :cond_1a

    const/4 v0, 0x0

    move v6, v0

    :goto_14
    sget v0, Ln;->c:I

    if-lt v6, v0, :cond_a3

    const/4 v0, -0x1

    :goto_19
    return v0

    :cond_1a
    sget-object v0, La;->i:[I

    aget v0, v0, v6

    const/4 v2, 0x5

    if-eq v0, v2, :cond_9e

    sget-object v0, La;->e:[I

    aget v0, v0, v6

    if-lt v0, p0, :cond_9e

    sget-object v0, La;->e:[I

    aget v0, v0, v6

    if-gt v0, p1, :cond_9e

    sget-object v0, La;->f:[I

    aget v0, v0, v6

    if-lt v0, v8, :cond_9e

    sget-object v0, La;->f:[I

    aget v0, v0, v6

    if-gt v0, v9, :cond_9e

    if-eq v6, p2, :cond_9e

    const/4 v0, 0x2

    if-le v1, v0, :cond_40

    const/4 v0, -0x1

    goto :goto_19

    :cond_40
    add-int/lit8 v7, v1, 0x1

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lh;

    sget-object v2, La;->e:[I

    aget v2, v2, v6

    sget-object v3, La;->f:[I

    aget v3, v3, v6

    add-int/lit16 v3, v3, -0x82

    const/16 v4, 0xa

    invoke-direct {v1, v2, v3, v4}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->aJ:I

    div-int/lit8 v0, v0, 0x6

    sget v1, Lg;->aF:I

    neg-int v1, v1

    const/4 v2, 0x0

    invoke-static {v6, v0, v1, v2}, La;->a(IIII)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lg;->aJ:I

    div-int/lit8 v1, v1, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, La;->e:[I

    aget v2, v2, v6

    sget-object v3, La;->f:[I

    aget v3, v3, v6

    sget-object v4, La;->g:[I

    aget v4, v4, v6

    sub-int/2addr v3, v4

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, La;->e:[I

    aget v0, v0, v6

    sget-object v1, La;->f:[I

    aget v1, v1, v6

    sget-object v2, La;->g:[I

    aget v2, v2, v6

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    sget v2, Lg;->aF:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    move v1, v7

    :cond_9e
    add-int/lit8 v0, v6, 0x1

    move v6, v0

    goto/16 :goto_e

    :cond_a3
    sget-object v0, Ln;->i:[I

    aget v0, v0, v6

    const/4 v2, 0x5

    if-eq v0, v2, :cond_11f

    sget-object v0, Ln;->e:[I

    aget v0, v0, v6

    if-lt v0, p0, :cond_11f

    sget-object v0, Ln;->e:[I

    aget v0, v0, v6

    if-gt v0, p1, :cond_11f

    sget-object v0, Ln;->f:[I

    aget v0, v0, v6

    if-lt v0, v8, :cond_11f

    sget-object v0, Ln;->f:[I

    aget v0, v0, v6

    if-gt v0, v9, :cond_11f

    if-eq v6, p2, :cond_11f

    const/4 v0, 0x2

    if-le v1, v0, :cond_ca

    const/4 v0, -0x1

    goto/16 :goto_19

    :cond_ca
    add-int/lit8 v7, v1, 0x1

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lh;

    sget-object v2, Ln;->e:[I

    aget v2, v2, v6

    sget-object v3, Ln;->f:[I

    aget v3, v3, v6

    add-int/lit16 v3, v3, -0x82

    const/16 v4, 0xa

    invoke-direct {v1, v2, v3, v4}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->aJ:I

    div-int/lit8 v0, v0, 0x6

    sget v1, Lg;->aF:I

    neg-int v1, v1

    invoke-static {v6, v0, v1}, Ln;->a(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lg;->aJ:I

    div-int/lit8 v1, v1, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v6

    sget-object v3, Ln;->f:[I

    aget v3, v3, v6

    add-int/lit8 v3, v3, -0x19

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v6

    sget-object v1, Ln;->f:[I

    aget v1, v1, v6

    add-int/lit8 v1, v1, -0xc

    sget v2, Lg;->aF:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    move v1, v7

    :cond_11f
    add-int/lit8 v0, v6, 0x1

    move v6, v0

    goto/16 :goto_14
.end method

.method public static final a()V
    .registers 12

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v1, -0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    sget v0, Lg;->Q:I

    sget v2, Lq;->as:I

    if-eq v0, v2, :cond_c

    :cond_b
    :goto_b
    return-void

    :cond_c
    :try_start_c
    sget v0, Lg;->V:I

    packed-switch v0, :pswitch_data_8fc

    :pswitch_11  #0x6, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x10, 0x11
    goto :goto_b

    :pswitch_12  #0x1
    sget v0, Lg;->ae:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ae:I

    const/16 v2, 0x1e

    if-le v0, v2, :cond_1f

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    :cond_1f
    sget v0, Lg;->ae:I

    rem-int/lit8 v0, v0, 0xf

    if-ge v0, v10, :cond_94

    const/4 v0, 0x0

    sput v0, Lg;->W:I

    :goto_28
    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_79

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x6

    if-nez v0, :cond_79

    sget-boolean v0, Lq;->aA:Z

    if-nez v0, :cond_79

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v2, 0x3

    if-ge v0, v2, :cond_42

    move v0, v7

    :goto_3e
    sget v2, La;->c:I

    if-lt v0, v2, :cond_98

    :cond_42
    move v0, v7

    :goto_43
    sget v2, Ln;->c:I

    if-lt v0, v2, :cond_e3

    sget v0, Lm;->c:I

    sget v2, Lg;->S:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x32

    if-ge v0, v2, :cond_12e

    sget v0, Lm;->b:I

    sget v2, Lg;->R:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x32

    if-ge v0, v2, :cond_12e

    sget v0, Lm;->e:I

    if-lez v0, :cond_12e

    sget v0, Lm;->b:I

    sget v2, Lg;->R:I

    if-le v0, v2, :cond_12b

    :goto_6b
    sput v8, Lg;->ad:I

    const/4 v0, 0x5

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->bl:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    :cond_79
    :goto_79
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xf

    if-nez v0, :cond_b

    invoke-static {}, Lg;->j()V
    :try_end_82
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_82} :catch_83

    goto :goto_b

    :catch_83
    move-exception v0

    sget v0, Lg;->at:I

    sput v0, Lg;->R:I

    sget v0, Lg;->au:I

    sput v0, Lg;->S:I

    sput v7, Lg;->T:I

    sput v7, Lg;->U:I

    sput v11, Lg;->V:I

    goto/16 :goto_b

    :cond_94
    const/4 v0, 0x1

    :try_start_95
    sput v0, Lg;->W:I

    goto :goto_28

    :cond_98
    sget-object v2, La;->i:[I

    aget v2, v2, v0

    if-eq v2, v10, :cond_df

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v3, Lg;->S:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_df

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v3, Lg;->R:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x28

    if-ge v2, v3, :cond_df

    sget-object v2, La;->a:[I

    sget-object v3, La;->d:[I

    aget v3, v3, v0

    aget v2, v2, v3

    if-lez v2, :cond_df

    sget-object v2, La;->e:[I

    aget v0, v2, v0

    sget v2, Lg;->R:I

    if-le v0, v2, :cond_dd

    :goto_ce
    sput v8, Lg;->ad:I

    const/4 v0, 0x5

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->bl:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    goto :goto_79

    :cond_dd
    move v8, v1

    goto :goto_ce

    :cond_df
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_3e

    :cond_e3
    sget-object v2, Ln;->i:[I

    aget v2, v2, v0

    if-eq v2, v10, :cond_127

    sget-object v2, Ln;->f:[I

    aget v2, v2, v0

    sget v3, Lg;->S:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x1e

    if-ge v2, v3, :cond_127

    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget v3, Lg;->R:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x28

    if-ge v2, v3, :cond_127

    sget-object v2, Ln;->b:[I

    aget v2, v2, v0

    if-lez v2, :cond_127

    sget-object v2, Ln;->e:[I

    aget v0, v2, v0

    sget v2, Lg;->R:I

    if-le v0, v2, :cond_125

    :goto_115
    sput v8, Lg;->ad:I

    const/4 v0, 0x5

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->bl:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    goto/16 :goto_79

    :cond_125
    move v8, v1

    goto :goto_115

    :cond_127
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_43

    :cond_12b
    move v8, v1

    goto/16 :goto_6b

    :cond_12e
    sget v0, Lg;->at:I

    sget v2, Lg;->R:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x19

    if-le v0, v2, :cond_79

    sget v0, Lg;->ax:I

    if-ne v0, v10, :cond_79

    sget v0, Lg;->at:I

    sget v2, Lg;->R:I

    if-le v0, v2, :cond_155

    :goto_145
    sput v8, Lg;->ad:I

    const/4 v0, 0x5

    sput v0, Lg;->V:I

    const/4 v0, 0x1

    sput v0, Lg;->bl:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    goto/16 :goto_79

    :cond_155
    move v8, v1

    goto :goto_145

    :pswitch_157  #0x2
    sget v0, Lg;->ae:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ae:I

    const/16 v2, 0xa

    if-lt v0, v2, :cond_164

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    :cond_164
    sget v0, Lg;->ae:I

    shr-int/lit8 v0, v0, 0x1

    add-int/lit8 v0, v0, 0x2

    sput v0, Lg;->W:I

    sget v0, Lg;->ad:I

    if-ne v0, v8, :cond_1f7

    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    add-int/2addr v0, v2

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    const/4 v3, 0x4

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_192

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    add-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->Z:I

    sub-int/2addr v0, v2

    sput v0, Lg;->R:I

    :cond_192
    :goto_192
    sget v0, Lg;->R:I

    sget v2, Lg;->T:I

    add-int/2addr v0, v2

    sput v0, Lg;->R:I

    if-gez v0, :cond_19e

    const/4 v0, 0x0

    sput v0, Lg;->R:I

    :cond_19e
    sget v0, Lg;->R:I

    sget v2, Lj;->c:I

    if-lt v0, v2, :cond_1aa

    sget v0, Lj;->c:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->R:I

    :cond_1aa
    sget v0, Lq;->aX:I

    if-eq v0, v1, :cond_233

    sget v0, Lg;->R:I

    sget-object v1, Lq;->aY:[I

    sget v2, Lq;->aX:I

    aget v1, v1, v2

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-lt v0, v1, :cond_1d0

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    sget v0, Lg;->R:I

    sget v1, Lg;->S:I

    const/4 v2, 0x2

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_223

    const/4 v0, 0x1

    sput v0, Lg;->V:I

    :cond_1d0
    :goto_1d0
    sget v0, Lg;->ad:I

    sget v1, Lg;->R:I

    sget v2, Lg;->ad:I

    shl-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    sget v2, Lg;->S:I

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    sget v0, Lg;->ao:I

    if-eqz v0, :cond_25f

    sget v0, Lg;->ao:I

    sget v1, Lg;->R:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-ge v0, v1, :cond_b

    const/4 v0, 0x1

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->ao:I

    goto/16 :goto_b

    :cond_1f7
    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    const/16 v3, 0x8

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_192

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lj;->f:I

    add-int/2addr v0, v2

    sget v2, Lg;->Z:I

    add-int/2addr v0, v2

    sput v0, Lg;->R:I

    goto/16 :goto_192

    :cond_223
    const/4 v0, 0x4

    sput v0, Lg;->V:I

    const/4 v0, 0x2

    sput v0, Lg;->U:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->T:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    goto :goto_1d0

    :cond_233
    sget v0, Lg;->R:I

    sget v1, Lg;->ad:I

    sget v2, Lg;->X:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    sget v1, Lg;->S:I

    invoke-static {v0, v1}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1d0

    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_1d0

    sget-boolean v0, Lq;->m:Z

    if-nez v0, :cond_1d0

    const/4 v0, 0x1

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->W:I

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    goto/16 :goto_1d0

    :cond_25f
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_b

    invoke-static {}, Lg;->j()V

    goto/16 :goto_b

    :pswitch_26a  #0x3
    sget v0, Lg;->T:I

    if-nez v0, :cond_274

    sget v0, Lg;->ad:I

    shl-int/lit8 v0, v0, 0x2

    sput v0, Lg;->T:I

    :cond_274
    sget v0, Lg;->ad:I

    if-ne v0, v8, :cond_338

    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    add-int/2addr v0, v2

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v11, :cond_28d

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    :cond_28d
    :goto_28d
    sget v0, Lg;->au:I

    if-gez v0, :cond_297

    const/4 v0, 0x0

    sput v0, Lg;->au:I

    const/4 v0, -0x1

    sput v0, Lg;->aw:I

    :cond_297
    sget v0, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x5

    add-int/2addr v0, v2

    sget v2, Lg;->R:I

    if-le v0, v2, :cond_2a3

    move v1, v8

    :cond_2a3
    sput v1, Lg;->ad:I

    sget v0, Lg;->R:I

    sget v1, Lg;->T:I

    add-int/2addr v0, v1

    sput v0, Lg;->R:I

    if-gez v0, :cond_2b1

    const/4 v0, 0x0

    sput v0, Lg;->R:I

    :cond_2b1
    sget v0, Lg;->R:I

    sget v1, Lj;->c:I

    if-lt v0, v1, :cond_2bd

    sget v0, Lj;->c:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->R:I

    :cond_2bd
    sget v0, Lq;->as:I

    const/16 v1, 0xf

    if-ne v0, v1, :cond_2d7

    sget v0, Lg;->R:I

    sget v1, Lq;->W:I

    mul-int/lit8 v1, v1, 0x18

    if-ge v0, v1, :cond_2d7

    sget v0, Lq;->W:I

    mul-int/lit8 v0, v0, 0x18

    sput v0, Lg;->R:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x14

    sput v0, Lg;->T:I

    :cond_2d7
    sget v0, Lg;->S:I

    sget v1, Lg;->U:I

    add-int/2addr v0, v1

    sput v0, Lg;->S:I

    sget v0, Lg;->ae:I

    if-nez v0, :cond_351

    const/4 v0, 0x7

    sput v0, Lg;->W:I

    :goto_2e5
    sget v0, Lg;->T:I

    if-le v0, v8, :cond_2ef

    sget v0, Lg;->T:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->T:I

    :cond_2ef
    sget v0, Lg;->U:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->U:I

    if-nez v0, :cond_303

    const/4 v0, 0x4

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    const/4 v0, 0x1

    sput v0, Lg;->U:I

    :cond_303
    sget v0, Lg;->ag:I

    if-gez v0, :cond_30d

    sget v0, Lg;->ag:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ag:I

    :cond_30d
    sget v0, Lg;->S:I

    sget v1, Lg;->Y:I

    if-le v0, v1, :cond_b

    sget v0, Lg;->R:I

    sget v1, Lg;->S:I

    sget v2, Lg;->Y:I

    sub-int/2addr v1, v2

    const/16 v2, 0x4000

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_b

    sget v0, Lg;->S:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    sput v0, Lg;->S:I

    const/4 v0, 0x4

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    const/4 v0, 0x1

    sput v0, Lg;->U:I

    goto/16 :goto_b

    :cond_338
    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    sub-int/2addr v0, v2

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v2, 0x8

    if-ne v0, v2, :cond_28d

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    goto/16 :goto_28d

    :cond_351
    const/16 v0, 0x8

    sput v0, Lg;->W:I

    goto :goto_2e5

    :pswitch_356  #0x4
    sget v0, Lq;->as:I

    if-ne v0, v10, :cond_38d

    sget-boolean v0, Lg;->j:Z

    if-eqz v0, :cond_38d

    sget v0, Lg;->au:I

    const/16 v2, 0x288

    if-ge v0, v2, :cond_38d

    sget-boolean v0, Lg;->ap:Z

    if-nez v0, :cond_38d

    sget v0, Lg;->U:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->U:I

    sget v0, Lg;->S:I

    sget v1, Lg;->U:I

    add-int/2addr v0, v1

    sput v0, Lg;->S:I

    sget v1, Lq;->Z:I

    mul-int/lit8 v1, v1, 0x18

    add-int/lit8 v1, v1, 0x28

    if-le v0, v1, :cond_b

    const/4 v0, 0x1

    sput-boolean v0, Lg;->ap:Z

    const/4 v0, 0x0

    sput-boolean v0, Lg;->O:Z

    const/16 v0, 0x18

    invoke-static {v0}, Lq;->g(I)V

    const/4 v0, -0x1

    sput v0, Lg;->Q:I

    goto/16 :goto_b

    :cond_38d
    sget v0, Lg;->ad:I

    if-ne v0, v8, :cond_48b

    sget v0, Lg;->R:I

    sget v2, Lg;->X:I

    add-int/2addr v0, v2

    sget v2, Lg;->S:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v11, :cond_3a3

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    :cond_3a3
    :goto_3a3
    const/4 v0, -0x1

    sput v0, Lg;->bk:I

    sget v0, Lg;->R:I

    sget v2, Lg;->T:I

    add-int/2addr v0, v2

    sput v0, Lg;->R:I

    if-gez v0, :cond_3b2

    const/4 v0, 0x0

    sput v0, Lg;->R:I

    :cond_3b2
    sget v0, Lg;->R:I

    sget v2, Lj;->c:I

    if-lt v0, v2, :cond_3be

    sget v0, Lj;->c:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->R:I

    :cond_3be
    sget v0, Lg;->S:I

    sget v2, Lg;->U:I

    add-int/2addr v0, v2

    sput v0, Lg;->S:I

    sget v0, Lg;->U:I

    const/16 v2, 0x12

    if-ge v0, v2, :cond_3d1

    sget v0, Lg;->U:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->U:I

    :cond_3d1
    sget v0, Lg;->U:I

    if-le v0, v10, :cond_3d8

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    :cond_3d8
    sget v0, Lg;->T:I

    if-le v0, v8, :cond_3e2

    sget v0, Lg;->T:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->T:I

    :cond_3e2
    const/16 v0, 0x8

    sput v0, Lg;->W:I

    sget v0, Lg;->S:I

    sget v2, Lj;->d:I

    if-lt v0, v2, :cond_3f9

    sget v0, Lj;->d:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->S:I

    const/4 v0, 0x3

    sput v0, Lg;->V:I

    const/16 v0, -0xf

    sput v0, Lg;->U:I

    :cond_3f9
    sget v0, Lg;->U:I

    if-le v0, v11, :cond_433

    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    if-ne v0, v2, :cond_433

    const/4 v0, 0x1

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->U:I

    sput v0, Lg;->T:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    sput v0, Lg;->ae:I

    sget v0, Lg;->S:I

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Lg;->S:I

    const/4 v0, -0x1

    sget v2, Lg;->R:I

    add-int/lit8 v2, v2, 0x8

    sget v3, Lg;->S:I

    invoke-static {v0, v2, v3}, Lq;->b(III)Z

    const/4 v0, 0x1

    sget v2, Lg;->R:I

    add-int/lit8 v2, v2, -0x8

    sget v3, Lg;->S:I

    invoke-static {v0, v2, v3}, Lq;->b(III)Z

    :cond_433
    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    const/16 v3, 0x40

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_477

    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    add-int/lit8 v2, v2, 0x18

    const/16 v3, 0x1000

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_477

    sget v0, Lg;->S:I

    sget v2, Lj;->f:I

    rem-int/2addr v0, v2

    const/16 v2, 0x8

    if-le v0, v2, :cond_477

    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x8

    invoke-static {v0, v2}, Lq;->c(II)Z

    const/4 v0, 0x3

    sput v0, Lg;->V:I

    sget v0, Lg;->at:I

    sget v2, Lg;->R:I

    if-le v0, v2, :cond_46d

    move v1, v8

    :cond_46d
    sput v1, Lg;->ad:I

    shl-int/lit8 v0, v1, 0x2

    sput v0, Lg;->T:I

    const/16 v0, -0xb

    sput v0, Lg;->U:I

    :cond_477
    sget v0, Lg;->U:I

    const/4 v1, 0x6

    if-le v0, v1, :cond_47f

    const/4 v0, 0x6

    sput v0, Lg;->W:I

    :cond_47f
    sget v0, Lg;->ag:I

    if-gez v0, :cond_b

    sget v0, Lg;->ag:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ag:I

    goto/16 :goto_b

    :cond_48b
    sget v0, Lg;->R:I

    sget v2, Lg;->X:I

    sub-int/2addr v0, v2

    sget v2, Lg;->S:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v2, 0x8

    if-ne v0, v2, :cond_3a3

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    goto/16 :goto_3a3

    :pswitch_4a1  #0x5
    sget v0, Lg;->ae:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ae:I

    packed-switch v0, :pswitch_data_92a

    :cond_4aa
    :goto_4aa
    sget v0, Lg;->bl:I

    if-ne v0, v8, :cond_b

    const/4 v0, -0x1

    sput v0, Lg;->bk:I

    goto/16 :goto_b

    :pswitch_4b3  #0x1, 0x2, 0x3
    const/4 v0, -0x1

    sput v0, Lg;->bk:I

    const/16 v0, 0x9

    sput v0, Lg;->W:I

    goto :goto_4aa

    :pswitch_4bb  #0x4, 0x5
    const/4 v0, 0x0

    sput v0, Lg;->bk:I

    const/16 v0, 0xa

    sput v0, Lg;->W:I

    goto :goto_4aa

    :pswitch_4c3  #0x6
    const/4 v0, 0x1

    sput v0, Lg;->bk:I

    const/16 v0, 0xb

    sput v0, Lg;->W:I

    sget v0, Lg;->bl:I

    if-ne v0, v8, :cond_4ec

    sget v0, Lg;->ad:I

    shl-int/lit8 v0, v0, 0x3

    sget v1, Lg;->au:I

    sget v2, Lg;->S:I

    sub-int/2addr v1, v2

    shr-int/lit8 v1, v1, 0x3

    sget v2, Lg;->R:I

    sget v3, Lg;->ad:I

    shl-int/lit8 v3, v3, 0x3

    add-int/2addr v2, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0xc

    add-int/lit8 v4, v0, -0x8

    add-int/2addr v1, v4

    const/4 v4, 0x1

    invoke-static {v2, v3, v0, v1, v4}, Lq;->a(IIIIZ)V

    goto :goto_4aa

    :cond_4ec
    sget v0, Lg;->aJ:I

    shl-int/lit8 v9, v0, 0x1

    sget v0, Lg;->ad:I

    if-lez v0, :cond_653

    sget v0, Lg;->R:I

    add-int/lit8 v0, v0, -0x14

    move v3, v0

    :goto_4f9
    sget v0, Lg;->ad:I

    if-lez v0, :cond_65a

    sget v0, Lg;->R:I

    add-int/lit8 v0, v0, 0x3c

    move v2, v0

    :goto_502
    sget v0, Lg;->S:I

    sget v4, Lg;->Y:I

    sub-int/2addr v0, v4

    add-int/lit8 v4, v0, -0xf

    sget v0, Lg;->S:I

    add-int/lit8 v5, v0, 0x5

    move v0, v7

    :goto_50e
    sget v6, La;->c:I

    if-lt v0, v6, :cond_661

    move v3, v1

    :goto_513
    if-eq v3, v1, :cond_583

    sget-object v0, Lo;->a:Lo;

    new-instance v1, Lh;

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    const/4 v5, 0x3

    invoke-direct {v1, v2, v4, v5}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lh;

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    add-int/lit16 v4, v4, -0x82

    const/16 v5, 0xa

    invoke-direct {v1, v2, v4, v5}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->ad:I

    neg-int v0, v0

    const/4 v1, 0x2

    invoke-static {v3, v9, v0, v1}, La;->a(IIII)Z

    sget-object v0, La;->e:[I

    aget v0, v0, v3

    sget-object v1, La;->f:[I

    aget v1, v1, v3

    sget-object v2, La;->g:[I

    aget v2, v2, v3

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    sget v2, Lg;->ad:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v9}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    sget-object v5, La;->g:[I

    aget v3, v5, v3

    sub-int v3, v4, v3

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "mob"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :cond_583
    move v6, v7

    :goto_584
    sget v0, Ln;->c:I

    if-lt v6, v0, :cond_686

    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_5ea

    sget v0, Lg;->S:I

    sget v1, Lq;->aI:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_5ea

    sget v0, Lg;->R:I

    sget v1, Lg;->ad:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lq;->aH:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x28

    if-ge v0, v1, :cond_5ea

    sget v0, Lg;->ad:I

    neg-int v0, v0

    invoke-static {v9, v0}, Lq;->d(II)Z

    move-result v0

    if-nez v0, :cond_5ea

    sget v0, Lg;->R:I

    sget v1, Lq;->aH:I

    sget v2, Lg;->R:I

    sub-int/2addr v1, v2

    shr-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sget v1, Lg;->S:I

    add-int/lit8 v1, v1, -0xc

    sget v2, Lg;->ad:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v9}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    sget v4, Lq;->aJ:I

    sub-int/2addr v3, v4

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "pigBozz"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :cond_5ea
    sget-boolean v0, Lm;->a:Z

    if-eqz v0, :cond_4aa

    sget v0, Lg;->S:I

    sget v1, Lm;->c:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_4aa

    sget v0, Lg;->R:I

    sget v1, Lg;->ad:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lm;->b:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_4aa

    sget v0, Lg;->aJ:I

    div-int/lit8 v0, v0, 0x3

    invoke-static {v0}, Lm;->b(I)Z

    move-result v0

    if-nez v0, :cond_4aa

    sget v0, Lg;->R:I

    sget v1, Lm;->b:I

    sget v2, Lg;->R:I

    sub-int/2addr v1, v2

    shr-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sget v1, Lg;->S:I

    add-int/lit8 v1, v1, -0xc

    sget v2, Lg;->ad:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lg;->aJ:I

    div-int/lit8 v1, v1, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    sget v4, Lm;->d:I

    sub-int/2addr v3, v4

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "shark"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_4aa

    :cond_653
    sget v0, Lg;->R:I

    add-int/lit8 v0, v0, -0x3c

    move v3, v0

    goto/16 :goto_4f9

    :cond_65a
    sget v0, Lg;->R:I

    add-int/lit8 v0, v0, 0x14

    move v2, v0

    goto/16 :goto_502

    :cond_661
    sget-object v6, La;->i:[I

    aget v6, v6, v0

    if-eq v6, v10, :cond_682

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    if-lt v6, v3, :cond_682

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    if-gt v6, v2, :cond_682

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    if-lt v6, v4, :cond_682

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    if-gt v6, v5, :cond_682

    move v3, v0

    goto/16 :goto_513

    :cond_682
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_50e

    :cond_686
    sget v0, Lg;->S:I

    sget-object v1, Ln;->f:[I

    aget v1, v1, v6

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0xc

    if-gt v0, v1, :cond_70d

    sget v0, Lg;->R:I

    sget v1, Lg;->ad:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget-object v1, Ln;->e:[I

    aget v1, v1, v6

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x18

    if-ge v0, v1, :cond_70d

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lh;

    sget-object v2, Ln;->e:[I

    aget v2, v2, v6

    sget-object v3, Ln;->f:[I

    aget v3, v3, v6

    const/4 v4, 0x3

    invoke-direct {v1, v2, v3, v4}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lh;

    sget-object v2, Ln;->e:[I

    aget v2, v2, v6

    sget-object v3, Ln;->f:[I

    aget v3, v3, v6

    add-int/lit16 v3, v3, -0x82

    const/16 v4, 0xa

    invoke-direct {v1, v2, v3, v4}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->ad:I

    neg-int v0, v0

    invoke-static {v6, v9, v0}, Ln;->a(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v9}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v6

    sget-object v3, Ln;->f:[I

    aget v3, v3, v6

    add-int/lit8 v3, v3, -0x1c

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v6

    sget-object v1, Ln;->f:[I

    aget v1, v1, v6

    add-int/lit8 v1, v1, -0xf

    sget v2, Lg;->ad:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "nj"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :cond_70d
    add-int/lit8 v0, v6, 0x1

    move v6, v0

    goto/16 :goto_584

    :pswitch_712  #0x7
    const/4 v0, 0x2

    sput v0, Lg;->bk:I

    const/16 v0, 0xb

    sput v0, Lg;->W:I

    goto/16 :goto_4aa

    :pswitch_71b  #0x8
    const/4 v0, -0x1

    sput v0, Lg;->bk:I

    const/16 v0, 0xc

    sput v0, Lg;->W:I

    goto/16 :goto_4aa

    :pswitch_724  #0x9
    const/4 v0, -0x1

    sput v0, Lg;->bk:I

    const/16 v0, 0x9

    sput v0, Lg;->W:I

    const/4 v0, 0x1

    sput v0, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    goto/16 :goto_4aa

    :pswitch_736  #0x7
    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    add-int/2addr v0, v2

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v11, :cond_74d

    sget v0, Lg;->T:I

    neg-int v0, v0

    sput v0, Lg;->T:I

    :cond_74d
    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    sub-int/2addr v0, v2

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v2, 0x8

    if-ne v0, v2, :cond_766

    sget v0, Lg;->T:I

    neg-int v0, v0

    sput v0, Lg;->T:I

    :cond_766
    sget v0, Lg;->R:I

    sget v2, Lg;->T:I

    add-int/2addr v0, v2

    sput v0, Lg;->R:I

    sget v0, Lg;->S:I

    sget v2, Lg;->U:I

    add-int/2addr v0, v2

    sput v0, Lg;->S:I

    const/4 v0, 0x7

    sput v0, Lg;->W:I

    sget v0, Lg;->T:I

    if-le v0, v8, :cond_781

    sget v0, Lg;->T:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->T:I

    :cond_781
    sget v0, Lg;->T:I

    if-ge v0, v1, :cond_78b

    sget v0, Lg;->T:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->T:I

    :cond_78b
    sget v0, Lg;->U:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->U:I

    if-lez v0, :cond_796

    const/4 v0, 0x0

    sput v0, Lg;->U:I

    :cond_796
    sget v0, Lg;->ae:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ae:I

    const/4 v1, 0x7

    if-lt v0, v1, :cond_b

    const/4 v0, 0x4

    sput v0, Lg;->V:I

    const/16 v0, -0x14

    sput v0, Lg;->ag:I

    const/4 v0, 0x0

    sput v0, Lg;->af:I

    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    const/4 v0, 0x1

    sput v0, Lg;->U:I

    goto/16 :goto_b

    :pswitch_7b1  #0x13
    sget v0, Lg;->aF:I

    sput v0, Lg;->ad:I

    sget v0, Lg;->aG:I

    sput v0, Lg;->ae:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v1, 0x3

    if-le v0, v1, :cond_7ed

    const/16 v0, 0xe

    sput v0, Lg;->W:I

    :goto_7c4
    sget v0, Lg;->ae:I

    if-lez v0, :cond_7d2

    sget v0, Lg;->ae:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->ae:I

    const/16 v0, 0x10

    sput v0, Lg;->W:I

    :cond_7d2
    sget v0, Lg;->at:I

    sget v1, Lg;->aF:I

    mul-int/lit8 v1, v1, 0xf

    sub-int/2addr v0, v1

    sput v0, Lg;->R:I

    sget v0, Lg;->au:I

    sput v0, Lg;->S:I

    sget v0, Lg;->av:I

    sput v0, Lg;->T:I

    sget v0, Lg;->aw:I

    sput v0, Lg;->U:I

    sget v0, Lg;->ax:I

    sput v0, Lg;->V:I

    goto/16 :goto_b

    :cond_7ed
    const/16 v0, 0xf

    sput v0, Lg;->W:I

    sget v0, Lg;->ad:I

    sget v1, Lg;->R:I

    sget v2, Lg;->ad:I

    shl-int/lit8 v2, v2, 0x4

    sub-int/2addr v1, v2

    sget v2, Lg;->S:I

    add-int/lit8 v2, v2, -0x5

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    goto :goto_7c4

    :pswitch_802  #0x12
    sget v0, Lg;->aF:I

    sput v0, Lg;->ad:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v1, 0x3

    if-le v0, v1, :cond_816

    const/16 v0, 0xe

    sput v0, Lg;->W:I

    :goto_811
    const/4 v0, 0x0

    sput v0, Lg;->ae:I

    goto/16 :goto_b

    :cond_816
    const/16 v0, 0xf

    sput v0, Lg;->W:I

    sget v0, Lg;->aF:I

    sget v1, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x4

    sub-int/2addr v1, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0x5

    invoke-static {v0, v1, v2}, Lq;->b(III)Z
    :try_end_82a
    .catch Ljava/lang/Exception; {:try_start_95 .. :try_end_82a} :catch_83

    goto :goto_811

    :pswitch_82b  #0x14
    :try_start_82b
    sget v0, Lg;->aF:I

    sput v0, Lg;->ad:I

    sget v0, Lg;->at:I

    sget v1, Lg;->aF:I

    mul-int/lit8 v1, v1, 0xf

    sub-int/2addr v0, v1

    sput v0, Lg;->R:I

    sget v0, Lg;->au:I

    sput v0, Lg;->S:I

    sget v0, Lg;->av:I

    sput v0, Lg;->T:I

    sget v0, Lg;->aw:I

    sput v0, Lg;->U:I

    sget v0, Lg;->aG:I

    sput v0, Lg;->ae:I

    sget v0, Lg;->aI:I

    sput v0, Lg;->ag:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v1, 0x3

    if-le v0, v1, :cond_889

    const/16 v0, 0xe

    sput v0, Lg;->W:I

    :goto_857
    sget v0, Lg;->ax:I

    sput v0, Lg;->V:I

    sget v0, Lg;->R:I

    sget v1, Lg;->S:I

    const/16 v2, 0x40

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_87d

    sget v0, Lg;->S:I

    sget v1, Lj;->f:I

    rem-int/2addr v0, v1

    const/16 v1, 0x8

    if-le v0, v1, :cond_87d

    sget v0, Lg;->R:I

    sget v1, Lg;->S:I

    invoke-static {v1}, Lj;->d(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x8

    invoke-static {v0, v1}, Lq;->c(II)Z
    :try_end_87d
    .catch Ljava/lang/Exception; {:try_start_82b .. :try_end_87d} :catch_89e

    :cond_87d
    :goto_87d
    :try_start_87d
    sget v0, Lg;->ag:I

    if-gez v0, :cond_b

    sget v0, Lg;->ag:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ag:I
    :try_end_887
    .catch Ljava/lang/Exception; {:try_start_87d .. :try_end_887} :catch_83

    goto/16 :goto_b

    :cond_889
    const/16 v0, 0xf

    :try_start_88b
    sput v0, Lg;->W:I

    sget v0, Lg;->ad:I

    sget v1, Lg;->R:I

    sget v2, Lg;->ad:I

    shl-int/lit8 v2, v2, 0x4

    sub-int/2addr v1, v2

    sget v2, Lg;->S:I

    add-int/lit8 v2, v2, -0x5

    invoke-static {v0, v1, v2}, Lq;->b(III)Z
    :try_end_89d
    .catch Ljava/lang/Exception; {:try_start_88b .. :try_end_89d} :catch_89e

    goto :goto_857

    :catch_89e
    move-exception v0

    goto :goto_87d

    :pswitch_8a0  #0x15
    :try_start_8a0
    sget v0, Lg;->aF:I

    sput v0, Lg;->ad:I

    sget v0, Lg;->at:I

    sget v1, Lg;->aF:I

    mul-int/lit8 v1, v1, 0xf

    sub-int/2addr v0, v1

    sput v0, Lg;->R:I

    sget v0, Lg;->au:I

    sput v0, Lg;->S:I

    sget v0, Lg;->av:I

    sput v0, Lg;->T:I

    sget v0, Lg;->aw:I

    sput v0, Lg;->U:I

    sget v0, Lg;->ax:I

    sput v0, Lg;->V:I

    sget v0, Lg;->aG:I

    sput v0, Lg;->ae:I

    sget v0, Lg;->ag:I

    if-gez v0, :cond_8cb

    sget v0, Lg;->ag:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->ag:I

    :cond_8cb
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v1, 0x3

    if-le v0, v1, :cond_8e6

    const/16 v0, 0xe

    sput v0, Lg;->W:I

    :goto_8d6
    sget v0, Lg;->ae:I

    if-lez v0, :cond_b

    sget v0, Lg;->ae:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->ae:I

    const/16 v0, 0x10

    sput v0, Lg;->W:I

    goto/16 :goto_b

    :cond_8e6
    const/16 v0, 0xf

    sput v0, Lg;->W:I

    sget v0, Lg;->ad:I

    sget v1, Lg;->R:I

    sget v2, Lg;->ad:I

    shl-int/lit8 v2, v2, 0x4

    sub-int/2addr v1, v2

    sget v2, Lg;->S:I

    add-int/lit8 v2, v2, -0x5

    invoke-static {v0, v1, v2}, Lq;->b(III)Z
    :try_end_8fa
    .catch Ljava/lang/Exception; {:try_start_8a0 .. :try_end_8fa} :catch_83

    goto :goto_8d6

    nop

    :pswitch_data_8fc
    .packed-switch 0x1
        :pswitch_12  #00000001
        :pswitch_157  #00000002
        :pswitch_26a  #00000003
        :pswitch_356  #00000004
        :pswitch_4a1  #00000005
        :pswitch_11  #00000006
        :pswitch_736  #00000007
        :pswitch_11  #00000008
        :pswitch_11  #00000009
        :pswitch_11  #0000000a
        :pswitch_11  #0000000b
        :pswitch_11  #0000000c
        :pswitch_11  #0000000d
        :pswitch_11  #0000000e
        :pswitch_11  #0000000f
        :pswitch_11  #00000010
        :pswitch_11  #00000011
        :pswitch_802  #00000012
        :pswitch_7b1  #00000013
        :pswitch_82b  #00000014
        :pswitch_8a0  #00000015
    .end packed-switch

    :pswitch_data_92a
    .packed-switch 0x1
        :pswitch_4b3  #00000001
        :pswitch_4b3  #00000002
        :pswitch_4b3  #00000003
        :pswitch_4bb  #00000004
        :pswitch_4bb  #00000005
        :pswitch_4c3  #00000006
        :pswitch_712  #00000007
        :pswitch_71b  #00000008
        :pswitch_724  #00000009
    .end packed-switch
.end method

.method public static a(I)V
    .registers 14

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v0, 0x0

    sput v0, Lg;->F:I

    new-array v1, v0, [Z

    sput-object v1, Lg;->I:[Z

    if-nez p0, :cond_7c

    sget-boolean v1, Lq;->f:Z

    if-eqz v1, :cond_1de

    const/4 v1, 0x5

    sput v1, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0xf

    const/16 v3, 0x11

    const/16 v4, 0x82

    const/16 v5, 0xb

    const/16 v6, 0x16

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v7, v1, v0

    move v1, v0

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0xf

    const/16 v4, 0x11

    const/16 v5, 0xa0

    const/16 v6, 0xf

    const/16 v7, 0x1e

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v9

    move v1, v9

    move v2, v9

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v3, 0x10

    const/16 v4, 0x11

    const/16 v5, 0xc8

    const/16 v7, 0x1d

    sget-object v6, Ll;->f:[[Ljava/lang/String;

    const/4 v8, 0x2

    aget-object v8, v6, v8

    move v6, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x10

    const/16 v4, 0x11

    const/16 v5, 0x64

    const/16 v7, 0x1d

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v12

    move v1, v12

    move v2, v12

    move v6, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0xe

    const/16 v4, 0xc

    const/16 v5, 0x64

    const/16 v6, 0x24

    const/16 v7, 0x29

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v10

    move v1, v10

    move v2, v10

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    invoke-static {v11}, Lg;->e(I)V

    move v1, v0

    :goto_78
    sget v2, Lg;->F:I

    if-lt v1, v2, :cond_1d6

    :cond_7c
    :goto_7c
    const/16 v1, 0x69

    if-ne p0, v1, :cond_99

    sput v9, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0x25

    const/16 v3, 0xa

    const/4 v4, 0x2

    const/16 v6, 0x26

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    const/4 v5, 0x5

    aget-object v7, v1, v5

    move v1, v10

    move v5, v9

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    invoke-static {v11}, Lg;->e(I)V

    :cond_99
    const/16 v1, 0x63

    if-ne p0, v1, :cond_f8

    const/4 v1, 0x5

    sput v1, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0x30

    const/16 v3, 0xb

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v7, v1, v0

    move v1, v0

    move v4, v0

    move v5, v0

    move v6, v0

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x31

    const/16 v4, 0xb

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v9

    move v1, v9

    move v2, v9

    move v5, v0

    move v6, v0

    move v7, v0

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v3, 0x32

    const/16 v4, 0xb

    sget-object v5, Ll;->f:[[Ljava/lang/String;

    const/4 v6, 0x2

    aget-object v8, v5, v6

    move v5, v0

    move v6, v0

    move v7, v0

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x30

    const/16 v4, 0xb

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v12

    move v1, v12

    move v2, v12

    move v5, v0

    move v6, v0

    move v7, v0

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x31

    const/16 v4, 0xb

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v10

    move v1, v10

    move v2, v10

    move v5, v0

    move v6, v0

    move v7, v0

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    sput-boolean v9, Lg;->H:Z

    invoke-static {v11}, Lg;->e(I)V

    :cond_f8
    if-ne p0, v10, :cond_176

    const/4 v1, 0x5

    sput v1, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0x32

    const/16 v3, 0xa

    const/16 v4, 0x82

    const/16 v5, 0x2d

    const/16 v6, 0x33

    sget-object v1, Ll;->i:[[Ljava/lang/String;

    aget-object v7, v1, v0

    move v1, v0

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x2a

    const/16 v4, 0xa

    const/16 v5, 0x6b

    const/16 v6, 0x28

    const/16 v7, 0x33

    sget-object v1, Ll;->i:[[Ljava/lang/String;

    aget-object v8, v1, v9

    move v1, v9

    move v2, v9

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v1, 0x2

    const/16 v3, 0x2d

    const/4 v4, 0x6

    const/16 v5, 0x64

    const/16 v6, 0x2b

    const/16 v7, 0x32

    sget-object v2, Ll;->i:[[Ljava/lang/String;

    aget-object v8, v2, v12

    move v2, v12

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x1d

    const/16 v4, 0x9

    const/16 v5, 0x6e

    const/16 v6, 0x1a

    const/16 v7, 0x1d

    sget-object v1, Ll;->i:[[Ljava/lang/String;

    aget-object v8, v1, v10

    move v1, v12

    move v2, v10

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v2, 0x2

    const/16 v3, 0x2f

    const/16 v5, 0x5a

    const/16 v6, 0x2b

    const/16 v7, 0x32

    sget-object v1, Ll;->i:[[Ljava/lang/String;

    const/4 v4, 0x2

    aget-object v8, v1, v4

    move v1, v10

    move v4, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    invoke-static {v11}, Lg;->e(I)V

    if-ne p0, v10, :cond_176

    sget-object v1, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_176

    const/4 v1, 0x7

    :try_start_167
    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    move v1, v9

    :goto_16c
    if-lt v1, v11, :cond_2b8

    const/4 v1, 0x7

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cm:[Ljavax/microedition/lcdui/Image;
    :try_end_173
    .catch Ljava/lang/Exception; {:try_start_167 .. :try_end_173} :catch_2fa

    move v1, v9

    :goto_174
    if-lt v1, v11, :cond_2d9

    :cond_176
    :goto_176
    sget-boolean v1, Lg;->C:Z

    if-eqz v1, :cond_1d5

    const/16 v1, 0x9

    if-ne p0, v1, :cond_1d5

    sput v10, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0x5b

    const/16 v3, 0xf

    const/16 v4, 0x82

    const/16 v5, 0x56

    const/16 v6, 0x5d

    sget-object v1, Ll;->j:[[Ljava/lang/String;

    aget-object v7, v1, v0

    move v1, v0

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v2, 0x53

    const/16 v3, 0xf

    const/16 v4, 0x6b

    const/16 v5, 0x4e

    const/16 v6, 0x56

    sget-object v0, Ll;->j:[[Ljava/lang/String;

    aget-object v7, v0, v9

    move v0, v9

    move v1, v9

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/16 v2, 0x4d

    const/16 v3, 0xa

    const/16 v4, 0x64

    const/16 v5, 0x47

    const/16 v6, 0x50

    sget-object v7, Ll;->j:[[Ljava/lang/String;

    const/4 v8, 0x2

    aget-object v7, v7, v8

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v2, 0x57

    const/16 v3, 0xa

    const/16 v4, 0x6e

    const/16 v5, 0x53

    const/16 v6, 0x5b

    sget-object v0, Ll;->j:[[Ljava/lang/String;

    aget-object v7, v0, v12

    move v0, v12

    move v1, v12

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    invoke-static {v10}, Lg;->e(I)V

    invoke-static {p0}, Lg;->f(I)V

    :cond_1d5
    return-void

    :cond_1d6
    sget-object v2, Lg;->M:[I

    aput v9, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_78

    :cond_1de
    sget-boolean v1, Lq;->g:Z

    if-eqz v1, :cond_250

    const/4 v1, 0x5

    sput v1, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0x14

    const/16 v3, 0x11

    const/16 v4, 0x82

    const/16 v5, 0xb

    const/16 v6, 0x16

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    const/4 v7, 0x6

    aget-object v7, v1, v7

    move v1, v0

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x18

    const/16 v4, 0x11

    const/16 v5, 0xa0

    const/16 v6, 0xf

    const/16 v7, 0x1e

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v11

    move v1, v9

    move v2, v9

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v3, 0x11

    const/16 v4, 0xc

    const/16 v5, 0xc8

    const/16 v7, 0x1d

    sget-object v6, Ll;->f:[[Ljava/lang/String;

    const/16 v8, 0x8

    aget-object v8, v6, v8

    move v6, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x17

    const/16 v4, 0x8

    const/16 v5, 0x64

    const/16 v7, 0x1d

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    const/16 v2, 0x9

    aget-object v8, v1, v2

    move v1, v12

    move v2, v12

    move v6, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x25

    const/16 v4, 0x10

    const/16 v5, 0x64

    const/16 v6, 0x24

    const/16 v7, 0x29

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    const/16 v2, 0xa

    aget-object v8, v1, v2

    move v1, v10

    move v2, v10

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    invoke-static {v11}, Lg;->e(I)V

    goto/16 :goto_7c

    :cond_250
    const/4 v1, 0x5

    sput v1, Lg;->F:I

    invoke-static {}, Lg;->o()V

    const/16 v2, 0xe

    const/16 v3, 0x11

    const/16 v4, 0x82

    const/16 v5, 0xb

    const/16 v6, 0x16

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v7, v1, v0

    move v1, v0

    invoke-static/range {v0 .. v7}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x18

    const/16 v4, 0x11

    const/16 v5, 0xa0

    const/16 v6, 0xf

    const/16 v7, 0x1e

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v9

    move v1, v9

    move v2, v9

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v3, 0x11

    const/16 v4, 0xc

    const/16 v5, 0xc8

    const/16 v7, 0x1d

    sget-object v6, Ll;->f:[[Ljava/lang/String;

    const/4 v8, 0x2

    aget-object v8, v6, v8

    move v6, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x17

    const/16 v4, 0x8

    const/16 v5, 0x64

    const/16 v7, 0x1d

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v12

    move v1, v12

    move v2, v12

    move v6, v11

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    const/16 v3, 0x25

    const/16 v4, 0x10

    const/16 v5, 0x64

    const/16 v6, 0x24

    const/16 v7, 0x25

    sget-object v1, Ll;->f:[[Ljava/lang/String;

    aget-object v8, v1, v10

    move v1, v10

    move v2, v10

    invoke-static/range {v1 .. v8}, Lg;->a(IIIIIII[Ljava/lang/String;)V

    invoke-static {v11}, Lg;->e(I)V

    goto/16 :goto_7c

    :cond_2b8
    :try_start_2b8
    sget-object v2, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/db"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_16c

    :cond_2d9
    sget-object v2, Lg;->cm:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/dl"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1
    :try_end_2f6
    .catch Ljava/lang/Exception; {:try_start_2b8 .. :try_end_2f6} :catch_2fa

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_174

    :catch_2fa
    move-exception v1

    goto/16 :goto_176
.end method

.method public static final a(II)V
    .registers 8

    const/4 v2, -0x1

    const/4 v1, 0x0

    sget v0, Lg;->aL:I

    sub-int/2addr v0, p0

    sput v0, Lg;->aL:I

    sput v2, Lg;->aq:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    sput v2, Lq;->aX:I

    sget v0, Lg;->aL:I

    if-gtz v0, :cond_48

    sput v1, Lg;->aL:I

    const/4 v0, -0x7

    sput v0, Lg;->aw:I

    shl-int/lit8 v0, p1, 0x2

    sput v0, Lg;->av:I

    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    sput v2, Lq;->aQ:I

    :cond_20
    :goto_20
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    neg-int v3, v3

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lg;->at:I

    sget v3, Lg;->au:I

    sget v4, Lg;->aA:I

    sub-int/2addr v3, v4

    const/4 v5, -0x2

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    return-void

    :cond_48
    sget v0, Lq;->aQ:I

    if-ne v0, v2, :cond_20

    sget v0, Lg;->ax:I

    const/16 v2, 0x17

    if-eq v0, v2, :cond_20

    shl-int/lit8 v0, p1, 0x2

    sput v0, Lg;->av:I

    const/4 v0, -0x3

    sput v0, Lg;->aw:I

    sput v1, Lg;->aG:I

    sput v1, Lg;->aH:I

    const/4 v0, 0x7

    sput v0, Lg;->ax:I

    goto :goto_20
.end method

.method private static a(IIIIIII[Ljava/lang/String;)V
    .registers 13

    const/4 v4, -0x1

    const/4 v3, 0x0

    sget-object v0, Lg;->K:[I

    mul-int/lit8 v1, p2, 0x18

    shl-int/lit8 v2, p0, 0x2

    add-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, Lg;->L:[I

    mul-int/lit8 v1, p3, 0x18

    aput v1, v0, p0

    sget-object v0, Lg;->bR:[I

    aput v3, v0, p0

    sget-object v0, Lg;->bS:[I

    aput v3, v0, p0

    sget-object v0, Lg;->bT:[I

    const/4 v1, 0x1

    aput v1, v0, p0

    sget-object v0, Lg;->M:[I

    aput v4, v0, p0

    sget-object v0, Lg;->bU:[I

    aput v3, v0, p0

    sget-object v0, Lg;->bV:[I

    add-int/lit8 v1, p0, 0x1

    mul-int/lit8 v1, v1, 0x14

    add-int/2addr v1, p0

    aput v1, v0, p0

    sget-object v0, Lg;->bW:[I

    aput v3, v0, p0

    sget-object v0, Lg;->bX:[I

    aput p1, v0, p0

    sget-object v0, Lg;->bY:[I

    aput v4, v0, p0

    sget-object v0, Lg;->ca:[I

    aput v4, v0, p0

    sget-object v0, Lg;->cb:[I

    mul-int/lit8 v1, p5, 0x18

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Lg;->cc:[I

    mul-int/lit8 v1, p6, 0x18

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Lg;->bZ:[I

    aput p4, v0, p0

    sget-object v0, Lg;->G:[[Ljava/lang/String;

    aput-object p7, v0, p0

    return-void
.end method

.method public static final a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, -0x1

    const/16 v9, 0x18

    const/4 v10, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    sget v0, Lg;->Q:I

    sget v1, Lq;->as:I

    if-eq v0, v1, :cond_d

    :cond_c
    :goto_c
    return-void

    :cond_d
    sget v0, Lg;->ad:I

    if-ne v0, v10, :cond_b3

    sget-object v0, Lg;->cf:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bN:[[[I

    sget v3, Lg;->W:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->R:I

    sget-object v3, Lg;->bN:[[[I

    sget v4, Lg;->W:I

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->S:I

    sget-object v4, Lg;->bN:[[[I

    sget v5, Lg;->W:I

    aget-object v4, v4, v5

    aget-object v4, v4, v2

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cg:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bN:[[[I

    sget v3, Lg;->W:I

    aget-object v1, v1, v3

    aget-object v1, v1, v10

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->R:I

    sget-object v3, Lg;->bN:[[[I

    sget v4, Lg;->W:I

    aget-object v3, v3, v4

    aget-object v3, v3, v10

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->S:I

    sget-object v4, Lg;->bN:[[[I

    sget v5, Lg;->W:I

    aget-object v4, v4, v5

    aget-object v4, v4, v10

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bN:[[[I

    sget v3, Lg;->W:I

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->R:I

    sget-object v3, Lg;->bN:[[[I

    sget v4, Lg;->W:I

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->S:I

    sget-object v4, Lg;->bN:[[[I

    sget v5, Lg;->W:I

    aget-object v4, v4, v5

    aget-object v4, v4, v6

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget v0, Lg;->bk:I

    if-eq v0, v11, :cond_c

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->bk:I

    aget-object v0, v0, v1

    sget v1, Lg;->R:I

    sget-object v3, Lg;->bO:[I

    sget v4, Lg;->bk:I

    aget v3, v3, v4

    sub-int/2addr v1, v3

    sget v3, Lg;->S:I

    sget-object v4, Lg;->bP:[I

    sget v5, Lg;->bk:I

    aget v4, v4, v5

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_c

    :cond_b3
    sget-object v0, Lg;->cf:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bN:[[[I

    sget v3, Lg;->W:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cf:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bN:[[[I

    sget v4, Lg;->W:I

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cf:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bN:[[[I

    sget v5, Lg;->W:I

    aget-object v3, v3, v5

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->R:I

    sget-object v3, Lg;->bN:[[[I

    sget v7, Lg;->W:I

    aget-object v3, v3, v7

    aget-object v3, v3, v2

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->S:I

    sget-object v3, Lg;->bN:[[[I

    sget v8, Lg;->W:I

    aget-object v3, v3, v8

    aget-object v3, v3, v2

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cg:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bN:[[[I

    sget v3, Lg;->W:I

    aget-object v1, v1, v3

    aget-object v1, v1, v10

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cg:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bN:[[[I

    sget v4, Lg;->W:I

    aget-object v3, v3, v4

    aget-object v3, v3, v10

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cg:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bN:[[[I

    sget v5, Lg;->W:I

    aget-object v3, v3, v5

    aget-object v3, v3, v10

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->R:I

    sget-object v3, Lg;->bN:[[[I

    sget v7, Lg;->W:I

    aget-object v3, v3, v7

    aget-object v3, v3, v10

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->S:I

    sget-object v3, Lg;->bN:[[[I

    sget v8, Lg;->W:I

    aget-object v3, v3, v8

    aget-object v3, v3, v10

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bN:[[[I

    sget v3, Lg;->W:I

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bN:[[[I

    sget v4, Lg;->W:I

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bN:[[[I

    sget v5, Lg;->W:I

    aget-object v3, v3, v5

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->R:I

    sget-object v3, Lg;->bN:[[[I

    sget v7, Lg;->W:I

    aget-object v3, v3, v7

    aget-object v3, v3, v6

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->S:I

    sget-object v3, Lg;->bN:[[[I

    sget v8, Lg;->W:I

    aget-object v3, v3, v8

    aget-object v3, v3, v6

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget v0, Lg;->bk:I

    if-eq v0, v11, :cond_c

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->bk:I

    aget-object v1, v0, v1

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v3, Lg;->bk:I

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v3, Lg;->bk:I

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->R:I

    sget-object v3, Lg;->bO:[I

    sget v7, Lg;->bk:I

    aget v3, v3, v7

    add-int v7, v0, v3

    sget v0, Lg;->S:I

    sget-object v3, Lg;->bP:[I

    sget v8, Lg;->bk:I

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_c
.end method

.method public static final b()V
    .registers 10

    const/4 v5, 0x4

    const/4 v2, 0x2

    const/4 v9, -0x1

    const/4 v6, 0x1

    const/4 v1, 0x0

    sget-boolean v0, Lg;->aY:Z

    if-eqz v0, :cond_1d

    sget v0, Lg;->at:I

    sget v3, Lq;->ad:I

    sub-int/2addr v0, v3

    sget v3, Lq;->ag:I

    sget v4, Lg;->aF:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sput v0, Lq;->aw:I

    sget v0, Lg;->au:I

    sget v3, Lq;->af:I

    sub-int/2addr v0, v3

    sput v0, Lq;->ax:I

    :cond_1d
    sget v0, Lg;->aN:I

    sget v3, Lg;->aO:I

    if-ge v0, v3, :cond_5f

    sget v0, Lg;->ax:I

    if-ne v0, v6, :cond_5f

    sget v0, Lg;->bM:I

    const/16 v3, 0x32

    if-ge v0, v3, :cond_51

    sget v0, Lg;->bM:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bM:I

    :cond_33
    :goto_33
    sget v0, Lg;->ax:I

    packed-switch v0, :pswitch_data_e84

    :cond_38
    :goto_38
    :pswitch_38  #0x9, 0xa, 0xd, 0xe, 0xf, 0x10, 0x11, 0x16
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x3

    if-nez v0, :cond_50

    sget-boolean v0, Lg;->ba:Z

    if-eqz v0, :cond_50

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x5

    sput v0, Lg;->aN:I

    if-gtz v0, :cond_4e

    sput v1, Lg;->aN:I

    sput-boolean v1, Lg;->ba:Z

    :cond_4e
    sput-boolean v6, Lq;->J:Z

    :cond_50
    return-void

    :cond_51
    sget v0, Lg;->bM:I

    const/16 v3, 0x32

    if-ne v0, v3, :cond_33

    sput-boolean v6, Lq;->J:Z

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aN:I

    :cond_5f
    sput v1, Lg;->bM:I

    goto :goto_33

    :pswitch_62  #0x1
    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    const/16 v2, 0x1e

    if-le v0, v2, :cond_6e

    sput v1, Lg;->aG:I

    :cond_6e
    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0xf

    const/4 v2, 0x5

    if-ge v0, v2, :cond_d7

    sput v1, Lg;->ay:I

    :goto_77
    invoke-static {}, Lg;->l()V

    move v0, v1

    :goto_7b
    sget v2, Lg;->F:I

    if-lt v0, v2, :cond_da

    :goto_7f
    sget v0, Lg;->Q:I

    sget v2, Lq;->as:I

    if-ne v0, v2, :cond_ae

    sget v0, Lg;->V:I

    if-ne v0, v6, :cond_ae

    sget v0, Lg;->au:I

    sget v2, Lg;->S:I

    if-ne v0, v2, :cond_ae

    sget v0, Lg;->at:I

    sget v2, Lg;->R:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x1e

    if-ge v0, v2, :cond_ae

    sget-object v0, Lq;->V:Ljava/lang/String;

    const-string v2, ""

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ae

    const-string v0, "Nói chuyện"

    sput-object v0, Lq;->V:Ljava/lang/String;

    sput-boolean v6, Lq;->J:Z

    sput-boolean v6, Lg;->bg:Z

    :cond_ae
    move v0, v1

    :goto_af
    sget v2, Lc;->c:I

    if-lt v0, v2, :cond_113

    :goto_b3
    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    sget-object v0, Lp;->b:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    sget v4, Lg;->ay:I

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->e:[I

    sget v2, Lp;->g:I

    aput v6, v0, v2

    goto/16 :goto_38

    :cond_d7
    sput v6, Lg;->ay:I

    goto :goto_77

    :cond_da
    sget-object v2, Lg;->bT:[I

    aget v2, v2, v0

    if-ne v2, v6, :cond_10f

    sget v2, Lg;->au:I

    sget-object v3, Lg;->L:[I

    aget v3, v3, v0

    if-ne v2, v3, :cond_10f

    sget v2, Lg;->at:I

    sget-object v3, Lg;->K:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x1e

    if-ge v2, v3, :cond_10f

    sget v2, Lg;->bj:I

    if-ne v2, v9, :cond_10f

    sget-object v2, Lq;->V:Ljava/lang/String;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_10f

    sput-boolean v6, Lq;->J:Z

    const-string v2, "Trò chuyện"

    sput-object v2, Lq;->V:Ljava/lang/String;

    sput v0, Lg;->bj:I

    goto/16 :goto_7f

    :cond_10f
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_7b

    :cond_113
    sget v2, Lg;->au:I

    sget-object v3, Lc;->e:[I

    aget v3, v3, v0

    if-ne v2, v3, :cond_138

    sget v2, Lg;->at:I

    sget-object v3, Lc;->d:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x1e

    if-ge v2, v3, :cond_138

    sget v2, Lg;->bi:I

    if-ne v2, v9, :cond_138

    const-string v2, "Giao tiếp"

    sput-object v2, Lq;->V:Ljava/lang/String;

    sput-boolean v6, Lq;->J:Z

    sput v0, Lg;->bi:I

    goto/16 :goto_b3

    :cond_138
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_af

    :pswitch_13c  #0x2
    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    const/16 v3, 0xa

    if-lt v0, v3, :cond_14a

    sput v1, Lg;->aG:I

    sput v1, Lg;->aR:I

    :cond_14a
    sget v0, Lg;->aG:I

    shr-int/lit8 v0, v0, 0x1

    add-int/lit8 v0, v0, 0x2

    sput v0, Lg;->ay:I

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_21b

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3, v5}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_176

    sput v1, Lg;->av:I

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    sput v0, Lg;->at:I

    :cond_176
    :goto_176
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x1

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x40

    const/16 v3, 0x40

    if-ne v0, v3, :cond_246

    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    shr-int/lit8 v3, v3, 0x1

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    :goto_18f
    sget v0, Lg;->av:I

    if-lez v0, :cond_24f

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :goto_199
    sget v0, Lq;->aX:I

    if-eq v0, v9, :cond_26f

    sget v0, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    sget v4, Lq;->aX:I

    aget v3, v3, v4

    sub-int/2addr v0, v3

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v3, 0x14

    if-lt v0, v3, :cond_1bc

    sput v9, Lq;->aX:I

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_261

    sput v6, Lg;->ax:I

    :cond_1bc
    :goto_1bc
    invoke-static {}, Lg;->s()V

    sget v0, Lg;->aF:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    sget v4, Lg;->au:I

    invoke-static {v0, v3, v4}, Lq;->b(III)Z

    invoke-static {}, Lg;->l()V

    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_1ff

    const/4 v0, 0x3

    sput v0, Lq;->aC:I

    sget-object v0, Lp;->d:[I

    sget v3, Lp;->g:I

    sget v4, Lg;->aF:I

    aput v4, v0, v3

    sget-object v0, Lp;->b:[I

    sget v3, Lp;->g:I

    sget v4, Lg;->at:I

    sget v5, Lg;->aF:I

    shl-int/lit8 v5, v5, 0x3

    sub-int/2addr v4, v5

    aput v4, v0, v3

    sget-object v0, Lp;->c:[I

    sget v3, Lp;->g:I

    sget v4, Lg;->au:I

    sget v5, Lg;->aG:I

    rem-int/lit8 v5, v5, 0x3

    add-int/2addr v4, v5

    aput v4, v0, v3

    sget-object v0, Lp;->e:[I

    sget v3, Lp;->g:I

    aput v2, v0, v3

    :cond_1ff
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v2, Ljava/lang/StringBuffer;

    sget v3, Lg;->av:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v3, ">>>>>>>>>>."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_38

    :cond_21b
    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    add-int/lit8 v0, v0, -0x1

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    const/16 v4, 0x8

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_176

    sput v1, Lg;->av:I

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    add-int/lit8 v0, v0, -0x1

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v3, Lj;->f:I

    add-int/2addr v0, v3

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    goto/16 :goto_176

    :cond_246
    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    goto/16 :goto_18f

    :cond_24f
    sget v0, Lg;->av:I

    if-gez v0, :cond_25b

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    goto/16 :goto_199

    :cond_25b
    sput v6, Lg;->ax:I

    sput v1, Lg;->aR:I

    goto/16 :goto_199

    :cond_261
    sput v5, Lg;->ax:I

    sput v2, Lg;->aw:I

    sget v0, Lg;->aF:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->av:I

    sput v1, Lg;->aH:I

    goto/16 :goto_1bc

    :cond_26f
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-eq v0, v2, :cond_1bc

    sput v5, Lg;->ax:I

    sget v0, Lg;->aF:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->av:I

    sput v1, Lg;->aH:I

    goto/16 :goto_1bc

    :pswitch_287  #0x3
    sget v0, Lg;->at:I

    sget v2, Lg;->av:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    sget v0, Lg;->au:I

    sget v2, Lg;->aw:I

    add-int/2addr v0, v2

    sput v0, Lg;->au:I

    if-gez v0, :cond_29f

    sget v0, Lj;->j:I

    if-ne v0, v9, :cond_38

    sput v1, Lg;->au:I

    sput v9, Lg;->aw:I

    :cond_29f
    sget v0, Lg;->aG:I

    if-nez v0, :cond_350

    const/4 v0, 0x7

    sput v0, Lg;->ay:I

    :goto_2a6
    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    sget v0, Lp;->g:I

    if-ne v0, v9, :cond_2bd

    sget-boolean v0, Lg;->f:Z

    if-eqz v0, :cond_2bd

    sget v0, Lg;->aw:I

    const/4 v2, -0x3

    if-ne v0, v2, :cond_356

    const/16 v0, 0x8

    sput v0, Lg;->ay:I

    :cond_2bd
    :goto_2bd
    sget v0, Lg;->aw:I

    if-nez v0, :cond_2d3

    sput v5, Lg;->ax:I

    sput v1, Lg;->aG:I

    sget v0, Lp;->g:I

    if-ne v0, v9, :cond_375

    sget-boolean v0, Lg;->f:Z

    if-eqz v0, :cond_375

    sput v6, Lg;->aH:I

    :goto_2cf
    sput v6, Lg;->aw:I

    sput-boolean v6, Lq;->J:Z

    :cond_2d3
    sget v0, Lg;->aI:I

    if-gez v0, :cond_2dd

    sget v0, Lg;->aI:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aI:I

    :cond_2dd
    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_379

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v5, :cond_300

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    sput v0, Lg;->at:I

    sput v1, Lg;->av:I

    :cond_300
    :goto_300
    sget v0, Lg;->au:I

    sget v2, Lg;->aA:I

    if-le v0, v2, :cond_325

    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    sget v3, Lg;->aA:I

    sub-int/2addr v2, v3

    const/16 v3, 0x4000

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_325

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    sput v0, Lg;->au:I

    sput v5, Lg;->ax:I

    sput v1, Lg;->aG:I

    sput v1, Lg;->aH:I

    sput v6, Lg;->aw:I

    :cond_325
    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    sget-object v0, Lp;->d:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->aF:I

    aput v3, v0, v2

    sget-object v0, Lp;->b:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, 0x2

    aput v3, v0, v2

    sget-object v0, Lp;->e:[I

    sget v2, Lp;->g:I

    aput v6, v0, v2

    goto/16 :goto_38

    :cond_350
    const/16 v0, 0x17

    sput v0, Lg;->ay:I

    goto/16 :goto_2a6

    :cond_356
    sget v0, Lg;->aw:I

    const/4 v2, -0x2

    if-ne v0, v2, :cond_361

    const/16 v0, 0x9

    sput v0, Lg;->ay:I

    goto/16 :goto_2bd

    :cond_361
    sget v0, Lg;->aw:I

    if-ne v0, v9, :cond_36b

    const/16 v0, 0xa

    sput v0, Lg;->ay:I

    goto/16 :goto_2bd

    :cond_36b
    sget v0, Lg;->aw:I

    if-nez v0, :cond_2bd

    const/16 v0, 0xb

    sput v0, Lg;->ay:I

    goto/16 :goto_2bd

    :cond_375
    sput v1, Lg;->aH:I

    goto/16 :goto_2cf

    :cond_379
    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    sget v2, Lg;->au:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v2, 0x8

    if-ne v0, v2, :cond_300

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, 0x18

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    sput v1, Lg;->av:I

    goto/16 :goto_300

    :pswitch_39e  #0x4
    invoke-static {}, Lg;->k()V

    goto/16 :goto_38

    :pswitch_3a3  #0x5
    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_47b

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v5, :cond_3c1

    sput v1, Lg;->av:I

    :cond_3c1
    :goto_3c1
    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    sget v0, Lg;->au:I

    sget v3, Lg;->aw:I

    add-int/2addr v0, v3

    sput v0, Lg;->au:I

    if-gez v0, :cond_3d5

    sput v1, Lg;->aw:I

    sput v1, Lg;->au:I

    :cond_3d5
    sget v0, Lg;->aw:I

    if-nez v0, :cond_4a3

    sget v0, Lq;->aX:I

    if-ne v0, v9, :cond_3fa

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-eq v0, v2, :cond_3fa

    sput v5, Lg;->ax:I

    sput v9, Lg;->aq:I

    sget v0, Lq;->aC:I

    shr-int/lit8 v0, v0, 0x1

    sget v3, Lg;->aF:I

    mul-int/2addr v0, v3

    sput v0, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    :cond_3fa
    sget v0, Lq;->aX:I

    if-eq v0, v9, :cond_41d

    sget v0, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    sget v4, Lq;->aX:I

    aget v3, v3, v4

    sub-int/2addr v0, v3

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v3, 0x14

    if-lt v0, v3, :cond_41d

    sput v9, Lq;->aX:I

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_493

    sput v6, Lg;->ax:I

    :cond_41d
    :goto_41d
    sget v0, Lg;->av:I

    if-lez v0, :cond_54e

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :cond_427
    :goto_427
    sget v0, Lg;->av:I

    if-eqz v0, :cond_42e

    invoke-static {}, Lg;->s()V

    :cond_42e
    sget v0, Lg;->aV:I

    packed-switch v0, :pswitch_data_eb6

    :cond_433
    :goto_433
    :pswitch_433  #0x4, 0x5, 0x6, 0x7, 0x8
    sget v0, Lg;->ar:I

    if-ne v0, v6, :cond_439

    sput v9, Lg;->aq:I

    :cond_439
    sget v0, Lg;->ax:I

    const/4 v3, 0x5

    if-ne v0, v3, :cond_448

    sget v0, Lg;->aw:I

    if-eqz v0, :cond_765

    sget v0, Lg;->ay:I

    add-int/lit8 v0, v0, 0xe

    sput v0, Lg;->ay:I

    :cond_448
    :goto_448
    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    const/4 v0, 0x3

    sput v0, Lq;->aC:I

    sget-object v0, Lp;->d:[I

    sget v3, Lp;->g:I

    sget v4, Lg;->aF:I

    aput v4, v0, v3

    sget-object v0, Lp;->b:[I

    sget v3, Lp;->g:I

    sget v4, Lg;->at:I

    sget v5, Lg;->aF:I

    shl-int/lit8 v5, v5, 0x3

    sub-int/2addr v4, v5

    aput v4, v0, v3

    sget-object v3, Lp;->e:[I

    sget v4, Lp;->g:I

    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0x6

    if-le v0, v2, :cond_771

    move v0, v6

    :goto_46f
    aput v0, v3, v4

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    aput v3, v0, v2

    goto/16 :goto_38

    :cond_47b
    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v3, 0x8

    if-ne v0, v3, :cond_3c1

    sput v1, Lg;->av:I

    goto/16 :goto_3c1

    :cond_493
    sput v5, Lg;->ax:I

    sput v2, Lg;->aw:I

    sget v0, Lg;->aF:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->av:I

    sput v9, Lg;->aq:I

    sput v1, Lg;->aH:I

    goto/16 :goto_41d

    :cond_4a3
    sget v0, Lg;->aw:I

    if-gez v0, :cond_4b3

    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    if-nez v0, :cond_41d

    sput v6, Lg;->aw:I

    goto/16 :goto_41d

    :cond_4b3
    sget v0, Lg;->aw:I

    const/16 v3, 0x14

    if-ge v0, v3, :cond_4c5

    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_4c5

    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    :cond_4c5
    sget v0, Lg;->aw:I

    const/4 v3, 0x3

    if-le v0, v3, :cond_4cd

    const/4 v0, 0x3

    sput v0, Lg;->aw:I

    :cond_4cd
    sget v0, Lg;->aw:I

    if-le v0, v2, :cond_4ed

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, 0x3

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-ne v0, v2, :cond_4ed

    sput v1, Lg;->aw:I

    sput v1, Lg;->av:I

    sget v0, Lg;->au:I

    add-int/lit8 v0, v0, 0x3

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Lg;->au:I

    :cond_4ed
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    const/16 v4, 0x40

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_535

    sget v0, Lg;->au:I

    sget v3, Lj;->f:I

    rem-int/2addr v0, v3

    const/16 v3, 0x8

    if-le v0, v3, :cond_535

    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x8

    invoke-static {v0, v2}, Lq;->c(II)Z

    const/16 v0, 0xb

    sput v0, Lg;->ax:I

    sget v0, Lg;->aF:I

    shl-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    sget v0, Lg;->aw:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->aw:I

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    add-int/lit8 v0, v0, 0xc

    sput v0, Lg;->au:I

    sput v9, Lg;->aq:I

    sget v0, Lg;->aN:I

    if-nez v0, :cond_38

    const/16 v0, 0xc

    sput v0, Lg;->ax:I

    goto/16 :goto_38

    :cond_535
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    const/16 v4, 0x1000

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_549

    const/16 v0, 0xc

    sput v0, Lg;->ax:I

    sput v9, Lg;->aq:I

    goto/16 :goto_38

    :cond_549
    invoke-static {}, Lg;->q()V

    goto/16 :goto_41d

    :cond_54e
    sget v0, Lg;->av:I

    if-gez v0, :cond_427

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    goto/16 :goto_427

    :pswitch_55a  #0x0
    sget v0, Lg;->aG:I

    packed-switch v0, :pswitch_data_ed0

    goto/16 :goto_433

    :pswitch_561  #0x1, 0x2, 0x3
    sput v9, Lg;->aq:I

    const/16 v0, 0xd

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_569  #0x4
    sput v1, Lg;->aq:I

    const/16 v0, 0xe

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_571  #0x5
    sput v6, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_579  #0x6
    sput v6, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    invoke-static {}, Lg;->p()V

    goto/16 :goto_433

    :pswitch_584  #0x7
    sput v2, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_58c  #0x8
    sput v2, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    sget-boolean v0, Lg;->aZ:Z

    if-eqz v0, :cond_59e

    sput-boolean v1, Lg;->aZ:Z

    sput v2, Lg;->aV:I

    :goto_59a
    sput v6, Lg;->aG:I

    goto/16 :goto_433

    :cond_59e
    sput v6, Lg;->aV:I

    goto :goto_59a

    :pswitch_5a1  #0x3
    sget v0, Lg;->aG:I

    packed-switch v0, :pswitch_data_ee4

    goto/16 :goto_433

    :pswitch_5a8  #0x1
    sput v6, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_5b0  #0x2
    sput v6, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_5b8  #0x3
    sput v2, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_5c0  #0x4
    sput v2, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    sget-boolean v0, Lg;->aZ:Z

    if-eqz v0, :cond_5d2

    sput-boolean v1, Lg;->aZ:Z

    sput v2, Lg;->aV:I

    :goto_5ce
    sput v6, Lg;->aG:I

    goto/16 :goto_433

    :cond_5d2
    sput v6, Lg;->aV:I

    goto :goto_5ce

    :pswitch_5d5  #0x1
    sget v0, Lg;->aG:I

    packed-switch v0, :pswitch_data_ef0

    goto/16 :goto_433

    :pswitch_5dc  #0x1
    sput v6, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_5e4  #0x2
    sput v6, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    const/16 v0, 0xa

    sput v0, Lg;->aV:I

    goto/16 :goto_433

    :pswitch_5f0  #0x2
    sget v0, Lg;->aG:I

    packed-switch v0, :pswitch_data_ef8

    goto/16 :goto_433

    :pswitch_5f7  #0x1, 0x2, 0x3
    const/4 v0, 0x3

    sput v0, Lg;->aq:I

    const/16 v0, 0x11

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_600  #0x4
    sput v5, Lg;->aq:I

    const/16 v0, 0x12

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_608  #0x5
    const/4 v0, 0x5

    sput v0, Lg;->aq:I

    const/16 v0, 0x13

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_611  #0x6
    const/4 v0, 0x6

    sput v0, Lg;->aq:I

    const/16 v0, 0x14

    sput v0, Lg;->ay:I

    sget v0, Lg;->as:I

    if-ne v0, v5, :cond_65e

    sget v0, Lg;->aU:I

    if-lt v0, v6, :cond_65e

    sget v0, Lg;->at:I

    sget v3, Le;->a:I

    sub-int/2addr v0, v3

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v3, 0x28

    if-le v0, v3, :cond_65e

    sget-object v0, Lo;->b:Lo;

    new-instance v3, Lh;

    sget v4, Lg;->at:I

    sget-object v5, Lg;->bO:[I

    sget v7, Lg;->aq:I

    aget v5, v5, v7

    add-int/lit8 v5, v5, -0x28

    sget v7, Lg;->aF:I

    mul-int/2addr v5, v7

    sub-int/2addr v4, v5

    sget v5, Lg;->au:I

    sget-object v7, Lg;->bP:[I

    sget v8, Lg;->aq:I

    aget v7, v7, v8

    sub-int/2addr v5, v7

    add-int/lit8 v5, v5, 0xd

    const/16 v7, 0x16

    invoke-direct {v3, v4, v5, v7}, Lh;-><init>(III)V

    invoke-virtual {v0, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh;

    sget v3, Lg;->aF:I

    iput v3, v0, Lh;->e:I

    :cond_65e
    invoke-static {}, Lg;->p()V

    goto/16 :goto_433

    :pswitch_663  #0x7
    const/4 v0, 0x6

    sput v0, Lg;->aq:I

    const/16 v0, 0x14

    sput v0, Lg;->ay:I

    sget-boolean v0, Lg;->aZ:Z

    if-eqz v0, :cond_692

    sget v0, Lg;->aU:I

    if-ge v0, v2, :cond_692

    sget v0, Lg;->aw:I

    if-nez v0, :cond_686

    sget-boolean v0, Lg;->cl:Z

    if-eqz v0, :cond_686

    sput v1, Lg;->aG:I

    sput-boolean v1, Lg;->aZ:Z

    const/16 v0, 0x9

    sput v0, Lg;->aV:I

    :goto_682
    sput v6, Lg;->aG:I

    goto/16 :goto_433

    :cond_686
    sput-boolean v1, Lg;->aZ:Z

    const/4 v0, 0x3

    sput v0, Lg;->aV:I

    sget v0, Lg;->aU:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aU:I

    goto :goto_682

    :cond_692
    const/16 v0, 0xa

    sput v0, Lg;->aV:I

    goto :goto_682

    :pswitch_697  #0x9
    sget v0, Lg;->aG:I

    packed-switch v0, :pswitch_data_f0a

    goto/16 :goto_433

    :pswitch_69e  #0x1, 0x2, 0x3
    sput v9, Lg;->aq:I

    const/16 v0, 0xd

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_6a6  #0x4
    sput v1, Lg;->aq:I

    const/16 v0, 0xe

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_6ae  #0x5, 0x6
    const/16 v0, 0x9

    sput v0, Lg;->aq:I

    const/16 v0, 0xf

    sput v0, Lg;->ay:I

    sget v0, Lg;->as:I

    if-ne v0, v6, :cond_6bf

    sget v0, Lg;->aN:I

    const/4 v3, 0x6

    if-ge v0, v3, :cond_6db

    :cond_6bf
    sget v0, Lg;->as:I

    if-ne v0, v2, :cond_6c8

    sget v0, Lg;->aN:I

    const/4 v3, 0x7

    if-ge v0, v3, :cond_6db

    :cond_6c8
    sget v0, Lg;->as:I

    const/4 v3, 0x3

    if-ne v0, v3, :cond_6d3

    sget v0, Lg;->aN:I

    const/16 v3, 0x8

    if-ge v0, v3, :cond_6db

    :cond_6d3
    sget v0, Lg;->as:I

    if-nez v0, :cond_433

    sget v0, Lg;->aN:I

    if-lez v0, :cond_433

    :cond_6db
    invoke-static {}, Lg;->t()I

    move-result v0

    sput-boolean v1, Lg;->cl:Z

    if-eq v0, v9, :cond_433

    sput-boolean v6, Lg;->cl:Z

    sget-object v3, La;->e:[I

    aget v3, v3, v0

    sget-object v4, La;->f:[I

    aget v4, v4, v0

    sget-object v5, La;->g:[I

    aget v5, v5, v0

    shr-int/lit8 v5, v5, 0x1

    sub-int/2addr v4, v5

    sget v5, Lg;->aF:I

    invoke-static {v3, v4, v5}, Lq;->c(III)Z

    sget-object v3, La;->i:[I

    const/16 v4, 0x9

    aput v4, v3, v0

    sget-object v3, La;->j:[I

    const/4 v4, -0x8

    aput v4, v3, v0

    invoke-static {}, Lq;->s()V

    goto/16 :goto_433

    :pswitch_709  #0x7, 0x8
    const/16 v0, 0xa

    sput v0, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_713  #0x9
    sput v9, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    sget-boolean v0, Lg;->cl:Z

    if-eqz v0, :cond_727

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    sput v1, Lg;->av:I

    const/4 v0, -0x8

    sput v0, Lg;->aw:I

    goto/16 :goto_433

    :cond_727
    sput v1, Lg;->aG:I

    sput v1, Lg;->aH:I

    const/16 v0, 0xa

    sput v0, Lg;->aV:I

    goto/16 :goto_433

    :pswitch_731  #0xa
    sget v0, Lg;->aG:I

    packed-switch v0, :pswitch_data_f20

    goto/16 :goto_433

    :pswitch_738  #0x1
    sput v2, Lg;->aq:I

    const/16 v0, 0x10

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_740  #0x2
    sput v1, Lg;->aq:I

    const/16 v0, 0xe

    sput v0, Lg;->ay:I

    goto/16 :goto_433

    :pswitch_748  #0x3, 0x4
    const/16 v0, 0xd

    sput v0, Lg;->ay:I

    sput v9, Lg;->aq:I

    goto/16 :goto_433

    :pswitch_750  #0x5
    const/16 v0, 0xd

    sput v0, Lg;->ay:I

    sput v9, Lg;->aq:I

    sget v0, Lg;->aw:I

    if-eqz v0, :cond_762

    sput v5, Lg;->ax:I

    :goto_75c
    sput v1, Lg;->aU:I

    sput v1, Lg;->aH:I

    goto/16 :goto_433

    :cond_762
    sput v6, Lg;->ax:I

    goto :goto_75c

    :cond_765
    sget v0, Lg;->av:I

    if-eqz v0, :cond_448

    sget v0, Lg;->ay:I

    add-int/lit8 v0, v0, 0x16

    sput v0, Lg;->ay:I

    goto/16 :goto_448

    :cond_771
    move v0, v2

    goto/16 :goto_46f

    :pswitch_774  #0x6
    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    sget v0, Lg;->av:I

    if-le v0, v6, :cond_785

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :cond_785
    sget v0, Lg;->av:I

    if-ge v0, v9, :cond_78f

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    :cond_78f
    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    sget v0, Lg;->au:I

    sget v3, Lg;->aw:I

    add-int/2addr v0, v3

    sput v0, Lg;->au:I

    const/16 v0, 0x15

    sput v0, Lg;->ay:I

    sget v0, Lg;->au:I

    sget v3, Lj;->d:I

    if-ge v0, v3, :cond_7c1

    sget v0, Lg;->au:I

    sget v3, Lq;->az:I

    sget v4, Lq;->ac:I

    add-int/2addr v3, v4

    sget v4, Lg;->aA:I

    add-int/2addr v3, v4

    if-gt v0, v3, :cond_7c1

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    sget v4, Lg;->aA:I

    sub-int/2addr v3, v4

    const/16 v4, 0x1000

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_7f9

    :cond_7c1
    sget-boolean v0, Lq;->aN:Z

    if-eqz v0, :cond_826

    sget-object v0, Lq;->u:[[I

    sget v3, Lq;->aM:I

    aget-object v0, v0, v3

    sget v3, Lq;->aO:I

    aget v0, v0, v3

    const/4 v3, 0x5

    if-ne v0, v3, :cond_826

    sput v6, Lg;->aL:I

    sput v6, Lg;->aN:I

    sput v6, Lg;->ax:I

    sput v6, Lg;->at:I

    sput v6, Lg;->au:I

    sput v1, Lg;->aw:I

    sput v1, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    sput-boolean v6, Lq;->J:Z

    sget-object v0, Lq;->v:[[I

    sget v3, Lq;->aM:I

    aget-object v0, v0, v3

    sget v3, Lq;->aO:I

    aget v0, v0, v3

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    :cond_7f9
    :goto_7f9
    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    sput v2, Lg;->aw:I

    sget-object v0, Lp;->d:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->aF:I

    aput v3, v0, v2

    sget-object v0, Lp;->e:[I

    sget v2, Lp;->g:I

    aput v6, v0, v2

    sget-object v0, Lp;->b:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x2

    aput v3, v0, v2

    goto/16 :goto_38

    :cond_826
    sget v0, Lq;->as:I

    const/16 v3, 0xc

    if-ne v0, v3, :cond_893

    const/16 v0, 0xa8

    sput v0, Lg;->at:I

    sput v1, Lg;->au:I

    :goto_832
    sget v0, Lq;->as:I

    const/4 v3, 0x6

    if-ne v0, v3, :cond_83c

    sput v9, Lp;->g:I

    const/4 v0, 0x5

    sput v0, Lq;->aC:I

    :cond_83c
    sput v5, Lg;->ax:I

    sget v0, Lg;->aM:I

    div-int/lit8 v0, v0, 0x3

    sput v0, Lg;->aL:I

    sget v0, Lg;->aO:I

    div-int/lit8 v0, v0, 0x3

    sput v0, Lg;->aN:I

    sget-boolean v0, Lg;->l:Z

    if-nez v0, :cond_852

    sget v0, Lq;->aL:I

    sput v0, Lq;->aK:I

    :cond_852
    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_85a

    sget v0, Lt;->j:I

    sput v0, Lt;->i:I

    :cond_85a
    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_862

    sget v0, Lt;->l:I

    sput v0, Lt;->k:I

    :cond_862
    sget-boolean v0, Lm;->g:Z

    if-nez v0, :cond_86a

    sget v0, Lm;->f:I

    sput v0, Lm;->e:I

    :cond_86a
    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_872

    const/16 v0, 0x1f40

    sput v0, Le;->f:I

    :cond_872
    sput v1, Lg;->aw:I

    sput v1, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    sget v0, Lg;->aX:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aX:I

    sput-boolean v6, Lq;->J:Z

    invoke-static {}, Lq;->w()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lp;->a(I)V

    const/4 v0, 0x5

    invoke-static {v0}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_7f9

    :cond_893
    sget v0, Lq;->as:I

    const/16 v3, 0xb

    if-ne v0, v3, :cond_8a2

    const/16 v0, 0x18

    sput v0, Lg;->at:I

    const/16 v0, 0x348

    sput v0, Lg;->au:I

    goto :goto_832

    :cond_8a2
    sget v0, Lq;->as:I

    const/16 v3, 0x11

    if-ne v0, v3, :cond_8b1

    const/16 v0, 0x18

    sput v0, Lg;->at:I

    const/16 v0, 0x258

    sput v0, Lg;->au:I

    goto :goto_832

    :cond_8b1
    sget v0, Lq;->as:I

    const/16 v3, 0xd

    if-ne v0, v3, :cond_8e1

    const/16 v0, 0x48

    sput v0, Lg;->at:I

    const/16 v0, 0x60

    sput v0, Lg;->bo:I

    const/16 v0, 0x78

    sput v0, Lg;->R:I

    const/16 v0, 0x108

    sput v0, Lg;->au:I

    sput v0, Lg;->S:I

    sput v0, Lg;->bp:I

    sput v6, Lg;->ad:I

    sput v6, Lg;->V:I

    sput v1, Lq;->aP:I

    const/16 v0, 0xa

    const/16 v3, 0xb

    invoke-static {v1, v0, v3}, Lq;->a(III)V

    const/16 v0, 0xd

    invoke-static {v0}, Ln;->a(I)V

    sput-boolean v1, Lq;->m:Z

    goto/16 :goto_832

    :cond_8e1
    sget v0, Lg;->aS:I

    sput v0, Lg;->at:I

    sget v0, Lj;->b:I

    div-int/lit8 v0, v0, 0x3

    mul-int/lit8 v0, v0, 0x18

    sput v0, Lg;->au:I

    goto/16 :goto_832

    :pswitch_8ef  #0x7
    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v5, :cond_906

    sget v0, Lg;->av:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    :cond_906
    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v3, 0x8

    if-ne v0, v3, :cond_91f

    sget v0, Lg;->av:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    :cond_91f
    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    sget v0, Lg;->au:I

    sget v3, Lg;->aw:I

    add-int/2addr v0, v3

    sput v0, Lg;->au:I

    const/16 v0, 0x15

    sput v0, Lg;->ay:I

    sget v0, Lg;->av:I

    if-le v0, v6, :cond_93b

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :cond_93b
    sget v0, Lg;->av:I

    if-ge v0, v9, :cond_945

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    :cond_945
    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    if-lez v0, :cond_94f

    sput v1, Lg;->aw:I

    :cond_94f
    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    const/4 v3, 0x6

    if-lt v0, v3, :cond_964

    sput v5, Lg;->ax:I

    const/16 v0, -0x14

    sput v0, Lg;->aI:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    sput v9, Lg;->aw:I

    :cond_964
    invoke-static {}, Lg;->r()V

    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    sput v2, Lg;->aw:I

    sget-object v0, Lp;->d:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->aF:I

    aput v3, v0, v2

    sget-object v0, Lp;->e:[I

    sget v2, Lp;->g:I

    aput v6, v0, v2

    sget-object v0, Lp;->b:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x2

    aput v3, v0, v2

    goto/16 :goto_38

    :pswitch_994  #0x8
    const/16 v0, 0x16

    sput v0, Lg;->ay:I

    sget v0, Lg;->aG:I

    const/4 v2, 0x5

    if-ge v0, v2, :cond_9c6

    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    :cond_9a3
    :goto_9a3
    sget v0, Lg;->aH:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aH:I

    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    sget-object v0, Lp;->b:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, 0x2

    aput v3, v0, v2

    goto/16 :goto_38

    :cond_9c6
    sget-object v0, Lq;->C:[Z

    const/16 v2, 0x8

    aget-boolean v0, v0, v2

    if-nez v0, :cond_9a3

    sput v6, Lg;->ax:I

    goto :goto_9a3

    :pswitch_9d1  #0xb
    invoke-static {}, Lg;->n()V

    goto/16 :goto_38

    :pswitch_9d6  #0xc
    sget v0, Lq;->as:I

    const/16 v3, 0xe

    if-ne v0, v3, :cond_9eb

    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_9eb

    sget-boolean v0, Lq;->o:Z

    if-nez v0, :cond_9eb

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    :cond_9eb
    sget v0, Lq;->as:I

    const/16 v3, 0xe

    if-ne v0, v3, :cond_a10

    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_a10

    sget-boolean v0, Lq;->o:Z

    if-eqz v0, :cond_a10

    sget-boolean v0, Lg;->x:Z

    if-nez v0, :cond_a10

    sget v0, Lg;->at:I

    const/16 v3, 0xa50

    if-gt v0, v3, :cond_a10

    sget v0, Lg;->at:I

    const/16 v3, 0xa20

    if-le v0, v3, :cond_a10

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    :cond_a10
    sget v0, Lq;->as:I

    const/16 v3, 0xe

    if-ne v0, v3, :cond_a26

    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_a26

    sget v0, Lg;->D:I

    const/4 v3, 0x3

    if-ne v0, v3, :cond_a26

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    :cond_a26
    sget v0, Lg;->au:I

    sget v3, Lg;->aw:I

    add-int/2addr v0, v3

    sput v0, Lg;->au:I

    sget v0, Lg;->aw:I

    const/16 v3, 0x14

    if-ge v0, v3, :cond_a3f

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_a3f

    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    :cond_a3f
    const/4 v0, 0x7

    sput v0, Lg;->ay:I

    sget v0, Lg;->au:I

    sget v3, Lj;->d:I

    if-lt v0, v3, :cond_a51

    sput v1, Lg;->aL:I

    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    sput v9, Lg;->aq:I

    goto/16 :goto_38

    :cond_a51
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_aac

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    sput v0, Lg;->au:I

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x2

    const/16 v4, 0x40

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_a85

    sput v6, Lg;->ax:I

    sput v1, Lg;->aw:I

    sput v1, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    :cond_a7b
    :goto_a7b
    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Lg;->au:I

    goto/16 :goto_38

    :cond_a85
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x2

    const/16 v4, 0x1000

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_a97

    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    goto :goto_a7b

    :cond_a97
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_a7b

    sput v6, Lg;->ax:I

    sput v1, Lg;->aw:I

    sput v1, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    goto :goto_a7b

    :cond_aac
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    sget v4, Lg;->aA:I

    sub-int/2addr v3, v4

    add-int/lit8 v3, v3, -0x5

    const/16 v4, 0x1000

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_ac4

    sput v1, Lg;->aL:I

    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    sput v9, Lg;->aq:I

    :cond_ac4
    sget v0, Lp;->g:I

    if-eq v0, v9, :cond_38

    sput v2, Lg;->aw:I

    sget-object v0, Lp;->d:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->aF:I

    aput v3, v0, v2

    sget-object v0, Lp;->e:[I

    sget v2, Lp;->g:I

    aput v6, v0, v2

    sget-object v0, Lp;->b:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lp;->c:[I

    sget v2, Lp;->g:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x2

    aput v3, v0, v2

    goto/16 :goto_38

    :pswitch_af1  #0x13
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v3, 0x3

    if-le v0, v3, :cond_be0

    const/16 v0, 0x2b

    sput v0, Lg;->ay:I

    :goto_afc
    sget v0, Lg;->aG:I

    if-lez v0, :cond_b0a

    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aG:I

    const/16 v0, 0x2d

    sput v0, Lg;->ay:I

    :cond_b0a
    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_bf6

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3, v5}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_b2e

    sput v1, Lg;->av:I

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    sput v0, Lg;->at:I

    :cond_b2e
    :goto_b2e
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x1

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x40

    const/16 v3, 0x40

    if-ne v0, v3, :cond_c21

    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    shr-int/lit8 v3, v3, 0x1

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    :goto_b47
    sget-object v0, Lq;->aR:[I

    sget v3, Lq;->aQ:I

    sget v4, Lg;->at:I

    sget v5, Lg;->aF:I

    mul-int/lit8 v5, v5, 0x3

    sub-int/2addr v4, v5

    aput v4, v0, v3

    sget-object v0, Lq;->aS:[I

    sget v3, Lq;->aQ:I

    sget v4, Lg;->au:I

    aput v4, v0, v3

    sget v0, Lg;->av:I

    if-lez v0, :cond_c2a

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :goto_b66
    sget v0, Lq;->aX:I

    if-eq v0, v9, :cond_c4e

    sget v0, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    sget v4, Lq;->aX:I

    aget v3, v3, v4

    sub-int/2addr v0, v3

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v3, 0x14

    if-lt v0, v3, :cond_b8b

    sput v9, Lq;->aX:I

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_c3e

    const/16 v0, 0x12

    sput v0, Lg;->ax:I

    :cond_b8b
    :goto_b8b
    sget v0, Lg;->aF:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    sget v4, Lg;->au:I

    invoke-static {v0, v3, v4}, Lq;->b(III)Z

    invoke-static {}, Lg;->l()V

    invoke-static {}, Lg;->t()I

    move-result v3

    if-eq v3, v9, :cond_38

    sget-object v0, La;->i:[I

    aget v0, v0, v3

    if-eq v0, v2, :cond_baf

    sget-object v0, La;->i:[I

    aget v0, v0, v3

    const/4 v4, 0x3

    if-ne v0, v4, :cond_38

    :cond_baf
    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v3, v2, v0, v1}, La;->a(IIII)Z

    sget-object v0, La;->e:[I

    aget v0, v0, v3

    sget-object v2, La;->f:[I

    aget v2, v2, v3

    sget-object v4, La;->g:[I

    aget v4, v4, v3

    shr-int/lit8 v4, v4, 0x1

    sub-int/2addr v2, v4

    sget v4, Lg;->aF:I

    invoke-static {v0, v2, v4}, Lq;->c(III)Z

    const-string v0, "-2"

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    sget-object v5, La;->g:[I

    aget v3, v5, v3

    sub-int v3, v4, v3

    const/4 v5, -0x2

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    goto/16 :goto_38

    :cond_be0
    const/16 v0, 0x2c

    sput v0, Lg;->ay:I

    sget v0, Lg;->aF:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x4

    sub-int/2addr v3, v4

    sget v4, Lg;->au:I

    add-int/lit8 v4, v4, -0x5

    invoke-static {v0, v3, v4}, Lq;->b(III)Z

    goto/16 :goto_afc

    :cond_bf6
    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    add-int/lit8 v0, v0, -0x1

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    const/16 v4, 0x8

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_b2e

    sput v1, Lg;->av:I

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    add-int/lit8 v0, v0, -0x1

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v3, Lj;->f:I

    add-int/2addr v0, v3

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    goto/16 :goto_b2e

    :cond_c21
    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    goto/16 :goto_b47

    :cond_c2a
    sget v0, Lg;->av:I

    if-gez v0, :cond_c36

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    goto/16 :goto_b66

    :cond_c36
    const/16 v0, 0x12

    sput v0, Lg;->ax:I

    sput v1, Lg;->aR:I

    goto/16 :goto_b66

    :cond_c3e
    const/16 v0, 0x14

    sput v0, Lg;->ax:I

    sput v2, Lg;->aw:I

    sget v0, Lg;->aF:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->av:I

    sput v1, Lg;->aH:I

    goto/16 :goto_b8b

    :cond_c4e
    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-eq v0, v2, :cond_b8b

    const/16 v0, 0x14

    sput v0, Lg;->ax:I

    sget v0, Lg;->aF:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    goto/16 :goto_b8b

    :pswitch_c6a  #0x12
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v2, 0x3

    if-le v0, v2, :cond_c79

    const/16 v0, 0x2b

    sput v0, Lg;->ay:I

    :goto_c75
    sput v1, Lg;->aG:I

    goto/16 :goto_38

    :cond_c79
    const/16 v0, 0x2c

    sput v0, Lg;->ay:I

    sget v0, Lg;->aF:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x4

    sub-int/2addr v2, v3

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x5

    invoke-static {v0, v2, v3}, Lq;->b(III)Z

    goto :goto_c75

    :pswitch_c8e  #0x14
    :try_start_c8e
    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_d6e

    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    add-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v5, :cond_ca7

    const/4 v0, 0x0

    sput v0, Lg;->av:I

    :cond_ca7
    :goto_ca7
    const/4 v0, -0x1

    sput v0, Lg;->aq:I

    sget v0, Lg;->at:I

    sget v3, Lg;->av:I

    add-int/2addr v0, v3

    sput v0, Lg;->at:I

    sget v0, Lg;->au:I

    sget v3, Lg;->aw:I

    add-int/2addr v0, v3

    sput v0, Lg;->au:I

    sget v0, Lg;->aw:I

    const/16 v3, 0x14

    if-ge v0, v3, :cond_cc4

    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    :cond_cc4
    sget v0, Lg;->av:I

    if-lez v0, :cond_cce

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :cond_cce
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v3, 0x3

    if-le v0, v3, :cond_d89

    const/16 v0, 0x2b

    sput v0, Lg;->ay:I

    :goto_cd9
    sget v0, Lg;->aw:I

    if-le v0, v5, :cond_d05

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-ne v0, v2, :cond_d05

    sget v0, Lg;->aw:I

    const/16 v2, 0x8

    if-ge v0, v2, :cond_d9f

    const/16 v0, 0x12

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aw:I

    sput v0, Lg;->av:I

    const/4 v0, 0x0

    sput v0, Lg;->aH:I

    sput v0, Lg;->aG:I

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Lg;->au:I

    :cond_d05
    :goto_d05
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    const/16 v3, 0x40

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_d33

    sget v0, Lg;->au:I

    sget v2, Lj;->f:I

    rem-int/2addr v0, v2

    const/16 v2, 0x8

    if-le v0, v2, :cond_d33

    sget v0, Lq;->as:I

    const/16 v2, 0xe

    if-ne v0, v2, :cond_d26

    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lq;->aP:I

    :cond_d26
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x8

    invoke-static {v0, v2}, Lq;->c(II)Z

    :cond_d33
    sget-object v0, Lq;->aR:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    mul-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lq;->aS:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->au:I

    aput v3, v0, v2

    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    const/16 v3, 0x1000

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_d62

    sget-object v0, Lq;->aV:[I

    sget v2, Lq;->aQ:I

    const/4 v3, 0x1

    aput v3, v0, v2

    const/4 v0, -0x1

    sput v0, Lq;->aQ:I

    const/16 v0, 0xc

    sput v0, Lg;->ax:I
    :try_end_d62
    .catch Ljava/lang/Exception; {:try_start_c8e .. :try_end_d62} :catch_d87

    :cond_d62
    :goto_d62
    sget v0, Lg;->aI:I

    if-gez v0, :cond_38

    sget v0, Lg;->aI:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aI:I

    goto/16 :goto_38

    :cond_d6e
    :try_start_d6e
    sget v0, Lg;->at:I

    sget v3, Lg;->aB:I

    sub-int/2addr v0, v3

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    invoke-static {v0, v3}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v3, 0x8

    if-ne v0, v3, :cond_ca7

    const/4 v0, 0x0

    sput v0, Lg;->av:I

    goto/16 :goto_ca7

    :catch_d87
    move-exception v0

    goto :goto_d62

    :cond_d89
    const/16 v0, 0x2c

    sput v0, Lg;->ay:I

    sget v0, Lg;->aF:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    shl-int/lit8 v4, v4, 0x4

    sub-int/2addr v3, v4

    sget v4, Lg;->au:I

    add-int/lit8 v4, v4, -0x5

    invoke-static {v0, v3, v4}, Lq;->b(III)Z

    goto/16 :goto_cd9

    :cond_d9f
    const/16 v0, 0x15

    sput v0, Lg;->ax:I

    sget v0, Lg;->aw:I

    div-int/lit8 v0, v0, 0x3

    neg-int v0, v0

    sput v0, Lg;->aw:I

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Lg;->au:I
    :try_end_db2
    .catch Ljava/lang/Exception; {:try_start_d6e .. :try_end_db2} :catch_d87

    goto/16 :goto_d05

    :pswitch_db4  #0x15
    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_e51

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    sget v3, Lg;->aC:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v5, :cond_dcc

    sput v1, Lg;->av:I

    :cond_dcc
    :goto_dcc
    sget-object v0, Lq;->aR:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    mul-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lq;->aS:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->au:I

    aput v3, v0, v2

    sget v0, Lg;->at:I

    sget v2, Lg;->av:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    sget v0, Lg;->au:I

    sget v2, Lg;->aw:I

    add-int/2addr v0, v2

    sput v0, Lg;->au:I

    if-gez v0, :cond_df9

    sget v0, Lj;->j:I

    if-ne v0, v9, :cond_38

    sput v1, Lg;->au:I

    sput v1, Lg;->aw:I

    :cond_df9
    sget-object v0, Lq;->aR:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->at:I

    sget v4, Lg;->aF:I

    mul-int/lit8 v4, v4, 0x3

    sub-int/2addr v3, v4

    aput v3, v0, v2

    sget-object v0, Lq;->aS:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->au:I

    aput v3, v0, v2

    sget v0, Lg;->av:I

    if-lez v0, :cond_e18

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :cond_e18
    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    if-nez v0, :cond_e2c

    const/16 v0, 0x14

    sput v0, Lg;->ax:I

    sput v1, Lg;->aG:I

    sput v6, Lg;->aH:I

    sput v6, Lg;->aw:I

    sput-boolean v6, Lq;->J:Z

    :cond_e2c
    sget v0, Lg;->aI:I

    if-gez v0, :cond_e36

    sget v0, Lg;->aI:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aI:I

    :cond_e36
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    const/4 v2, 0x3

    if-le v0, v2, :cond_e69

    const/16 v0, 0x2b

    sput v0, Lg;->ay:I

    :goto_e41
    sget v0, Lg;->aG:I

    if-lez v0, :cond_38

    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aG:I

    const/16 v0, 0x2d

    sput v0, Lg;->ay:I

    goto/16 :goto_38

    :cond_e51
    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    sget v2, Lg;->au:I

    sget v3, Lg;->aC:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v2, 0x8

    if-ne v0, v2, :cond_dcc

    sput v1, Lg;->av:I

    goto/16 :goto_dcc

    :cond_e69
    const/16 v0, 0x2c

    sput v0, Lg;->ay:I

    sget v0, Lg;->aF:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x4

    sub-int/2addr v2, v3

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x5

    invoke-static {v0, v2, v3}, Lq;->b(III)Z

    goto :goto_e41

    :pswitch_e7e  #0x17
    invoke-static {}, Lg;->m()V

    goto/16 :goto_38

    nop

    :pswitch_data_e84
    .packed-switch 0x1
        :pswitch_62  #00000001
        :pswitch_13c  #00000002
        :pswitch_287  #00000003
        :pswitch_39e  #00000004
        :pswitch_3a3  #00000005
        :pswitch_774  #00000006
        :pswitch_8ef  #00000007
        :pswitch_994  #00000008
        :pswitch_38  #00000009
        :pswitch_38  #0000000a
        :pswitch_9d1  #0000000b
        :pswitch_9d6  #0000000c
        :pswitch_38  #0000000d
        :pswitch_38  #0000000e
        :pswitch_38  #0000000f
        :pswitch_38  #00000010
        :pswitch_38  #00000011
        :pswitch_c6a  #00000012
        :pswitch_af1  #00000013
        :pswitch_c8e  #00000014
        :pswitch_db4  #00000015
        :pswitch_38  #00000016
        :pswitch_e7e  #00000017
    .end packed-switch

    :pswitch_data_eb6
    .packed-switch 0x0
        :pswitch_55a  #00000000
        :pswitch_5d5  #00000001
        :pswitch_5f0  #00000002
        :pswitch_5a1  #00000003
        :pswitch_433  #00000004
        :pswitch_433  #00000005
        :pswitch_433  #00000006
        :pswitch_433  #00000007
        :pswitch_433  #00000008
        :pswitch_697  #00000009
        :pswitch_731  #0000000a
    .end packed-switch

    :pswitch_data_ed0
    .packed-switch 0x1
        :pswitch_561  #00000001
        :pswitch_561  #00000002
        :pswitch_561  #00000003
        :pswitch_569  #00000004
        :pswitch_571  #00000005
        :pswitch_579  #00000006
        :pswitch_584  #00000007
        :pswitch_58c  #00000008
    .end packed-switch

    :pswitch_data_ee4
    .packed-switch 0x1
        :pswitch_5a8  #00000001
        :pswitch_5b0  #00000002
        :pswitch_5b8  #00000003
        :pswitch_5c0  #00000004
    .end packed-switch

    :pswitch_data_ef0
    .packed-switch 0x1
        :pswitch_5dc  #00000001
        :pswitch_5e4  #00000002
    .end packed-switch

    :pswitch_data_ef8
    .packed-switch 0x1
        :pswitch_5f7  #00000001
        :pswitch_5f7  #00000002
        :pswitch_5f7  #00000003
        :pswitch_600  #00000004
        :pswitch_608  #00000005
        :pswitch_611  #00000006
        :pswitch_663  #00000007
    .end packed-switch

    :pswitch_data_f0a
    .packed-switch 0x1
        :pswitch_69e  #00000001
        :pswitch_69e  #00000002
        :pswitch_69e  #00000003
        :pswitch_6a6  #00000004
        :pswitch_6ae  #00000005
        :pswitch_6ae  #00000006
        :pswitch_709  #00000007
        :pswitch_709  #00000008
        :pswitch_713  #00000009
    .end packed-switch

    :pswitch_data_f20
    .packed-switch 0x1
        :pswitch_738  #00000001
        :pswitch_740  #00000002
        :pswitch_748  #00000003
        :pswitch_748  #00000004
        :pswitch_750  #00000005
    .end packed-switch
.end method

.method public static final b(I)V
    .registers 9

    const/16 v7, 0xa

    const/16 v6, 0x8

    const/4 v5, 0x3

    const/4 v0, 0x0

    sget-boolean v1, Lg;->O:Z

    if-eqz v1, :cond_c

    sput p0, Lg;->Q:I

    :cond_c
    sget v1, Lg;->Q:I

    if-eq v1, p0, :cond_11

    :cond_10
    :goto_10
    return-void

    :cond_11
    const/4 v1, -0x1

    sput v1, Lg;->bk:I

    sget-object v1, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_31

    const/16 v1, 0x8

    :try_start_1a
    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_1f
    if-lt v1, v6, :cond_6a

    const/4 v1, 0x3

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cf:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_27
    if-lt v1, v5, :cond_8a

    const/16 v1, 0xa

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cg:[Ljavax/microedition/lcdui/Image;
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_2f} :catch_cc

    :goto_2f
    if-lt v0, v7, :cond_ab

    :cond_31
    :goto_31
    const/16 v0, 0x16

    sput v0, Lg;->X:I

    const/16 v0, 0x20

    sput v0, Lg;->Y:I

    sget v0, Lg;->X:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->Z:I

    sget v0, Lg;->Y:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aa:I

    sget v0, Lg;->X:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->ab:I

    sget v0, Lg;->Y:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->ac:I

    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_10

    sget v0, Lg;->at:I

    sget v1, Lg;->aF:I

    mul-int/lit8 v1, v1, 0xa

    sub-int/2addr v0, v1

    sput v0, Lg;->R:I

    sget v0, Lg;->au:I

    sput v0, Lg;->S:I

    sget v0, Lg;->aF:I

    sput v0, Lg;->ad:I

    const/4 v0, 0x4

    sput v0, Lg;->V:I

    goto :goto_10

    :cond_6a
    :try_start_6a
    sget-object v2, Lg;->ce:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/gb"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_8a
    sget-object v2, Lg;->cf:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/gh"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_27

    :cond_ab
    sget-object v1, Lg;->cg:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/cp/gl"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_c8
    .catch Ljava/lang/Exception; {:try_start_6a .. :try_end_c8} :catch_cc

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_2f

    :catch_cc
    move-exception v0

    goto/16 :goto_31
.end method

.method public static final b(II)V
    .registers 8

    const/4 v5, -0x2

    const/4 v1, 0x0

    const/4 v0, -0x1

    sput v0, Lg;->bk:I

    shl-int/lit8 v0, p1, 0x2

    sput v0, Lg;->T:I

    sput v5, Lg;->U:I

    sput v1, Lg;->ae:I

    sput v1, Lg;->af:I

    const/4 v0, 0x7

    sput v0, Lg;->V:I

    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->ad:I

    neg-int v3, v3

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lg;->R:I

    sget v3, Lg;->S:I

    sget v4, Lg;->Y:I

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    return-void
.end method

.method public static final b(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, -0x1

    const/16 v9, 0x18

    const/4 v10, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    sget-boolean v0, Lg;->ba:Z

    if-eqz v0, :cond_14

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x14

    if-le v0, v6, :cond_b9

    const/16 v0, 0x19

    sput v0, Lg;->ay:I

    :cond_14
    :goto_14
    sget v0, Lg;->aF:I

    if-ne v0, v10, :cond_bf

    sget-object v0, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->E:[[[I

    sget v3, Lg;->ay:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->at:I

    sget-object v3, Lg;->E:[[[I

    sget v4, Lg;->ay:I

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->au:I

    sget-object v4, Lg;->E:[[[I

    sget v5, Lg;->ay:I

    aget-object v4, v4, v5

    aget-object v4, v4, v2

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->E:[[[I

    sget v3, Lg;->ay:I

    aget-object v1, v1, v3

    aget-object v1, v1, v10

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->at:I

    sget-object v3, Lg;->E:[[[I

    sget v4, Lg;->ay:I

    aget-object v3, v3, v4

    aget-object v3, v3, v10

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->au:I

    sget-object v4, Lg;->E:[[[I

    sget v5, Lg;->ay:I

    aget-object v4, v4, v5

    aget-object v4, v4, v10

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->E:[[[I

    sget v3, Lg;->ay:I

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->at:I

    sget-object v3, Lg;->E:[[[I

    sget v4, Lg;->ay:I

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->au:I

    sget-object v4, Lg;->E:[[[I

    sget v5, Lg;->ay:I

    aget-object v4, v4, v5

    aget-object v4, v4, v6

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget v0, Lg;->aq:I

    if-eq v0, v11, :cond_b8

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->aq:I

    aget-object v0, v0, v1

    sget v1, Lg;->at:I

    sget-object v3, Lg;->bO:[I

    sget v4, Lg;->aq:I

    aget v3, v3, v4

    sub-int/2addr v1, v3

    sget v3, Lg;->au:I

    sget-object v4, Lg;->bP:[I

    sget v5, Lg;->aq:I

    aget v4, v4, v5

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_b8
    :goto_b8
    return-void

    :cond_b9
    const/16 v0, 0x1a

    sput v0, Lg;->ay:I

    goto/16 :goto_14

    :cond_bf
    sget-object v0, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->E:[[[I

    sget v3, Lg;->ay:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->E:[[[I

    sget v4, Lg;->ay:I

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->E:[[[I

    sget v5, Lg;->ay:I

    aget-object v3, v3, v5

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->at:I

    sget-object v3, Lg;->E:[[[I

    sget v7, Lg;->ay:I

    aget-object v3, v3, v7

    aget-object v3, v3, v2

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->au:I

    sget-object v3, Lg;->E:[[[I

    sget v8, Lg;->ay:I

    aget-object v3, v3, v8

    aget-object v3, v3, v2

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->E:[[[I

    sget v3, Lg;->ay:I

    aget-object v1, v1, v3

    aget-object v1, v1, v10

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->E:[[[I

    sget v4, Lg;->ay:I

    aget-object v3, v3, v4

    aget-object v3, v3, v10

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->E:[[[I

    sget v5, Lg;->ay:I

    aget-object v3, v3, v5

    aget-object v3, v3, v10

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->at:I

    sget-object v3, Lg;->E:[[[I

    sget v7, Lg;->ay:I

    aget-object v3, v3, v7

    aget-object v3, v3, v10

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->au:I

    sget-object v3, Lg;->E:[[[I

    sget v8, Lg;->ay:I

    aget-object v3, v3, v8

    aget-object v3, v3, v10

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->E:[[[I

    sget v3, Lg;->ay:I

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->E:[[[I

    sget v4, Lg;->ay:I

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->E:[[[I

    sget v5, Lg;->ay:I

    aget-object v3, v3, v5

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->at:I

    sget-object v3, Lg;->E:[[[I

    sget v7, Lg;->ay:I

    aget-object v3, v3, v7

    aget-object v3, v3, v6

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->au:I

    sget-object v3, Lg;->E:[[[I

    sget v8, Lg;->ay:I

    aget-object v3, v3, v8

    aget-object v3, v3, v6

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget v0, Lg;->aq:I

    if-eq v0, v11, :cond_b8

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->aq:I

    aget-object v1, v0, v1

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v3, Lg;->aq:I

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v3, Lg;->aq:I

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->at:I

    sget-object v3, Lg;->bO:[I

    sget v7, Lg;->aq:I

    aget v3, v3, v7

    add-int v7, v0, v3

    sget v0, Lg;->au:I

    sget-object v3, Lg;->bP:[I

    sget v8, Lg;->aq:I

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_b8
.end method

.method public static c()V
    .registers 9

    const/16 v8, 0xf

    const/4 v4, -0x1

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v0, v1

    :goto_7
    sget v2, Lg;->F:I

    if-lt v0, v2, :cond_c

    return-void

    :cond_c
    sget-object v2, Lg;->bT:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_2e2

    :cond_13
    :goto_13
    :pswitch_13  #0x3, 0x4
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    :pswitch_16  #0x1
    sget-object v2, Lg;->bU:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    const/16 v5, 0x1e

    if-le v2, v5, :cond_2a

    sget-object v2, Lg;->bU:[I

    aput v1, v2, v0

    :cond_2a
    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    add-int/lit8 v5, v0, 0x12

    rem-int/2addr v2, v5

    add-int/lit8 v5, v0, 0x6

    if-ge v2, v5, :cond_72

    sget-object v2, Lg;->bW:[I

    aput v1, v2, v0

    :goto_39
    sget-object v2, Lg;->I:[Z

    aget-boolean v2, v2, v0

    if-eqz v2, :cond_81

    sget-object v2, Lg;->bV:[I

    sget v5, Lg;->J:I

    aput v5, v2, v0

    sget-object v5, Lg;->M:[I

    sget v2, Lg;->J:I

    sget-object v6, Lg;->K:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_77

    move v2, v3

    :goto_50
    aput v2, v5, v0

    sget-object v2, Lg;->bR:[I

    sget-object v5, Lg;->M:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x2

    aput v5, v2, v0

    sget-object v5, Lg;->bR:[I

    sget-object v2, Lg;->M:[I

    aget v2, v2, v0

    if-lez v2, :cond_79

    sget-object v2, Lg;->bR:[I

    aget v2, v2, v0

    rem-int/lit8 v6, v0, 0x2

    add-int/2addr v2, v6

    :goto_6b
    aput v2, v5, v0

    sget-object v2, Lg;->bT:[I

    aput v7, v2, v0

    goto :goto_13

    :cond_72
    sget-object v2, Lg;->bW:[I

    aput v3, v2, v0

    goto :goto_39

    :cond_77
    move v2, v4

    goto :goto_50

    :cond_79
    sget-object v2, Lg;->bR:[I

    aget v2, v2, v0

    rem-int/lit8 v6, v0, 0x2

    sub-int/2addr v2, v6

    goto :goto_6b

    :cond_81
    sget-boolean v2, Lg;->H:Z

    if-nez v2, :cond_13

    sget-object v2, Lg;->bV:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Lg;->bV:[I

    aget v2, v2, v0

    sget-object v5, Lg;->bZ:[I

    aget v5, v5, v0

    sget-object v6, Lg;->K:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    rem-int/lit8 v5, v5, 0x14

    sget-object v6, Lg;->bZ:[I

    aget v6, v6, v0

    shr-int/lit8 v6, v6, 0x1

    add-int/2addr v5, v6

    if-le v2, v5, :cond_ed

    sget-boolean v2, Lq;->bd:Z

    if-eqz v2, :cond_ad

    sget v2, Lg;->bj:I

    if-eq v2, v0, :cond_13

    :cond_ad
    sget-object v2, Lg;->bV:[I

    aput v1, v2, v0

    sget v2, Lq;->at:I

    sget-object v5, Lg;->bZ:[I

    aget v5, v5, v0

    add-int/2addr v2, v5

    rem-int/lit8 v2, v2, 0x78

    add-int/lit8 v2, v2, -0x3c

    if-lez v2, :cond_f8

    sget-object v5, Lg;->bZ:[I

    aget v5, v5, v0

    add-int/2addr v2, v5

    :goto_c3
    sget-object v5, Lg;->bV:[I

    sget-object v6, Lg;->K:[I

    aget v6, v6, v0

    add-int/2addr v6, v2

    aput v6, v5, v0

    sget-object v5, Lg;->M:[I

    if-lez v2, :cond_fe

    move v2, v3

    :goto_d1
    aput v2, v5, v0

    sget-object v2, Lg;->bR:[I

    sget-object v5, Lg;->M:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x2

    aput v5, v2, v0

    sget-object v2, Lg;->bT:[I

    aput v7, v2, v0

    sget v2, Lg;->bj:I

    if-ne v2, v0, :cond_ed

    sput v4, Lg;->bj:I

    const-string v2, " "

    sput-object v2, Lq;->V:Ljava/lang/String;

    sput-boolean v3, Lq;->J:Z

    :cond_ed
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0xa

    if-ne v2, v3, :cond_13

    invoke-static {v0}, Lg;->h(I)V

    goto/16 :goto_13

    :cond_f8
    sget-object v5, Lg;->bZ:[I

    aget v5, v5, v0

    sub-int/2addr v2, v5

    goto :goto_c3

    :cond_fe
    move v2, v4

    goto :goto_d1

    :pswitch_100  #0x2
    sget-object v2, Lg;->bU:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    const/16 v5, 0xa

    if-lt v2, v5, :cond_114

    sget-object v2, Lg;->bU:[I

    aput v1, v2, v0

    :cond_114
    sget-object v2, Lg;->bW:[I

    sget-object v5, Lg;->bU:[I

    aget v5, v5, v0

    shr-int/lit8 v5, v5, 0x1

    add-int/lit8 v5, v5, 0x2

    aput v5, v2, v0

    sget-object v2, Lg;->K:[I

    aget v5, v2, v0

    sget-object v6, Lg;->bR:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Lg;->K:[I

    aget v2, v2, v0

    sget-object v5, Lg;->cc:[I

    aget v5, v5, v0

    if-gt v2, v5, :cond_150

    sget-object v2, Lg;->K:[I

    aget v2, v2, v0

    sget-object v5, Lg;->cb:[I

    aget v5, v5, v0

    if-lt v2, v5, :cond_150

    sget-object v2, Lg;->K:[I

    aget v2, v2, v0

    sget-object v5, Lg;->bV:[I

    aget v5, v5, v0

    sub-int/2addr v2, v5

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v5, 0x8

    if-ge v2, v5, :cond_171

    :cond_150
    sget-object v2, Lg;->bU:[I

    sget-object v5, Lg;->bV:[I

    aput v1, v5, v0

    aput v1, v2, v0

    sget-object v2, Lg;->K:[I

    aget v5, v2, v0

    sget-object v6, Lg;->bR:[I

    aget v6, v6, v0

    sub-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Lg;->bR:[I

    aput v1, v2, v0

    sget-object v2, Lg;->bT:[I

    aput v3, v2, v0

    sget-object v2, Lg;->I:[Z

    aput-boolean v1, v2, v0

    goto/16 :goto_13

    :cond_171
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0xa

    if-nez v2, :cond_13

    invoke-static {v0}, Lg;->h(I)V

    goto/16 :goto_13

    :pswitch_17c  #0x5
    sget-object v2, Lg;->bU:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Lg;->bV:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_2f0

    :pswitch_18b  #0x4, 0x5, 0x6, 0x7, 0x8, 0x9
    goto/16 :goto_13

    :pswitch_18d  #0x0
    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_30a

    goto/16 :goto_13

    :pswitch_196  #0x1, 0x2, 0x3
    sget-object v2, Lg;->bY:[I

    aput v4, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0xd

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_1a2  #0x4
    sget-object v2, Lg;->bY:[I

    aput v1, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0xe

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_1ae  #0x5
    sget-object v2, Lg;->bY:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bW:[I

    aput v8, v2, v0

    goto/16 :goto_13

    :pswitch_1b8  #0x6
    sget-object v2, Lg;->bY:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bW:[I

    aput v8, v2, v0

    invoke-static {v0}, Lg;->g(I)V

    goto/16 :goto_13

    :pswitch_1c5  #0x7
    sget-object v2, Lg;->bY:[I

    aput v7, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x10

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_1d1  #0x8
    sget-object v2, Lg;->bY:[I

    aput v7, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x10

    aput v5, v2, v0

    sget-object v2, Lg;->bV:[I

    aput v7, v2, v0

    sget-object v2, Lg;->bU:[I

    aput v3, v2, v0

    goto/16 :goto_13

    :pswitch_1e5  #0x3
    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_31e

    goto/16 :goto_13

    :pswitch_1ee  #0x1
    sget-object v2, Lg;->bY:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bW:[I

    aput v8, v2, v0

    goto/16 :goto_13

    :pswitch_1f8  #0x2
    sget-object v2, Lg;->bY:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bW:[I

    aput v8, v2, v0

    goto/16 :goto_13

    :pswitch_202  #0x3
    sget-object v2, Lg;->bY:[I

    aput v7, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x10

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_20e  #0x4
    sget-object v2, Lg;->bY:[I

    aput v7, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x10

    aput v5, v2, v0

    sget-object v2, Lg;->bV:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bU:[I

    aput v3, v2, v0

    goto/16 :goto_13

    :pswitch_222  #0x1
    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_32a

    goto/16 :goto_13

    :pswitch_22b  #0x1
    sget-object v2, Lg;->bY:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bW:[I

    aput v8, v2, v0

    goto/16 :goto_13

    :pswitch_235  #0x2
    sget-object v2, Lg;->bY:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bW:[I

    aput v8, v2, v0

    sget-object v2, Lg;->bV:[I

    const/16 v5, 0xa

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_245  #0x2
    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_332

    goto/16 :goto_13

    :pswitch_24e  #0x1, 0x2, 0x3
    sget-object v2, Lg;->bY:[I

    const/4 v5, 0x3

    aput v5, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x11

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_25b  #0x4
    sget-object v2, Lg;->bY:[I

    const/4 v5, 0x4

    aput v5, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x12

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_268  #0x5
    sget-object v2, Lg;->bY:[I

    const/4 v5, 0x5

    aput v5, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x13

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_275  #0x6
    sget-object v2, Lg;->bY:[I

    const/4 v5, 0x6

    aput v5, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x14

    aput v5, v2, v0

    invoke-static {v0}, Lg;->g(I)V

    goto/16 :goto_13

    :pswitch_285  #0x7
    sget-object v2, Lg;->bY:[I

    const/4 v5, 0x6

    aput v5, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x14

    aput v5, v2, v0

    sget-object v2, Lg;->bV:[I

    const/4 v5, 0x3

    aput v5, v2, v0

    sget-object v2, Lg;->bU:[I

    aput v3, v2, v0

    goto/16 :goto_13

    :pswitch_29b  #0xa
    sget-object v2, Lg;->bU:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_344

    goto/16 :goto_13

    :pswitch_2a4  #0x1
    sget-object v2, Lg;->bY:[I

    aput v7, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0x10

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_2b0  #0x2
    sget-object v2, Lg;->bY:[I

    aput v1, v2, v0

    sget-object v2, Lg;->bW:[I

    const/16 v5, 0xe

    aput v5, v2, v0

    goto/16 :goto_13

    :pswitch_2bc  #0x3, 0x4
    sget-object v2, Lg;->bW:[I

    const/16 v5, 0xd

    aput v5, v2, v0

    sget-object v2, Lg;->bY:[I

    aput v4, v2, v0

    goto/16 :goto_13

    :pswitch_2c8  #0x5
    sget-object v2, Lg;->bW:[I

    const/16 v5, 0xd

    aput v5, v2, v0

    sget-object v2, Lg;->bY:[I

    aput v4, v2, v0

    sget-object v2, Lg;->bT:[I

    aput v3, v2, v0

    sget-object v2, Lg;->bV:[I

    const/16 v5, 0x78

    aput v5, v2, v0

    sget-object v2, Lg;->bU:[I

    aput v1, v2, v0

    goto/16 :goto_13

    :pswitch_data_2e2
    .packed-switch 0x1
        :pswitch_16  #00000001
        :pswitch_100  #00000002
        :pswitch_13  #00000003
        :pswitch_13  #00000004
        :pswitch_17c  #00000005
    .end packed-switch

    :pswitch_data_2f0
    .packed-switch 0x0
        :pswitch_18d  #00000000
        :pswitch_222  #00000001
        :pswitch_245  #00000002
        :pswitch_1e5  #00000003
        :pswitch_18b  #00000004
        :pswitch_18b  #00000005
        :pswitch_18b  #00000006
        :pswitch_18b  #00000007
        :pswitch_18b  #00000008
        :pswitch_18b  #00000009
        :pswitch_29b  #0000000a
    .end packed-switch

    :pswitch_data_30a
    .packed-switch 0x1
        :pswitch_196  #00000001
        :pswitch_196  #00000002
        :pswitch_196  #00000003
        :pswitch_1a2  #00000004
        :pswitch_1ae  #00000005
        :pswitch_1b8  #00000006
        :pswitch_1c5  #00000007
        :pswitch_1d1  #00000008
    .end packed-switch

    :pswitch_data_31e
    .packed-switch 0x1
        :pswitch_1ee  #00000001
        :pswitch_1f8  #00000002
        :pswitch_202  #00000003
        :pswitch_20e  #00000004
    .end packed-switch

    :pswitch_data_32a
    .packed-switch 0x1
        :pswitch_22b  #00000001
        :pswitch_235  #00000002
    .end packed-switch

    :pswitch_data_332
    .packed-switch 0x1
        :pswitch_24e  #00000001
        :pswitch_24e  #00000002
        :pswitch_24e  #00000003
        :pswitch_25b  #00000004
        :pswitch_268  #00000005
        :pswitch_275  #00000006
        :pswitch_285  #00000007
    .end packed-switch

    :pswitch_data_344
    .packed-switch 0x1
        :pswitch_2a4  #00000001
        :pswitch_2b0  #00000002
        :pswitch_2bc  #00000003
        :pswitch_2bc  #00000004
        :pswitch_2c8  #00000005
    .end packed-switch
.end method

.method public static c(I)V
    .registers 9

    const/4 v7, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x0

    sget v0, Lg;->aX:I

    add-int/2addr v0, p0

    sput v0, Lg;->aX:I

    sget-object v2, Lg;->c:[I

    sget v3, Lg;->aW:I

    add-int/lit8 v3, v3, -0x1

    aget v2, v2, v3

    if-le v0, v2, :cond_10d

    sget-boolean v0, Lb;->a:Z

    if-nez v0, :cond_2a

    sget v0, Lg;->aW:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_2a

    sput v4, Lg;->aX:I

    const/4 v0, 0x6

    invoke-static {v0}, Lq;->h(I)V

    const-string v0, "Bạn cần phải kích hoạt để có thể lên level 5"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    :goto_29
    return-void

    :cond_2a
    const-string v0, "level-up"

    sget v2, Lg;->at:I

    sget v3, Lg;->au:I

    sget v5, Lg;->aA:I

    sub-int/2addr v3, v5

    const/4 v5, -0x1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Lq;->bw:[Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "Tăng máu +"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v3, Lg;->d:[I

    sget v5, Lg;->aW:I

    add-int/lit8 v5, v5, -0x1

    aget v3, v3, v5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v4

    sget-object v0, Lq;->bw:[Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "Tăng công +"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v3, Lg;->b:[I

    sget v5, Lg;->aW:I

    add-int/lit8 v5, v5, -0x1

    aget v3, v3, v5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v7

    sget-object v0, Lq;->bw:[Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "Tăng mana +"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v3, Lg;->e:[I

    sget v5, Lg;->aW:I

    add-int/lit8 v5, v5, -0x1

    aget v3, v3, v5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lq;->bx:[Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "Máu: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v3, Lg;->aM:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    sget v3, Lg;->aM:I

    sget-object v5, Lg;->d:[I

    sget v6, Lg;->aW:I

    add-int/lit8 v6, v6, -0x1

    aget v5, v5, v6

    add-int/2addr v3, v5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v4

    sget-object v0, Lq;->bx:[Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "Công: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v3, Lg;->aJ:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    sget v3, Lg;->aJ:I

    sget-object v4, Lg;->b:[I

    sget v5, Lg;->aW:I

    add-int/lit8 v5, v5, -0x1

    aget v4, v4, v5

    add-int/2addr v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v7

    sget-object v0, Lq;->bx:[Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "Mana: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v3, Lg;->aO:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    sget v3, Lg;->aO:I

    sget-object v4, Lg;->e:[I

    sget v5, Lg;->aW:I

    add-int/lit8 v5, v5, -0x1

    aget v4, v4, v5

    add-int/2addr v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-static {}, Lq;->x()V

    :goto_109
    sput-boolean v7, Lq;->J:Z

    goto/16 :goto_29

    :cond_10d
    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "+"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lg;->at:I

    sget v3, Lg;->au:I

    sget v5, Lg;->aA:I

    sub-int/2addr v3, v5

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    goto :goto_109
.end method

.method public static c(Ljavax/microedition/lcdui/Graphics;)V
    .registers 14

    const/4 v12, -0x1

    const/16 v9, 0x18

    const/4 v11, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    move v10, v2

    :goto_7
    sget v0, Lg;->F:I

    if-lt v10, v0, :cond_c

    return-void

    :cond_c
    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget v1, Lg;->aB:I

    add-int/2addr v0, v1

    sget v1, Lq;->ay:I

    if-lt v0, v1, :cond_11d

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget v1, Lg;->aB:I

    sub-int/2addr v0, v1

    sget v1, Lq;->ay:I

    sget v3, Lq;->ab:I

    add-int/2addr v1, v3

    if-gt v0, v1, :cond_11d

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    if-lt v0, v1, :cond_11d

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget v1, Lg;->aA:I

    sub-int/2addr v0, v1

    sget v1, Lq;->az:I

    sget v3, Lq;->ac:I

    add-int/2addr v1, v3

    if-gt v0, v1, :cond_11d

    sget-object v0, Lg;->M:[I

    aget v0, v0, v10

    if-ne v0, v11, :cond_281

    sget v0, Lq;->as:I

    const/4 v1, 0x4

    if-ne v0, v1, :cond_122

    sget-object v0, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bX:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->cs:[I

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v2

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cm:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v11

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v11

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    add-int/lit8 v3, v3, -0x2

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v11

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v6

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :goto_f2
    sget-object v0, Lg;->bY:[I

    aget v0, v0, v10

    if-eq v0, v12, :cond_11d

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bY:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bO:[I

    sget-object v4, Lg;->bY:[I

    aget v4, v4, v10

    aget v3, v3, v4

    sub-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bP:[I

    sget-object v5, Lg;->bY:[I

    aget v5, v5, v10

    aget v4, v4, v5

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_11d
    :goto_11d
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_7

    :cond_122
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_1da

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_1da

    sget-object v0, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bX:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->ct:[I

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v2

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cp:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v11

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v11

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    add-int/lit8 v3, v3, -0x2

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v11

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v6

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_f2

    :cond_1da
    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bX:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v2

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v11

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v11

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v11

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget-object v1, Lg;->K:[I

    aget v1, v1, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v11

    add-int/2addr v1, v3

    sget-object v3, Lg;->L:[I

    aget v3, v3, v10

    sget-object v4, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v4, v4, v5

    aget-object v4, v4, v6

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_f2

    :cond_281
    sget v0, Lq;->as:I

    const/4 v1, 0x4

    if-ne v0, v1, :cond_40b

    sget-object v0, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bX:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bX:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bX:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->cs:[I

    aget v3, v3, v10

    sub-int/2addr v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v2

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v2

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cm:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v11

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cm:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v11

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cm:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v11

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v11

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    add-int/lit8 v0, v0, -0x2

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v11

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cn:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v6

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v6

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :goto_3c2
    sget-object v0, Lg;->bY:[I

    aget v0, v0, v10

    if-eq v0, v12, :cond_11d

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bY:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bY:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bY:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bO:[I

    sget-object v7, Lg;->bY:[I

    aget v7, v7, v10

    aget v3, v3, v7

    add-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bP:[I

    sget-object v8, Lg;->bY:[I

    aget v8, v8, v10

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_11d

    :cond_40b
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_553

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_553

    sget-object v0, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bX:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bX:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bX:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->ct:[I

    aget v3, v3, v10

    sub-int/2addr v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v2

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v2

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cp:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v11

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cp:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v11

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cp:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v11

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v11

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    add-int/lit8 v0, v0, -0x2

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v11

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v6

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v6

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_3c2

    :cond_553
    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bX:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bX:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bX:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v2

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v2

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v11

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v11

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v11

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v11

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v11

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget-object v3, Lg;->bW:[I

    aget v3, v3, v10

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v4, Lg;->bW:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget-object v5, Lg;->bW:[I

    aget v5, v5, v10

    aget-object v3, v3, v5

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lg;->K:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v7, Lg;->bW:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    aget-object v3, v3, v6

    aget v3, v3, v11

    sub-int v7, v0, v3

    sget-object v0, Lg;->L:[I

    aget v0, v0, v10

    sget-object v3, Lg;->bQ:[[[I

    sget-object v8, Lg;->bW:[I

    aget v8, v8, v10

    aget-object v3, v3, v8

    aget-object v3, v3, v6

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_3c2
.end method

.method public static final d()V
    .registers 9

    const/16 v8, 0x14

    const/16 v7, 0xb

    const/16 v6, 0xa

    const/4 v5, -0x1

    const/4 v0, 0x0

    sput v5, Lg;->aq:I

    sget-object v1, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_28

    const/16 v1, 0x14

    :try_start_10
    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_15
    if-lt v1, v8, :cond_4e

    const/16 v1, 0xb

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->N:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_1e
    if-lt v1, v7, :cond_6e

    const/16 v1, 0xa

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->ci:[Ljavax/microedition/lcdui/Image;
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_26} :catch_af

    :goto_26
    if-lt v0, v6, :cond_8e

    :cond_28
    :goto_28
    invoke-static {}, Lg;->e()V

    const/16 v0, 0x16

    sput v0, Lg;->az:I

    const/16 v0, 0x20

    sput v0, Lg;->aA:I

    sget v0, Lg;->az:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aB:I

    sget v0, Lg;->aA:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aC:I

    sget v0, Lg;->az:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->aD:I

    sget v0, Lg;->aA:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->aE:I

    sput v5, Lg;->bi:I

    return-void

    :cond_4e
    :try_start_4e
    sget-object v2, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/cb"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_6e
    sget-object v2, Lg;->N:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/ch"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1e

    :cond_8e
    sget-object v1, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/cp/cl"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_ab
    .catch Ljava/lang/Exception; {:try_start_4e .. :try_end_ab} :catch_af

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_26

    :catch_af
    move-exception v0

    goto/16 :goto_28
.end method

.method public static final d(I)V
    .registers 6

    const/16 v4, 0x9

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v1, -0x1

    if-ne p0, v4, :cond_19

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_19

    const/16 v0, 0x6f0

    sput v0, Lg;->bo:I

    const/16 v0, 0x168

    sput v0, Lg;->bp:I

    sput v3, Lg;->bs:I

    sput v4, Lg;->bn:I

    sput v2, Lg;->bL:I

    :cond_19
    const/16 v0, 0xe

    if-ne p0, v0, :cond_22

    sput-boolean v2, Lg;->bm:Z

    sput v1, Lg;->bn:I

    :cond_21
    :goto_21
    return-void

    :cond_22
    sget-boolean v0, Lg;->bm:Z

    if-eqz v0, :cond_28

    sput p0, Lg;->bn:I

    :cond_28
    sget v0, Lg;->bn:I

    if-ne v0, p0, :cond_21

    const/4 v0, 0x3

    invoke-static {v0}, Lg;->e(I)V

    sput v1, Lg;->cu:I

    const/16 v0, 0x16

    sput v0, Lg;->bu:I

    const/16 v0, 0x20

    sput v0, Lg;->bv:I

    sget v0, Lg;->bu:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bw:I

    sget v0, Lg;->bv:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bx:I

    sget v0, Lg;->bu:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->by:I

    sget v0, Lg;->bv:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->bz:I

    sget-boolean v0, Lg;->bm:Z

    if-eqz v0, :cond_6b

    sget v0, Lg;->at:I

    sget v1, Lg;->aF:I

    mul-int/lit8 v1, v1, 0xa

    sub-int/2addr v0, v1

    sput v0, Lg;->bo:I

    sget v0, Lg;->au:I

    sput v0, Lg;->bp:I

    sget v0, Lg;->aF:I

    sput v0, Lg;->bA:I

    const/4 v0, 0x4

    sput v0, Lg;->bs:I

    goto :goto_21

    :cond_6b
    sput v3, Lg;->bs:I

    goto :goto_21
.end method

.method public static final d(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, -0x1

    const/16 v9, 0x18

    const/4 v10, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    sget v0, Lg;->bn:I

    sget v1, Lq;->as:I

    if-eq v0, v1, :cond_d

    :cond_c
    :goto_c
    return-void

    :cond_d
    sget v0, Lg;->bA:I

    if-ne v0, v10, :cond_b5

    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget-object v1, Lg;->bQ:[[[I

    sget v3, Lg;->bt:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->bo:I

    sget-object v3, Lg;->bQ:[[[I

    sget v4, Lg;->bt:I

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->bp:I

    sget-object v4, Lg;->bQ:[[[I

    sget v5, Lg;->bt:I

    aget-object v4, v4, v5

    aget-object v4, v4, v2

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget v3, Lg;->bt:I

    aget-object v1, v1, v3

    aget-object v1, v1, v10

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->bo:I

    sget-object v3, Lg;->bQ:[[[I

    sget v4, Lg;->bt:I

    aget-object v3, v3, v4

    aget-object v3, v3, v10

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->bp:I

    sget-object v4, Lg;->bQ:[[[I

    sget v5, Lg;->bt:I

    aget-object v4, v4, v5

    aget-object v4, v4, v10

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget v3, Lg;->bt:I

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lg;->bo:I

    sget-object v3, Lg;->bQ:[[[I

    sget v4, Lg;->bt:I

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v10

    add-int/2addr v1, v3

    sget v3, Lg;->bp:I

    sget-object v4, Lg;->bQ:[[[I

    sget v5, Lg;->bt:I

    aget-object v4, v4, v5

    aget-object v4, v4, v6

    aget v4, v4, v6

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget v0, Lg;->cu:I

    if-eq v0, v11, :cond_c

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->cu:I

    aget-object v0, v0, v1

    sget v1, Lg;->bo:I

    sget-object v3, Lg;->bO:[I

    sget v4, Lg;->cu:I

    aget v3, v3, v4

    sub-int/2addr v1, v3

    sget v3, Lg;->bp:I

    sget-object v4, Lg;->bP:[I

    sget v5, Lg;->cu:I

    aget v4, v4, v5

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_c

    :cond_b5
    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget-object v1, Lg;->bQ:[[[I

    sget v3, Lg;->bt:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget-object v3, Lg;->bQ:[[[I

    sget v4, Lg;->bt:I

    aget-object v3, v3, v4

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget-object v3, Lg;->bQ:[[[I

    sget v5, Lg;->bt:I

    aget-object v3, v3, v5

    aget-object v3, v3, v2

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->bo:I

    sget-object v3, Lg;->bQ:[[[I

    sget v7, Lg;->bt:I

    aget-object v3, v3, v7

    aget-object v3, v3, v2

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->bp:I

    sget-object v3, Lg;->bQ:[[[I

    sget v8, Lg;->bt:I

    aget-object v3, v3, v8

    aget-object v3, v3, v2

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget v3, Lg;->bt:I

    aget-object v1, v1, v3

    aget-object v1, v1, v10

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget v4, Lg;->bt:I

    aget-object v3, v3, v4

    aget-object v3, v3, v10

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget v5, Lg;->bt:I

    aget-object v3, v3, v5

    aget-object v3, v3, v10

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->bo:I

    sget-object v3, Lg;->bQ:[[[I

    sget v7, Lg;->bt:I

    aget-object v3, v3, v7

    aget-object v3, v3, v10

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->bp:I

    sget-object v3, Lg;->bQ:[[[I

    sget v8, Lg;->bt:I

    aget-object v3, v3, v8

    aget-object v3, v3, v10

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lg;->bQ:[[[I

    sget v3, Lg;->bt:I

    aget-object v1, v1, v3

    aget-object v1, v1, v6

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget v4, Lg;->bt:I

    aget-object v3, v3, v4

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lg;->bQ:[[[I

    sget v5, Lg;->bt:I

    aget-object v3, v3, v5

    aget-object v3, v3, v6

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->bo:I

    sget-object v3, Lg;->bQ:[[[I

    sget v7, Lg;->bt:I

    aget-object v3, v3, v7

    aget-object v3, v3, v6

    aget v3, v3, v10

    sub-int v7, v0, v3

    sget v0, Lg;->bp:I

    sget-object v3, Lg;->bQ:[[[I

    sget v8, Lg;->bt:I

    aget-object v3, v3, v8

    aget-object v3, v3, v6

    aget v3, v3, v6

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget v0, Lg;->cu:I

    if-eq v0, v11, :cond_c

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->cu:I

    aget-object v1, v0, v1

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v3, Lg;->cu:I

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    sget v3, Lg;->cu:I

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lg;->bo:I

    sget-object v3, Lg;->bO:[I

    sget v7, Lg;->cu:I

    aget v3, v3, v7

    add-int v7, v0, v3

    sget v0, Lg;->bp:I

    sget-object v3, Lg;->bP:[I

    sget v8, Lg;->cu:I

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_c
.end method

.method public static e()V
    .registers 5

    const/16 v4, 0xb

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    const/4 v0, 0x0

    move v1, v0

    :goto_b
    if-lt v1, v4, :cond_e

    return-void

    :cond_e
    :try_start_e
    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/c/w"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "t"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    sget v3, Lg;->as:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_37
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_37} :catch_3b

    :goto_37
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_b

    :catch_3b
    move-exception v0

    :try_start_3c
    sget-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/c/w"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, "t0.png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_59
    .catch Ljava/io/IOException; {:try_start_3c .. :try_end_59} :catch_5a

    goto :goto_37

    :catch_5a
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_37
.end method

.method private static e(I)V
    .registers 8

    const/4 v6, 0x2

    const/4 v1, 0x0

    sget-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_17

    filled-new-array {p0, v6}, [I

    move-result-object v0

    const-class v2, Ljavax/microedition/lcdui/Image;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    move v2, v1

    :goto_15
    if-lt v2, p0, :cond_21

    :cond_17
    sget v0, Lq;->as:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_65

    sget-object v0, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    if-eqz v0, :cond_54

    :cond_20
    return-void

    :cond_21
    move v0, v1

    :goto_22
    if-lt v0, v6, :cond_28

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_15

    :cond_28
    :try_start_28
    sget-object v3, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v2

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/cp/f"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "h"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v0
    :try_end_51
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_51} :catch_ee

    :goto_51
    add-int/lit8 v0, v0, 0x1

    goto :goto_22

    :cond_54
    filled-new-array {p0, v6}, [I

    move-result-object v0

    const-class v2, Ljavax/microedition/lcdui/Image;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    move v2, v1

    :goto_63
    if-lt v2, p0, :cond_8b

    :cond_65
    sget v0, Lq;->as:I

    const/16 v2, 0x9

    if-ne v0, v2, :cond_20

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_20

    sget-object v0, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_20

    filled-new-array {p0, v6}, [I

    move-result-object v0

    const-class v2, Ljavax/microedition/lcdui/Image;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    move v2, v1

    :goto_82
    if-ge v2, p0, :cond_20

    move v0, v1

    :goto_85
    if-lt v0, v6, :cond_be

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_82

    :cond_8b
    move v0, v1

    :goto_8c
    if-lt v0, v6, :cond_92

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_63

    :cond_92
    :try_start_92
    sget-object v3, Lg;->co:[[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v2

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/cp/d"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "h"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v0
    :try_end_bb
    .catch Ljava/lang/Exception; {:try_start_92 .. :try_end_bb} :catch_ec

    :goto_bb
    add-int/lit8 v0, v0, 0x1

    goto :goto_8c

    :cond_be
    :try_start_be
    sget-object v3, Lg;->cr:[[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v2

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/cp/h"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "h"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v0
    :try_end_e7
    .catch Ljava/lang/Exception; {:try_start_be .. :try_end_e7} :catch_ea

    :goto_e7
    add-int/lit8 v0, v0, 0x1

    goto :goto_85

    :catch_ea
    move-exception v3

    goto :goto_e7

    :catch_ec
    move-exception v3

    goto :goto_bb

    :catch_ee
    move-exception v3

    goto/16 :goto_51
.end method

.method private static f(I)V
    .registers 7

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/16 v1, 0x9

    if-ne p0, v1, :cond_a

    sget-boolean v1, Lg;->C:Z

    if-nez v1, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    sget-object v1, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_a

    const/4 v1, 0x7

    :try_start_10
    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_15
    if-lt v1, v5, :cond_3e

    const/4 v1, 0x7

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lg;->cp:[Ljavax/microedition/lcdui/Image;

    :goto_1c
    if-ge v0, v5, :cond_a

    sget-object v1, Lg;->cp:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/cp/hl"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_1c

    :cond_3e
    sget-object v2, Lg;->cq:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/cp/hb"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_5b} :catch_5e

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :catch_5e
    move-exception v0

    goto :goto_a
.end method

.method public static f()Z
    .registers 2

    sget v0, Lg;->au:I

    sget v1, Lq;->aI:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_1c

    sget v0, Lg;->at:I

    sget v1, Lq;->aH:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0xc8

    if-ge v0, v1, :cond_1c

    const/4 v0, 0x1

    :goto_1b
    return v0

    :cond_1c
    const/4 v0, 0x0

    goto :goto_1b
.end method

.method public static g()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lg;->ck:[[Ljavax/microedition/lcdui/Image;

    return-void
.end method

.method private static g(I)V
    .registers 7

    const/4 v1, 0x0

    sget v0, Lg;->aJ:I

    sget-object v2, Lg;->ca:[I

    aget v2, v2, p0

    sget-object v3, Lg;->M:[I

    aget v3, v3, p0

    neg-int v3, v3

    invoke-static {v2, v0, v3}, La;->a(III)Z

    move-result v2

    if-nez v2, :cond_65

    sget-object v2, La;->e:[I

    sget-object v3, Lg;->ca:[I

    aget v3, v3, p0

    aget v2, v2, v3

    sget-object v3, La;->f:[I

    sget-object v4, Lg;->ca:[I

    aget v4, v4, p0

    aget v3, v3, v4

    sget-object v4, La;->g:[I

    sget-object v5, Lg;->ca:[I

    aget v5, v5, p0

    aget v4, v4, v5

    shr-int/lit8 v4, v4, 0x1

    sub-int/2addr v3, v4

    sget-object v4, La;->k:[I

    sget-object v5, Lg;->ca:[I

    aget v5, v5, p0

    aget v4, v4, v5

    invoke-static {v2, v3, v4}, Lq;->c(III)Z

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "-"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, La;->e:[I

    sget-object v3, Lg;->ca:[I

    aget v3, v3, p0

    aget v2, v2, v3

    sget-object v3, La;->f:[I

    sget-object v4, Lg;->ca:[I

    aget v4, v4, p0

    aget v3, v3, v4

    sget-object v4, La;->g:[I

    sget-object v5, Lg;->ca:[I

    aget v5, v5, p0

    aget v4, v4, v5

    sub-int/2addr v3, v4

    const/4 v5, -0x2

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_65
    return-void
.end method

.method public static h()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lg;->ci:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->cd:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->cj:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method private static h(I)V
    .registers 6

    const/4 v4, 0x5

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, La;->c:I

    if-lt v0, v2, :cond_8

    return-void

    :cond_8
    sget-object v2, La;->i:[I

    aget v2, v2, v0

    if-eq v2, v4, :cond_4f

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v3, Lg;->L:[I

    aget v3, v3, p0

    if-ne v2, v3, :cond_4f

    sget-object v2, Lg;->K:[I

    aget v2, v2, p0

    sget-object v3, Lg;->M:[I

    aget v3, v3, p0

    shl-int/lit8 v3, v3, 0x3

    add-int/2addr v2, v3

    sget-object v3, La;->e:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_4f

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v3, Lg;->K:[I

    aget v3, v3, p0

    if-ge v2, v3, :cond_52

    sget-object v2, Lg;->M:[I

    const/4 v3, -0x1

    aput v3, v2, p0

    :goto_3f
    sget-object v2, Lg;->bT:[I

    aput v4, v2, p0

    sget-object v2, Lg;->bU:[I

    sget-object v3, Lg;->bV:[I

    aput v1, v3, p0

    aput v1, v2, p0

    sget-object v2, Lg;->ca:[I

    aput v0, v2, p0

    :cond_4f
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_52
    sget-object v2, Lg;->M:[I

    const/4 v3, 0x1

    aput v3, v2, p0

    goto :goto_3f
.end method

.method public static final i()V
    .registers 11

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v1, -0x1

    const/4 v0, 0x1

    const/4 v6, 0x0

    sget v2, Lg;->bn:I

    sget v3, Lq;->as:I

    if-eq v2, v3, :cond_c

    :cond_b
    :goto_b
    return-void

    :cond_c
    sget v2, Lq;->as:I

    const/16 v3, 0xd

    if-ne v2, v3, :cond_1c

    sget-boolean v2, Lq;->aA:Z

    if-eqz v2, :cond_1c

    sget v2, Lq;->aB:I

    if-lt v2, v0, :cond_1c

    sput v0, Lg;->bs:I

    :cond_1c
    :try_start_1c
    sget v2, Lg;->bs:I

    packed-switch v2, :pswitch_data_58c

    :pswitch_21  #0x6
    goto :goto_b

    :pswitch_22  #0x1
    sget v2, Lg;->bL:I

    if-lez v2, :cond_29

    invoke-static {}, Lg;->u()V

    :cond_29
    sget v2, Lg;->bB:I

    add-int/lit8 v2, v2, 0x1

    sput v2, Lg;->bB:I

    const/16 v3, 0x1e

    if-le v2, v3, :cond_36

    const/4 v2, 0x0

    sput v2, Lg;->bB:I

    :cond_36
    sget v2, Lg;->bB:I

    rem-int/lit8 v2, v2, 0xf

    if-ge v2, v10, :cond_68

    const/4 v2, 0x0

    sput v2, Lg;->bt:I

    :goto_3f
    sget-boolean v2, Lg;->bm:Z

    if-eqz v2, :cond_4e

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x6

    if-nez v2, :cond_4e

    move v2, v6

    :goto_4a
    sget v3, La;->c:I

    if-lt v2, v3, :cond_6c

    :cond_4e
    :goto_4e
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xf

    if-nez v0, :cond_b

    invoke-static {}, Lg;->u()V
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_57} :catch_58

    goto :goto_b

    :catch_58
    move-exception v0

    sget v0, Lg;->at:I

    sput v0, Lg;->bo:I

    sget v0, Lg;->au:I

    sput v0, Lg;->bp:I

    sput v6, Lg;->bq:I

    sput v6, Lg;->br:I

    sput v9, Lg;->bs:I

    goto :goto_b

    :cond_68
    const/4 v2, 0x1

    :try_start_69
    sput v2, Lg;->bt:I

    goto :goto_3f

    :cond_6c
    sget-object v3, La;->i:[I

    aget v3, v3, v2

    if-eq v3, v10, :cond_a9

    sget-object v3, La;->f:[I

    aget v3, v3, v2

    sget v4, Lg;->bp:I

    sub-int/2addr v3, v4

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    const/16 v4, 0x28

    if-ge v3, v4, :cond_a9

    sget-object v3, La;->e:[I

    aget v3, v3, v2

    sget v4, Lg;->bo:I

    sub-int/2addr v3, v4

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    const/16 v4, 0x3c

    if-ge v3, v4, :cond_a9

    sget-object v3, La;->e:[I

    aget v2, v3, v2

    sget v3, Lg;->bo:I

    if-le v2, v3, :cond_a7

    :goto_98
    sput v0, Lg;->bA:I

    const/4 v0, 0x5

    sput v0, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->cv:I

    const/4 v0, 0x0

    sput v0, Lg;->bB:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    goto :goto_4e

    :cond_a7
    move v0, v1

    goto :goto_98

    :cond_a9
    add-int/lit8 v2, v2, 0x1

    goto :goto_4a

    :pswitch_ac  #0x2
    sget v2, Lg;->bB:I

    add-int/lit8 v2, v2, 0x1

    sput v2, Lg;->bB:I

    const/16 v3, 0xa

    if-lt v2, v3, :cond_b9

    const/4 v2, 0x0

    sput v2, Lg;->bB:I

    :cond_b9
    sget v2, Lg;->bB:I

    shr-int/lit8 v2, v2, 0x1

    add-int/lit8 v2, v2, 0x2

    sput v2, Lg;->bt:I

    sget v2, Lg;->bA:I

    if-ne v2, v0, :cond_160

    sget v0, Lg;->bo:I

    sget v2, Lg;->bw:I

    add-int/2addr v0, v2

    sget v2, Lg;->bp:I

    sget v3, Lg;->bx:I

    sub-int/2addr v2, v3

    const/4 v3, 0x4

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_f4

    sget v0, Lg;->bL:I

    if-eqz v0, :cond_e3

    const/4 v0, 0x3

    sput v0, Lg;->bs:I

    const/16 v0, -0xa

    sput v0, Lg;->br:I

    goto/16 :goto_b

    :cond_e3
    const/4 v0, 0x0

    sput v0, Lg;->bq:I

    sget v0, Lg;->bo:I

    sget v2, Lg;->bw:I

    add-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->bw:I

    sub-int/2addr v0, v2

    sput v0, Lg;->bo:I

    :cond_f4
    :goto_f4
    sget v0, Lg;->bL:I

    const/16 v2, 0x2710

    if-ne v0, v2, :cond_fe

    const/16 v0, 0x9

    sput v0, Lg;->bq:I

    :cond_fe
    sget v0, Lg;->bo:I

    sget v2, Lg;->bq:I

    add-int/2addr v0, v2

    sput v0, Lg;->bo:I

    if-gez v0, :cond_10a

    const/4 v0, 0x0

    sput v0, Lg;->bo:I

    :cond_10a
    sget v0, Lg;->bo:I

    sget v2, Lj;->c:I

    if-lt v0, v2, :cond_116

    sget v0, Lj;->c:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->bo:I

    :cond_116
    sget v0, Lq;->aX:I

    if-eq v0, v1, :cond_1a9

    sget v0, Lg;->bo:I

    sget-object v1, Lq;->aY:[I

    sget v2, Lq;->aX:I

    aget v1, v1, v2

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-lt v0, v1, :cond_13c

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    sget v0, Lg;->bo:I

    sget v1, Lg;->bp:I

    const/4 v2, 0x2

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_199

    const/4 v0, 0x1

    sput v0, Lg;->bs:I

    :cond_13c
    :goto_13c
    sget v0, Lg;->bA:I

    sget v1, Lg;->bo:I

    sget v2, Lg;->bA:I

    shl-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    sget v2, Lg;->bp:I

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    sget v0, Lg;->bL:I

    if-eqz v0, :cond_1da

    sget v0, Lg;->bL:I

    sget v1, Lg;->bo:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-ge v0, v1, :cond_b

    const/4 v0, 0x0

    sput v0, Lg;->bL:I

    goto/16 :goto_b

    :cond_160
    sget v0, Lg;->bo:I

    sget v2, Lg;->bw:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    sget v2, Lg;->bp:I

    sget v3, Lg;->bx:I

    sub-int/2addr v2, v3

    const/16 v3, 0x8

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_f4

    sget v0, Lg;->bL:I

    if-eqz v0, :cond_181

    const/4 v0, 0x3

    sput v0, Lg;->bs:I

    const/16 v0, -0xa

    sput v0, Lg;->br:I

    goto/16 :goto_b

    :cond_181
    const/4 v0, 0x0

    sput v0, Lg;->bq:I

    sget v0, Lg;->bo:I

    sget v2, Lg;->bw:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lj;->f:I

    add-int/2addr v0, v2

    sget v2, Lg;->bw:I

    add-int/2addr v0, v2

    sput v0, Lg;->bo:I

    goto/16 :goto_f4

    :cond_199
    const/4 v0, 0x4

    sput v0, Lg;->bs:I

    const/4 v0, 0x2

    sput v0, Lg;->br:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->bq:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    goto :goto_13c

    :cond_1a9
    sget v0, Lg;->bo:I

    sget v1, Lg;->bA:I

    sget v2, Lg;->bu:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    sget v1, Lg;->bp:I

    invoke-static {v0, v1}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    const/4 v1, 0x2

    if-eq v0, v1, :cond_13c

    sget v0, Lg;->bL:I

    if-eqz v0, :cond_1c9

    const/4 v0, 0x3

    sput v0, Lg;->bs:I

    const/16 v0, -0xa

    sput v0, Lg;->br:I

    goto/16 :goto_b

    :cond_1c9
    const/4 v0, 0x1

    sput v0, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->bt:I

    const/4 v0, 0x0

    sput v0, Lg;->bq:I

    const/4 v0, 0x0

    sput v0, Lg;->bB:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    goto/16 :goto_13c

    :cond_1da
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_b

    invoke-static {}, Lg;->u()V

    goto/16 :goto_b

    :pswitch_1e5  #0x3
    sget v1, Lg;->bq:I

    if-nez v1, :cond_1ef

    sget v1, Lg;->bA:I

    shl-int/lit8 v1, v1, 0x2

    sput v1, Lg;->bq:I

    :cond_1ef
    sget v1, Lg;->bA:I

    if-ne v1, v0, :cond_292

    sget v1, Lg;->bo:I

    sget v2, Lg;->bw:I

    add-int/2addr v1, v2

    sget v2, Lg;->bp:I

    sget v3, Lg;->bx:I

    sub-int/2addr v2, v3

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x4

    if-ne v1, v9, :cond_208

    const/4 v1, 0x0

    sput v1, Lg;->bq:I

    :cond_208
    :goto_208
    sget v1, Lg;->au:I

    if-gez v1, :cond_212

    const/4 v1, 0x0

    sput v1, Lg;->au:I

    const/4 v1, -0x1

    sput v1, Lg;->aw:I

    :cond_212
    sget v1, Lg;->bL:I

    const/16 v2, 0x2710

    if-ne v1, v2, :cond_21b

    const/4 v1, 0x5

    sput v1, Lg;->bq:I

    :cond_21b
    sget v1, Lg;->bo:I

    sget v2, Lg;->bq:I

    add-int/2addr v1, v2

    sput v1, Lg;->bo:I

    if-gez v1, :cond_227

    const/4 v1, 0x0

    sput v1, Lg;->bo:I

    :cond_227
    sget v1, Lg;->bo:I

    sget v2, Lj;->c:I

    if-lt v1, v2, :cond_233

    sget v1, Lj;->c:I

    add-int/lit8 v1, v1, -0x1

    sput v1, Lg;->bo:I

    :cond_233
    sget v1, Lg;->bp:I

    sget v2, Lg;->br:I

    add-int/2addr v1, v2

    sput v1, Lg;->bp:I

    sget v1, Lg;->bB:I

    const/4 v1, 0x7

    sput v1, Lg;->bt:I

    sget v1, Lg;->bq:I

    if-le v1, v0, :cond_249

    sget v0, Lg;->bq:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->bq:I

    :cond_249
    sget v0, Lg;->br:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->br:I

    if-nez v0, :cond_25d

    const/4 v0, 0x4

    sput v0, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->bB:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    const/4 v0, 0x1

    sput v0, Lg;->br:I

    :cond_25d
    sget v0, Lg;->bD:I

    if-gez v0, :cond_267

    sget v0, Lg;->bD:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bD:I

    :cond_267
    sget v0, Lg;->bp:I

    sget v1, Lg;->bv:I

    if-le v0, v1, :cond_b

    sget v0, Lg;->bo:I

    sget v1, Lg;->bp:I

    sget v2, Lg;->bv:I

    sub-int/2addr v1, v2

    const/16 v2, 0x4000

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_b

    sget v0, Lg;->bp:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    sput v0, Lg;->bp:I

    const/4 v0, 0x4

    sput v0, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->bB:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    const/4 v0, 0x1

    sput v0, Lg;->br:I

    goto/16 :goto_b

    :cond_292
    sget v1, Lg;->bo:I

    sget v2, Lg;->bw:I

    sub-int/2addr v1, v2

    sget v2, Lg;->bp:I

    sget v3, Lg;->bx:I

    sub-int/2addr v2, v3

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x8

    const/16 v2, 0x8

    if-ne v1, v2, :cond_208

    const/4 v1, 0x0

    sput v1, Lg;->bq:I

    goto/16 :goto_208

    :pswitch_2ab  #0x4
    sget v2, Lg;->bA:I

    if-ne v2, v0, :cond_3a9

    sget v2, Lg;->bo:I

    sget v3, Lg;->bu:I

    add-int/2addr v2, v3

    sget v3, Lg;->bp:I

    invoke-static {v2, v3}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x4

    if-ne v2, v9, :cond_2c1

    const/4 v2, 0x0

    sput v2, Lg;->bq:I

    :cond_2c1
    :goto_2c1
    const/4 v2, -0x1

    sput v2, Lg;->cu:I

    sget v2, Lg;->bo:I

    sget v3, Lg;->bq:I

    add-int/2addr v2, v3

    sput v2, Lg;->bo:I

    if-gez v2, :cond_2d0

    const/4 v2, 0x0

    sput v2, Lg;->bo:I

    :cond_2d0
    sget v2, Lg;->bo:I

    sget v3, Lj;->c:I

    if-lt v2, v3, :cond_2dc

    sget v2, Lj;->c:I

    add-int/lit8 v2, v2, -0x1

    sput v2, Lg;->bo:I

    :cond_2dc
    sget v2, Lg;->bp:I

    sget v3, Lg;->br:I

    add-int/2addr v2, v3

    sput v2, Lg;->bp:I

    sget v2, Lg;->br:I

    const/16 v3, 0x12

    if-ge v2, v3, :cond_2ef

    sget v2, Lg;->br:I

    add-int/lit8 v2, v2, 0x1

    sput v2, Lg;->br:I

    :cond_2ef
    sget v2, Lg;->br:I

    if-le v2, v10, :cond_2f6

    const/4 v2, 0x0

    sput v2, Lg;->bq:I

    :cond_2f6
    sget v2, Lg;->bq:I

    if-le v2, v0, :cond_300

    sget v2, Lg;->bq:I

    add-int/lit8 v2, v2, -0x1

    sput v2, Lg;->bq:I

    :cond_300
    const/16 v2, 0xc

    sput v2, Lg;->bt:I

    sget v2, Lg;->bp:I

    sget v3, Lj;->d:I

    if-lt v2, v3, :cond_317

    sget v2, Lj;->d:I

    add-int/lit8 v2, v2, -0x1

    sput v2, Lg;->bp:I

    const/4 v2, 0x3

    sput v2, Lg;->bs:I

    const/16 v2, -0x14

    sput v2, Lg;->br:I

    :cond_317
    sget v2, Lg;->br:I

    if-le v2, v9, :cond_351

    sget v2, Lg;->bo:I

    sget v3, Lg;->bp:I

    invoke-static {v2, v3}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_351

    const/4 v2, 0x1

    sput v2, Lg;->bs:I

    const/4 v2, 0x0

    sput v2, Lg;->br:I

    sput v2, Lg;->bq:I

    const/4 v2, 0x0

    sput v2, Lg;->bC:I

    sput v2, Lg;->bB:I

    sget v2, Lg;->bp:I

    invoke-static {v2}, Lj;->e(I)I

    move-result v2

    sput v2, Lg;->bp:I

    const/4 v2, -0x1

    sget v3, Lg;->bo:I

    add-int/lit8 v3, v3, 0x8

    sget v4, Lg;->bp:I

    invoke-static {v2, v3, v4}, Lq;->b(III)Z

    const/4 v2, 0x1

    sget v3, Lg;->bo:I

    add-int/lit8 v3, v3, -0x8

    sget v4, Lg;->bp:I

    invoke-static {v2, v3, v4}, Lq;->b(III)Z

    :cond_351
    sget v2, Lg;->bo:I

    sget v3, Lg;->bp:I

    const/16 v4, 0x40

    invoke-static {v2, v3, v4}, Lj;->a(III)Z

    move-result v2

    if-eqz v2, :cond_395

    sget v2, Lg;->bo:I

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, 0x18

    const/16 v4, 0x1000

    invoke-static {v2, v3, v4}, Lj;->a(III)Z

    move-result v2

    if-eqz v2, :cond_395

    sget v2, Lg;->bp:I

    sget v3, Lj;->f:I

    rem-int/2addr v2, v3

    const/16 v3, 0x8

    if-le v2, v3, :cond_395

    sget v2, Lg;->bo:I

    sget v3, Lg;->bp:I

    invoke-static {v3}, Lj;->d(I)I

    move-result v3

    add-int/lit8 v3, v3, 0x8

    invoke-static {v2, v3}, Lq;->c(II)Z

    const/4 v2, 0x3

    sput v2, Lg;->bs:I

    sget v2, Lg;->at:I

    sget v3, Lg;->bo:I

    if-le v2, v3, :cond_38b

    move v1, v0

    :cond_38b
    sput v1, Lg;->bA:I

    shl-int/lit8 v0, v1, 0x2

    sput v0, Lg;->bq:I

    const/16 v0, -0xb

    sput v0, Lg;->br:I

    :cond_395
    sget v0, Lg;->br:I

    const/4 v1, 0x6

    if-le v0, v1, :cond_39d

    const/4 v0, 0x6

    sput v0, Lg;->bt:I

    :cond_39d
    sget v0, Lg;->bD:I

    if-gez v0, :cond_b

    sget v0, Lg;->bD:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bD:I

    goto/16 :goto_b

    :cond_3a9
    sget v2, Lg;->bo:I

    sget v3, Lg;->bu:I

    sub-int/2addr v2, v3

    sget v3, Lg;->bp:I

    invoke-static {v2, v3}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x8

    const/16 v3, 0x8

    if-ne v2, v3, :cond_2c1

    const/4 v2, 0x0

    sput v2, Lg;->bq:I

    goto/16 :goto_2c1

    :pswitch_3bf  #0x5
    sget v0, Lg;->bB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bB:I

    packed-switch v0, :pswitch_data_59e

    goto/16 :goto_b

    :pswitch_3ca  #0x1, 0x2, 0x3
    const/4 v0, -0x1

    sput v0, Lg;->cu:I

    const/16 v0, 0xd

    sput v0, Lg;->bt:I

    goto/16 :goto_b

    :pswitch_3d3  #0x4, 0x5
    const/4 v0, 0x0

    sput v0, Lg;->cu:I

    const/16 v0, 0xe

    sput v0, Lg;->bt:I

    goto/16 :goto_b

    :pswitch_3dc  #0x6
    const/4 v0, 0x1

    sput v0, Lg;->cu:I

    const/16 v0, 0xf

    sput v0, Lg;->bt:I

    sget v0, Lg;->aJ:I

    shl-int/lit8 v7, v0, 0x1

    sget v0, Lg;->bA:I

    if-lez v0, :cond_4ba

    sget v0, Lg;->bo:I

    add-int/lit8 v0, v0, -0x1e

    move v3, v0

    :goto_3f0
    sget v0, Lg;->bA:I

    if-lez v0, :cond_4c1

    sget v0, Lg;->bo:I

    add-int/lit8 v0, v0, 0x46

    move v2, v0

    :goto_3f9
    sget v0, Lg;->bp:I

    sget v4, Lg;->bv:I

    sub-int/2addr v0, v4

    add-int/lit8 v4, v0, -0x23

    sget v0, Lg;->bp:I

    add-int/lit8 v5, v0, 0xf

    move v0, v6

    :goto_405
    sget v8, La;->c:I

    if-lt v0, v8, :cond_4c8

    move v3, v1

    :goto_40a
    if-eq v3, v1, :cond_45d

    sget-object v0, Lo;->a:Lo;

    new-instance v1, Lh;

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    const/4 v5, 0x0

    invoke-direct {v1, v2, v4, v5}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->bA:I

    neg-int v0, v0

    const/4 v1, 0x1

    invoke-static {v3, v7, v0, v1}, La;->a(IIII)Z

    sget-object v0, La;->e:[I

    aget v0, v0, v3

    sget-object v1, La;->f:[I

    aget v1, v1, v3

    sget-object v2, La;->g:[I

    aget v2, v2, v3

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    sget v2, Lg;->bA:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    sget-object v5, La;->g:[I

    aget v3, v5, v3

    sub-int v3, v4, v3

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_45d
    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_b

    sget v0, Lg;->bp:I

    sget v1, Lq;->aI:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_b

    sget v0, Lg;->bo:I

    sget v1, Lg;->bA:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lq;->aH:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x28

    if-ge v0, v1, :cond_b

    sget v0, Lg;->bA:I

    neg-int v0, v0

    invoke-static {v7, v0}, Lq;->d(II)Z

    move-result v0

    if-nez v0, :cond_b

    sget v0, Lg;->bo:I

    sget v1, Lq;->aH:I

    sget v2, Lg;->bo:I

    sub-int/2addr v1, v2

    shr-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sget v1, Lg;->bp:I

    add-int/lit8 v1, v1, -0xc

    sget v2, Lg;->bA:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    sget v4, Lq;->aJ:I

    sub-int/2addr v3, v4

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    goto/16 :goto_b

    :cond_4ba
    sget v0, Lg;->bo:I

    add-int/lit8 v0, v0, -0x46

    move v3, v0

    goto/16 :goto_3f0

    :cond_4c1
    sget v0, Lg;->bo:I

    add-int/lit8 v0, v0, 0x1e

    move v2, v0

    goto/16 :goto_3f9

    :cond_4c8
    sget-object v8, La;->i:[I

    aget v8, v8, v0

    if-eq v8, v10, :cond_4e9

    sget-object v8, La;->e:[I

    aget v8, v8, v0

    if-lt v8, v3, :cond_4e9

    sget-object v8, La;->e:[I

    aget v8, v8, v0

    if-gt v8, v2, :cond_4e9

    sget-object v8, La;->f:[I

    aget v8, v8, v0

    if-lt v8, v4, :cond_4e9

    sget-object v8, La;->f:[I

    aget v8, v8, v0

    if-gt v8, v5, :cond_4e9

    move v3, v0

    goto/16 :goto_40a

    :cond_4e9
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_405

    :pswitch_4ed  #0x7
    const/4 v0, 0x2

    sput v0, Lg;->cu:I

    const/16 v0, 0xf

    sput v0, Lg;->bt:I

    goto/16 :goto_b

    :pswitch_4f6  #0x8
    const/4 v0, -0x1

    sput v0, Lg;->cu:I

    const/16 v0, 0x10

    sput v0, Lg;->bt:I

    goto/16 :goto_b

    :pswitch_4ff  #0x9
    const/4 v0, -0x1

    sput v0, Lg;->cu:I

    const/16 v0, 0xd

    sput v0, Lg;->bt:I

    const/4 v0, 0x1

    sput v0, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->bB:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    goto/16 :goto_b

    :pswitch_511  #0x7
    sget v2, Lg;->bo:I

    sget v3, Lg;->bw:I

    add-int/2addr v2, v3

    sget v3, Lg;->bp:I

    sget v4, Lg;->bx:I

    sub-int/2addr v3, v4

    invoke-static {v2, v3}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x4

    if-ne v2, v9, :cond_528

    sget v2, Lg;->bq:I

    neg-int v2, v2

    sput v2, Lg;->bq:I

    :cond_528
    sget v2, Lg;->bo:I

    sget v3, Lg;->bw:I

    sub-int/2addr v2, v3

    sget v3, Lg;->bp:I

    sget v4, Lg;->bx:I

    sub-int/2addr v3, v4

    invoke-static {v2, v3}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x8

    const/16 v3, 0x8

    if-ne v2, v3, :cond_541

    sget v2, Lg;->bq:I

    neg-int v2, v2

    sput v2, Lg;->bq:I

    :cond_541
    sget v2, Lg;->bo:I

    sget v3, Lg;->bq:I

    add-int/2addr v2, v3

    sput v2, Lg;->bo:I

    sget v2, Lg;->bp:I

    sget v3, Lg;->br:I

    add-int/2addr v2, v3

    sput v2, Lg;->bp:I

    const/4 v2, 0x7

    sput v2, Lg;->bt:I

    sget v2, Lg;->bq:I

    if-le v2, v0, :cond_55c

    sget v0, Lg;->bq:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->bq:I

    :cond_55c
    sget v0, Lg;->bq:I

    if-ge v0, v1, :cond_566

    sget v0, Lg;->bq:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bq:I

    :cond_566
    sget v0, Lg;->br:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->br:I

    if-lez v0, :cond_571

    const/4 v0, 0x0

    sput v0, Lg;->br:I

    :cond_571
    sget v0, Lg;->bB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bB:I

    const/4 v1, 0x7

    if-lt v0, v1, :cond_b

    const/4 v0, 0x4

    sput v0, Lg;->bs:I

    const/16 v0, -0x14

    sput v0, Lg;->bD:I

    const/4 v0, 0x0

    sput v0, Lg;->bC:I

    const/4 v0, 0x0

    sput v0, Lg;->bB:I

    const/4 v0, 0x1

    sput v0, Lg;->br:I
    :try_end_58a
    .catch Ljava/lang/Exception; {:try_start_69 .. :try_end_58a} :catch_58

    goto/16 :goto_b

    :pswitch_data_58c
    .packed-switch 0x1
        :pswitch_22  #00000001
        :pswitch_ac  #00000002
        :pswitch_1e5  #00000003
        :pswitch_2ab  #00000004
        :pswitch_3bf  #00000005
        :pswitch_21  #00000006
        :pswitch_511  #00000007
    .end packed-switch

    :pswitch_data_59e
    .packed-switch 0x1
        :pswitch_3ca  #00000001
        :pswitch_3ca  #00000002
        :pswitch_3ca  #00000003
        :pswitch_3d3  #00000004
        :pswitch_3d3  #00000005
        :pswitch_3dc  #00000006
        :pswitch_4ed  #00000007
        :pswitch_4f6  #00000008
        :pswitch_4ff  #00000009
    .end packed-switch
.end method

.method private static j()V
    .registers 9

    const/4 v8, -0x4

    const/4 v2, -0x1

    const/4 v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    sget v0, Lq;->as:I

    const/16 v3, 0xd

    if-ne v0, v3, :cond_10

    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_10

    :cond_f
    :goto_f
    return-void

    :cond_10
    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_f

    sget v0, Lg;->au:I

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x18

    if-gt v0, v3, :cond_31

    sget v0, Lg;->R:I

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x1

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_31

    sput v7, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    const/4 v0, -0x7

    sput v0, Lg;->U:I

    goto :goto_f

    :cond_31
    sget v0, Lg;->au:I

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x18

    if-gt v0, v3, :cond_4f

    sget v0, Lg;->R:I

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x19

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_4f

    sput v7, Lg;->V:I

    const/4 v0, 0x0

    sput v0, Lg;->T:I

    const/16 v0, -0xa

    sput v0, Lg;->U:I

    goto :goto_f

    :cond_4f
    sget v0, Lg;->R:I

    sget v3, Lq;->ay:I

    add-int/lit8 v3, v3, -0x18

    if-lt v0, v3, :cond_62

    sget v0, Lg;->R:I

    sget v3, Lq;->ay:I

    sget v4, Lq;->ab:I

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x18

    if-le v0, v3, :cond_c5

    :cond_62
    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->R:I

    if-le v0, v3, :cond_97

    move v0, v1

    :goto_6e
    sput v0, Lg;->ad:I

    sget v0, Lg;->at:I

    sget v3, Lg;->R:I

    if-le v0, v3, :cond_99

    sget v0, Lq;->ay:I

    add-int/lit8 v0, v0, -0x18

    :goto_7a
    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x14

    const/16 v4, 0x2000

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v4

    if-nez v4, :cond_a1

    sput v0, Lg;->R:I

    sput v3, Lg;->S:I

    const/4 v0, 0x4

    sput v0, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x4

    sput v0, Lg;->T:I

    sput v7, Lg;->U:I

    goto/16 :goto_f

    :cond_97
    move v0, v2

    goto :goto_6e

    :cond_99
    sget v0, Lq;->ay:I

    sget v3, Lq;->ab:I

    add-int/2addr v0, v3

    add-int/lit8 v0, v0, 0x18

    goto :goto_7a

    :cond_a1
    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    sget v4, Lg;->X:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_f

    sget v0, Lg;->at:I

    sget v3, Lg;->R:I

    if-le v0, v3, :cond_c3

    :goto_b7
    sput v1, Lg;->ad:I

    sput v6, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0xc

    sput v0, Lg;->T:I

    goto/16 :goto_f

    :cond_c3
    move v1, v2

    goto :goto_b7

    :cond_c5
    sget v0, Lg;->S:I

    sget v3, Lq;->az:I

    add-int/lit8 v3, v3, -0x1e

    if-lt v0, v3, :cond_d8

    sget v0, Lg;->S:I

    sget v3, Lq;->az:I

    sget v4, Lq;->ac:I

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x1e

    if-le v0, v3, :cond_109

    :cond_d8
    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->R:I

    if-le v0, v3, :cond_101

    :goto_e3
    sput v1, Lg;->ad:I

    sget v1, Lg;->at:I

    sget v0, Lg;->au:I

    sget v2, Lg;->S:I

    if-le v0, v2, :cond_103

    sget v0, Lq;->az:I

    add-int/lit8 v0, v0, -0x14

    :goto_f1
    sput v1, Lg;->R:I

    sput v0, Lg;->S:I

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    shl-int/lit8 v0, v0, 0x2

    sput v0, Lg;->T:I

    sput v8, Lg;->U:I

    goto/16 :goto_f

    :cond_101
    move v1, v2

    goto :goto_e3

    :cond_103
    sget v0, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v0, v2

    goto :goto_f1

    :cond_109
    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->R:I

    sub-int/2addr v0, v3

    invoke-static {v0}, Lq;->a(I)I

    move-result v3

    sget v0, Lg;->ax:I

    const/4 v4, 0x5

    if-ne v0, v4, :cond_14c

    const/16 v0, 0x28

    :goto_11e
    if-le v3, v0, :cond_2aa

    sget v0, Lg;->au:I

    sget v3, Lg;->S:I

    if-ge v0, v3, :cond_1c3

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v3, 0x4

    if-le v0, v3, :cond_1c3

    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_14f

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->T:I

    const/16 v0, -0x9

    sput v0, Lg;->U:I

    goto/16 :goto_f

    :cond_14c
    const/16 v0, 0x46

    goto :goto_11e

    :cond_14f
    move v0, v1

    :goto_150
    if-le v0, v7, :cond_18a

    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x2

    const/16 v4, 0x40

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_f

    sget v0, Lg;->S:I

    add-int/lit8 v0, v0, 0x18

    sget v3, Lj;->d:I

    if-ge v0, v3, :cond_17e

    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, 0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_1af

    :cond_17e
    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x7

    sput v0, Lg;->T:I

    sput v8, Lg;->U:I

    goto/16 :goto_f

    :cond_18a
    sget v3, Lg;->R:I

    sget v4, Lg;->ad:I

    mul-int/lit8 v4, v4, 0x18

    add-int/2addr v3, v4

    sget v4, Lg;->S:I

    mul-int/lit8 v5, v0, 0x18

    sub-int/2addr v4, v5

    invoke-static {v3, v4, v6}, Lj;->a(III)Z

    move-result v3

    if-eqz v3, :cond_1ac

    sput v7, Lg;->V:I

    sget v1, Lg;->ad:I

    mul-int/lit8 v1, v1, 0x6

    sput v1, Lg;->T:I

    mul-int/lit8 v0, v0, 0x3

    rsub-int/lit8 v0, v0, -0x5

    sput v0, Lg;->U:I

    goto/16 :goto_f

    :cond_1ac
    add-int/lit8 v0, v0, 0x1

    goto :goto_150

    :cond_1af
    sput v7, Lg;->V:I

    sget v0, Lg;->R:I

    sget v3, Lg;->at:I

    if-ge v0, v3, :cond_1c1

    :goto_1b7
    sput v1, Lg;->ad:I

    mul-int/lit8 v0, v1, 0x6

    sput v0, Lg;->T:I

    sput v8, Lg;->U:I

    goto/16 :goto_f

    :cond_1c1
    move v1, v2

    goto :goto_1b7

    :cond_1c3
    sget v0, Lg;->au:I

    sget v3, Lg;->S:I

    if-le v0, v3, :cond_27e

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v3, 0x4

    if-le v0, v3, :cond_27e

    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    sget v4, Lg;->X:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_1f5

    sget v0, Lg;->at:I

    sget v3, Lg;->R:I

    if-le v0, v3, :cond_1f3

    :goto_1e6
    sput v1, Lg;->ad:I

    sput v6, Lg;->V:I

    sget v0, Lg;->ad:I

    sget v1, Lq;->aC:I

    mul-int/2addr v0, v1

    sput v0, Lg;->T:I

    goto/16 :goto_f

    :cond_1f3
    move v1, v2

    goto :goto_1e6

    :cond_1f5
    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, 0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_213

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x7

    sput v0, Lg;->T:I

    const/4 v0, -0x5

    sput v0, Lg;->U:I

    goto/16 :goto_f

    :cond_213
    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x18

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_241

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->T:I

    const/4 v0, -0x7

    sput v0, Lg;->U:I

    :cond_22f
    :goto_22f
    sput v7, Lg;->V:I

    sget v0, Lg;->R:I

    sget v3, Lg;->at:I

    if-ge v0, v3, :cond_27c

    :goto_237
    sput v1, Lg;->ad:I

    shl-int/lit8 v0, v1, 0x2

    sput v0, Lg;->T:I

    sput v8, Lg;->U:I

    goto/16 :goto_f

    :cond_241
    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_25e

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x6

    sput v0, Lg;->T:I

    const/4 v0, -0x8

    sput v0, Lg;->U:I

    goto :goto_22f

    :cond_25e
    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    mul-int/lit8 v3, v3, 0x18

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x30

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_22f

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->T:I

    const/16 v0, -0xb

    sput v0, Lg;->U:I

    goto :goto_22f

    :cond_27c
    move v1, v2

    goto :goto_237

    :cond_27e
    sget v0, Lg;->R:I

    sget v3, Lg;->ad:I

    sget v4, Lg;->X:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sget v3, Lg;->S:I

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_f

    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->R:I

    if-le v0, v3, :cond_2a8

    :goto_299
    sput v1, Lg;->ad:I

    sput v6, Lg;->V:I

    sget v0, Lg;->ad:I

    sget v1, Lq;->aC:I

    add-int/lit8 v1, v1, -0x1

    mul-int/2addr v0, v1

    sput v0, Lg;->T:I

    goto/16 :goto_f

    :cond_2a8
    move v1, v2

    goto :goto_299

    :cond_2aa
    sput v1, Lg;->V:I

    goto/16 :goto_f
.end method

.method private static k()V
    .registers 8

    const/16 v7, 0xc

    const/16 v6, 0x8

    const/4 v5, 0x1

    const/4 v4, -0x1

    const/4 v1, 0x0

    sget v0, Lg;->au:I

    add-int/lit8 v0, v0, 0x4

    sget v2, Lj;->d:I

    if-lt v0, v2, :cond_15

    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    sput v1, Lg;->aL:I

    :cond_14
    :goto_14
    return-void

    :cond_15
    sput v4, Lg;->aq:I

    sget v0, Lg;->at:I

    sget v2, Lg;->av:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    sget v0, Lg;->au:I

    sget v2, Lg;->aw:I

    add-int/2addr v0, v2

    sput v0, Lg;->au:I

    sget v0, Lg;->aw:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aw:I

    sget v0, Lg;->av:I

    if-lez v0, :cond_39

    sget v0, Lp;->g:I

    if-ne v0, v4, :cond_39

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :cond_39
    const/4 v0, 0x7

    sput v0, Lg;->ay:I

    sget v0, Lg;->au:I

    add-int/lit8 v0, v0, 0x4

    sget v2, Lj;->d:I

    if-ge v0, v2, :cond_14

    sget v0, Lg;->aw:I

    const/4 v2, 0x4

    if-gt v0, v2, :cond_4d

    sget v0, Lp;->g:I

    if-eq v0, v4, :cond_be

    :cond_4d
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, 0x3

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    if-ne v0, v2, :cond_be

    sget v0, Lg;->aw:I

    if-le v0, v7, :cond_bb

    sput v6, Lg;->ax:I

    :goto_62
    sput v1, Lg;->aw:I

    sput v1, Lg;->av:I

    sput v1, Lg;->aH:I

    sput v1, Lg;->aG:I

    sget v0, Lg;->au:I

    add-int/lit8 v0, v0, 0x3

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Lg;->au:I

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, 0x8

    sget v2, Lg;->au:I

    invoke-static {v4, v0, v2}, Lq;->b(III)Z

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, -0x8

    sget v2, Lg;->au:I

    invoke-static {v5, v0, v2}, Lq;->b(III)Z

    move v0, v1

    :goto_87
    sget v2, Lq;->aP:I

    if-ge v0, v2, :cond_14

    sget v2, Lg;->au:I

    sget-object v3, Lq;->aS:[I

    aget v3, v3, v0

    if-ne v2, v3, :cond_b8

    sget v2, Lg;->at:I

    sget-object v3, Lq;->aR:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x10

    if-ge v2, v3, :cond_b8

    sget-object v2, Lq;->aR:[I

    aget v2, v2, v0

    sput v2, Lg;->at:I

    const/16 v2, 0x12

    sput v2, Lg;->ax:I

    sput v0, Lq;->aQ:I

    sget-object v2, Lq;->aT:[I

    sget v3, Lg;->aF:I

    aput v3, v2, v0

    sget-object v2, Lq;->aU:[I

    aput v1, v2, v0

    :cond_b8
    add-int/lit8 v0, v0, 0x1

    goto :goto_87

    :cond_bb
    sput v5, Lg;->ax:I

    goto :goto_62

    :cond_be
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    const/16 v3, 0x40

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_131

    sget v0, Lg;->au:I

    sget v2, Lj;->f:I

    rem-int/2addr v0, v2

    if-le v0, v6, :cond_131

    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_f2

    sget v0, Lg;->at:I

    const/16 v2, 0x318

    if-gt v0, v2, :cond_e1

    sget v0, Lg;->at:I

    const/16 v2, 0x2b8

    if-ge v0, v2, :cond_ed

    :cond_e1
    sget v0, Lg;->at:I

    const/16 v2, 0x1c8

    if-gt v0, v2, :cond_f2

    sget v0, Lg;->at:I

    const/16 v2, 0x150

    if-lt v0, v2, :cond_f2

    :cond_ed
    const/4 v0, 0x6

    sput v0, Lg;->ax:I

    goto/16 :goto_14

    :cond_f2
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x8

    invoke-static {v0, v2}, Lq;->c(II)Z

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x8

    sput v0, Lg;->au:I

    const/16 v0, 0xb

    sput v0, Lg;->ax:I

    sget v0, Lg;->aF:I

    shl-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    sget v0, Lg;->aw:I

    shr-int/lit8 v0, v0, 0x2

    sput v0, Lg;->aw:I

    sget v0, Lg;->au:I

    invoke-static {v0}, Lj;->d(I)I

    move-result v0

    add-int/lit8 v0, v0, 0xc

    sput v0, Lg;->au:I

    sget v0, Lg;->aN:I

    if-eqz v0, :cond_12f

    sget v0, Lp;->g:I

    if-ne v0, v4, :cond_12f

    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_131

    :cond_12f
    sput v7, Lg;->ax:I

    :cond_131
    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    const/16 v3, 0x1000

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_13f

    sput v7, Lg;->ax:I

    :cond_13f
    sget v0, Lg;->aH:I

    if-ne v0, v5, :cond_206

    sget-boolean v0, Lg;->bb:Z

    if-nez v0, :cond_206

    sget v0, Lg;->aw:I

    const/4 v2, 0x3

    if-ne v0, v2, :cond_1e9

    const/16 v0, 0xb

    sput v0, Lg;->ay:I

    :cond_150
    :goto_150
    sget v0, Lg;->aw:I

    const/4 v2, 0x6

    if-le v0, v2, :cond_157

    sput v7, Lg;->ay:I

    :cond_157
    sget v0, Lg;->aI:I

    if-gez v0, :cond_161

    sget v0, Lg;->aI:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aI:I

    :cond_161
    sget v0, Lg;->aF:I

    if-ne v0, v5, :cond_20c

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x4

    if-ne v0, v2, :cond_185

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    sput v0, Lg;->at:I

    sput v1, Lg;->av:I

    :cond_185
    :goto_185
    invoke-static {}, Lg;->q()V

    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_1bb

    sget v0, Lg;->aw:I

    const/4 v2, 0x4

    if-lt v0, v2, :cond_1bb

    sget v0, Lg;->at:I

    sget v2, Lq;->aH:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x1e

    if-ge v0, v2, :cond_1bb

    sget v0, Lg;->au:I

    sget v2, Lq;->aI:I

    add-int/lit8 v2, v2, -0x19

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/4 v2, 0x5

    if-ge v0, v2, :cond_1bb

    sget v0, Lg;->aw:I

    shr-int/lit8 v0, v0, 0x1

    neg-int v0, v0

    sput v0, Lg;->aw:I

    sget v0, Lg;->aF:I

    shl-int/lit8 v0, v0, 0x3

    sput v0, Lg;->av:I

    sput v1, Lg;->aG:I

    :cond_1bb
    sget v0, Lp;->g:I

    if-eq v0, v4, :cond_14

    const/4 v0, 0x2

    sput v0, Lg;->aw:I

    sget-object v0, Lp;->d:[I

    sget v1, Lp;->g:I

    sget v2, Lg;->aF:I

    aput v2, v0, v1

    sget-object v0, Lp;->e:[I

    sget v1, Lp;->g:I

    aput v5, v0, v1

    sget-object v0, Lp;->b:[I

    sget v1, Lp;->g:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x3

    sub-int/2addr v2, v3

    aput v2, v0, v1

    sget-object v0, Lp;->c:[I

    sget v1, Lp;->g:I

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0x2

    aput v2, v0, v1

    goto/16 :goto_14

    :cond_1e9
    sget v0, Lg;->aw:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_1f2

    sput v6, Lg;->ay:I

    goto/16 :goto_150

    :cond_1f2
    sget v0, Lg;->aw:I

    if-ne v0, v5, :cond_1fc

    const/16 v0, 0x9

    sput v0, Lg;->ay:I

    goto/16 :goto_150

    :cond_1fc
    sget v0, Lg;->aw:I

    if-nez v0, :cond_150

    const/16 v0, 0xa

    sput v0, Lg;->ay:I

    goto/16 :goto_150

    :cond_206
    const/16 v0, 0x17

    sput v0, Lg;->ay:I

    goto/16 :goto_150

    :cond_20c
    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    sget v2, Lg;->au:I

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    if-ne v0, v6, :cond_185

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, 0x18

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    sput v1, Lg;->av:I

    goto/16 :goto_185
.end method

.method private static final l()V
    .registers 4

    const/16 v3, 0x400

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_7

    :cond_6
    :goto_6
    return-void

    :cond_7
    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, 0x1

    const/16 v2, 0x800

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_27

    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1, v3}, Lj;->b(III)V

    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, -0x2

    invoke-static {v0, v1, v3}, Lj;->b(III)V

    :cond_27
    sget v0, Lg;->at:I

    sget v1, Lj;->f:I

    sub-int/2addr v0, v1

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_4e

    sget v0, Lg;->at:I

    sget v1, Lj;->f:I

    sub-int/2addr v0, v1

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1, v3}, Lj;->c(III)V

    sget v0, Lg;->at:I

    sget v1, Lj;->f:I

    sub-int/2addr v0, v1

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, -0x2

    invoke-static {v0, v1, v3}, Lj;->c(III)V

    :cond_4e
    sget v0, Lg;->at:I

    sget v1, Lj;->f:I

    add-int/2addr v0, v1

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_6

    sget v0, Lg;->at:I

    sget v1, Lj;->f:I

    add-int/2addr v0, v1

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, 0x1

    invoke-static {v0, v1, v3}, Lj;->c(III)V

    sget v0, Lg;->at:I

    sget v1, Lj;->f:I

    add-int/2addr v0, v1

    sget v1, Lg;->au:I

    add-int/lit8 v1, v1, -0x2

    invoke-static {v0, v1, v3}, Lj;->c(III)V

    goto :goto_6
.end method

.method private static m()V
    .registers 7

    const/16 v4, 0x1e

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x0

    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    if-ne v0, v2, :cond_51

    sget v0, Lg;->at:I

    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v3}, Lq;->b(II)V

    sput v1, Lq;->w:I

    sget-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_48

    new-array v0, v6, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    :try_start_20
    sget-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x0

    const-string v4, "/cp/ch0x.png"

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v0, v3

    sget-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x1

    const-string v4, "/cp/ch1x.png"

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v0, v3
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_36} :catch_12a

    :goto_36
    sget-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x2

    sget-object v4, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v2

    aput-object v4, v0, v3

    sget-object v0, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x3

    sget-object v4, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v1

    aput-object v4, v0, v3

    :cond_48
    :goto_48
    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0x2

    if-lez v0, :cond_123

    sput v1, Lg;->ay:I

    :cond_50
    :goto_50
    return-void

    :cond_51
    sget v0, Lg;->aG:I

    if-lt v0, v4, :cond_bf

    sput v2, Lg;->ax:I

    sput v1, Lg;->aG:I

    move v0, v1

    :goto_5a
    const/16 v3, 0xb

    if-lt v0, v3, :cond_9d

    :goto_5e
    sput v6, Lg;->as:I

    sget v0, Lg;->aJ:I

    add-int/lit8 v0, v0, 0x5

    sput v0, Lg;->aJ:I

    invoke-static {}, Lg;->e()V

    invoke-static {}, Lq;->i()V

    sget-object v0, Lq;->bf:[I

    sget v3, Lq;->bh:I

    sget v4, Lg;->as:I

    aput v4, v0, v3

    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v3, Lq;->bh:I

    const-string v4, "Gươm hỏa long"

    aput-object v4, v0, v3

    sget-object v0, Lq;->bs:[I

    sget v3, Lq;->bh:I

    const/4 v4, 0x5

    aput v4, v0, v3

    sget v0, Lq;->bh:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bh:I

    const/16 v0, 0x9

    invoke-static {v0}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    sget v0, Lg;->aN:I

    if-eqz v0, :cond_50

    sget-boolean v0, Lg;->bb:Z

    if-eqz v0, :cond_bd

    move v0, v1

    :goto_9a
    sput-boolean v0, Lg;->bb:Z

    goto :goto_48

    :cond_9d
    :try_start_9d
    sget-object v3, Lg;->N:[Ljavax/microedition/lcdui/Image;

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/cp/ch"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v0
    :try_end_ba
    .catch Ljava/io/IOException; {:try_start_9d .. :try_end_ba} :catch_127

    add-int/lit8 v0, v0, 0x1

    goto :goto_5a

    :cond_bd
    move v0, v2

    goto :goto_9a

    :cond_bf
    sget v0, Lg;->aG:I

    const/16 v3, 0xa

    if-gt v0, v3, :cond_e1

    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_48

    move v0, v1

    :goto_cc
    if-ge v0, v6, :cond_48

    sget-object v3, Lg;->N:[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v0

    sget-object v4, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v5, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aget-object v5, v5, v0

    aput-object v5, v4, v0

    sget-object v4, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aput-object v3, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_cc

    :cond_e1
    sget v0, Lg;->aG:I

    const/16 v3, 0x14

    if-ge v0, v3, :cond_103

    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0x3

    if-nez v0, :cond_48

    move v0, v1

    :goto_ee
    if-ge v0, v6, :cond_48

    sget-object v3, Lg;->N:[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v0

    sget-object v4, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v5, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aget-object v5, v5, v0

    aput-object v5, v4, v0

    sget-object v4, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aput-object v3, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_ee

    :cond_103
    sget v0, Lg;->aG:I

    if-ge v0, v4, :cond_48

    sget v0, Lg;->aG:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_48

    move v0, v1

    :goto_10e
    if-ge v0, v6, :cond_48

    sget-object v3, Lg;->N:[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v0

    sget-object v4, Lg;->N:[Ljavax/microedition/lcdui/Image;

    sget-object v5, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aget-object v5, v5, v0

    aput-object v5, v4, v0

    sget-object v4, Lg;->ch:[Ljavax/microedition/lcdui/Image;

    aput-object v3, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_10e

    :cond_123
    sput v2, Lg;->ay:I

    goto/16 :goto_50

    :catch_127
    move-exception v0

    goto/16 :goto_5e

    :catch_12a
    move-exception v0

    goto/16 :goto_36
.end method

.method private static n()V
    .registers 8

    const/16 v7, 0x8

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/16 v4, 0xc

    const/4 v1, 0x0

    sget v0, Lg;->au:I

    sget v2, Lj;->f:I

    rem-int/2addr v0, v2

    if-le v0, v7, :cond_1c

    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    const/16 v3, 0x40

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_1c

    sput v6, Lg;->ax:I

    :cond_1c
    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    const/4 v2, 0x5

    if-lt v0, v2, :cond_29

    sput v1, Lg;->aG:I

    sput v1, Lg;->aR:I

    :cond_29
    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x2

    sput v0, Lg;->ay:I

    sget v0, Lg;->aF:I

    if-ne v0, v5, :cond_9a

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0x1

    invoke-static {v0, v2, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_52

    sput v1, Lg;->av:I

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    sput v0, Lg;->at:I

    :cond_52
    :goto_52
    sget v0, Lg;->at:I

    sget v2, Lg;->av:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    sget v0, Lg;->av:I

    if-lez v0, :cond_c1

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->av:I

    :goto_63
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_79

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x5

    sput v0, Lg;->aN:I

    if-gtz v0, :cond_77

    sput v1, Lg;->aN:I

    sput v1, Lg;->av:I

    sput v4, Lg;->ax:I

    :cond_77
    sput-boolean v5, Lq;->J:Z

    :cond_79
    sget v0, Lq;->as:I

    const/16 v2, 0xe

    if-eq v0, v2, :cond_84

    move v0, v1

    :goto_80
    sget v2, Lq;->aW:I

    if-lt v0, v2, :cond_d1

    :cond_84
    :goto_84
    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    invoke-static {v0, v1}, Lq;->c(II)Z

    sget v0, Lg;->aF:I

    sget v1, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    sget v2, Lg;->au:I

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    return-void

    :cond_9a
    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0x1

    invoke-static {v0, v2, v7}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_52

    sput v1, Lg;->av:I

    sget v0, Lg;->at:I

    sget v2, Lg;->aB:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sget v2, Lj;->f:I

    add-int/2addr v0, v2

    sget v2, Lg;->aB:I

    add-int/2addr v0, v2

    sput v0, Lg;->at:I

    goto :goto_52

    :cond_c1
    sget v0, Lg;->av:I

    if-gez v0, :cond_cc

    sget v0, Lg;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->av:I

    goto :goto_63

    :cond_cc
    sput v4, Lg;->ax:I

    sput v1, Lg;->aR:I

    goto :goto_63

    :cond_d1
    sget v2, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_111

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    sget v3, Lg;->au:I

    if-le v2, v3, :cond_111

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x18

    sget v3, Lg;->au:I

    if-ge v2, v3, :cond_111

    sput v1, Lg;->av:I

    sget v1, Lg;->at:I

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    if-ge v1, v2, :cond_108

    sget-object v1, Lq;->aY:[I

    aget v0, v1, v0

    add-int/lit8 v0, v0, -0x14

    sput v0, Lg;->at:I

    :goto_104
    sput v4, Lg;->ax:I

    goto/16 :goto_84

    :cond_108
    sget-object v1, Lq;->aY:[I

    aget v0, v1, v0

    add-int/lit8 v0, v0, 0x14

    sput v0, Lg;->at:I

    goto :goto_104

    :cond_111
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_80
.end method

.method private static o()V
    .registers 1

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->K:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->L:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bR:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bS:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bT:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bU:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->M:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bV:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bW:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bX:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bY:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->bZ:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->ca:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->cb:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [I

    sput-object v0, Lg;->cc:[I

    sget v0, Lg;->F:I

    new-array v0, v0, [[Ljava/lang/String;

    sput-object v0, Lg;->G:[[Ljava/lang/String;

    sget v0, Lg;->F:I

    new-array v0, v0, [Z

    sput-object v0, Lg;->I:[Z

    return-void
.end method

.method private static p()V
    .registers 13

    const/4 v12, 0x3

    const/16 v11, 0xa

    const/4 v5, -0x2

    const/4 v8, 0x1

    const/4 v1, 0x0

    sget v0, Lg;->aJ:I

    sget v2, Lq;->at:I

    sget v3, Lg;->aJ:I

    shr-int/lit8 v3, v3, 0x1

    rem-int/2addr v2, v3

    add-int/2addr v0, v2

    shr-int/lit8 v2, v0, 0x1

    sget v3, Lg;->as:I

    mul-int/2addr v2, v3

    add-int/2addr v0, v2

    sget-boolean v2, Lg;->bb:Z

    if-eqz v2, :cond_730

    shl-int/lit8 v0, v0, 0x1

    move v6, v0

    :goto_1d
    sget v0, Lg;->ar:I

    if-ne v0, v8, :cond_3b

    sget v0, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x3

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x3

    sget v4, Lg;->av:I

    add-int/2addr v3, v4

    sget v4, Lg;->aw:I

    shl-int/lit8 v4, v4, 0x1

    invoke-static {v0, v2, v3, v4, v1}, Lq;->a(IIIIZ)V

    :cond_3a
    :goto_3a
    return-void

    :cond_3b
    sget v0, Lg;->aw:I

    if-lez v0, :cond_45

    sget v0, Lg;->av:I

    if-nez v0, :cond_45

    sput v5, Lg;->aw:I

    :cond_45
    invoke-static {}, Lg;->t()I

    move-result v7

    sput-boolean v1, Lg;->cl:Z

    const/4 v0, -0x1

    if-eq v7, v0, :cond_e7

    sget v0, Lg;->as:I

    if-ne v0, v8, :cond_315

    sget v0, Lg;->aN:I

    const/4 v2, 0x5

    if-lt v0, v2, :cond_30e

    sget-object v0, La;->e:[I

    aget v0, v0, v7

    add-int/lit8 v0, v0, -0x32

    sget-object v2, La;->e:[I

    aget v2, v2, v7

    add-int/lit8 v2, v2, 0x32

    invoke-static {v0, v2, v7}, Lg;->a(III)I

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x5

    sput v0, Lg;->aN:I

    sput-boolean v8, Lq;->J:Z

    sget v0, Lg;->aJ:I

    shr-int/lit8 v0, v0, 0x2

    add-int/2addr v6, v0

    sget-object v0, Lo;->a:Lo;

    new-instance v2, Lh;

    sget-object v3, La;->e:[I

    aget v3, v3, v7

    sget-object v4, La;->f:[I

    aget v4, v4, v7

    invoke-direct {v2, v3, v4, v12}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, La;->e:[I

    aget v3, v3, v7

    sget-object v4, La;->f:[I

    aget v4, v4, v7

    add-int/lit16 v4, v4, -0x82

    invoke-direct {v2, v3, v4, v11}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    mul-int/lit8 v0, v6, 0x3

    div-int/lit8 v0, v0, 0x4

    sget v2, Lg;->aF:I

    neg-int v2, v2

    invoke-static {v7, v0, v2, v1}, La;->a(IIII)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    mul-int/lit8 v2, v6, 0x3

    div-int/lit8 v2, v2, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, La;->e:[I

    aget v2, v2, v7

    sget-object v3, La;->f:[I

    aget v3, v3, v7

    sget-object v4, La;->g:[I

    aget v4, v4, v7

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, La;->e:[I

    aget v0, v0, v7

    sget-object v2, La;->f:[I

    aget v2, v2, v7

    sget-object v3, La;->g:[I

    aget v3, v3, v7

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    :cond_db
    :goto_db
    sput-boolean v8, Lg;->cl:Z

    sget v0, Lg;->aw:I

    if-lez v0, :cond_e4

    const/4 v0, -0x7

    sput v0, Lg;->aw:I

    :cond_e4
    invoke-static {}, Lq;->s()V

    :cond_e7
    move v0, v1

    :goto_e8
    sget v2, Lq;->aW:I

    if-lt v0, v2, :cond_487

    :goto_ec
    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_156

    sget-boolean v0, Lg;->l:Z

    if-nez v0, :cond_156

    sget v0, Lg;->au:I

    sget v2, Lq;->aI:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x1e

    if-ge v0, v2, :cond_156

    sget v0, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x4

    add-int/2addr v0, v2

    sget v2, Lq;->aH:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x28

    if-ge v0, v2, :cond_156

    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_4d2

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v6, v0}, Lq;->d(II)Z

    move-result v0

    if-nez v0, :cond_153

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aN:I

    sget v0, Lg;->at:I

    sget v2, Lq;->aH:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    sget v4, Lq;->aJ:I

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_153
    :goto_153
    invoke-static {}, Lq;->s()V

    :cond_156
    sget-boolean v0, Lt;->a:Z

    if-eqz v0, :cond_235

    sget v0, Lt;->n:I

    if-nez v0, :cond_1c1

    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_1c1

    sget v0, Lg;->au:I

    sget v2, Lt;->d:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x1e

    if-ge v0, v2, :cond_1c1

    sget v0, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x4

    add-int/2addr v0, v2

    sget v2, Lt;->c:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x28

    if-ge v0, v2, :cond_1c1

    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_4d9

    invoke-static {v6}, Lt;->b(I)Z

    move-result v0

    if-nez v0, :cond_1be

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aN:I

    sget v0, Lg;->at:I

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    sget v4, Lt;->h:I

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_1be
    :goto_1be
    invoke-static {}, Lq;->s()V

    :cond_1c1
    sget v0, Lt;->n:I

    if-ne v0, v8, :cond_235

    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_235

    sget v0, Lg;->au:I

    sget v2, Lt;->d:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x1e

    if-ge v0, v2, :cond_235

    sget v0, Lg;->at:I

    sget v2, Lt;->c:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x46

    if-ge v0, v2, :cond_235

    sget v0, Lg;->at:I

    sget v2, Lt;->c:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x28

    if-le v0, v2, :cond_235

    sget v0, Lt;->f:I

    const/4 v2, 0x4

    if-eq v0, v2, :cond_235

    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_4e0

    invoke-static {v6}, Lt;->b(I)Z

    move-result v0

    if-nez v0, :cond_232

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aN:I

    sget v0, Lg;->at:I

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    sget v4, Lt;->h:I

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_232
    :goto_232
    invoke-static {}, Lq;->s()V

    :cond_235
    sget-boolean v0, Lm;->a:Z

    if-eqz v0, :cond_298

    sget v0, Lg;->au:I

    sget v2, Lm;->c:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x28

    if-ge v0, v2, :cond_298

    sget v0, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x4

    add-int/2addr v0, v2

    sget v2, Lm;->b:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x32

    if-ge v0, v2, :cond_298

    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_4e7

    invoke-static {v6}, Lm;->b(I)Z

    move-result v0

    if-nez v0, :cond_295

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aN:I

    sget v0, Lg;->at:I

    sget v2, Lm;->b:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    sget v4, Lm;->d:I

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_295
    :goto_295
    invoke-static {}, Lq;->s()V

    :cond_298
    move v7, v1

    :goto_299
    sget v0, Ln;->c:I

    if-lt v7, v0, :cond_4ee

    :goto_29d
    sget-boolean v0, Le;->d:Z

    if-eqz v0, :cond_3a

    sget v0, Lq;->as:I

    const/16 v2, 0x14

    if-ne v0, v2, :cond_3a

    sget v0, Lg;->au:I

    sget v2, Le;->b:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x14

    if-ge v0, v2, :cond_3a

    sget v0, Lg;->at:I

    sget v2, Le;->a:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x3c

    if-ge v0, v2, :cond_3a

    sget v0, Lg;->as:I

    const/4 v2, 0x4

    if-eq v0, v2, :cond_6ea

    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_309

    sget v0, Lg;->aJ:I

    sget v2, Lg;->aF:I

    neg-int v2, v2

    invoke-static {v0, v2}, Le;->a(II)Z

    move-result v0

    if-nez v0, :cond_309

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aN:I

    sget v0, Lg;->at:I

    sget v2, Le;->a:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v2, Lg;->aJ:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Le;->a:I

    sget v3, Le;->b:I

    add-int/lit8 v3, v3, -0x30

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_309
    :goto_309
    invoke-static {}, Lq;->s()V

    goto/16 :goto_3a

    :cond_30e
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_db

    :cond_315
    sget v0, Lg;->as:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_391

    sget v0, Lg;->aN:I

    const/4 v2, 0x6

    if-lt v0, v2, :cond_38a

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x6

    sput v0, Lg;->aN:I

    sput-boolean v8, Lq;->J:Z

    sget v0, Lg;->aJ:I

    shr-int/lit8 v0, v0, 0x2

    add-int/2addr v6, v0

    sget-object v0, La;->l:[I

    aget v0, v0, v7

    if-le v0, v8, :cond_33c

    sget-object v0, La;->m:[I

    aget v0, v0, v7

    if-eq v0, v8, :cond_33c

    sget-object v0, La;->m:[I

    aput v8, v0, v7

    :cond_33c
    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, La;->e:[I

    aget v3, v3, v7

    sget-object v4, La;->f:[I

    aget v4, v4, v7

    invoke-direct {v2, v3, v4, v1}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v7, v6, v0, v1}, La;->a(IIII)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, La;->e:[I

    aget v2, v2, v7

    sget-object v3, La;->f:[I

    aget v3, v3, v7

    sget-object v4, La;->g:[I

    aget v4, v4, v7

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, La;->e:[I

    aget v0, v0, v7

    sget-object v2, La;->f:[I

    aget v2, v2, v7

    sget-object v3, La;->g:[I

    aget v3, v3, v7

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    goto/16 :goto_db

    :cond_38a
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_db

    :cond_391
    sget v0, Lg;->as:I

    if-ne v0, v12, :cond_43a

    sget v0, Lg;->aN:I

    if-lt v0, v11, :cond_433

    sget-object v0, La;->m:[I

    aget v0, v0, v7

    if-eq v0, v8, :cond_3a3

    sget-object v0, La;->m:[I

    aput v8, v0, v7

    :cond_3a3
    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lg;->aN:I

    sput-boolean v8, Lq;->J:Z

    sget v0, Lg;->aJ:I

    shr-int/lit8 v0, v0, 0x2

    add-int/2addr v6, v0

    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, La;->e:[I

    aget v3, v3, v7

    sget-object v4, La;->f:[I

    aget v4, v4, v7

    add-int/lit8 v4, v4, -0x5

    const/16 v9, 0x17

    invoke-direct {v2, v3, v4, v9}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    mul-int/lit8 v0, v6, 0x3

    div-int/lit8 v0, v0, 0x4

    sget v2, Lg;->aF:I

    neg-int v2, v2

    invoke-static {v7, v0, v2, v1}, La;->a(IIII)Z

    sget-object v0, La;->e:[I

    aget v0, v0, v7

    sget-object v2, La;->f:[I

    aget v2, v2, v7

    sget-object v3, La;->g:[I

    aget v3, v3, v7

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    mul-int/lit8 v2, v6, 0x3

    div-int/lit8 v2, v2, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, La;->e:[I

    aget v2, v2, v7

    sget-object v3, La;->f:[I

    aget v3, v3, v7

    sget-object v4, La;->g:[I

    aget v4, v4, v7

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    move v2, v8

    :goto_409
    const/16 v0, 0x8

    if-gt v2, v0, :cond_db

    sget-object v0, Lo;->b:Lo;

    new-instance v3, Lh;

    sget-object v4, La;->e:[I

    aget v4, v4, v7

    add-int/lit8 v4, v4, -0x4

    sget-object v9, La;->f:[I

    aget v9, v9, v7

    add-int/lit8 v9, v9, -0x7

    add-int/lit8 v10, v2, 0x18

    invoke-direct {v3, v4, v9, v10}, Lh;-><init>(III)V

    invoke-virtual {v0, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh;

    iput v7, v0, Lh;->e:I

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_409

    :cond_433
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_db

    :cond_43a
    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_480

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v7, v6, v0, v1}, La;->a(IIII)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, La;->e:[I

    aget v2, v2, v7

    sget-object v3, La;->f:[I

    aget v3, v3, v7

    sget-object v4, La;->g:[I

    aget v4, v4, v7

    sub-int/2addr v3, v4

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->aN:I

    sget-object v0, La;->e:[I

    aget v0, v0, v7

    sget-object v2, La;->f:[I

    aget v2, v2, v7

    sget-object v3, La;->g:[I

    aget v3, v3, v7

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    goto/16 :goto_db

    :cond_480
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_db

    :cond_487
    sget v2, Lg;->au:I

    sget v3, Lg;->aC:I

    sub-int/2addr v2, v3

    sget-object v3, Lq;->aZ:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_4ce

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x4

    add-int/2addr v2, v3

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x18

    if-ge v2, v3, :cond_4ce

    sget-object v2, Lq;->ba:[I

    const/4 v3, 0x2

    aput v3, v2, v0

    sget-object v2, Lq;->bb:[I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x3

    aput v3, v2, v0

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    sget-object v3, Lq;->aZ:[I

    aget v0, v3, v0

    add-int/lit8 v0, v0, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v2, v0, v3}, Lq;->c(III)Z

    invoke-static {}, Lq;->s()V

    goto/16 :goto_ec

    :cond_4ce
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_e8

    :cond_4d2
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_153

    :cond_4d9
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_1be

    :cond_4e0
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_232

    :cond_4e7
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_295

    :cond_4ee
    sget v0, Lg;->au:I

    sget-object v2, Ln;->f:[I

    aget v2, v2, v7

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0xc

    if-gt v0, v2, :cond_6e5

    sget v0, Lg;->at:I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x4

    add-int/2addr v0, v2

    sget-object v2, Ln;->e:[I

    aget v2, v2, v7

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x18

    if-ge v0, v2, :cond_6e5

    sget v0, Lg;->as:I

    if-ne v0, v8, :cond_599

    sget v0, Lg;->aN:I

    const/4 v2, 0x5

    if-le v0, v2, :cond_593

    sget-object v0, Ln;->e:[I

    aget v0, v0, v7

    add-int/lit8 v0, v0, -0x32

    sget-object v2, Ln;->e:[I

    aget v2, v2, v7

    add-int/lit8 v2, v2, 0x32

    invoke-static {v0, v2, v7}, Lg;->a(III)I

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x5

    sput v0, Lg;->aN:I

    sput-boolean v8, Lq;->J:Z

    sget v0, Lg;->aJ:I

    shr-int/lit8 v0, v0, 0x2

    add-int/2addr v6, v0

    sget-object v0, Lo;->a:Lo;

    new-instance v2, Lh;

    sget-object v3, Ln;->e:[I

    aget v3, v3, v7

    sget-object v4, Ln;->f:[I

    aget v4, v4, v7

    invoke-direct {v2, v3, v4, v12}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, Ln;->e:[I

    aget v3, v3, v7

    sget-object v4, Ln;->f:[I

    aget v4, v4, v7

    add-int/lit16 v4, v4, -0x82

    invoke-direct {v2, v3, v4, v11}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v7, v6, v0}, Ln;->a(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v7

    sget-object v3, Ln;->f:[I

    aget v3, v3, v7

    add-int/lit8 v3, v3, -0x1c

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v7

    sget-object v2, Ln;->f:[I

    aget v2, v2, v7

    add-int/lit8 v2, v2, -0xf

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    :cond_58e
    :goto_58e
    invoke-static {}, Lq;->s()V

    goto/16 :goto_29d

    :cond_593
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_58e

    :cond_599
    sget v0, Lg;->as:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_60b

    sget v0, Lg;->aN:I

    const/4 v2, 0x6

    if-lt v0, v2, :cond_605

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x6

    sput v0, Lg;->aN:I

    sput-boolean v8, Lq;->J:Z

    sget v0, Lg;->aJ:I

    shr-int/lit8 v0, v0, 0x2

    add-int/2addr v6, v0

    sget-object v0, Ln;->d:[I

    aget v0, v0, v7

    if-le v0, v8, :cond_5c0

    sget-object v0, Ln;->k:[I

    aget v0, v0, v7

    if-eq v0, v8, :cond_5c0

    sget-object v0, Ln;->k:[I

    aput v8, v0, v7

    :cond_5c0
    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, Ln;->e:[I

    aget v3, v3, v7

    sget-object v4, Ln;->f:[I

    aget v4, v4, v7

    invoke-direct {v2, v3, v4, v1}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v7, v6, v0}, Ln;->a(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v7

    sget-object v3, Ln;->f:[I

    aget v3, v3, v7

    add-int/lit8 v3, v3, -0x1c

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v7

    sget-object v2, Ln;->f:[I

    aget v2, v2, v7

    add-int/lit8 v2, v2, -0xf

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    goto :goto_58e

    :cond_605
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_58e

    :cond_60b
    sget v0, Lg;->as:I

    if-ne v0, v12, :cond_6a6

    sget v0, Lg;->aN:I

    if-lt v0, v11, :cond_69f

    sget-object v0, Ln;->k:[I

    aget v0, v0, v7

    if-eq v0, v8, :cond_61d

    sget-object v0, Ln;->k:[I

    aput v8, v0, v7

    :cond_61d
    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lg;->aN:I

    sput-boolean v8, Lq;->J:Z

    sget v0, Lg;->aJ:I

    shr-int/lit8 v0, v0, 0x2

    add-int/2addr v6, v0

    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, Ln;->e:[I

    aget v3, v3, v7

    sget-object v4, Ln;->f:[I

    aget v4, v4, v7

    const/16 v9, 0x17

    invoke-direct {v2, v3, v4, v9}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    mul-int/lit8 v0, v6, 0x3

    div-int/lit8 v0, v0, 0x4

    sget v2, Lg;->aF:I

    neg-int v2, v2

    invoke-static {v7, v0, v2}, Ln;->a(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    mul-int/lit8 v2, v6, 0x3

    div-int/lit8 v2, v2, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v7

    sget-object v3, Ln;->f:[I

    aget v3, v3, v7

    add-int/lit8 v3, v3, -0x1c

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v7

    sget-object v2, Ln;->f:[I

    aget v2, v2, v7

    add-int/lit8 v2, v2, -0xf

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    move v2, v8

    :goto_679
    const/16 v0, 0x8

    if-gt v2, v0, :cond_58e

    sget-object v0, Lo;->b:Lo;

    new-instance v3, Lh;

    sget-object v4, Ln;->e:[I

    aget v4, v4, v7

    sget-object v9, Ln;->f:[I

    aget v9, v9, v7

    add-int/lit8 v10, v2, 0x18

    invoke-direct {v3, v4, v9, v10}, Lh;-><init>(III)V

    invoke-virtual {v0, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lo;->b:Lo;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lh;

    iput v7, v0, Lh;->e:I

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_679

    :cond_69f
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_58e

    :cond_6a6
    sget v0, Lg;->aN:I

    if-lt v0, v8, :cond_6de

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v7, v6, v0}, Ln;->a(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v7

    sget-object v3, Ln;->f:[I

    aget v3, v3, v7

    add-int/lit8 v3, v3, -0x1c

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v7

    sget-object v2, Ln;->f:[I

    aget v2, v2, v7

    add-int/lit8 v2, v2, -0xf

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    goto/16 :goto_58e

    :cond_6de
    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_58e

    :cond_6e5
    add-int/lit8 v0, v7, 0x1

    move v7, v0

    goto/16 :goto_299

    :cond_6ea
    sget v0, Lg;->as:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_309

    sget v0, Lg;->aN:I

    if-lt v0, v11, :cond_309

    sget v0, Lg;->aF:I

    neg-int v0, v0

    invoke-static {v6, v0}, Le;->a(II)Z

    move-result v0

    if-nez v0, :cond_309

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lg;->aN:I

    sget v0, Lg;->at:I

    sget v2, Le;->a:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sget v2, Lg;->au:I

    add-int/lit8 v2, v2, -0xc

    sget v3, Lg;->aF:I

    invoke-static {v0, v2, v3}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Le;->a:I

    sget v3, Le;->b:I

    add-int/lit8 v3, v3, -0x30

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    goto/16 :goto_309

    :cond_730
    move v6, v0

    goto/16 :goto_1d
.end method

.method private static q()V
    .registers 4

    const/4 v1, 0x0

    sget v0, Lq;->as:I

    const/16 v2, 0xe

    if-ne v0, v2, :cond_8

    :cond_7
    :goto_7
    return-void

    :cond_8
    move v0, v1

    :goto_9
    sget v2, Lq;->aW:I

    if-ge v0, v2, :cond_7

    sget-object v2, Lq;->ba:[I

    aget v2, v2, v0

    const/4 v3, 0x4

    if-eq v2, v3, :cond_6f

    sget v2, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_6f

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    sget v3, Lg;->au:I

    if-le v2, v3, :cond_6f

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x18

    sget v3, Lg;->au:I

    if-gt v2, v3, :cond_6f

    sput v1, Lg;->av:I

    sput v1, Lg;->aw:I

    sget-object v1, Lq;->aZ:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, -0x18

    sput v1, Lg;->au:I

    const/4 v1, 0x1

    sput v1, Lg;->ax:I

    const/4 v1, -0x1

    sput v1, Lg;->aq:I

    sput v0, Lq;->aX:I

    sget-object v1, Lq;->ba:[I

    aget v1, v1, v0

    const/16 v2, 0xb

    if-ne v1, v2, :cond_7

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xa

    invoke-static {v1, v2}, Lq;->c(II)Z

    sget-object v1, Lq;->aZ:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x4

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x4

    aput v2, v1, v0

    goto :goto_7

    :cond_6f
    add-int/lit8 v0, v0, 0x1

    goto :goto_9
.end method

.method private static r()V
    .registers 5

    const/4 v4, 0x4

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, Lq;->aW:I

    if-lt v0, v2, :cond_8

    :goto_7
    return-void

    :cond_8
    sget v2, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_54

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    sget v3, Lg;->au:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    if-ge v2, v4, :cond_54

    sput v1, Lg;->av:I

    sget v2, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    if-ge v2, v3, :cond_4b

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x14

    sput v2, Lg;->at:I

    :goto_36
    sget-object v2, Lq;->ba:[I

    aget v2, v2, v0

    if-eq v2, v4, :cond_54

    sget-object v1, Lq;->ba:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    sget-object v1, Lq;->bb:[I

    sget v2, Lg;->aF:I

    neg-int v2, v2

    shl-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    goto :goto_7

    :cond_4b
    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0x14

    sput v2, Lg;->at:I

    goto :goto_36

    :cond_54
    add-int/lit8 v0, v0, 0x1

    goto :goto_3
.end method

.method private static s()V
    .registers 4

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    sget v2, Lq;->aW:I

    if-lt v0, v2, :cond_7

    :goto_6
    return-void

    :cond_7
    sget v2, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_4e

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    sget v3, Lg;->au:I

    if-ne v2, v3, :cond_4e

    sput v1, Lg;->av:I

    sget v2, Lg;->at:I

    sget-object v3, Lq;->aY:[I

    aget v3, v3, v0

    if-ge v2, v3, :cond_45

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x14

    sput v2, Lg;->at:I

    :goto_30
    sget-object v2, Lq;->ba:[I

    aget v2, v2, v0

    const/4 v3, 0x4

    if-eq v2, v3, :cond_4e

    sget-object v1, Lq;->ba:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    sget-object v1, Lq;->bb:[I

    sget v2, Lg;->aF:I

    shl-int/lit8 v2, v2, 0x2

    aput v2, v1, v0

    goto :goto_6

    :cond_45
    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0x14

    sput v2, Lg;->at:I

    goto :goto_30

    :cond_4e
    add-int/lit8 v0, v0, 0x1

    goto :goto_2
.end method

.method private static t()I
    .registers 7

    sget v0, Lg;->aF:I

    if-lez v0, :cond_22

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, -0x14

    :goto_8
    sget v1, Lg;->aF:I

    if-lez v1, :cond_27

    sget v1, Lg;->at:I

    add-int/lit8 v1, v1, 0x28

    :goto_10
    sget v2, Lg;->au:I

    sget v3, Lg;->aA:I

    sub-int/2addr v2, v3

    add-int/lit8 v3, v2, -0xf

    sget v2, Lg;->au:I

    add-int/lit8 v4, v2, 0x5

    const/4 v2, 0x0

    :goto_1c
    sget v5, La;->c:I

    if-lt v2, v5, :cond_2c

    const/4 v2, -0x1

    :cond_21
    return v2

    :cond_22
    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, -0x28

    goto :goto_8

    :cond_27
    sget v1, Lg;->at:I

    add-int/lit8 v1, v1, 0x14

    goto :goto_10

    :cond_2c
    sget-object v5, La;->i:[I

    aget v5, v5, v2

    const/4 v6, 0x5

    if-eq v5, v6, :cond_4b

    sget-object v5, La;->e:[I

    aget v5, v5, v2

    if-lt v5, v0, :cond_4b

    sget-object v5, La;->e:[I

    aget v5, v5, v2

    if-gt v5, v1, :cond_4b

    sget-object v5, La;->f:[I

    aget v5, v5, v2

    if-lt v5, v3, :cond_4b

    sget-object v5, La;->f:[I

    aget v5, v5, v2

    if-le v5, v4, :cond_21

    :cond_4b
    add-int/lit8 v2, v2, 0x1

    goto :goto_1c
.end method

.method private static u()V
    .registers 9

    const/4 v8, -0x4

    const/4 v2, -0x1

    const/4 v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    sget v0, Lq;->as:I

    const/16 v3, 0xd

    if-ne v0, v3, :cond_10

    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_10

    :cond_f
    :goto_f
    return-void

    :cond_10
    sget v0, Lg;->bL:I

    if-lez v0, :cond_1d

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x7

    sput v0, Lg;->bq:I

    sput v6, Lg;->bs:I

    goto :goto_f

    :cond_1d
    sget-boolean v0, Lg;->bm:Z

    if-eqz v0, :cond_f

    sget v0, Lg;->au:I

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x18

    if-gt v0, v3, :cond_3e

    sget v0, Lg;->bo:I

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x1

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_3e

    sput v7, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->bq:I

    const/4 v0, -0x7

    sput v0, Lg;->br:I

    goto :goto_f

    :cond_3e
    sget v0, Lg;->au:I

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x18

    if-gt v0, v3, :cond_5c

    sget v0, Lg;->bo:I

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x19

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_5c

    sput v7, Lg;->bs:I

    const/4 v0, 0x0

    sput v0, Lg;->bq:I

    const/16 v0, -0xa

    sput v0, Lg;->br:I

    goto :goto_f

    :cond_5c
    sget v0, Lg;->bo:I

    sget v3, Lq;->ay:I

    add-int/lit8 v3, v3, -0x18

    if-lt v0, v3, :cond_6f

    sget v0, Lg;->bo:I

    sget v3, Lq;->ay:I

    sget v4, Lq;->ab:I

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x18

    if-le v0, v3, :cond_cf

    :cond_6f
    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->bo:I

    if-le v0, v3, :cond_a1

    move v0, v1

    :goto_7b
    sput v0, Lg;->bA:I

    sget v0, Lg;->at:I

    sget v3, Lg;->bo:I

    if-le v0, v3, :cond_a3

    sget v0, Lq;->ay:I

    add-int/lit8 v0, v0, -0x18

    :goto_87
    sget v3, Lg;->au:I

    add-int/lit8 v3, v3, -0x14

    const/16 v4, 0x2000

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v4

    if-nez v4, :cond_ab

    sput v0, Lg;->bo:I

    sput v3, Lg;->bp:I

    const/4 v0, 0x4

    sput v0, Lg;->bs:I

    const/4 v0, 0x4

    sput v0, Lg;->bq:I

    sput v7, Lg;->br:I

    goto/16 :goto_f

    :cond_a1
    move v0, v2

    goto :goto_7b

    :cond_a3
    sget v0, Lq;->ay:I

    sget v3, Lq;->ab:I

    add-int/2addr v0, v3

    add-int/lit8 v0, v0, 0x18

    goto :goto_87

    :cond_ab
    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    sget v4, Lg;->bu:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_f

    sget v0, Lg;->at:I

    sget v3, Lg;->bo:I

    if-le v0, v3, :cond_cd

    :goto_c1
    sput v1, Lg;->bA:I

    sput v6, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0xc

    sput v0, Lg;->bq:I

    goto/16 :goto_f

    :cond_cd
    move v1, v2

    goto :goto_c1

    :cond_cf
    sget v0, Lg;->bp:I

    sget v3, Lq;->az:I

    add-int/lit8 v3, v3, -0x1e

    if-lt v0, v3, :cond_e2

    sget v0, Lg;->bp:I

    sget v3, Lq;->az:I

    sget v4, Lq;->ac:I

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x1e

    if-le v0, v3, :cond_113

    :cond_e2
    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->bo:I

    if-le v0, v3, :cond_10b

    :goto_ed
    sput v1, Lg;->bA:I

    sget v1, Lg;->at:I

    sget v0, Lg;->au:I

    sget v2, Lg;->bp:I

    if-le v0, v2, :cond_10d

    sget v0, Lq;->az:I

    add-int/lit8 v0, v0, -0x14

    :goto_fb
    sput v1, Lg;->bo:I

    sput v0, Lg;->bp:I

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    shl-int/lit8 v0, v0, 0x2

    sput v0, Lg;->bq:I

    sput v8, Lg;->br:I

    goto/16 :goto_f

    :cond_10b
    move v1, v2

    goto :goto_ed

    :cond_10d
    sget v0, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v0, v2

    goto :goto_fb

    :cond_113
    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->bo:I

    sub-int/2addr v0, v3

    invoke-static {v0}, Lq;->a(I)I

    move-result v3

    sget v0, Lg;->ax:I

    const/4 v4, 0x5

    if-ne v0, v4, :cond_155

    const/16 v0, 0xa

    :goto_128
    if-le v3, v0, :cond_2b3

    sget v0, Lg;->au:I

    sget v3, Lg;->bp:I

    if-ge v0, v3, :cond_1cc

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v3, 0x4

    if-gt v0, v3, :cond_1cc

    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_158

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->bq:I

    const/4 v0, -0x8

    sput v0, Lg;->br:I

    goto/16 :goto_f

    :cond_155
    const/16 v0, 0x28

    goto :goto_128

    :cond_158
    move v0, v1

    :goto_159
    if-le v0, v7, :cond_193

    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x2

    const/16 v4, 0x40

    invoke-static {v0, v3, v4}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_f

    sget v0, Lg;->bp:I

    add-int/lit8 v0, v0, 0x18

    sget v3, Lj;->d:I

    if-ge v0, v3, :cond_187

    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, 0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_1b8

    :cond_187
    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x7

    sput v0, Lg;->bq:I

    sput v8, Lg;->br:I

    goto/16 :goto_f

    :cond_193
    sget v3, Lg;->bo:I

    sget v4, Lg;->bA:I

    mul-int/lit8 v4, v4, 0x18

    add-int/2addr v3, v4

    sget v4, Lg;->bp:I

    mul-int/lit8 v5, v0, 0x18

    sub-int/2addr v4, v5

    invoke-static {v3, v4, v6}, Lj;->a(III)Z

    move-result v3

    if-eqz v3, :cond_1b5

    sput v7, Lg;->bs:I

    sget v1, Lg;->bA:I

    mul-int/lit8 v1, v1, 0x6

    sput v1, Lg;->bq:I

    mul-int/lit8 v0, v0, 0x3

    rsub-int/lit8 v0, v0, -0x5

    sput v0, Lg;->br:I

    goto/16 :goto_f

    :cond_1b5
    add-int/lit8 v0, v0, 0x1

    goto :goto_159

    :cond_1b8
    sput v7, Lg;->bs:I

    sget v0, Lg;->bo:I

    sget v3, Lg;->at:I

    if-ge v0, v3, :cond_1ca

    :goto_1c0
    sput v1, Lg;->bA:I

    mul-int/lit8 v0, v1, 0x6

    sput v0, Lg;->bq:I

    sput v8, Lg;->br:I

    goto/16 :goto_f

    :cond_1ca
    move v1, v2

    goto :goto_1c0

    :cond_1cc
    sget v0, Lg;->au:I

    sget v3, Lg;->bp:I

    if-le v0, v3, :cond_287

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v3, 0x4

    if-gt v0, v3, :cond_287

    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    sget v4, Lg;->bu:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_1fe

    sget v0, Lg;->at:I

    sget v3, Lg;->bo:I

    if-le v0, v3, :cond_1fc

    :goto_1ef
    sput v1, Lg;->bA:I

    sput v6, Lg;->bs:I

    sget v0, Lg;->bA:I

    sget v1, Lq;->aC:I

    mul-int/2addr v0, v1

    sput v0, Lg;->bq:I

    goto/16 :goto_f

    :cond_1fc
    move v1, v2

    goto :goto_1ef

    :cond_1fe
    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, 0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_21c

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x7

    sput v0, Lg;->bq:I

    const/4 v0, -0x5

    sput v0, Lg;->br:I

    goto/16 :goto_f

    :cond_21c
    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x18

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_24a

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->bq:I

    const/4 v0, -0x7

    sput v0, Lg;->br:I

    :cond_238
    :goto_238
    sput v7, Lg;->bs:I

    sget v0, Lg;->bo:I

    sget v3, Lg;->at:I

    if-ge v0, v3, :cond_285

    :goto_240
    sput v1, Lg;->bA:I

    shl-int/lit8 v0, v1, 0x2

    sput v0, Lg;->bq:I

    sput v8, Lg;->br:I

    goto/16 :goto_f

    :cond_24a
    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x30

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x18

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_267

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x6

    sput v0, Lg;->bq:I

    const/4 v0, -0x8

    sput v0, Lg;->br:I

    goto :goto_238

    :cond_267
    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    mul-int/lit8 v3, v3, 0x18

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    add-int/lit8 v3, v3, -0x30

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_238

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->bq:I

    const/16 v0, -0xb

    sput v0, Lg;->br:I

    goto :goto_238

    :cond_285
    move v1, v2

    goto :goto_240

    :cond_287
    sget v0, Lg;->bo:I

    sget v3, Lg;->bA:I

    sget v4, Lg;->bu:I

    mul-int/2addr v3, v4

    add-int/2addr v0, v3

    sget v3, Lg;->bp:I

    invoke-static {v0, v3, v6}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_f

    sget v0, Lg;->at:I

    sget v3, Lg;->aF:I

    shl-int/lit8 v3, v3, 0x5

    add-int/2addr v0, v3

    sget v3, Lg;->bo:I

    if-le v0, v3, :cond_2b1

    :goto_2a2
    sput v1, Lg;->bA:I

    sput v6, Lg;->bs:I

    sget v0, Lg;->bA:I

    sget v1, Lq;->aC:I

    add-int/lit8 v1, v1, 0x2

    mul-int/2addr v0, v1

    sput v0, Lg;->bq:I

    goto/16 :goto_f

    :cond_2b1
    move v1, v2

    goto :goto_2a2

    :cond_2b3
    sput v1, Lg;->bs:I

    goto/16 :goto_f
.end method
