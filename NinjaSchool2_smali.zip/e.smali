.class public final Le;
.super Ljava/lang/Object;


# static fields
.field public static a:I

.field public static b:I

.field public static c:I

.field public static d:Z

.field public static e:I

.field public static f:I

.field private static g:I

.field private static h:I

.field private static i:I

.field private static j:I

.field private static k:I

.field private static l:I

.field private static m:I

.field private static n:I

.field private static o:I

.field private static p:[Ljavax/microedition/lcdui/Image;

.field private static q:I

.field private static r:[[I

.field private static s:[[I

.field private static t:[[I


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/16 v8, -0xa

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/16 v0, 0x1f40

    sput v0, Le;->f:I

    const/16 v0, 0xa

    new-array v0, v0, [[I

    new-array v1, v6, [I

    aput v5, v1, v7

    const/4 v2, -0x5

    aput v2, v1, v4

    aput-object v1, v0, v7

    new-array v1, v6, [I

    aput v5, v1, v7

    const/4 v2, -0x6

    aput v2, v1, v4

    aput-object v1, v0, v4

    new-array v1, v6, [I

    const/4 v2, -0x7

    aput v2, v1, v7

    aput v8, v1, v4

    aput-object v1, v0, v5

    const/4 v1, 0x3

    new-array v2, v6, [I

    const/4 v3, -0x6

    aput v3, v2, v7

    const/4 v3, -0x8

    aput v3, v2, v4

    aput-object v2, v0, v1

    new-array v1, v6, [I

    aput v8, v1, v7

    const/4 v2, -0x7

    aput v2, v1, v4

    aput-object v1, v0, v6

    const/4 v1, 0x5

    new-array v2, v6, [I

    const/4 v3, -0x1

    aput v3, v2, v7

    const/4 v3, -0x5

    aput v3, v2, v4

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v6, [I

    const/16 v3, -0xd

    aput v3, v2, v7

    const/4 v3, -0x4

    aput v3, v2, v4

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v6, [I

    const/4 v3, -0x7

    aput v3, v2, v7

    aput v8, v2, v4

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v6, [I

    const/16 v3, -0xd

    aput v3, v2, v7

    const/4 v3, -0x4

    aput v3, v2, v4

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v6, [I

    const/4 v3, -0x2

    aput v3, v2, v4

    aput-object v2, v0, v1

    sput-object v0, Le;->r:[[I

    const/16 v0, 0xa

    new-array v0, v0, [[I

    new-array v1, v5, [I

    fill-array-data v1, :array_de

    aput-object v1, v0, v7

    new-array v1, v5, [I

    fill-array-data v1, :array_e6

    aput-object v1, v0, v4

    new-array v1, v5, [I

    fill-array-data v1, :array_ee

    aput-object v1, v0, v5

    const/4 v1, 0x3

    new-array v2, v5, [I

    fill-array-data v2, :array_f6

    aput-object v2, v0, v1

    new-array v1, v5, [I

    aput v4, v1, v4

    aput-object v1, v0, v6

    const/4 v1, 0x5

    new-array v2, v5, [I

    fill-array-data v2, :array_fe

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v5, [I

    fill-array-data v2, :array_106

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v5, [I

    fill-array-data v2, :array_10e

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v5, [I

    fill-array-data v2, :array_116

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v5, [I

    fill-array-data v2, :array_11e

    aput-object v2, v0, v1

    sput-object v0, Le;->s:[[I

    new-array v0, v5, [[I

    const/16 v1, 0x8

    new-array v1, v1, [I

    fill-array-data v1, :array_126

    aput-object v1, v0, v7

    new-array v1, v6, [I

    fill-array-data v1, :array_13a

    aput-object v1, v0, v4

    sput-object v0, Le;->t:[[I

    return-void

    :array_de
    .array-data 4
        0x6
        0x7
    .end array-data

    :array_e6
    .array-data 4
        0x6
        0x7
    .end array-data

    :array_ee
    .array-data 4
        0x3
        0x4
    .end array-data

    :array_f6
    .array-data 4
        0x3
        0x1
    .end array-data

    :array_fe
    .array-data 4
        0x6
        0x1
    .end array-data

    :array_106
    .array-data 4
        0x2
        0x1
    .end array-data

    :array_10e
    .array-data 4
        0x3
        0x4
    .end array-data

    :array_116
    .array-data 4
        0x2
        0x1
    .end array-data

    :array_11e
    .array-data 4
        0x5
        0x8
    .end array-data

    :array_126
    .array-data 4
        0x5
        0x4
        0x4
        0x4
        0x5
        0x6
        0x6
        0x6
    .end array-data

    :array_13a
    .array-data 4
        0x5
        0x6
        0x6
        0x6
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 8

    const/16 v7, -0xc

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x0

    sget-boolean v1, Le;->d:Z

    if-nez v1, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    sget v1, Lq;->as:I

    const/16 v2, 0x6a

    if-eq v1, v2, :cond_31

    sget v1, Lq;->as:I

    const/16 v2, 0x14

    if-ne v1, v2, :cond_31

    sget-boolean v1, Lq;->aN:Z

    if-nez v1, :cond_31

    sget v1, Le;->a:I

    sget v2, Le;->m:I

    if-lt v1, v2, :cond_69

    const/4 v1, -0x1

    sput v1, Le;->o:I

    :goto_24
    const/16 v1, 0xb

    sput v1, Le;->c:I

    sput v4, Le;->k:I

    sput v4, Le;->j:I

    sput v7, Le;->h:I

    const/4 v1, 0x5

    sput v1, Le;->g:I

    :cond_31
    sget-boolean v1, Lq;->aA:Z

    if-eqz v1, :cond_3b

    sget v1, Le;->c:I

    if-eq v1, v0, :cond_3b

    sput v6, Le;->c:I

    :cond_3b
    sget v1, Le;->c:I

    packed-switch v1, :pswitch_data_352

    :pswitch_40  #0x5, 0x7, 0x8, 0x9, 0xa
    goto :goto_a

    :pswitch_41  #0x1
    const/16 v1, 0x9

    sput v1, Le;->i:I

    sget v1, Le;->h:I

    const/16 v2, 0x14

    if-ge v1, v2, :cond_51

    sget v1, Le;->h:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->h:I

    :cond_51
    sget v1, Le;->b:I

    sget v2, Le;->h:I

    add-int/2addr v1, v2

    sput v1, Le;->b:I

    const/16 v2, 0x180

    if-le v1, v2, :cond_a

    sput-boolean v4, Le;->d:Z

    sput-boolean v0, Lg;->C:Z

    const/4 v0, -0x1

    sput v0, Lg;->a:I

    const/16 v0, 0x2b

    invoke-static {v0}, Lq;->g(I)V

    goto :goto_a

    :cond_69
    sget v1, Le;->a:I

    sget v2, Le;->l:I

    if-gt v1, v2, :cond_31

    sput v0, Le;->o:I

    goto :goto_24

    :pswitch_72  #0x3
    sget v1, Le;->j:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->j:I

    const/16 v2, 0xa

    if-le v1, v2, :cond_7e

    sput v4, Le;->j:I

    :cond_7e
    sget v1, Le;->j:I

    const/4 v2, 0x6

    if-le v1, v2, :cond_c2

    sput v4, Le;->i:I

    :goto_85
    sget v1, Le;->a:I

    sget v2, Lg;->at:I

    if-le v1, v2, :cond_c5

    const/4 v1, -0x1

    sput v1, Le;->o:I

    :goto_8e
    sget v1, Le;->k:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->k:I

    sget v1, Lq;->as:I

    const/16 v2, 0x6a

    if-eq v1, v2, :cond_a

    sget v1, Lq;->as:I

    const/16 v2, 0x14

    if-ne v1, v2, :cond_a

    sget-boolean v1, Lq;->aN:Z

    if-nez v1, :cond_a

    sget-boolean v1, Lq;->aA:Z

    if-nez v1, :cond_a

    sget v1, Le;->k:I

    const/16 v2, 0x14

    if-le v1, v2, :cond_bd

    sput v4, Le;->k:I

    sput v0, Le;->g:I

    sput v5, Le;->c:I

    sget v1, Le;->a:I

    sget v2, Lg;->at:I

    if-le v1, v2, :cond_bb

    const/4 v0, -0x1

    :cond_bb
    sput v0, Le;->o:I

    :cond_bd
    invoke-static {}, Le;->b()V

    goto/16 :goto_a

    :cond_c2
    sput v0, Le;->i:I

    goto :goto_85

    :cond_c5
    sput v0, Le;->o:I

    goto :goto_8e

    :pswitch_c8  #0x2
    sget v1, Le;->g:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->g:I

    sget v1, Le;->j:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->j:I

    sget v1, Le;->o:I

    if-ne v1, v0, :cond_13c

    sget v1, Le;->a:I

    add-int/lit8 v1, v1, 0x2e

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x30

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x4

    const/4 v2, 0x4

    if-ne v1, v2, :cond_f6

    sput v4, Le;->g:I

    const/16 v1, 0xb

    sput v1, Le;->c:I

    sput v7, Le;->h:I

    sput v4, Le;->j:I

    const/4 v1, 0x5

    sput v1, Le;->g:I

    :cond_f6
    :goto_f6
    sput v6, Le;->i:I

    sget v1, Le;->a:I

    sget v2, Le;->g:I

    sget v3, Le;->o:I

    mul-int/2addr v2, v3

    add-int/2addr v1, v2

    sput v1, Le;->a:I

    sget v2, Le;->b:I

    invoke-static {v1, v2, v5}, Lj;->a(III)Z

    move-result v1

    if-nez v1, :cond_114

    const/16 v1, 0xa

    sput v1, Le;->g:I

    sput v4, Le;->j:I

    const/16 v1, 0xc

    sput v1, Le;->c:I

    :cond_114
    sget v1, Le;->g:I

    const/16 v2, 0xa

    if-le v1, v2, :cond_120

    sput v4, Le;->g:I

    sput v4, Le;->j:I

    sput v6, Le;->c:I

    :cond_120
    sget v1, Lg;->au:I

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x28

    if-ge v1, v2, :cond_137

    sget v1, Lg;->ax:I

    if-ne v1, v0, :cond_137

    const/16 v0, 0xb

    sput v0, Le;->c:I

    sput v7, Le;->h:I

    sput v4, Le;->j:I

    const/4 v0, 0x5

    sput v0, Le;->g:I

    :cond_137
    invoke-static {}, Le;->b()V

    goto/16 :goto_a

    :cond_13c
    sget v1, Le;->a:I

    add-int/lit8 v1, v1, -0x2e

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x30

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x8

    const/16 v2, 0x8

    if-ne v1, v2, :cond_f6

    sput v4, Le;->g:I

    const/16 v1, 0xb

    sput v1, Le;->c:I

    sput v7, Le;->h:I

    sput v4, Le;->j:I

    const/4 v1, 0x5

    sput v1, Le;->g:I

    goto :goto_f6

    :pswitch_15c  #0x4
    sget v1, Le;->o:I

    if-ne v1, v0, :cond_1d9

    sget v1, Le;->a:I

    add-int/lit8 v1, v1, 0x2e

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x30

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x4

    const/4 v2, 0x4

    if-ne v1, v2, :cond_173

    sput v4, Le;->g:I

    :cond_173
    :goto_173
    sget v1, Le;->b:I

    sget v2, Le;->h:I

    add-int/2addr v1, v2

    sput v1, Le;->b:I

    if-gez v1, :cond_180

    sput v4, Le;->h:I

    sput v4, Le;->b:I

    :cond_180
    sget v1, Le;->h:I

    if-gez v1, :cond_1ee

    sget v1, Le;->h:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->h:I

    if-nez v1, :cond_18e

    sput v0, Le;->h:I

    :cond_18e
    :goto_18e
    sget v1, Le;->n:I

    if-nez v1, :cond_22f

    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x2

    if-nez v1, :cond_a

    sget v1, Le;->j:I

    sget-object v2, Le;->t:[[I

    aget-object v2, v2, v4

    array-length v2, v2

    if-lt v1, v2, :cond_1b0

    sput v5, Le;->c:I

    sget v1, Le;->a:I

    sget v2, Lg;->at:I

    if-le v1, v2, :cond_22c

    const/4 v1, -0x1

    :goto_1aa
    sput v1, Le;->o:I

    sput v4, Le;->j:I

    sput v0, Le;->g:I

    :cond_1b0
    sget-object v1, Le;->t:[[I

    aget-object v1, v1, v4

    sget v2, Le;->j:I

    aget v1, v1, v2

    sput v1, Le;->i:I

    sget v1, Le;->j:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->j:I

    if-eq v1, v0, :cond_1c7

    sget v1, Le;->j:I

    const/4 v2, 0x5

    if-ne v1, v2, :cond_a

    :cond_1c7
    sget v1, Le;->a:I

    sget v2, Le;->o:I

    mul-int/lit8 v2, v2, 0x1a

    add-int/2addr v1, v2

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x1d

    sget v3, Le;->o:I

    invoke-static {v1, v2, v0, v3}, Lq;->a(IIII)V

    goto/16 :goto_a

    :cond_1d9
    sget v1, Le;->a:I

    add-int/lit8 v1, v1, -0x2e

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x30

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x8

    const/16 v2, 0x8

    if-ne v1, v2, :cond_173

    sput v4, Le;->g:I

    goto :goto_173

    :cond_1ee
    sget v1, Le;->h:I

    if-lez v1, :cond_18e

    sget v1, Le;->h:I

    const/16 v2, 0x14

    if-ge v1, v2, :cond_204

    sget v1, Le;->j:I

    rem-int/lit8 v1, v1, 0x5

    if-nez v1, :cond_204

    sget v1, Le;->h:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->h:I

    :cond_204
    sget v1, Le;->h:I

    if-le v1, v6, :cond_20a

    sput v6, Le;->h:I

    :cond_20a
    sget v1, Le;->h:I

    if-le v1, v5, :cond_18e

    sget v1, Le;->a:I

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, 0x3

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x2

    if-ne v1, v5, :cond_18e

    sput v4, Le;->h:I

    sput v4, Le;->g:I

    sget v1, Le;->b:I

    add-int/lit8 v1, v1, 0x3

    invoke-static {v1}, Lj;->e(I)I

    move-result v1

    sput v1, Le;->b:I

    goto/16 :goto_18e

    :cond_22c
    move v1, v0

    goto/16 :goto_1aa

    :cond_22f
    sget v1, Le;->n:I

    if-ne v1, v0, :cond_26c

    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x2

    if-nez v1, :cond_a

    sget v1, Le;->j:I

    sget-object v2, Le;->t:[[I

    aget-object v2, v2, v0

    array-length v2, v2

    if-lt v1, v2, :cond_248

    sput v5, Le;->c:I

    sput v0, Le;->g:I

    sput v4, Le;->j:I

    :cond_248
    sget-object v1, Le;->t:[[I

    aget-object v0, v1, v0

    sget v1, Le;->j:I

    aget v0, v0, v1

    sput v0, Le;->i:I

    sget v0, Le;->j:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Le;->j:I

    if-ne v0, v5, :cond_a

    sget v0, Le;->a:I

    sget v1, Le;->o:I

    mul-int/lit8 v1, v1, 0x1a

    add-int/2addr v0, v1

    sget v1, Le;->b:I

    add-int/lit8 v1, v1, -0x12

    sget v2, Le;->o:I

    invoke-static {v0, v1, v5, v2}, Lq;->a(IIII)V

    goto/16 :goto_a

    :cond_26c
    sget v0, Le;->a:I

    sget v1, Le;->g:I

    sget v2, Le;->o:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    sput v0, Le;->a:I

    goto/16 :goto_a

    :pswitch_278  #0x6
    const/16 v0, 0x9

    sput v0, Le;->i:I

    sget v0, Le;->j:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Le;->j:I

    if-lt v0, v6, :cond_a

    sput v4, Le;->j:I

    const/4 v0, -0x5

    invoke-static {v7, v0}, Lq;->e(II)I

    move-result v0

    sput v0, Le;->h:I

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {v0, v1}, Lq;->e(II)I

    move-result v0

    sput v0, Le;->g:I

    const/16 v0, 0xb

    sput v0, Le;->c:I

    goto/16 :goto_a

    :pswitch_29b  #0xb
    sget v1, Le;->b:I

    sget v2, Lq;->X:I

    if-ge v1, v2, :cond_2ab

    const/16 v1, 0xc

    sput v1, Le;->c:I

    const/16 v1, 0xa

    sput v1, Le;->g:I

    sput v4, Le;->j:I

    :cond_2ab
    sget v1, Le;->j:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->j:I

    sput v5, Le;->i:I

    sget v1, Le;->b:I

    sget v2, Le;->h:I

    add-int/2addr v1, v2

    sput v1, Le;->b:I

    sget v1, Le;->a:I

    sget v2, Le;->o:I

    sget v3, Le;->g:I

    mul-int/2addr v2, v3

    add-int/2addr v1, v2

    sput v1, Le;->a:I

    sget v1, Le;->h:I

    const/16 v2, 0xc

    if-ge v1, v2, :cond_2d0

    sget v1, Le;->h:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->h:I

    :cond_2d0
    sget v1, Le;->h:I

    if-nez v1, :cond_2de

    const/16 v1, 0xa

    sput v1, Le;->g:I

    const/16 v1, 0xc

    sput v1, Le;->c:I

    sput v4, Le;->j:I

    :cond_2de
    sget v1, Le;->a:I

    sget v2, Le;->b:I

    invoke-static {v1, v2, v5}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_a

    sget v1, Le;->j:I

    const/16 v2, 0x8

    if-le v1, v2, :cond_a

    sget v1, Le;->b:I

    invoke-static {v1}, Lj;->e(I)I

    move-result v1

    sput v1, Le;->b:I

    sput v4, Le;->h:I

    sput v0, Le;->g:I

    sput v5, Le;->c:I

    goto/16 :goto_a

    :pswitch_2fe  #0xc
    sget v1, Le;->h:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Le;->h:I

    sget v1, Le;->a:I

    sget v2, Le;->g:I

    sget v3, Le;->o:I

    mul-int/2addr v2, v3

    add-int/2addr v1, v2

    sput v1, Le;->a:I

    sget v1, Le;->b:I

    sget v2, Le;->h:I

    add-int/2addr v1, v2

    sput v1, Le;->b:I

    sget v1, Le;->g:I

    if-lez v1, :cond_31f

    sget v1, Le;->g:I

    add-int/lit8 v1, v1, -0x1

    sput v1, Le;->g:I

    :cond_31f
    sput v5, Le;->i:I

    sget v1, Le;->b:I

    add-int/lit8 v1, v1, 0x4

    sget v2, Lj;->d:I

    if-ge v1, v2, :cond_a

    sget v1, Le;->h:I

    const/4 v2, 0x4

    if-le v1, v2, :cond_a

    sget v1, Le;->a:I

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, 0x3

    invoke-static {v1, v2}, Lj;->b(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x2

    if-ne v1, v5, :cond_a

    sput v5, Le;->c:I

    sput v0, Le;->g:I

    sput v4, Le;->h:I

    sput v4, Le;->k:I

    sput v4, Le;->j:I

    sget v0, Le;->b:I

    add-int/lit8 v0, v0, 0x3

    invoke-static {v0}, Lj;->e(I)I

    move-result v0

    sput v0, Le;->b:I

    goto/16 :goto_a

    :pswitch_data_352
    .packed-switch 0x1
        :pswitch_41  #00000001
        :pswitch_c8  #00000002
        :pswitch_72  #00000003
        :pswitch_15c  #00000004
        :pswitch_40  #00000005
        :pswitch_278  #00000006
        :pswitch_40  #00000007
        :pswitch_40  #00000008
        :pswitch_40  #00000009
        :pswitch_40  #0000000a
        :pswitch_29b  #0000000b
        :pswitch_2fe  #0000000c
    .end packed-switch
.end method

.method public static a(I)V
    .registers 7

    const/16 v5, 0x6a

    const/16 v4, 0x8

    const/4 v0, 0x0

    sget-boolean v1, Lg;->C:Z

    if-eqz v1, :cond_a

    :cond_9
    :goto_9
    return-void

    :cond_a
    sput-boolean v0, Le;->d:Z

    if-eq p0, v5, :cond_12

    const/16 v1, 0x14

    if-ne p0, v1, :cond_9

    :cond_12
    const/4 v1, 0x1

    sput-boolean v1, Le;->d:Z

    const/4 v1, -0x1

    sput v1, Le;->o:I

    const/4 v1, 0x3

    sput v1, Le;->c:I

    const/16 v1, 0x9

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Le;->p:[Ljavax/microedition/lcdui/Image;

    :goto_21
    if-lt v0, v4, :cond_3a

    :try_start_23
    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x8

    const-string v2, "/cp/cb0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_2f
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_2f} :catch_5a

    :goto_2f
    if-ne p0, v5, :cond_63

    const/16 v0, 0x42a

    sput v0, Le;->a:I

    const/16 v0, 0xa8

    sput v0, Le;->b:I

    goto :goto_9

    :cond_3a
    :try_start_3a
    sget-object v1, Le;->p:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/mob/nj6t"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_57
    .catch Ljava/io/IOException; {:try_start_3a .. :try_end_57} :catch_5a

    add-int/lit8 v0, v0, 0x1

    goto :goto_21

    :catch_5a
    move-exception v0

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "Image Error"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_2f

    :cond_63
    const/16 v0, 0x712

    sput v0, Le;->a:I

    const/16 v0, 0x120

    sput v0, Le;->b:I

    const/16 v0, 0x18

    sput v0, Le;->l:I

    const/16 v0, 0x768

    sput v0, Le;->m:I

    const/16 v0, 0xc8

    sput v0, Le;->e:I

    const/16 v0, 0x1f40

    sput v0, Le;->f:I

    goto :goto_9
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/16 v9, 0x21

    const/4 v11, 0x3

    const/4 v6, 0x2

    const/4 v10, 0x1

    const/4 v2, 0x0

    sget-boolean v0, Le;->d:Z

    if-nez v0, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    sget v0, Le;->o:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_a8

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Le;->s:[[I

    sget v3, Le;->i:I

    aget-object v1, v1, v3

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Le;->a:I

    sget-object v3, Le;->r:[[I

    sget v4, Le;->i:I

    aget-object v3, v3, v4

    aget v2, v3, v2

    add-int/2addr v1, v2

    sget v2, Le;->b:I

    sget-object v3, Le;->r:[[I

    sget v4, Le;->i:I

    aget-object v3, v3, v4

    aget v3, v3, v10

    add-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Le;->s:[[I

    sget v2, Le;->i:I

    aget-object v1, v1, v2

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget v1, Le;->a:I

    sget-object v2, Le;->r:[[I

    sget v3, Le;->i:I

    aget-object v2, v2, v3

    aget v2, v2, v6

    add-int/2addr v1, v2

    sget v2, Le;->b:I

    sget-object v3, Le;->r:[[I

    sget v4, Le;->i:I

    aget-object v3, v3, v4

    aget v3, v3, v11

    add-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :goto_5a
    sget v0, Le;->q:I

    if-eqz v0, :cond_a

    const v0, 0x330011

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Le;->a:I

    add-int/lit8 v0, v0, -0x17

    add-int/lit8 v0, v0, -0x1

    sget v1, Le;->b:I

    add-int/lit8 v1, v1, -0x30

    add-int/lit8 v1, v1, -0x7

    const/16 v2, 0x30

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Le;->f:I

    mul-int/lit8 v0, v0, 0x2e

    div-int/lit16 v0, v0, 0x1f40

    const/high16 v1, 0xee0000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Le;->a:I

    add-int/lit8 v1, v1, -0x17

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x30

    add-int/lit8 v2, v2, -0x6

    invoke-virtual {p0, v1, v2, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0x440022

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Le;->a:I

    add-int/lit8 v1, v1, -0x17

    add-int/2addr v1, v0

    sget v2, Le;->b:I

    add-int/lit8 v2, v2, -0x30

    add-int/lit8 v2, v2, -0x6

    rsub-int/lit8 v0, v0, 0x2e

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v1, v2, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    goto/16 :goto_a

    :cond_a8
    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Le;->s:[[I

    sget v3, Le;->i:I

    aget-object v1, v1, v3

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Le;->s:[[I

    sget v4, Le;->i:I

    aget-object v3, v3, v4

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Le;->s:[[I

    sget v5, Le;->i:I

    aget-object v3, v3, v5

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Le;->a:I

    sget-object v3, Le;->r:[[I

    sget v7, Le;->i:I

    aget-object v3, v3, v7

    aget v3, v3, v2

    sub-int v7, v0, v3

    sget v0, Le;->b:I

    sget-object v3, Le;->r:[[I

    sget v8, Le;->i:I

    aget-object v3, v3, v8

    aget v3, v3, v10

    add-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Le;->s:[[I

    sget v3, Le;->i:I

    aget-object v1, v1, v3

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Le;->s:[[I

    sget v4, Le;->i:I

    aget-object v3, v3, v4

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Le;->p:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Le;->s:[[I

    sget v5, Le;->i:I

    aget-object v3, v3, v5

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Le;->a:I

    sget-object v3, Le;->r:[[I

    sget v7, Le;->i:I

    aget-object v3, v3, v7

    aget v3, v3, v6

    add-int v7, v0, v3

    sget v0, Le;->b:I

    sget-object v3, Le;->r:[[I

    sget v8, Le;->i:I

    aget-object v3, v3, v8

    aget v3, v3, v11

    add-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_5a
.end method

.method public static a(II)Z
    .registers 9

    const/4 v6, 0x1

    const/4 v0, 0x0

    sget v1, Le;->f:I

    sub-int/2addr v1, p0

    sput v1, Le;->f:I

    sget v1, Le;->c:I

    if-ne v1, v6, :cond_d

    move v0, v6

    :goto_c
    return v0

    :cond_d
    sget v1, Le;->f:I

    if-gtz v1, :cond_53

    sput v0, Le;->f:I

    sput p1, Le;->o:I

    shl-int/lit8 v1, p1, 0x3

    neg-int v1, v1

    sput v1, Le;->g:I

    const/16 v1, -0xc

    sput v1, Le;->h:I

    sput v0, Le;->j:I

    sput v6, Le;->c:I

    sget v0, Le;->a:I

    sget v1, Le;->b:I

    sget v2, Le;->o:I

    shl-int/lit8 v2, v2, 0x2

    neg-int v2, v2

    const/4 v3, -0x4

    sget v4, Lq;->at:I

    rem-int/lit8 v4, v4, 0xa

    add-int/lit8 v4, v4, 0x5f

    invoke-static {v0, v1, v2, v3, v4}, Lq;->a(IIIII)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x14

    const/4 v1, 0x5

    if-le v0, v1, :cond_51

    sget v0, Le;->a:I

    sget v1, Le;->b:I

    sget v2, Le;->o:I

    shl-int/lit8 v2, v2, 0x3

    neg-int v2, v2

    const/4 v3, -0x5

    sget v4, Le;->e:I

    sget v5, Lq;->at:I

    add-int/lit8 v5, v5, 0x1

    rem-int/lit8 v5, v5, 0x2

    invoke-static/range {v0 .. v5}, Lq;->a(IIIIII)V

    :cond_51
    move v0, v6

    goto :goto_c

    :cond_53
    sput v0, Le;->j:I

    sput p1, Le;->o:I

    const/16 v1, 0x64

    sput v1, Le;->q:I

    const/4 v1, 0x6

    sput v1, Le;->c:I

    goto :goto_c
.end method

.method private static b()V
    .registers 7

    const/4 v6, 0x4

    const/16 v5, 0x1e

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v1, -0x1

    sget v2, Lg;->au:I

    sget v3, Le;->b:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    if-gt v2, v5, :cond_4d

    sget v2, Le;->a:I

    sget v3, Le;->o:I

    shl-int/lit8 v3, v3, 0x3

    add-int/2addr v2, v3

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x2d

    if-ge v2, v3, :cond_4d

    sget v2, Le;->a:I

    sget v3, Le;->o:I

    shl-int/lit8 v3, v3, 0x3

    add-int/2addr v2, v3

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    if-le v2, v5, :cond_4d

    sget v2, Lq;->am:I

    if-ne v2, v1, :cond_4d

    sput v4, Le;->j:I

    sput v4, Le;->k:I

    sput v6, Le;->c:I

    sget v2, Lg;->at:I

    sget v3, Le;->a:I

    if-le v2, v3, :cond_4b

    :goto_43
    sput v0, Le;->o:I

    sput v4, Le;->n:I

    const/4 v0, 0x5

    sput v0, Le;->i:I

    :cond_4a
    :goto_4a
    return-void

    :cond_4b
    move v0, v1

    goto :goto_43

    :cond_4d
    sget v2, Lg;->au:I

    sget v3, Le;->b:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    if-gt v2, v5, :cond_4a

    sget v2, Le;->a:I

    sget v3, Le;->o:I

    shl-int/lit8 v3, v3, 0x3

    add-int/2addr v2, v3

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x64

    if-ge v2, v3, :cond_4a

    sget v2, Lq;->am:I

    if-ne v2, v1, :cond_4a

    sget v2, Le;->a:I

    sget v3, Le;->o:I

    shl-int/lit8 v3, v3, 0x3

    add-int/2addr v2, v3

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x2d

    if-lt v2, v3, :cond_4a

    sput v4, Le;->j:I

    sput v4, Le;->k:I

    sput v6, Le;->c:I

    sget v2, Lg;->at:I

    sget v3, Le;->a:I

    if-le v2, v3, :cond_8d

    move v1, v0

    :cond_8d
    sput v1, Le;->o:I

    sput v0, Le;->n:I

    goto :goto_4a
.end method
