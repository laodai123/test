.class public final Ln;
.super Ljava/lang/Object;


# static fields
.field private static A:[I

.field private static B:[I

.field private static C:[I

.field private static D:[I

.field private static E:[I

.field private static F:[I

.field private static G:[I

.field private static H:[I

.field private static I:[Z

.field private static J:[Z

.field public static a:Z

.field public static final b:[I

.field public static c:I

.field public static d:[I

.field public static e:[I

.field public static f:[I

.field public static g:[I

.field public static h:[I

.field public static i:[I

.field public static j:[I

.field public static k:[I

.field private static l:[I

.field private static m:[I

.field private static n:[I

.field private static o:[[I

.field private static p:[[I

.field private static q:[I

.field private static r:[Ljavax/microedition/lcdui/Image;

.field private static s:[[Ljavax/microedition/lcdui/Image;

.field private static t:[I

.field private static u:[I

.field private static v:[I

.field private static w:[I

.field private static x:[I

.field private static y:[I

.field private static z:[I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    const/4 v7, 0x0

    const/4 v6, -0x5

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    new-array v0, v4, [I

    fill-array-data v0, :array_94

    sput-object v0, Ln;->l:[I

    new-array v0, v4, [I

    fill-array-data v0, :array_a6

    sput-object v0, Ln;->b:[I

    new-array v0, v4, [I

    fill-array-data v0, :array_b8

    sput-object v0, Ln;->m:[I

    new-array v0, v4, [I

    fill-array-data v0, :array_ca

    sput-object v0, Ln;->n:[I

    new-array v0, v4, [[I

    new-array v1, v3, [I

    fill-array-data v1, :array_dc

    aput-object v1, v0, v7

    new-array v1, v3, [I

    fill-array-data v1, :array_e4

    aput-object v1, v0, v5

    new-array v1, v3, [I

    aput-object v1, v0, v3

    const/4 v1, 0x3

    new-array v2, v3, [I

    fill-array-data v2, :array_ec

    aput-object v2, v0, v1

    const/4 v1, 0x4

    new-array v2, v3, [I

    fill-array-data v2, :array_f4

    aput-object v2, v0, v1

    const/4 v1, 0x5

    new-array v2, v3, [I

    fill-array-data v2, :array_fc

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v3, [I

    aput-object v2, v0, v1

    sput-object v0, Ln;->o:[[I

    new-array v0, v4, [[I

    new-array v1, v3, [I

    fill-array-data v1, :array_104

    aput-object v1, v0, v7

    new-array v1, v3, [I

    fill-array-data v1, :array_10c

    aput-object v1, v0, v5

    new-array v1, v3, [I

    aput v6, v1, v5

    aput-object v1, v0, v3

    const/4 v1, 0x3

    new-array v2, v3, [I

    fill-array-data v2, :array_114

    aput-object v2, v0, v1

    const/4 v1, 0x4

    new-array v2, v3, [I

    fill-array-data v2, :array_11c

    aput-object v2, v0, v1

    const/4 v1, 0x5

    new-array v2, v3, [I

    fill-array-data v2, :array_124

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v3, [I

    aput v6, v2, v5

    aput-object v2, v0, v1

    sput-object v0, Ln;->p:[[I

    new-array v0, v4, [I

    fill-array-data v0, :array_12c

    sput-object v0, Ln;->q:[I

    return-void

    nop

    :array_94
    .array-data 4
        0x384
        0x384
        0xcf8
        0x7d0
        0xc80
        0xce4
        0xdac
    .end array-data

    :array_a6
    .array-data 4
        0x3c
        0x46
        0x5a
        0x12c
        0x190
        0x1f4
        0x258
    .end array-data

    :array_b8
    .array-data 4
        0x5f
        0x5a
        0x50
        0x87
        0x8c
        0x91
        0x96
    .end array-data

    :array_ca
    .array-data 4
        0x96
        0x8c
        0x78
        0xf0
        0x118
        0x122
        0x12c
    .end array-data

    :array_dc
    .array-data 4
        0x5
        0x8
    .end array-data

    :array_e4
    .array-data 4
        0x3
        0x3
    .end array-data

    :array_ec
    .array-data 4
        0x4
        0x4
    .end array-data

    :array_f4
    .array-data 4
        0x5
        0x8
    .end array-data

    :array_fc
    .array-data 4
        0x3
        0x3
    .end array-data

    :array_104
    .array-data 4
        -0x5
        -0x2
    .end array-data

    :array_10c
    .array-data 4
        -0x2
        -0x4
    .end array-data

    :array_114
    .array-data 4
        -0x6
        -0x6
    .end array-data

    :array_11c
    .array-data 4
        -0x5
        -0x2
    .end array-data

    :array_124
    .array-data 4
        -0x2
        -0x4
    .end array-data

    :array_12c
    .array-data 4
        0x1
        -0x2
        0x1
        0x1
        0x1
        -0x2
        0x1
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a(II)I
    .registers 9

    const/16 v6, 0x8

    const/4 v0, 0x0

    div-int/lit8 v2, p0, 0x18

    div-int/lit8 v3, p1, 0x18

    move v1, v0

    :cond_8
    add-int/lit8 v1, v1, 0x1

    add-int/lit8 v2, v2, -0x1

    if-gtz v2, :cond_11

    :goto_e
    mul-int/lit8 v0, v0, 0x18

    return v0

    :cond_11
    if-gt v1, v6, :cond_26

    invoke-static {v2, v3}, Lj;->a(II)I

    move-result v4

    and-int/lit8 v4, v4, 0x2

    const/4 v5, 0x2

    if-ne v4, v5, :cond_26

    add-int/lit8 v4, v3, -0x1

    invoke-static {v2, v4}, Lj;->a(II)I

    move-result v4

    and-int/lit8 v4, v4, 0x8

    if-ne v4, v6, :cond_8

    :cond_26
    add-int/lit8 v0, v2, 0x1

    goto :goto_e
.end method

.method public static a()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Ln;->s:[[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method public static a(I)V
    .registers 9

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x4

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_a

    :cond_9
    :goto_9
    return-void

    :cond_a
    const/4 v0, 0x0

    sput v0, Ln;->c:I

    const/4 v0, 0x0

    sput-boolean v0, Ln;->a:Z

    const/16 v0, 0x6a

    if-ne p0, v0, :cond_4c

    sput v6, Ln;->c:I

    new-array v0, v6, [Z

    aput-boolean v4, v0, v5

    aput-boolean v4, v0, v3

    const/4 v1, 0x5

    aput-boolean v4, v0, v1

    aput-boolean v4, v0, v7

    sput-object v0, Ln;->J:[Z

    invoke-static {}, Ln;->c()V

    const/4 v0, 0x0

    const/16 v1, 0x2a

    invoke-static {v0, v1, v6, v5}, Ln;->a(IIII)V

    const/16 v0, 0x2b

    invoke-static {v4, v0, v6, v3}, Ln;->a(IIII)V

    const/4 v0, 0x2

    const/16 v1, 0x2d

    invoke-static {v0, v1, v6, v5}, Ln;->a(IIII)V

    const/16 v0, 0x2e

    invoke-static {v5, v0, v6, v3}, Ln;->a(IIII)V

    const/16 v0, 0x2c

    invoke-static {v3, v0, v6, v7}, Ln;->a(IIII)V

    const/4 v0, 0x5

    const/16 v1, 0x2d

    invoke-static {v0, v1, v6, v7}, Ln;->a(IIII)V

    const/16 v0, 0x2a

    invoke-static {v7, v0, v6, v7}, Ln;->a(IIII)V

    :cond_4c
    const/16 v0, 0x14

    if-ne p0, v0, :cond_8d

    sput v7, Ln;->c:I

    new-array v0, v6, [Z

    aput-boolean v4, v0, v5

    aput-boolean v4, v0, v3

    const/4 v1, 0x5

    aput-boolean v4, v0, v1

    aput-boolean v4, v0, v7

    sput-object v0, Ln;->J:[Z

    invoke-static {}, Ln;->c()V

    const/4 v0, 0x0

    const/16 v1, 0xb

    invoke-static {v0, v5, v1, v5}, Ln;->a(IIII)V

    const/16 v0, 0xd

    const/16 v1, 0xb

    invoke-static {v4, v0, v1, v3}, Ln;->a(IIII)V

    const/4 v0, 0x2

    const/16 v1, 0x16

    const/16 v2, 0xe

    invoke-static {v0, v1, v2, v5}, Ln;->a(IIII)V

    const/16 v0, 0x1d

    const/16 v1, 0xd

    invoke-static {v5, v0, v1, v3}, Ln;->a(IIII)V

    const/16 v0, 0x32

    const/16 v1, 0xa

    invoke-static {v3, v0, v1, v5}, Ln;->a(IIII)V

    const/4 v0, 0x5

    const/16 v1, 0x34

    const/16 v2, 0xa

    invoke-static {v0, v1, v2, v3}, Ln;->a(IIII)V

    :cond_8d
    const/16 v0, 0xd

    if-ne p0, v0, :cond_9

    const/16 v0, 0xa

    sput v0, Ln;->c:I

    new-array v0, v6, [Z

    aput-boolean v4, v0, v5

    aput-boolean v4, v0, v3

    const/4 v1, 0x5

    aput-boolean v4, v0, v1

    aput-boolean v4, v0, v7

    sput-object v0, Ln;->J:[Z

    invoke-static {}, Ln;->c()V

    const/4 v0, 0x0

    const/16 v1, 0x33

    const/16 v2, 0xb

    invoke-static {v0, v1, v2, v3}, Ln;->a(IIII)V

    const/4 v0, 0x2

    const/16 v1, 0x2c

    const/16 v2, 0x9

    invoke-static {v0, v1, v2, v3}, Ln;->a(IIII)V

    const/16 v0, 0x10

    const/16 v1, 0xb

    invoke-static {v5, v0, v1, v3}, Ln;->a(IIII)V

    const/16 v0, 0x35

    const/16 v1, 0xb

    invoke-static {v3, v0, v1, v3}, Ln;->a(IIII)V

    const/4 v0, 0x5

    const/16 v1, 0x4b

    invoke-static {v0, v1, v7, v3}, Ln;->a(IIII)V

    const/16 v0, 0x55

    invoke-static {v7, v0, v3, v3}, Ln;->a(IIII)V

    const/16 v0, 0x13

    const/16 v1, 0xb

    invoke-static {v6, v0, v1, v3}, Ln;->a(IIII)V

    const/16 v0, 0x8

    const/16 v1, 0x4f

    const/16 v2, 0xb

    invoke-static {v0, v1, v2, v3}, Ln;->a(IIII)V

    const/16 v0, 0x9

    const/16 v1, 0x58

    const/16 v2, 0xb

    invoke-static {v0, v1, v2, v5}, Ln;->a(IIII)V

    const/16 v0, 0x45

    const/16 v1, 0x9

    invoke-static {v4, v0, v1, v3}, Ln;->a(IIII)V

    goto/16 :goto_9
.end method

.method private static a(IIII)V
    .registers 8

    const/4 v3, -0x1

    const/4 v2, 0x0

    sget-object v0, Ln;->u:[I

    mul-int/lit8 v1, p1, 0x18

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Ln;->v:[I

    mul-int/lit8 v1, p2, 0x18

    aput v1, v0, p0

    sget-object v0, Ln;->e:[I

    sget-object v1, Ln;->u:[I

    aget v1, v1, p0

    aput v1, v0, p0

    sget-object v0, Ln;->f:[I

    sget-object v1, Ln;->v:[I

    aget v1, v1, p0

    aput v1, v0, p0

    sget-object v0, Ln;->g:[I

    sget-object v1, Ln;->e:[I

    aget v1, v1, p0

    aput v1, v0, p0

    sget-object v0, Ln;->h:[I

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, -0x9

    aput v1, v0, p0

    sget-object v0, Ln;->B:[I

    aput p3, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x3

    aput v1, v0, p0

    sget-object v0, Ln;->C:[I

    shl-int/lit8 v1, p0, 0x1

    aput v1, v0, p0

    sget-object v0, Ln;->D:[I

    aput v2, v0, p0

    sget-object v0, Ln;->I:[Z

    aput-boolean v2, v0, p0

    sget-object v0, Ln;->j:[I

    aput v3, v0, p0

    sget-object v0, Ln;->E:[I

    aput v2, v0, p0

    sget-object v0, Ln;->F:[I

    aput v2, v0, p0

    sget-object v0, Ln;->A:[I

    aput v2, v0, p0

    sget-object v0, Ln;->G:[I

    sget-object v1, Ln;->u:[I

    aget v1, v1, p0

    sget-object v2, Ln;->v:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, 0xa

    invoke-static {v1, v2}, Ln;->a(II)I

    move-result v1

    aput v1, v0, p0

    sget-object v0, Ln;->H:[I

    sget-object v1, Ln;->u:[I

    aget v1, v1, p0

    sget-object v2, Ln;->v:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, 0xa

    invoke-static {v1, v2}, Ln;->b(II)I

    move-result v1

    aput v1, v0, p0

    sget-object v0, Ln;->d:[I

    sget-object v1, Ln;->l:[I

    sget-object v2, Ln;->B:[I

    aget v2, v2, p0

    aget v1, v1, v2

    aput v1, v0, p0

    sget-object v0, Ln;->k:[I

    aput v3, v0, p0

    return-void
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, 0x3

    const/4 v6, 0x2

    const/16 v9, 0x21

    const/4 v2, 0x0

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_a

    :cond_9
    return-void

    :cond_a
    move v10, v2

    :goto_b
    sget v0, Ln;->c:I

    if-ge v10, v0, :cond_9

    sget-object v0, Ln;->i:[I

    aget v0, v0, v10

    const/4 v1, 0x5

    if-eq v0, v1, :cond_e7

    sget-object v0, Ln;->e:[I

    aget v0, v0, v10

    add-int/lit8 v0, v0, 0xf

    sget v1, Lq;->ay:I

    if-lt v0, v1, :cond_e7

    sget-object v0, Ln;->e:[I

    aget v0, v0, v10

    add-int/lit8 v0, v0, -0xf

    sget v1, Lq;->ay:I

    sget v3, Lq;->ab:I

    add-int/2addr v1, v3

    if-gt v0, v1, :cond_e7

    sget-object v0, Ln;->f:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    if-lt v0, v1, :cond_e7

    sget-object v0, Ln;->f:[I

    aget v0, v0, v10

    add-int/lit8 v0, v0, -0x1e

    sget v1, Lq;->az:I

    sget v3, Lq;->ac:I

    add-int/2addr v1, v3

    if-gt v0, v1, :cond_e7

    sget-object v0, Ln;->j:[I

    aget v0, v0, v10

    const/4 v1, -0x1

    if-ne v0, v1, :cond_ec

    sget-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Ln;->E:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Ln;->e:[I

    aget v1, v1, v10

    sget-object v3, Ln;->q:[I

    sget-object v4, Ln;->B:[I

    aget v4, v4, v10

    aget v3, v3, v4

    add-int/2addr v1, v3

    sget-object v3, Ln;->f:[I

    aget v3, v3, v10

    invoke-virtual {p0, v0, v1, v3, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Ln;->s:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Ln;->B:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Ln;->F:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Ln;->g:[I

    aget v1, v1, v10

    sget-object v3, Ln;->p:[[I

    sget-object v4, Ln;->B:[I

    aget v4, v4, v10

    aget-object v3, v3, v4

    sget-object v4, Ln;->F:[I

    aget v4, v4, v10

    aget v3, v3, v4

    add-int/2addr v1, v3

    sget-object v3, Ln;->h:[I

    aget v3, v3, v10

    invoke-virtual {p0, v0, v1, v3, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :goto_8d
    sget-object v0, Ln;->t:[I

    aget v0, v0, v10

    if-eqz v0, :cond_e7

    const/16 v0, 0x3311

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, v10

    add-int/lit8 v0, v0, -0xd

    sget-object v1, Ln;->f:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0x28

    const/16 v3, 0x1a

    const/4 v4, 0x4

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v0, Ln;->d:[I

    aget v0, v0, v10

    mul-int/lit8 v0, v0, 0x18

    sget-object v1, Ln;->l:[I

    sget-object v3, Ln;->B:[I

    aget v3, v3, v10

    aget v1, v1, v3

    div-int/2addr v0, v1

    const/high16 v1, 0xee0000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v1, Ln;->e:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0xc

    sget-object v3, Ln;->f:[I

    aget v3, v3, v10

    add-int/lit8 v3, v3, -0x27

    invoke-virtual {p0, v1, v3, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0x440022

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v1, Ln;->e:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0xc

    add-int/2addr v1, v0

    sget-object v3, Ln;->f:[I

    aget v3, v3, v10

    add-int/lit8 v3, v3, -0x27

    rsub-int/lit8 v0, v0, 0x18

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v1, v3, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :cond_e7
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_b

    :cond_ec
    sget-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Ln;->E:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Ln;->E:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Ln;->E:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Ln;->e:[I

    aget v0, v0, v10

    sget-object v3, Ln;->q:[I

    sget-object v7, Ln;->B:[I

    aget v7, v7, v10

    aget v3, v3, v7

    sub-int v7, v0, v3

    sget-object v0, Ln;->f:[I

    aget v8, v0, v10

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Ln;->s:[[Ljavax/microedition/lcdui/Image;

    sget-object v1, Ln;->B:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Ln;->F:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Ln;->s:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Ln;->B:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Ln;->F:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Ln;->s:[[Ljavax/microedition/lcdui/Image;

    sget-object v3, Ln;->B:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    sget-object v3, Ln;->F:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Ln;->g:[I

    aget v0, v0, v10

    sget-object v3, Ln;->p:[[I

    sget-object v7, Ln;->B:[I

    aget v7, v7, v10

    aget-object v3, v3, v7

    sget-object v7, Ln;->F:[I

    aget v7, v7, v10

    aget v3, v3, v7

    sub-int v7, v0, v3

    sget-object v0, Ln;->h:[I

    aget v8, v0, v10

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_8d
.end method

.method public static a(III)Z
    .registers 11

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v0, 0x0

    sget-object v1, Ln;->d:[I

    aget v2, v1, p0

    sub-int/2addr v2, p1

    aput v2, v1, p0

    sget-object v1, Ln;->i:[I

    aget v1, v1, p0

    if-eq v1, v6, :cond_16

    sget-object v1, Ln;->i:[I

    aget v1, v1, p0

    if-ne v1, v7, :cond_18

    :cond_16
    move v0, v6

    :goto_17
    return v0

    :cond_18
    sget-object v1, Ln;->d:[I

    aget v1, v1, p0

    if-gtz v1, :cond_9b

    sget-object v1, Ln;->d:[I

    aput v0, v1, p0

    sget-object v1, Ln;->j:[I

    aput p2, v1, p0

    sget-object v1, Ln;->w:[I

    aput v0, v1, p0

    sget-object v1, Ln;->x:[I

    aput v0, v1, p0

    sget-object v1, Ln;->y:[I

    shl-int/lit8 v2, p2, 0x3

    neg-int v2, v2

    aput v2, v1, p0

    sget-object v1, Ln;->z:[I

    const/4 v2, -0x6

    aput v2, v1, p0

    sget-object v1, Ln;->C:[I

    aput v0, v1, p0

    sget-object v1, Ln;->t:[I

    aput v0, v1, p0

    sget-object v0, Ln;->i:[I

    aput v6, v0, p0

    sget-object v0, Ln;->n:[I

    sget-object v1, Ln;->B:[I

    aget v1, v1, p0

    aget v0, v0, v1

    invoke-static {v0}, Lg;->c(I)V

    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    sget-object v2, Ln;->j:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x2

    neg-int v2, v2

    const/4 v3, -0x4

    sget-object v4, Ln;->m:[I

    sget-object v5, Ln;->B:[I

    aget v5, v5, p0

    aget v4, v4, v5

    sget v5, Lq;->at:I

    rem-int/lit8 v5, v5, 0xa

    add-int/2addr v4, v5

    invoke-static {v0, v1, v2, v3, v4}, Lq;->a(IIIII)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x14

    if-le v0, v7, :cond_98

    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    sget-object v2, Ln;->j:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x3

    neg-int v2, v2

    const/4 v3, -0x5

    sget-object v4, Ln;->b:[I

    sget-object v5, Ln;->B:[I

    aget v5, v5, p0

    aget v4, v4, v5

    sget v5, Lq;->at:I

    add-int/lit8 v5, v5, 0x1

    rem-int/lit8 v5, v5, 0x2

    invoke-static/range {v0 .. v5}, Lq;->a(IIIIII)V

    :cond_98
    move v0, v6

    goto/16 :goto_17

    :cond_9b
    sget-object v1, Ln;->C:[I

    aput v0, v1, p0

    sget-object v1, Ln;->j:[I

    aput p2, v1, p0

    sget-object v1, Ln;->t:[I

    const/16 v2, 0x64

    aput v2, v1, p0

    sget-object v1, Ln;->i:[I

    const/4 v2, 0x6

    aput v2, v1, p0

    goto/16 :goto_17
.end method

.method private static b(II)I
    .registers 7

    div-int/lit8 v1, p0, 0x18

    div-int/lit8 v2, p1, 0x18

    const/4 v0, 0x0

    :cond_5
    add-int/lit8 v0, v0, 0x1

    add-int/lit8 v1, v1, 0x1

    sget v3, Lj;->a:I

    add-int/lit8 v3, v3, -0x1

    if-lt v1, v3, :cond_16

    sget v0, Lj;->a:I

    add-int/lit8 v0, v0, -0x1

    :goto_13
    mul-int/lit8 v0, v0, 0x18

    return v0

    :cond_16
    const/16 v3, 0x8

    if-gt v0, v3, :cond_2e

    invoke-static {v1, v2}, Lj;->a(II)I

    move-result v3

    and-int/lit8 v3, v3, 0x2

    const/4 v4, 0x2

    if-ne v3, v4, :cond_2e

    add-int/lit8 v3, v2, -0x1

    invoke-static {v1, v3}, Lj;->a(II)I

    move-result v3

    and-int/lit8 v3, v3, 0x4

    const/4 v4, 0x4

    if-ne v3, v4, :cond_5

    :cond_2e
    add-int/lit8 v0, v1, -0x1

    goto :goto_13
.end method

.method public static b()V
    .registers 11

    const/4 v4, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_a

    :cond_9
    :goto_9
    return-void

    :cond_a
    move v0, v1

    :goto_b
    sget v2, Ln;->c:I

    if-ge v0, v2, :cond_9

    sget-object v2, Ln;->k:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_37

    sget-object v2, Ln;->k:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_37

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_37

    sget-object v2, Ln;->d:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_2d

    sget-object v2, Ln;->d:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, -0x3

    aput v5, v2, v0

    :cond_2d
    sget-object v2, Ln;->d:[I

    aget v2, v2, v0

    if-ge v2, v3, :cond_37

    sget-object v2, Ln;->d:[I

    aput v3, v2, v0

    :cond_37
    sget-object v2, Ln;->k:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_47

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_47

    sget-object v2, Ln;->t:[I

    const/16 v5, 0x64

    aput v5, v2, v0

    :cond_47
    sget-object v2, Ln;->t:[I

    aget v2, v2, v0

    if-lez v2, :cond_55

    sget-object v2, Ln;->t:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, -0x1

    aput v5, v2, v0

    :cond_55
    sget-boolean v2, Lq;->aA:Z

    if-eqz v2, :cond_5d

    sget-object v2, Ln;->i:[I

    aput v10, v2, v0

    :cond_5d
    sget-object v2, Ln;->i:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_5fc

    :cond_64
    :goto_64
    :pswitch_64  #0x8, 0x9, 0xa
    sget-object v2, Ln;->g:[I

    sget-object v5, Ln;->e:[I

    aget v5, v5, v0

    aput v5, v2, v0

    sget-object v2, Ln;->h:[I

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    add-int/lit8 v5, v5, -0x9

    sget-object v6, Ln;->A:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    sget-object v6, Ln;->o:[[I

    sget-object v7, Ln;->B:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, Ln;->F:[I

    aget v7, v7, v0

    aget v6, v6, v7

    add-int/2addr v5, v6

    aput v5, v2, v0

    :cond_8a
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_b

    :pswitch_8e  #0xb
    sget-object v2, Ln;->f:[I

    aget v5, v2, v0

    sget-object v6, Ln;->x:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->e:[I

    aget v5, v2, v0

    sget-object v6, Ln;->w:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->E:[I

    const/4 v5, 0x4

    aput v5, v2, v0

    sget-object v2, Ln;->x:[I

    aget v2, v2, v0

    const/16 v5, 0xc

    if-ge v2, v5, :cond_c1

    sget-object v2, Ln;->x:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    :cond_c1
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    invoke-static {v2, v5, v9}, Lj;->a(III)Z

    move-result v2

    if-eqz v2, :cond_64

    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    const/4 v5, 0x4

    if-le v2, v5, :cond_64

    sget-object v2, Ln;->f:[I

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    invoke-static {v5}, Lj;->e(I)I

    move-result v5

    aput v5, v2, v0

    sget-object v2, Ln;->w:[I

    sget-object v5, Ln;->x:[I

    aput v1, v5, v0

    aput v1, v2, v0

    sget-object v2, Ln;->G:[I

    sget-object v5, Ln;->e:[I

    aget v5, v5, v0

    sget-object v6, Ln;->f:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0xa

    invoke-static {v5, v6}, Ln;->a(II)I

    move-result v5

    aput v5, v2, v0

    sget-object v2, Ln;->H:[I

    sget-object v5, Ln;->e:[I

    aget v5, v5, v0

    sget-object v6, Ln;->f:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0xa

    invoke-static {v5, v6}, Ln;->b(II)I

    move-result v5

    aput v5, v2, v0

    sget-object v2, Ln;->i:[I

    aput v10, v2, v0

    goto/16 :goto_64

    :pswitch_114  #0x3
    sget-object v2, Ln;->k:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_122

    sget v2, Lg;->as:I

    if-ne v2, v10, :cond_122

    sget-object v2, Ln;->k:[I

    aput v4, v2, v0

    :cond_122
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    invoke-static {v2, v5, v9}, Lj;->a(III)Z

    move-result v2

    if-nez v2, :cond_140

    sget-object v2, Ln;->w:[I

    const/16 v5, 0xa

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    sget-object v2, Ln;->i:[I

    const/16 v5, 0xc

    aput v5, v2, v0

    :cond_140
    sget v2, Lq;->at:I

    add-int/2addr v2, v0

    rem-int/lit8 v2, v2, 0xa

    const/4 v5, 0x5

    if-le v2, v5, :cond_1d7

    sget-object v2, Ln;->A:[I

    aput v3, v2, v0

    :goto_14c
    sget-object v2, Ln;->C:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->E:[I

    aput v1, v2, v0

    sget-object v2, Ln;->F:[I

    aput v1, v2, v0

    sget-boolean v2, Ln;->a:Z

    if-nez v2, :cond_64

    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    const/16 v5, 0x32

    if-le v2, v5, :cond_1bc

    sget v2, Lq;->at:I

    sub-int/2addr v2, v0

    add-int/lit8 v5, v0, 0x50

    rem-int/2addr v2, v5

    add-int/lit8 v2, v2, -0x28

    if-lez v2, :cond_1dd

    add-int/lit8 v2, v2, 0x14

    :goto_174
    sget-object v5, Ln;->D:[I

    sget-object v6, Ln;->e:[I

    aget v6, v6, v0

    add-int/2addr v6, v2

    aput v6, v5, v0

    sget-object v5, Ln;->j:[I

    if-lez v2, :cond_1e0

    move v2, v3

    :goto_182
    aput v2, v5, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x4

    if-le v2, v3, :cond_1e2

    sget-object v2, Ln;->i:[I

    aput v9, v2, v0

    sget-object v2, Ln;->w:[I

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    :goto_198
    sget-object v2, Ln;->D:[I

    aget v2, v2, v0

    sget-object v5, Ln;->G:[I

    aget v5, v5, v0

    if-ge v2, v5, :cond_1aa

    sget-object v2, Ln;->D:[I

    sget-object v5, Ln;->G:[I

    aget v5, v5, v0

    aput v5, v2, v0

    :cond_1aa
    sget-object v2, Ln;->D:[I

    aget v2, v2, v0

    sget-object v5, Ln;->H:[I

    aget v5, v5, v0

    if-le v2, v5, :cond_1bc

    sget-object v2, Ln;->D:[I

    sget-object v5, Ln;->H:[I

    aget v5, v5, v0

    aput v5, v2, v0

    :cond_1bc
    sget v2, Lg;->as:I

    if-ne v2, v10, :cond_1c6

    sget-object v2, Ln;->k:[I

    aget v2, v2, v0

    if-eq v2, v3, :cond_9

    :cond_1c6
    sget-object v2, Ln;->I:[Z

    aget-boolean v2, v2, v0

    if-eqz v2, :cond_1f2

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x7

    if-nez v2, :cond_1f2

    invoke-static {v0}, Ln;->b(I)V

    goto/16 :goto_64

    :cond_1d7
    sget-object v2, Ln;->A:[I

    aput v1, v2, v0

    goto/16 :goto_14c

    :cond_1dd
    add-int/lit8 v2, v2, -0x14

    goto :goto_174

    :cond_1e0
    move v2, v4

    goto :goto_182

    :cond_1e2
    sget-object v2, Ln;->i:[I

    const/4 v5, 0x7

    aput v5, v2, v0

    sget-object v2, Ln;->w:[I

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x2

    aput v5, v2, v0

    goto :goto_198

    :cond_1f2
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0xa

    if-nez v2, :cond_64

    invoke-static {v0}, Ln;->c(I)V

    invoke-static {v0}, Ln;->d(I)V

    goto/16 :goto_64

    :pswitch_200  #0x2
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    invoke-static {v2, v5, v9}, Lj;->a(III)Z

    move-result v2

    if-nez v2, :cond_21e

    sget-object v2, Ln;->w:[I

    const/16 v5, 0xa

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    sget-object v2, Ln;->i:[I

    const/16 v5, 0xc

    aput v5, v2, v0

    :cond_21e
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0xc

    const/4 v5, 0x5

    if-le v2, v5, :cond_258

    sget-object v2, Ln;->A:[I

    aput v3, v2, v0

    sget-object v2, Ln;->E:[I

    aput v3, v2, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0xc

    const/16 v5, 0x8

    if-ge v2, v5, :cond_253

    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->D:[I

    aget v5, v5, v0

    sub-int/2addr v2, v5

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/4 v5, 0x4

    if-ge v2, v5, :cond_248

    invoke-static {v0}, Ln;->b(I)V

    :cond_248
    sget-object v2, Ln;->e:[I

    aget v5, v2, v0

    sget-object v6, Ln;->w:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    :cond_253
    invoke-static {v0}, Ln;->c(I)V

    goto/16 :goto_64

    :cond_258
    sget-object v2, Ln;->E:[I

    aput v1, v2, v0

    sget-object v2, Ln;->A:[I

    aput v1, v2, v0

    goto/16 :goto_64

    :pswitch_262  #0xc
    sget-object v2, Ln;->x:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->e:[I

    aget v5, v2, v0

    sget-object v6, Ln;->w:[I

    aget v6, v6, v0

    sget-object v7, Ln;->j:[I

    aget v7, v7, v0

    mul-int/2addr v6, v7

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->f:[I

    aget v5, v2, v0

    sget-object v6, Ln;->x:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->w:[I

    aget v2, v2, v0

    if-lez v2, :cond_293

    sget-object v2, Ln;->w:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, -0x1

    aput v5, v2, v0

    :cond_293
    sget-object v2, Ln;->E:[I

    aput v9, v2, v0

    sget-object v2, Ln;->f:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0x4

    sget v5, Lj;->d:I

    if-ge v2, v5, :cond_9

    sget-object v2, Ln;->x:[I

    aget v2, v2, v0

    const/4 v5, 0x4

    if-le v2, v5, :cond_64

    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    add-int/lit8 v5, v5, 0x3

    invoke-static {v2, v5}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x2

    if-ne v2, v9, :cond_64

    sget-object v2, Ln;->i:[I

    aput v9, v2, v0

    sget-object v2, Ln;->w:[I

    aput v3, v2, v0

    sget-object v2, Ln;->x:[I

    aput v1, v2, v0

    sget-object v2, Ln;->C:[I

    sget-object v3, Ln;->D:[I

    aput v1, v3, v0

    aput v1, v2, v0

    sget-object v1, Ln;->f:[I

    sget-object v2, Ln;->f:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0x3

    invoke-static {v2}, Lj;->e(I)I

    move-result v2

    aput v2, v1, v0

    goto/16 :goto_9

    :pswitch_2de  #0x7
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->D:[I

    aget v5, v5, v0

    sub-int/2addr v2, v5

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v5, 0xc

    if-ge v2, v5, :cond_2f4

    invoke-static {v0}, Ln;->b(I)V

    goto/16 :goto_64

    :cond_2f4
    sget-object v2, Ln;->e:[I

    aget v5, v2, v0

    sget-object v6, Ln;->w:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-ne v2, v3, :cond_31b

    sget-object v2, Ln;->A:[I

    aput v3, v2, v0

    sget-object v2, Ln;->E:[I

    aput v10, v2, v0

    :goto_30d
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x4

    if-nez v2, :cond_64

    invoke-static {v0}, Ln;->c(I)V

    invoke-static {v0}, Ln;->d(I)V

    goto/16 :goto_64

    :cond_31b
    sget-object v2, Ln;->E:[I

    aput v9, v2, v0

    sget-object v2, Ln;->A:[I

    aput v1, v2, v0

    goto :goto_30d

    :pswitch_324  #0x4
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    invoke-static {v2, v5, v9}, Lj;->a(III)Z

    move-result v2

    if-nez v2, :cond_342

    sget-object v2, Ln;->w:[I

    const/16 v5, 0xa

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    sget-object v2, Ln;->i:[I

    const/16 v5, 0xc

    aput v5, v2, v0

    :cond_342
    sget-object v2, Ln;->C:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    if-ge v2, v10, :cond_391

    sget-object v2, Ln;->A:[I

    aput v1, v2, v0

    sget-object v2, Ln;->E:[I

    aput v1, v2, v0

    sget-object v2, Ln;->F:[I

    aput v1, v2, v0

    :goto_35c
    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    if-ne v2, v10, :cond_64

    sget-object v2, Ln;->B:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_618

    goto/16 :goto_64

    :pswitch_36b  #0x0, 0x4
    sget v2, Lq;->as:I

    const/16 v5, 0xd

    if-ne v2, v5, :cond_3e1

    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x3

    add-int/2addr v2, v5

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    add-int/lit8 v5, v5, -0xf

    sget-object v6, Ln;->j:[I

    aget v6, v6, v0

    mul-int/lit8 v6, v6, 0xc

    sget v7, Lg;->aM:I

    div-int/lit8 v7, v7, 0x2

    invoke-static {v2, v5, v6, v7, v1}, Lq;->b(IIIII)V

    goto/16 :goto_64

    :cond_391
    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    const/16 v5, 0xe

    if-ge v2, v5, :cond_3a6

    sget-object v2, Ln;->A:[I

    aput v3, v2, v0

    sget-object v2, Ln;->E:[I

    aput v3, v2, v0

    sget-object v2, Ln;->F:[I

    aput v3, v2, v0

    goto :goto_35c

    :cond_3a6
    sget-object v2, Ln;->i:[I

    aput v10, v2, v0

    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    goto :goto_35c

    :pswitch_3af  #0x2, 0x3, 0x6
    sget v2, Lg;->au:I

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    sub-int/2addr v2, v5

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/4 v5, 0x5

    if-ge v2, v5, :cond_64

    sget v2, Lq;->as:I

    const/16 v5, 0xd

    if-ne v2, v5, :cond_3d0

    sget v2, Lg;->aM:I

    div-int/lit8 v2, v2, 0x2

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    invoke-static {v2, v5}, Lg;->a(II)V

    goto/16 :goto_64

    :cond_3d0
    sget-object v2, Ln;->b:[I

    sget-object v5, Ln;->B:[I

    aget v5, v5, v0

    aget v2, v2, v5

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    invoke-static {v2, v5}, Lg;->a(II)V

    goto/16 :goto_64

    :cond_3e1
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x3

    add-int/2addr v2, v5

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    add-int/lit8 v5, v5, -0xf

    sget-object v6, Ln;->j:[I

    aget v6, v6, v0

    mul-int/lit8 v6, v6, 0xc

    sget-object v7, Ln;->b:[I

    sget-object v8, Ln;->B:[I

    aget v8, v8, v0

    aget v7, v7, v8

    invoke-static {v2, v5, v6, v7, v1}, Lq;->b(IIIII)V

    goto/16 :goto_64

    :pswitch_405  #0x1, 0x5
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x3

    add-int/2addr v2, v5

    sget-object v5, Ln;->f:[I

    aget v5, v5, v0

    add-int/lit8 v5, v5, -0xf

    sget-object v6, Ln;->j:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x3

    sget-object v7, Ln;->b:[I

    sget-object v8, Ln;->B:[I

    aget v8, v8, v0

    aget v7, v7, v8

    invoke-static {v2, v5, v6, v7, v3}, Lq;->b(IIIII)V

    goto/16 :goto_64

    :pswitch_429  #0x6
    sget v2, Lg;->as:I

    if-ne v2, v10, :cond_43b

    sget-object v2, Ln;->k:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_43b

    sget-object v2, Ln;->i:[I

    aput v10, v2, v0

    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    :cond_43b
    sget v2, Lq;->at:I

    add-int/2addr v2, v0

    rem-int/lit8 v2, v2, 0xa

    const/4 v5, 0x5

    if-le v2, v5, :cond_4e4

    sget-object v2, Ln;->A:[I

    aput v3, v2, v0

    :goto_447
    sget-object v2, Ln;->E:[I

    aput v1, v2, v0

    sget-object v2, Ln;->F:[I

    aput v1, v2, v0

    sget-object v2, Ln;->C:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_481

    sget-object v2, Ln;->e:[I

    aget v5, v2, v0

    sget-object v6, Ln;->j:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x3

    sub-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->G:[I

    aget v5, v5, v0

    if-ge v2, v5, :cond_4ea

    sget-object v2, Ln;->e:[I

    sget-object v5, Ln;->G:[I

    aget v5, v5, v0

    aput v5, v2, v0

    sget-object v2, Ln;->i:[I

    const/4 v5, 0x4

    aput v5, v2, v0

    :cond_481
    :goto_481
    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    const/4 v5, 0x5

    if-lt v2, v5, :cond_64

    sget-object v2, Ln;->D:[I

    sget v5, Lg;->at:I

    aput v5, v2, v0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget v5, Lg;->at:I

    if-ge v2, v5, :cond_502

    sget-object v2, Ln;->D:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, -0x50

    aput v5, v2, v0

    :goto_49e
    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    sget-object v5, Ln;->j:[I

    sget-object v2, Ln;->D:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-ge v2, v6, :cond_50b

    move v2, v4

    :goto_4ad
    aput v2, v5, v0

    sget-object v2, Ln;->i:[I

    const/4 v5, 0x7

    aput v5, v2, v0

    sget-object v2, Ln;->w:[I

    sget-object v5, Ln;->j:[I

    aget v5, v5, v0

    shl-int/lit8 v5, v5, 0x3

    aput v5, v2, v0

    sget-object v2, Ln;->D:[I

    aget v2, v2, v0

    sget-object v5, Ln;->G:[I

    aget v5, v5, v0

    if-ge v2, v5, :cond_4d0

    sget-object v2, Ln;->D:[I

    sget-object v5, Ln;->G:[I

    aget v5, v5, v0

    aput v5, v2, v0

    :cond_4d0
    sget-object v2, Ln;->D:[I

    aget v2, v2, v0

    sget-object v5, Ln;->H:[I

    aget v5, v5, v0

    if-le v2, v5, :cond_64

    sget-object v2, Ln;->D:[I

    sget-object v5, Ln;->H:[I

    aget v5, v5, v0

    aput v5, v2, v0

    goto/16 :goto_64

    :cond_4e4
    sget-object v2, Ln;->A:[I

    aput v1, v2, v0

    goto/16 :goto_447

    :cond_4ea
    sget-object v2, Ln;->e:[I

    aget v2, v2, v0

    sget-object v5, Ln;->H:[I

    aget v5, v5, v0

    if-le v2, v5, :cond_481

    sget-object v2, Ln;->e:[I

    sget-object v5, Ln;->H:[I

    aget v5, v5, v0

    aput v5, v2, v0

    sget-object v2, Ln;->i:[I

    const/4 v5, 0x4

    aput v5, v2, v0

    goto :goto_481

    :cond_502
    sget-object v2, Ln;->D:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x50

    aput v5, v2, v0

    goto :goto_49e

    :cond_50b
    move v2, v3

    goto :goto_4ad

    :pswitch_50d  #0x5
    sget-object v2, Ln;->C:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    mul-int/lit8 v5, v0, 0x3

    add-int/lit8 v5, v5, 0x64

    if-le v2, v5, :cond_64

    sget-object v2, Ln;->e:[I

    sget-object v5, Ln;->u:[I

    aget v5, v5, v0

    aput v5, v2, v0

    sget-object v2, Ln;->f:[I

    sget-object v5, Ln;->v:[I

    aget v5, v5, v0

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    sget-object v2, Ln;->i:[I

    aput v10, v2, v0

    sget-object v2, Ln;->d:[I

    sget-object v5, Ln;->l:[I

    sget-object v6, Ln;->B:[I

    aget v6, v6, v0

    aget v5, v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->I:[Z

    aput-boolean v1, v2, v0

    goto/16 :goto_64

    :pswitch_549  #0x1
    sget-object v2, Ln;->k:[I

    aput v4, v2, v0

    sget-object v2, Ln;->F:[I

    aput v3, v2, v0

    sget-object v2, Ln;->C:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->e:[I

    aget v5, v2, v0

    sget-object v6, Ln;->w:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->f:[I

    aget v5, v2, v0

    sget-object v6, Ln;->x:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->g:[I

    aget v5, v2, v0

    sget-object v6, Ln;->y:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->h:[I

    aget v5, v2, v0

    sget-object v6, Ln;->z:[I

    aget v6, v6, v0

    add-int/2addr v5, v6

    aput v5, v2, v0

    sget-object v2, Ln;->C:[I

    aget v2, v2, v0

    const/16 v5, 0xe

    if-le v2, v5, :cond_5a3

    sget-object v2, Ln;->w:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_5dd

    sget-object v2, Ln;->w:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, -0x1

    aput v5, v2, v0

    :cond_59b
    :goto_59b
    sget-object v2, Ln;->x:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    :cond_5a3
    sget-object v2, Ln;->y:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_5ec

    sget-object v2, Ln;->y:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, -0x1

    aput v5, v2, v0

    :cond_5b1
    :goto_5b1
    sget-object v2, Ln;->z:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    sget-object v2, Ln;->f:[I

    aget v2, v2, v0

    sget v5, Lq;->az:I

    sget v6, Lq;->ac:I

    add-int/2addr v5, v6

    add-int/lit8 v5, v5, 0x20

    if-gt v2, v5, :cond_5ce

    sget-object v2, Ln;->f:[I

    aget v2, v2, v0

    sget v5, Lj;->d:I

    if-le v2, v5, :cond_8a

    :cond_5ce
    sget-object v2, Ln;->C:[I

    aput v1, v2, v0

    sget-object v2, Ln;->D:[I

    aput v1, v2, v0

    sget-object v2, Ln;->i:[I

    const/4 v5, 0x5

    aput v5, v2, v0

    goto/16 :goto_64

    :cond_5dd
    sget-object v2, Ln;->w:[I

    aget v2, v2, v0

    if-ge v2, v4, :cond_59b

    sget-object v2, Ln;->w:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    goto :goto_59b

    :cond_5ec
    sget-object v2, Ln;->y:[I

    aget v2, v2, v0

    if-ge v2, v4, :cond_5b1

    sget-object v2, Ln;->y:[I

    aget v5, v2, v0

    add-int/lit8 v5, v5, 0x1

    aput v5, v2, v0

    goto :goto_5b1

    nop

    :pswitch_data_5fc
    .packed-switch 0x1
        :pswitch_549  #00000001
        :pswitch_200  #00000002
        :pswitch_114  #00000003
        :pswitch_324  #00000004
        :pswitch_50d  #00000005
        :pswitch_429  #00000006
        :pswitch_2de  #00000007
        :pswitch_64  #00000008
        :pswitch_64  #00000009
        :pswitch_64  #0000000a
        :pswitch_8e  #0000000b
        :pswitch_262  #0000000c
    .end packed-switch

    :pswitch_data_618
    .packed-switch 0x0
        :pswitch_36b  #00000000
        :pswitch_405  #00000001
        :pswitch_3af  #00000002
        :pswitch_3af  #00000003
        :pswitch_36b  #00000004
        :pswitch_405  #00000005
        :pswitch_3af  #00000006
    .end packed-switch
.end method

.method private static b(I)V
    .registers 8

    const/4 v6, 0x1

    const/4 v5, -0x1

    const/16 v4, -0xa

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    rem-int/lit8 v1, p0, 0x2

    if-ne v0, v1, :cond_f

    :cond_e
    :goto_e
    return-void

    :cond_f
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x3

    rem-int/lit8 v1, p0, 0x3

    if-eq v0, v1, :cond_e

    sget-object v0, Ln;->I:[Z

    aget-boolean v0, v0, p0

    if-nez v0, :cond_2d

    sget-object v0, Ln;->C:[I

    sget-object v1, Ln;->D:[I

    aput v3, v1, p0

    aput v3, v0, p0

    sget-object v0, Ln;->i:[I

    aput v2, v0, p0

    invoke-static {p0}, Ln;->d(I)V

    goto :goto_e

    :cond_2d
    sget v0, Lg;->at:I

    sget-object v1, Ln;->e:[I

    aget v1, v1, p0

    if-le v0, v1, :cond_13b

    sget v0, Lg;->at:I

    sget-object v1, Ln;->e:[I

    aget v1, v1, p0

    sub-int/2addr v0, v1

    const/16 v1, 0x18

    if-ge v0, v1, :cond_af

    sget v0, Lg;->au:I

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_7b

    sget-object v0, Ln;->j:[I

    aput v6, v0, p0

    sget-object v0, Ln;->i:[I

    const/16 v1, 0xb

    aput v1, v0, p0

    sget-object v0, Ln;->C:[I

    aput v3, v0, p0

    sget-object v0, Ln;->w:[I

    aput v2, v0, p0

    sget-object v0, Ln;->f:[I

    aget v0, v0, p0

    sget v1, Lg;->au:I

    sub-int/2addr v0, v1

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_6b

    sget-object v0, Ln;->x:[I

    const/4 v1, -0x6

    aput v1, v0, p0

    goto :goto_e

    :cond_6b
    const/16 v1, 0x3c

    if-ge v0, v1, :cond_74

    sget-object v0, Ln;->x:[I

    aput v4, v0, p0

    goto :goto_e

    :cond_74
    sget-object v0, Ln;->x:[I

    const/16 v1, -0xe

    aput v1, v0, p0

    goto :goto_e

    :cond_7b
    sget v0, Lq;->at:I

    shl-int/lit8 v1, p0, 0x1

    add-int/2addr v0, v1

    rem-int/lit8 v0, v0, 0xa

    if-le v0, v2, :cond_92

    sget-object v0, Ln;->C:[I

    sget-object v1, Ln;->D:[I

    aput v3, v1, p0

    aput v3, v0, p0

    sget-object v0, Ln;->i:[I

    aput v2, v0, p0

    goto/16 :goto_e

    :cond_92
    sget-object v0, Ln;->D:[I

    sget-object v1, Ln;->H:[I

    aget v1, v1, p0

    aput v1, v0, p0

    sget-object v0, Ln;->j:[I

    aput v6, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x7

    aput v1, v0, p0

    sget-object v0, Ln;->w:[I

    sget-object v1, Ln;->j:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x2

    aput v1, v0, p0

    goto/16 :goto_e

    :cond_af
    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    add-int/lit8 v0, v0, 0x28

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, 0xa

    const/4 v2, 0x2

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_10f

    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    add-int/lit8 v0, v0, 0x30

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, -0xa

    const/4 v2, 0x4

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_10f

    sget-object v0, Ln;->H:[I

    sget-object v1, Ln;->e:[I

    aget v1, v1, p0

    sget-object v2, Ln;->f:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, 0xa

    invoke-static {v1, v2}, Ln;->b(II)I

    move-result v1

    aput v1, v0, p0

    sget-object v1, Ln;->D:[I

    sget-object v0, Ln;->H:[I

    aget v0, v0, p0

    sget v2, Lg;->at:I

    if-ge v0, v2, :cond_10c

    sget-object v0, Ln;->H:[I

    aget v0, v0, p0

    :goto_f5
    aput v0, v1, p0

    sget-object v0, Ln;->j:[I

    aput v6, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x7

    aput v1, v0, p0

    sget-object v0, Ln;->w:[I

    sget-object v1, Ln;->j:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x2

    aput v1, v0, p0

    goto/16 :goto_e

    :cond_10c
    sget v0, Lg;->at:I

    goto :goto_f5

    :cond_10f
    sget v0, Lg;->au:I

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_130

    sget-object v0, Ln;->w:[I

    const/4 v1, 0x2

    aput v1, v0, p0

    sget-object v0, Ln;->x:[I

    aput v4, v0, p0

    :goto_120
    sget-object v0, Ln;->j:[I

    aput v6, v0, p0

    sget-object v0, Ln;->i:[I

    const/16 v1, 0xb

    aput v1, v0, p0

    sget-object v0, Ln;->C:[I

    aput v3, v0, p0

    goto/16 :goto_e

    :cond_130
    sget-object v0, Ln;->w:[I

    const/4 v1, 0x5

    aput v1, v0, p0

    sget-object v0, Ln;->x:[I

    const/4 v1, -0x4

    aput v1, v0, p0

    goto :goto_120

    :cond_13b
    sget v0, Lg;->at:I

    sget-object v1, Ln;->e:[I

    aget v1, v1, p0

    sub-int/2addr v0, v1

    const/16 v1, -0x18

    if-le v0, v1, :cond_1b9

    sget v0, Lg;->au:I

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_185

    sget-object v0, Ln;->j:[I

    aput v5, v0, p0

    sget-object v0, Ln;->i:[I

    const/16 v1, 0xb

    aput v1, v0, p0

    sget-object v0, Ln;->C:[I

    aput v3, v0, p0

    sget-object v0, Ln;->w:[I

    const/4 v1, -0x3

    aput v1, v0, p0

    sget-object v0, Ln;->f:[I

    aget v0, v0, p0

    sget v1, Lg;->au:I

    sub-int/2addr v0, v1

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_173

    sget-object v0, Ln;->x:[I

    const/4 v1, -0x6

    aput v1, v0, p0

    goto/16 :goto_e

    :cond_173
    const/16 v1, 0x3c

    if-ge v0, v1, :cond_17d

    sget-object v0, Ln;->x:[I

    aput v4, v0, p0

    goto/16 :goto_e

    :cond_17d
    sget-object v0, Ln;->x:[I

    const/16 v1, -0xe

    aput v1, v0, p0

    goto/16 :goto_e

    :cond_185
    sget v0, Lq;->at:I

    shl-int/lit8 v1, p0, 0x1

    add-int/2addr v0, v1

    rem-int/lit8 v0, v0, 0xa

    if-le v0, v2, :cond_19c

    sget-object v0, Ln;->C:[I

    sget-object v1, Ln;->D:[I

    aput v3, v1, p0

    aput v3, v0, p0

    sget-object v0, Ln;->i:[I

    aput v2, v0, p0

    goto/16 :goto_e

    :cond_19c
    sget-object v0, Ln;->D:[I

    sget-object v1, Ln;->G:[I

    aget v1, v1, p0

    aput v1, v0, p0

    sget-object v0, Ln;->j:[I

    aput v5, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x7

    aput v1, v0, p0

    sget-object v0, Ln;->w:[I

    sget-object v1, Ln;->j:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x2

    aput v1, v0, p0

    goto/16 :goto_e

    :cond_1b9
    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    add-int/lit8 v0, v0, -0x28

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, 0xa

    const/4 v2, 0x2

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_21a

    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    add-int/lit8 v0, v0, -0x30

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, -0xa

    const/16 v2, 0x8

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_21a

    sget-object v0, Ln;->G:[I

    sget-object v1, Ln;->e:[I

    aget v1, v1, p0

    sget-object v2, Ln;->f:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, 0xa

    invoke-static {v1, v2}, Ln;->a(II)I

    move-result v1

    aput v1, v0, p0

    sget-object v1, Ln;->D:[I

    sget-object v0, Ln;->G:[I

    aget v0, v0, p0

    sget v2, Lg;->at:I

    if-le v0, v2, :cond_217

    sget-object v0, Ln;->G:[I

    aget v0, v0, p0

    :goto_200
    aput v0, v1, p0

    sget-object v0, Ln;->j:[I

    aput v5, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x7

    aput v1, v0, p0

    sget-object v0, Ln;->w:[I

    sget-object v1, Ln;->j:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x2

    aput v1, v0, p0

    goto/16 :goto_e

    :cond_217
    sget v0, Lg;->at:I

    goto :goto_200

    :cond_21a
    sget v0, Lg;->au:I

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_23b

    sget-object v0, Ln;->w:[I

    const/4 v1, -0x2

    aput v1, v0, p0

    sget-object v0, Ln;->x:[I

    aput v4, v0, p0

    :goto_22b
    sget-object v0, Ln;->j:[I

    aput v5, v0, p0

    sget-object v0, Ln;->i:[I

    const/16 v1, 0xb

    aput v1, v0, p0

    sget-object v0, Ln;->C:[I

    aput v3, v0, p0

    goto/16 :goto_e

    :cond_23b
    sget-object v0, Ln;->w:[I

    const/4 v1, -0x5

    aput v1, v0, p0

    sget-object v0, Ln;->x:[I

    const/4 v1, -0x4

    aput v1, v0, p0

    goto :goto_22b
.end method

.method private static c()V
    .registers 8

    const/4 v7, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v2, 0x0

    sget-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_23

    const/4 v0, 0x5

    :try_start_9
    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_d} :catch_108

    move v1, v2

    :goto_e
    if-lt v1, v5, :cond_b4

    const/4 v0, 0x7

    const/4 v3, 0x2

    :try_start_12
    filled-new-array {v0, v3}, [I

    move-result-object v0

    const-class v3, Ljavax/microedition/lcdui/Image;

    invoke-static {v3, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Ln;->s:[[Ljavax/microedition/lcdui/Image;
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_20} :catch_120

    move v0, v2

    :goto_21
    if-lt v0, v7, :cond_d5

    :cond_23
    :goto_23
    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->u:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->v:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->e:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->f:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->g:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->h:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->B:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->i:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->C:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->D:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->j:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->E:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->F:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->A:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->G:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->H:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->w:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->x:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->y:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->z:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->d:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->k:[I

    sget v0, Ln;->c:I

    new-array v0, v0, [Z

    sput-object v0, Ln;->I:[Z

    sget v0, Ln;->c:I

    new-array v0, v0, [I

    sput-object v0, Ln;->t:[I

    return-void

    :cond_b4
    :try_start_b4
    sget-object v0, Ln;->r:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/mob/x"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v0, v1
    :try_end_d1
    .catch Ljava/lang/Exception; {:try_start_b4 .. :try_end_d1} :catch_120

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_e

    :cond_d5
    :try_start_d5
    sget-object v1, Ln;->J:[Z

    aget-boolean v1, v1, v0

    if-eqz v1, :cond_de

    move v1, v2

    :goto_dc
    if-lt v1, v6, :cond_e2

    :cond_de
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_21

    :cond_e2
    sget-object v3, Ln;->s:[[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v0

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/mob/y"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v1
    :try_end_105
    .catch Ljava/lang/Exception; {:try_start_d5 .. :try_end_105} :catch_123

    add-int/lit8 v1, v1, 0x1

    goto :goto_dc

    :catch_108
    move-exception v0

    move v0, v2

    :goto_10a
    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "NJ ERR "

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_23

    :catch_120
    move-exception v0

    move v0, v1

    goto :goto_10a

    :catch_123
    move-exception v1

    goto :goto_10a
.end method

.method private static c(I)V
    .registers 6

    const/4 v1, -0x1

    const/4 v0, 0x1

    sget-boolean v2, Lg;->ba:Z

    if-eqz v2, :cond_7

    :cond_6
    :goto_6
    return-void

    :cond_7
    sget-object v2, Ln;->e:[I

    aget v2, v2, p0

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x64

    if-ge v2, v3, :cond_6

    sget-object v2, Ln;->I:[Z

    aput-boolean v0, v2, p0

    sget-object v2, Ln;->f:[I

    aget v2, v2, p0

    sget v3, Lg;->au:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x14

    if-ge v2, v3, :cond_6

    sget-object v2, Ln;->B:[I

    aget v2, v2, p0

    packed-switch v2, :pswitch_data_b0

    goto :goto_6

    :pswitch_31  #0x0, 0x1, 0x4, 0x5
    sget-object v2, Ln;->j:[I

    sget-object v3, Ln;->e:[I

    aget v3, v3, p0

    sget v4, Lg;->at:I

    if-ge v3, v4, :cond_ae

    :goto_3b
    aput v0, v2, p0

    sget-object v0, Ln;->D:[I

    sget-object v1, Ln;->C:[I

    const/4 v2, 0x0

    aput v2, v1, p0

    aput v2, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x4

    aput v1, v0, p0

    goto :goto_6

    :pswitch_4c  #0x2, 0x3, 0x6
    sget-object v2, Ln;->D:[I

    sget v3, Lg;->at:I

    aput v3, v2, p0

    sget-object v2, Ln;->e:[I

    aget v2, v2, p0

    sget v3, Lg;->at:I

    if-ge v2, v3, :cond_a3

    sget-object v2, Ln;->D:[I

    aget v3, v2, p0

    add-int/lit8 v3, v3, -0xa

    aput v3, v2, p0

    :goto_62
    sget-object v2, Ln;->j:[I

    sget-object v3, Ln;->D:[I

    aget v3, v3, p0

    sget v4, Lg;->at:I

    if-ge v3, v4, :cond_ac

    :goto_6c
    aput v0, v2, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x7

    aput v1, v0, p0

    sget-object v0, Ln;->w:[I

    sget-object v1, Ln;->j:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x3

    aput v1, v0, p0

    sget-object v0, Ln;->D:[I

    aget v0, v0, p0

    sget-object v1, Ln;->G:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_8f

    sget-object v0, Ln;->D:[I

    sget-object v1, Ln;->G:[I

    aget v1, v1, p0

    aput v1, v0, p0

    :cond_8f
    sget-object v0, Ln;->D:[I

    aget v0, v0, p0

    sget-object v1, Ln;->H:[I

    aget v1, v1, p0

    if-le v0, v1, :cond_6

    sget-object v0, Ln;->D:[I

    sget-object v1, Ln;->H:[I

    aget v1, v1, p0

    aput v1, v0, p0

    goto/16 :goto_6

    :cond_a3
    sget-object v2, Ln;->D:[I

    aget v3, v2, p0

    add-int/lit8 v3, v3, 0xa

    aput v3, v2, p0

    goto :goto_62

    :cond_ac
    move v0, v1

    goto :goto_6c

    :cond_ae
    move v0, v1

    goto :goto_3b

    :pswitch_data_b0
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_31  #00000001
        :pswitch_4c  #00000002
        :pswitch_4c  #00000003
        :pswitch_31  #00000004
        :pswitch_31  #00000005
        :pswitch_4c  #00000006
    .end packed-switch
.end method

.method private static d(I)V
    .registers 4

    sget v0, Lg;->au:I

    sget-object v1, Ln;->f:[I

    aget v1, v1, p0

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-gt v0, v1, :cond_48

    sget-object v0, Ln;->e:[I

    aget v0, v0, p0

    sget-object v1, Ln;->j:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x19

    if-ge v0, v1, :cond_48

    sget-object v0, Ln;->B:[I

    aget v0, v0, p0

    const/4 v1, 0x6

    if-eq v0, v1, :cond_3a

    sget-object v0, Ln;->B:[I

    aget v0, v0, p0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_3a

    sget-object v0, Ln;->B:[I

    aget v0, v0, p0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_48

    :cond_3a
    sget-object v0, Ln;->D:[I

    sget-object v1, Ln;->C:[I

    const/4 v2, 0x0

    aput v2, v1, p0

    aput v2, v0, p0

    sget-object v0, Ln;->i:[I

    const/4 v1, 0x4

    aput v1, v0, p0

    :cond_48
    return-void
.end method
