.class public Lh;
.super Ljava/lang/Object;


# static fields
.field public static final a:[[I

.field private static h:[I

.field private static i:[I

.field private static m:[Ljavax/microedition/lcdui/Image;


# instance fields
.field b:I

.field c:I

.field d:I

.field e:I

.field f:I

.field g:Z

.field private j:I

.field private k:I

.field private l:I


# direct methods
.method static constructor <clinit>()V
    .registers 10

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/16 v0, 0x21

    new-array v0, v0, [[I

    const/4 v1, 0x0

    new-array v2, v6, [I

    aput-object v2, v0, v1

    const/16 v1, 0x12

    new-array v1, v1, [I

    const/4 v2, 0x0

    const/16 v3, 0x11

    aput v3, v1, v2

    const/16 v2, 0x10

    aput v2, v1, v5

    const/16 v2, 0xf

    aput v2, v1, v6

    const/16 v2, 0xe

    aput v2, v1, v7

    const/16 v2, 0xd

    aput v2, v1, v8

    const/16 v2, 0xc

    aput v2, v1, v9

    const/4 v2, 0x6

    const/16 v3, 0xb

    aput v3, v1, v2

    const/4 v2, 0x7

    const/16 v3, 0xa

    aput v3, v1, v2

    const/16 v2, 0x8

    const/16 v3, 0x9

    aput v3, v1, v2

    const/16 v2, 0x9

    const/16 v3, 0x8

    aput v3, v1, v2

    const/16 v2, 0xa

    const/4 v3, 0x7

    aput v3, v1, v2

    const/16 v2, 0xb

    const/4 v3, 0x6

    aput v3, v1, v2

    const/16 v2, 0xc

    aput v9, v1, v2

    const/16 v2, 0xd

    aput v8, v1, v2

    const/16 v2, 0xe

    aput v7, v1, v2

    const/16 v2, 0xf

    aput v6, v1, v2

    const/16 v2, 0x10

    aput v5, v1, v2

    aput-object v1, v0, v5

    const/16 v1, 0x8

    new-array v1, v1, [I

    aput v5, v1, v5

    aput v6, v1, v6

    aput v7, v1, v7

    aput v8, v1, v8

    aput v9, v1, v9

    const/4 v2, 0x6

    const/4 v3, 0x6

    aput v3, v1, v2

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput v3, v1, v2

    aput-object v1, v0, v6

    new-array v1, v5, [I

    aput-object v1, v0, v7

    const/16 v1, 0xf

    new-array v1, v1, [I

    aput v5, v1, v5

    aput v6, v1, v6

    aput v7, v1, v7

    aput v8, v1, v8

    const/4 v2, 0x7

    aput v5, v1, v2

    const/16 v2, 0x8

    aput v5, v1, v2

    const/16 v2, 0x9

    aput v6, v1, v2

    const/16 v2, 0xa

    aput v6, v1, v2

    const/16 v2, 0xb

    aput v7, v1, v2

    const/16 v2, 0xc

    aput v7, v1, v2

    const/16 v2, 0xd

    aput v8, v1, v2

    const/16 v2, 0xe

    aput v8, v1, v2

    aput-object v1, v0, v8

    new-array v1, v6, [I

    aput v5, v1, v5

    aput-object v1, v0, v9

    const/4 v1, 0x6

    const/16 v2, 0x9

    new-array v2, v2, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput v7, v2, v7

    aput v8, v2, v8

    aput v9, v2, v9

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput v4, v2, v3

    const/4 v3, 0x7

    const/4 v4, 0x7

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x8

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v6, [I

    aput v5, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const/16 v2, 0x9

    new-array v2, v2, [I

    const/4 v3, 0x0

    const/16 v4, 0x8

    aput v4, v2, v3

    const/4 v3, 0x7

    aput v3, v2, v5

    const/4 v3, 0x6

    aput v3, v2, v6

    aput v9, v2, v7

    aput v8, v2, v8

    aput v7, v2, v9

    const/4 v3, 0x6

    aput v6, v2, v3

    const/4 v3, 0x7

    aput v5, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v5, [I

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v6, [I

    aput v5, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb

    const/16 v2, 0x12

    new-array v2, v2, [I

    aput v5, v2, v9

    const/4 v3, 0x6

    aput v5, v2, v3

    const/4 v3, 0x7

    aput v5, v2, v3

    const/16 v3, 0x8

    aput v5, v2, v3

    const/16 v3, 0x9

    aput v6, v2, v3

    const/16 v3, 0xa

    aput v6, v2, v3

    const/16 v3, 0xb

    aput v6, v2, v3

    const/16 v3, 0xc

    aput v6, v2, v3

    const/16 v3, 0xd

    aput v6, v2, v3

    const/16 v3, 0xe

    aput v6, v2, v3

    const/16 v3, 0xf

    aput v7, v2, v3

    const/16 v3, 0x10

    aput v7, v2, v3

    const/16 v3, 0x11

    aput v7, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xc

    const/16 v2, 0xc

    new-array v2, v2, [I

    aput v5, v2, v7

    aput v5, v2, v8

    aput v5, v2, v9

    const/4 v3, 0x6

    aput v6, v2, v3

    const/4 v3, 0x7

    aput v6, v2, v3

    const/16 v3, 0x8

    aput v6, v2, v3

    const/16 v3, 0x9

    aput v7, v2, v3

    const/16 v3, 0xa

    aput v7, v2, v3

    const/16 v3, 0xb

    aput v7, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v8, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput v7, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x12

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x13

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x16

    const/16 v2, 0x8

    new-array v2, v2, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput v5, v2, v7

    aput v6, v2, v8

    aput v7, v2, v9

    const/4 v3, 0x6

    aput v8, v2, v3

    const/4 v3, 0x7

    aput v9, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x17

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x18

    new-array v2, v8, [I

    aput v5, v2, v6

    aput v5, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x19

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v7, [I

    aput v5, v2, v5

    aput v6, v2, v6

    aput-object v2, v0, v1

    sput-object v0, Lh;->a:[[I

    const/16 v0, 0x21

    new-array v0, v0, [I

    fill-array-data v0, :array_252

    sput-object v0, Lh;->h:[I

    const/16 v0, 0x21

    new-array v0, v0, [I

    fill-array-data v0, :array_298

    sput-object v0, Lh;->i:[I

    const/16 v0, 0x32

    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    return-void

    :array_252
    .array-data 4
        0x34
        0xb
        0xc
        0x29
        0xe
        0x20
        0xc
        0x20
        0xa
        0x20
        0x10
        0xc
        0xe
        0x20
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x31
        0x1f
        0x10
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
    .end array-data

    :array_298
    .array-data 4
        0x12
        0xb
        0xc
        0x26
        0xe
        0x20
        0xc
        0x20
        0xa
        0x20
        0xc8
        0xc
        0xe
        0x20
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x1d
        0x24
        0xf
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
    .end array-data
.end method

.method public constructor <init>(III)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lh;->b:I

    iput p2, p0, Lh;->c:I

    iput p3, p0, Lh;->d:I

    sget-object v0, Lh;->h:[I

    aget v0, v0, p3

    iput v0, p0, Lh;->j:I

    sget-object v0, Lh;->i:[I

    aget v0, v0, p3

    iput v0, p0, Lh;->k:I

    const/4 v0, -0x1

    iput v0, p0, Lh;->f:I

    const/4 v0, 0x1

    iput v0, p0, Lh;->l:I

    return-void
.end method

.method public static a(I)V
    .registers 4

    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, p0

    if-nez v0, :cond_18

    const/16 v0, 0xf

    if-lt p0, v0, :cond_19

    const/16 v0, 0x15

    if-gt p0, v0, :cond_19

    :try_start_e
    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    const-string v1, "/g14.png"

    invoke-static {v1}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v1

    aput-object v1, v0, p0

    :cond_18
    :goto_18
    return-void

    :cond_19
    const/16 v0, 0x16

    if-ne p0, v0, :cond_2a

    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    const-string v1, "/g15.png"

    invoke-static {v1}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v1

    aput-object v1, v0, p0

    goto :goto_18

    :catch_28
    move-exception v0

    goto :goto_18

    :cond_2a
    const/16 v0, 0x19

    if-lt p0, v0, :cond_3d

    const/16 v0, 0x20

    if-gt p0, v0, :cond_3d

    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    const-string v1, "/g18.png"

    invoke-static {v1}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v1

    aput-object v1, v0, p0

    goto :goto_18

    :cond_3d
    const/16 v0, 0x17

    if-lt p0, v0, :cond_61

    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "/g"

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    add-int/lit8 v2, p0, -0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    const-string v2, ".png"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v1

    aput-object v1, v0, p0

    goto :goto_18

    :cond_61
    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "/g"

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    const-string v2, ".png"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v1

    aput-object v1, v0, p0
    :try_end_7e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_7e} :catch_28

    goto :goto_18
.end method


# virtual methods
.method public a()V
    .registers 8

    const/16 v2, 0x28

    const/16 v3, 0xf

    const/4 v6, 0x1

    const/4 v5, 0x0

    iget v0, p0, Lh;->d:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_ad

    iget v0, p0, Lh;->d:I

    const/16 v1, 0x15

    if-gt v0, v1, :cond_ad

    iget v0, p0, Lh;->d:I

    packed-switch v0, :pswitch_data_248

    :goto_17
    iget v0, p0, Lh;->b:I

    rsub-int v0, v0, 0x270

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v2, :cond_2b

    iget v0, p0, Lh;->c:I

    rsub-int/lit8 v0, v0, 0x52

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-lt v0, v2, :cond_33

    :cond_2b
    const/16 v0, 0x270

    iput v0, p0, Lh;->b:I

    const/16 v0, 0x52

    iput v0, p0, Lh;->c:I

    :cond_33
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_3f

    iget v0, p0, Lh;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->f:I

    :cond_3f
    iget v0, p0, Lh;->f:I

    sget-object v1, Lh;->a:[[I

    iget v2, p0, Lh;->d:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-lt v0, v1, :cond_4c

    iput v5, p0, Lh;->f:I

    :cond_4c
    sget-boolean v0, Lg;->B:Z

    if-nez v0, :cond_56

    sget v0, Lq;->as:I

    const/16 v1, 0x13

    if-eq v0, v1, :cond_5a

    :cond_56
    iput v5, p0, Lh;->f:I

    iput-boolean v6, p0, Lh;->g:Z

    :cond_5a
    :goto_5a
    return-void

    :pswitch_5b  #0xe
    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, -0x2

    iput v0, p0, Lh;->c:I

    goto :goto_17

    :pswitch_62  #0xf
    iget v0, p0, Lh;->b:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lh;->c:I

    goto :goto_17

    :pswitch_6f  #0x10
    iget v0, p0, Lh;->b:I

    add-int/lit8 v0, v0, 0x2

    iput v0, p0, Lh;->b:I

    goto :goto_17

    :pswitch_76  #0x11
    iget v0, p0, Lh;->b:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->c:I

    goto :goto_17

    :pswitch_83  #0x12
    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, 0x2

    iput v0, p0, Lh;->c:I

    goto :goto_17

    :pswitch_8a  #0x13
    iget v0, p0, Lh;->b:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->c:I

    goto :goto_17

    :pswitch_97  #0x14
    iget v0, p0, Lh;->b:I

    add-int/lit8 v0, v0, -0x2

    iput v0, p0, Lh;->b:I

    goto/16 :goto_17

    :pswitch_9f  #0x15
    iget v0, p0, Lh;->b:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lh;->c:I

    goto/16 :goto_17

    :cond_ad
    iget v0, p0, Lh;->d:I

    const/16 v1, 0x19

    if-lt v0, v1, :cond_16a

    iget v0, p0, Lh;->d:I

    const/16 v1, 0x20

    if-gt v0, v1, :cond_16a

    iget v0, p0, Lh;->d:I

    packed-switch v0, :pswitch_data_25c

    :goto_be
    iget v0, p0, Lh;->l:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->l:I

    iget v0, p0, Lh;->b:I

    sget v1, Lq;->W:I

    mul-int/lit8 v1, v1, 0x18

    if-lt v0, v1, :cond_e4

    iget v0, p0, Lh;->b:I

    sget v1, Lq;->Y:I

    mul-int/lit8 v1, v1, 0x18

    if-gt v0, v1, :cond_e4

    iget v0, p0, Lh;->c:I

    sget v1, Lq;->X:I

    mul-int/lit8 v1, v1, 0x18

    if-lt v0, v1, :cond_e4

    iget v0, p0, Lh;->c:I

    sget v1, Lq;->Z:I

    mul-int/lit8 v1, v1, 0x18

    if-le v0, v1, :cond_ea

    :cond_e4
    iput v5, p0, Lh;->f:I

    iput-boolean v6, p0, Lh;->g:Z

    iput v5, p0, Lh;->l:I

    :cond_ea
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_f6

    iget v0, p0, Lh;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->f:I

    :cond_f6
    iget v0, p0, Lh;->f:I

    sget-object v1, Lh;->a:[[I

    iget v2, p0, Lh;->d:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-lt v0, v1, :cond_5a

    iput v5, p0, Lh;->f:I

    goto/16 :goto_5a

    :pswitch_105  #0x19
    iget v0, p0, Lh;->c:I

    iget v1, p0, Lh;->l:I

    sub-int/2addr v0, v1

    iput v0, p0, Lh;->c:I

    goto :goto_be

    :pswitch_10d  #0x1a
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->l:I

    add-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    iget v1, p0, Lh;->l:I

    sub-int/2addr v0, v1

    iput v0, p0, Lh;->c:I

    goto :goto_be

    :pswitch_11c  #0x1b
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->l:I

    mul-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    goto :goto_be

    :pswitch_126  #0x1c
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->l:I

    add-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    iget v1, p0, Lh;->l:I

    add-int/2addr v0, v1

    iput v0, p0, Lh;->c:I

    goto :goto_be

    :pswitch_135  #0x1d
    iget v0, p0, Lh;->c:I

    iget v1, p0, Lh;->l:I

    mul-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    iput v0, p0, Lh;->c:I

    goto :goto_be

    :pswitch_13f  #0x1e
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->l:I

    sub-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    iget v1, p0, Lh;->l:I

    add-int/2addr v0, v1

    iput v0, p0, Lh;->c:I

    goto/16 :goto_be

    :pswitch_14f  #0x1f
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->l:I

    mul-int/lit8 v1, v1, 0x2

    sub-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    goto/16 :goto_be

    :pswitch_15a  #0x20
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->l:I

    sub-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lh;->c:I

    iget v1, p0, Lh;->l:I

    sub-int/2addr v0, v1

    iput v0, p0, Lh;->c:I

    goto/16 :goto_be

    :cond_16a
    iget v0, p0, Lh;->d:I

    const/16 v1, 0x16

    if-ne v0, v1, :cond_203

    iget v0, p0, Lh;->b:I

    iget v1, p0, Lh;->e:I

    iget v2, p0, Lh;->l:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_18c

    iget v0, p0, Lh;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->f:I

    iget v0, p0, Lh;->l:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->l:I

    :cond_18c
    iget v0, p0, Lh;->b:I

    sget v1, Le;->a:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1c

    if-ge v0, v1, :cond_1bc

    iget v0, p0, Lh;->c:I

    sget v1, Le;->b:I

    add-int/lit8 v1, v1, -0x1b

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x17

    if-ge v0, v1, :cond_1bc

    sget v0, Le;->a:I

    iget v1, p0, Lh;->e:I

    iget v2, p0, Lh;->l:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    sput v0, Le;->a:I

    const/4 v0, 0x6

    sput v0, Le;->c:I

    sget v0, Le;->f:I

    iget v1, p0, Lh;->l:I

    sub-int/2addr v0, v1

    sput v0, Le;->f:I

    :cond_1bc
    iget v0, p0, Lh;->b:I

    sget v1, Lq;->ak:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v3, :cond_1f0

    iget v0, p0, Lh;->c:I

    sget v1, Lq;->al:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v3, :cond_1f0

    sget v0, Lq;->an:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1f0

    iput v5, p0, Lh;->f:I

    iput-boolean v6, p0, Lh;->g:Z

    iput v5, p0, Lh;->l:I

    const/4 v0, -0x1

    sput v0, Lq;->am:I

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lh;

    iget v2, p0, Lh;->b:I

    iget v3, p0, Lh;->c:I

    const/16 v4, 0x21

    invoke-direct {v1, v2, v3, v4}, Lh;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :cond_1f0
    iget v0, p0, Lh;->f:I

    sget-object v1, Lh;->a:[[I

    iget v2, p0, Lh;->d:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-lt v0, v1, :cond_5a

    iput v5, p0, Lh;->f:I

    iput-boolean v6, p0, Lh;->g:Z

    iput v5, p0, Lh;->l:I

    goto/16 :goto_5a

    :cond_203
    iget v0, p0, Lh;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->f:I

    iget v0, p0, Lh;->f:I

    sget-object v1, Lh;->a:[[I

    iget v2, p0, Lh;->d:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-lt v0, v1, :cond_5a

    iput v5, p0, Lh;->f:I

    iput-boolean v6, p0, Lh;->g:Z

    iget v0, p0, Lh;->d:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_5a

    :try_start_21e
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/100.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/101.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->i:[I

    const/16 v1, 0xa

    const/4 v2, 0x0

    aput v2, v0, v1
    :try_end_243
    .catch Ljava/io/IOException; {:try_start_21e .. :try_end_243} :catch_245

    goto/16 :goto_5a

    :catch_245
    move-exception v0

    goto/16 :goto_5a

    :pswitch_data_248
    .packed-switch 0xe
        :pswitch_5b  #0000000e
        :pswitch_62  #0000000f
        :pswitch_6f  #00000010
        :pswitch_76  #00000011
        :pswitch_83  #00000012
        :pswitch_8a  #00000013
        :pswitch_97  #00000014
        :pswitch_9f  #00000015
    .end packed-switch

    :pswitch_data_25c
    .packed-switch 0x19
        :pswitch_105  #00000019
        :pswitch_10d  #0000001a
        :pswitch_11c  #0000001b
        :pswitch_126  #0000001c
        :pswitch_135  #0000001d
        :pswitch_13f  #0000001e
        :pswitch_14f  #0000001f
        :pswitch_15a  #00000020
    .end packed-switch
.end method

.method public final a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 12

    const/16 v3, 0x16

    const/4 v9, 0x3

    const/4 v2, 0x0

    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    iget v1, p0, Lh;->d:I

    aget-object v0, v0, v1

    if-eqz v0, :cond_11

    iget v0, p0, Lh;->f:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_12

    :cond_11
    :goto_11
    return-void

    :cond_12
    iget v0, p0, Lh;->d:I

    if-ne v0, v3, :cond_1f

    iget v0, p0, Lh;->d:I

    if-ne v0, v3, :cond_40

    iget v0, p0, Lh;->e:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_40

    :cond_1f
    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    iget v1, p0, Lh;->d:I

    aget-object v1, v0, v1

    sget-object v0, Lh;->a:[[I

    iget v3, p0, Lh;->d:I

    aget-object v0, v0, v3

    iget v3, p0, Lh;->f:I

    aget v0, v0, v3

    iget v3, p0, Lh;->k:I

    mul-int/2addr v3, v0

    iget v4, p0, Lh;->j:I

    iget v5, p0, Lh;->k:I

    iget v7, p0, Lh;->b:I

    iget v8, p0, Lh;->c:I

    move-object v0, p1

    move v6, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_11

    :cond_40
    sget-object v0, Lh;->m:[Ljavax/microedition/lcdui/Image;

    iget v1, p0, Lh;->d:I

    aget-object v1, v0, v1

    sget-object v0, Lh;->a:[[I

    iget v3, p0, Lh;->d:I

    aget-object v0, v0, v3

    iget v3, p0, Lh;->f:I

    aget v0, v0, v3

    iget v3, p0, Lh;->k:I

    mul-int/2addr v3, v0

    iget v4, p0, Lh;->j:I

    iget v5, p0, Lh;->k:I

    const/4 v6, 0x2

    iget v7, p0, Lh;->b:I

    iget v8, p0, Lh;->c:I

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_11
.end method
