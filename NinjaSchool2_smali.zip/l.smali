.class public final Ll;
.super Ljava/lang/Object;


# static fields
.field public static a:[Ljava/lang/String;

.field public static b:[Ljava/lang/String;

.field public static c:[[Ljava/lang/String;

.field public static d:[[Ljava/lang/String;

.field public static e:[[Ljava/lang/String;

.field public static f:[[Ljava/lang/String;

.field public static g:[[Ljava/lang/String;

.field public static h:[[Ljava/lang/String;

.field public static i:[[Ljava/lang/String;

.field public static j:[[Ljava/lang/String;

.field public static k:[[Ljava/lang/String;

.field public static final l:[[Ljava/lang/String;

.field public static final m:[[Ljava/lang/String;

.field public static final n:[[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 10

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Mùa hè năm 1938 tại trường Hirosaki"

    aput-object v1, v0, v5

    const-string v1, "Rừng trúc Ura 2 giờ sau.."

    aput-object v1, v0, v6

    const-string v1, "Chỉ dẫn: Dùng phím 5 tấn công"

    aput-object v1, v0, v7

    const-string v1, " 3 hôm sau, tại cánh đồng Fuki.."

    aput-object v1, v0, v8

    const-string v1, "Sáng hôm sau"

    aput-object v1, v0, v9

    const/4 v1, 0x5

    const-string v2, "Trường Hirosaki 3 ngày sau...."

    aput-object v2, v0, v1

    sput-object v0, Ll;->a:[Ljava/lang/String;

    new-array v0, v6, [Ljava/lang/String;

    const-string v1, "Kỳ học tiếp theo đã kết thúc êm đềm,trải qua bao gian khổ và nguy hiểm để hoàn thành nhiệm vụ.Các bạn trẻ của chúng ta đã biết thế nào là sự đoàn kết.Nhưng liệu cuộc sống có luôn yên bình không?Kỳ học tiếp theo của các bạn sẽ xảy ra chuyện gì....Mời các bạn tiếp tục theo dõi...."

    aput-object v1, v0, v5

    sput-object v0, Ll;->b:[Ljava/lang/String;

    const/16 v0, 0xd4

    new-array v0, v0, [[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Dạo này sức khoẻ của ông thế nào, ông Okame?"

    aput-object v2, v1, v5

    aput-object v1, v0, v5

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Ngón tay cái của tôi đã bớt đau, tôi bấm games nhiều quá mà!"

    aput-object v2, v1, v5

    aput-object v1, v0, v6

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Tôi cũng đã thay bàn phím và thay pin cho điện thoại của mình.."

    aput-object v2, v1, v5

    const-string v2, "..tôi có nhắn tin cho Toyotomi nhưng không thấy hồi âm.."

    aput-object v2, v1, v6

    const-string v2, "..haizz.."

    aput-object v2, v1, v7

    aput-object v1, v0, v7

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Cái gì thế kia !!!"

    aput-object v2, v1, v5

    aput-object v1, v0, v8

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "..ôi, cây phi đao của Toyotomi đây mà.."

    aput-object v2, v1, v5

    const-string v2, "Để tôi xem..."

    aput-object v2, v1, v6

    aput-object v1, v0, v9

    const/4 v1, 0x5

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Một chữ PHONG bằng máu?"

    aput-object v3, v2, v5

    const-string v3, "Có chuyện không hay rồi!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Hum.. Nó ám chỉ điều gì đây.. chữ Phong.."

    aput-object v3, v2, v5

    const-string v3, "..không lẽ là do tên Sanosuke - Bạo Vũ Đao.."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Toyotomi của tôi.."

    aput-object v3, v2, v5

    const-string v3, "Chúng ta phải làm gì đây, ông Okame?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Theo tôi chỉ còn một cách..."

    aput-object v3, v2, v5

    const-string v3, "Katashi!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vâng, thưa thầy?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Con gọi Onda đến đây cho ta!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thằng đó chạy lung tung lắm, ai biết kiếm nó ở đâu ạ!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Còn không biết đi tìm nó!"

    aput-object v3, v2, v5

    const-string v3, "Nhanh lên!!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vâng.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Hừ, bọn nhím lông nâu này lại xuất hiện.."

    aput-object v3, v2, v5

    const-string v3, "..chúng lại gặm hết hoa màu của dân làng rồi.."

    aput-object v3, v2, v6

    const-string v3, "để xem bọn mày còn sống được bao lâu!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Nè, Onda!"

    aput-object v3, v2, v5

    const-string v3, "..Thầy hiệu trưởng kêu mày về trường gấp kìa.."

    aput-object v3, v2, v6

    const-string v3, "Nhanh lên, mấy thầy đang chờ đó!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Uh, cảm ơn. Tớ về ngay!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Này Onda!"

    aput-object v3, v2, v5

    const-string v3, "Chúng ta muốn nhờ con giúp một việc.."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x12

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vâng ạ, bất kỳ chuyện gì, thầy cứ sai bảo.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x13

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Uhm, vừa rồi ta nhận được tin báo.."

    aput-object v3, v2, v5

    const-string v3, "..rằng trường Haruna, ngôi trường Ninja anh em với chúng ta.."

    aput-object v3, v2, v6

    const-string v3, "..đang gặp nạn. Chúng ta nghi ngờ tên dị nhân Sanosuke gây ra chuyện này.."

    aput-object v3, v2, v7

    const-string v3, "..vì thế, ta muốn con dẫn đầu 10 bạn, cùng nhau đến điều tra tình hình.."

    aput-object v3, v2, v8

    const-string v3, "..ta và thầy Honda hiện đang bị chấn thương ngón tay, nên sẽ đến đến sau.."

    aput-object v3, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Dạ..."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Uhm, hãy nhanh chóng tập hợp bạn bè cùng lên đường nhé.."

    aput-object v3, v2, v5

    const-string v3, "Trường Haruna nằm ở phía tây bắc, bên kia thác nước."

    aput-object v3, v2, v6

    const-string v3, "Chúc các con may mắn, chúng ta sẽ đến đó sau vài ngày!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x16

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vâng, con xin đi ngay!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x17

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Tại sao mình lại phải vướng bận thế, hành động một mình là đủ rồi .."

    aput-object v3, v2, v5

    const-string v3, "..dù sao mình cũng là Ninja cấp độ 30 rồi, đi một mình chẳng phải khỏe hơn sao?"

    aput-object v3, v2, v6

    const-string v3, "..mọi người đi theo chỉ vướng tay vướng chân chứ chẳng giúp được gì!"

    aput-object v3, v2, v7

    const-string v3, "..ha ha ha.."

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x18

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Cánh đồng Fuki đây rồi!"

    aput-object v3, v2, v5

    const-string v3, "Theo lời thầy Honda thì chỉ một đoạn ngắn nữa thôi, mình sẽ đến trường Haruna.."

    aput-object v3, v2, v6

    const-string v3, "..cố lên.."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x19

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Hê, đại ca nhìn kìa, có 1 thằng nhóc!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Ta không phải thằng nhóc. Ta là Ninja cấp độ 30 Onda"

    aput-object v3, v2, v5

    const-string v3, "Các ngươi là ai. Làm gì ở đây?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Hô hô, nó hỏi đại ca là ai kìa?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Thằng nhóc này đồng phục màu xanh, chắc là học sinh trường khác.."

    aput-object v3, v2, v5

    const-string v3, "Mà dù nó ở đâu, ninja là phải giết.."

    aput-object v3, v2, v6

    const-string v3, "Giết nó đi cho ta!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Này nhóc, mày được chết dưới tay đại ca Sanosuke là có phước rồi.."

    aput-object v3, v2, v5

    const-string v3, "Chuẩn bị nhé, 6 đứa chúng tao chấp một mình mày đó!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Haha, ngon thì nhào vô kiếm ăn!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Haha, con chuột nhắt đáng chết! Tao ghét mấy thằng học sinh!"

    aput-object v3, v2, v5

    const-string v3, "Các ngươi, về căn cứ thôi, sau vài ngày nữa..."

    aput-object v3, v2, v6

    const-string v3, "làm cỏ xong trường Haruna sẽ đến ngôi trường Hirosaki.."

    aput-object v3, v2, v7

    const-string v3, "..lần này ta quyết trả thù lão già Okame đó.."

    aput-object v3, v2, v8

    const-string v3, "..Hahahaha.."

    aput-object v3, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "..A.a.."

    aput-object v3, v2, v5

    const-string v3, "..ta đang ở đâu đây..."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x21

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Onda, con là truyền nhân của dòng dõi nhà ta!"

    aput-object v3, v2, v5

    const-string v3, "..con còn nhiều trọng trách phải gánh vác!"

    aput-object v3, v2, v6

    const-string v3, "..Hãy mau tỉnh dậy đi.."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x22

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Tình hình Onda thế nào rồi thưa thầy hiệu trưởng?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x23

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Uhm, nó bị thương khá nặng đấy.. suýt nữa thì mất mạng rồi."

    aput-object v3, v2, v5

    const-string v3, "Các con tìm thấy nó ở đâu thế?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Chúng con nghe người dân bảo, có học sinh bị trọng thương nằm bên bìa rừng"

    aput-object v3, v2, v5

    const-string v3, "Con liền chạy đến, thì ra đấy lại là Onda. Không biết tại sao bạn ấy lại ra nông nỗi này!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thầy hiệu trưởng.. vết thương này.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x26

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Thầy Hiroyaki đoán đúng đấy.."

    aput-object v3, v2, v5

    const-string v3, "Onda đã quá tự cao vào khả năng mình.."

    aput-object v3, v2, v6

    const-string v3, "Vết thương của nó xuất thân từ làng Kamikaze.."

    aput-object v3, v2, v7

    const-string v3, "..chính là của tên Sanosuke và đồng bọn."

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x27

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Cô Ayumi, thằng bé sao rồi?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x28

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Mọi người yên tâm, Onda đã qua cơn nguy kịch rồi.."

    aput-object v3, v2, v5

    const-string v3, "..cũng may thằng bé có dòng máu Xích Mao, nếu không thì.."

    aput-object v3, v2, v6

    const-string v3, "..hy vọng sẽ bình phục trong vài ngày nữa.."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x29

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Ta đang ở đâu.."

    aput-object v3, v2, v5

    const-string v3, "Các ngươi là ai!"

    aput-object v3, v2, v6

    const-string v3, "Sức mạnh ta đâu cả rồi!!!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x2a

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Onda, cậu tỉnh rồi à?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x2b

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Sakura, đây là đâu thế!"

    aput-object v3, v2, v5

    const-string v3, "Vì sao tớ lại ở đây! Bọn người kia đâu rồi!"

    aput-object v3, v2, v6

    const-string v3, "Sức mạnh của tớ.."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x2c

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Cậu đã bất tỉnh 3 ngày rồi đó, cậu không nhớ sao?"

    aput-object v3, v2, v5

    const-string v3, "Tớ nghe thầy hiệu trưởng nói, cậu dám đánh nhau với tên Sanosuke.."

    aput-object v3, v2, v6

    const-string v3, "..ngốc thế! cậu phải biết sức mình chứ.."

    aput-object v3, v2, v7

    const-string v3, "..để đến nỗi trọng thương, mất hết võ công.."

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x2d

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cậu nói sao!!"

    aput-object v3, v2, v5

    const-string v3, "..mất hết võ công??"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x2e

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Onda.."

    aput-object v3, v2, v5

    const-string v3, "chúng ta vẫn là.."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x2f

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Cậu im đi, tôi không cần ai thương hại!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x30

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Onda !!!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x31

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Cậu tỉnh rồi à? Thầy hiệu trưởng muốn gặp cậu đấy!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x32

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Con đã khỏe chưa?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x33

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vâng.. khỏe ạ.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x34

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Nghe đây Onda!"

    aput-object v3, v2, v5

    const-string v3, "Tuy con bị trọng thương, sức mạnh đã mất.."

    aput-object v3, v2, v6

    const-string v3, "..nhưng với tư chất của con, ta tin con có thể vượt qua.."

    aput-object v3, v2, v7

    const-string v3, "..con hiểu ý ta chứ! Hãy đến gặp cô Ayumi đi!"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x35

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sakura chắc hẳn ở bên dưới thác.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x36

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Nè nè, vô duyên! Cậu đứng đó nhìn gì thế!"

    aput-object v3, v2, v5

    const-string v3, "Mau biến đi, tớ la lên bây giờ đó!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x37

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sakura, thầy hiệu trưởng bảo cậu và tớ cùng về gặp thầy.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x38

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Thầy gọi à.."

    aput-object v3, v2, v5

    const-string v3, "Này, cậu giúp tớ một chuyện được không?"

    aput-object v3, v2, v6

    const-string v3, "Tớ vừa đánh rơi thanh kunai xuống dòng nước.."

    aput-object v3, v2, v7

    const-string v3, "Có lẽ nó trôi xuống chân thác rồi, cậu xuống dưới tìm đi!"

    aput-object v3, v2, v8

    const-string v3, "..xong rồi tớ sẽ cùng cậu về trường."

    aput-object v3, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x39

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Ok."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x3a

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Nhanh lên nhé! Cẩn thận con heo rừng bên dưới đó!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x3b

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "..heo rừng à? Tớ cóc sợ!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x3c

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Đừng có giả bộ đứng nhìn hoài!"

    aput-object v3, v2, v5

    const-string v3, "Cút đi mau lên!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x3d

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Cậu vẫn chưa tìm thấy kiếm à!"

    aput-object v3, v2, v5

    const-string v3, "Thanh kunai là của chị Ayumi tặng mình đấy!"

    aput-object v3, v2, v6

    const-string v3, "Chắc chắn nó bị trôi xuống dưới chân thác, cậu cố tìm lần nữa xem!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x3e

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Thanh kunai nè.."

    aput-object v3, v2, v5

    const-string v3, "Cậu sẵn sàn chưa!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x3f

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "..."

    aput-object v3, v2, v5

    const-string v3, "Cảm ơn.."

    aput-object v3, v2, v6

    const-string v3, "Đi gặp thầy thôi!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x40

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Toniku! Cậu đi cùng mình và Sakura đến trường Haruna nhé!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x41

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Tôi đi cùng các cậu à!?"

    aput-object v3, v2, v5

    const-string v3, "Haha, cậu đi một lần đến đó mà chưa biết sợ à?"

    aput-object v3, v2, v6

    const-string v3, "Tớ sẽ đi cùng, với điều kiện..."

    aput-object v3, v2, v7

    const-string v3, "..chúng ta chạy đua thử nhé, nếu cậu thắng thì sẽ đi.."

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x42

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Sẵn sàng thôi!"

    aput-object v3, v2, v5

    const-string v3, "Sakura, cậu có muốn vận động tí không nhỉ?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x43

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Chuẩn bị nhé!"

    aput-object v3, v2, v5

    const-string v3, "...3..."

    aput-object v3, v2, v6

    const-string v3, "...2..."

    aput-object v3, v2, v7

    const-string v3, "...1..."

    aput-object v3, v2, v8

    const-string v3, "..Chạy!"

    aput-object v3, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x44

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Hừ, không thể tin được!"

    aput-object v3, v2, v5

    const-string v3, "Dù biết là cậu chơi ăn gian, nhưng tớ cũng muốn thử sức một phen!"

    aput-object v3, v2, v6

    const-string v3, "Đi thôi!"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x45

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Hehe, thua rồi nhé!"

    aput-object v3, v2, v5

    const-string v3, "Tập luyện nhiều hơn nữa rồi hãy rủ anh mày đua!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x46

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Ngươi chưa được phép đi tiếp nếu chưa có sự đồng ý của thầy hiệu trưởng."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x47

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vâng!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x48

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Phiên bản DEMO chỉ cho chơi đến đây!"

    aput-object v3, v2, v5

    const-string v3, "Mời bạn đón chơi bản chính thức....tại wap site http://vechai321.xtgem.com"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x49

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Các con! Làm sao để di chuyển?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x4a

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sử dụng phím mũi tên, hoặc phím 2,4,6,8"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x4b

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Làm sao để tấn công?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x4c

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sử dụng phím giữa hoặc phím 5, nhấp nhiều lần để thi triển nhiều chiêu hơn."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x4d

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Làm sao để tấn công với sét, lửa, băng?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x4e

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Mua kiếm sét, gươm lửa, gươm băng từ người bán hàng."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x4f

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Các người là ai?"

    aput-object v3, v2, v5

    const-string v3, "sao lại đến làng này"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x50

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Con là Hyroya Onda, học sinh của trường Ninja"

    aput-object v3, v2, v5

    const-string v3, "con đang trên đường làm nhiệm vụ do thầy hiệu trưởng giao phó..."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x51

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Ninja ah..."

    aput-object v3, v2, v5

    const-string v3, "ta nghe nói Ninja có võ công rất giỏi"

    aput-object v3, v2, v6

    const-string v3, "nhưng dù người giỏi đến đâu thì cũng không thể vượt qua vách núi Ichidai được..."

    aput-object v3, v2, v7

    const-string v3, "nếu không có diều lượn của người Tone chúng ta"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x52

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Già làng có thể cho con mượn một con diều lượn được không ạ"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x53

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Già cũng muốn giúp ngươi lắm nhưng vật liệu để làm diều của làng Tone đã hết"

    aput-object v3, v2, v5

    const-string v3, "mà làng Tone giờ chỉ còn mình ta và một đám con nít..."

    aput-object v3, v2, v6

    const-string v3, "chẳng thể làm gì được cả"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x54

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vật liệu để làm diều là gì ah? con sẽ đi tìm cho"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x55

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Ta cần gân của 20 con ốc ma đen dưới chân vách đá Ichidai"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x56

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Tưởng gì..."

    aput-object v3, v2, v5

    const-string v3, "Đối với con đó chỉ là chuyện nhỏ thôi"

    aput-object v3, v2, v6

    const-string v3, "Già cứ đợi con ở đây nhé"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x57

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Aaaaaaaaa......"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x58

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "SAKURA....!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x59

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Chắc Sakura bị trượt chân xuống vách núi rồi"

    aput-object v3, v2, v5

    const-string v3, "mình phải quay xuống xem có chuyện gì ngay.."

    aput-object v3, v2, v6

    const-string v3, "mình sẽ đưa Sakura về làng Tone nhờ chữa trị"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x5a

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Vậy cậu nhớ chăm sóc Sakura cẩn thận đó"

    aput-object v3, v2, v5

    const-string v3, "sau khi giết được nó tớ sẽ về liền"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x5b

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sakura sao rồi?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x5c

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Già làng nói, Sakura cần thuốc của bà lão bán tạp hóa tại cánh đồng Fuki.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x5d

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Bà ấy bán tạp hóa sao có thuốc gì à!!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x5e

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Tớ cũng đâu có biết, già làng nói vậy thì nghe vậy đi."

    aput-object v3, v2, v5

    const-string v3, "Bây giờ cậu đã có diều lượn, cậu hãy đến cánh đồng Fuki mua thuốc về nhé"

    aput-object v3, v2, v6

    const-string v3, "tớ sẽ ở đây chăm sóc Sakura"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x5f

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Mình biết rồi, mình sẽ cố gắng về sớm"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x60

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Bà lão bán tạp hóa đây rồi, mình sẽ mua thuốc cho Sakura ngay..."

    aput-object v3, v2, v5

    const-string v3, "bà lão ở một mình neo đơn thật.."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x61

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cậu về rồi à, sao lâu thế?"

    aput-object v3, v2, v5

    const-string v3, "thuốc đâu? đưa đây mau lên"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x62

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thuốc đây, vì trên đường có mấy con quái chặn đường .."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x63

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Thôi, cậu đi nghỉ ngơi đi, tớ sẽ cho Sakura uống thuốc"

    aput-object v3, v2, v5

    const-string v3, "có lẽ sáng mai chúng ta có thể tiếp tục lên đường được rồi"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x64

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Yeah, ngày mai chúng ta sẽ men theo cây cầu Daihoshi để đến cánh đồng Fuki\t"

    aput-object v3, v2, v5

    const-string v3, "cây cầu đã được sửa tạm rồi"

    aput-object v3, v2, v6

    const-string v3, "với khinh công của chúng ta thì có thể qua cầu 1 cách dễ dàng"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x65

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Đến trường Haruna rồi..."

    aput-object v3, v2, v5

    const-string v3, "mà sao mọi người đi đâu hết rồi ..."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x66

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, " Thì cô Toyotomi, hiệu trưởng của trường Haruna đang gặp nạn\t"

    aput-object v3, v2, v5

    const-string v3, "nên chắc trường đang cho học sinh nghỉ dài hạn mà"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x67

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Nhiệm vụ của chúng ta là đến đây để tìm hiểu nguyên nhân"

    aput-object v3, v2, v5

    const-string v3, "chúng ta đi tìm xem có ai ở đây không..."

    aput-object v3, v2, v6

    const-string v3, "biết đâu sẽ biết được ít tin tức "

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x68

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Thẻ học sinh đâu?"

    aput-object v3, v2, v5

    const-string v3, "Không phải học sinh trường này thì không được phép qua khu ký túc xá, ta phải hỏi vậy để tránh sự trà trộn của bọn xấu"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x69

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cảm ơn các bạn nhé..."

    aput-object v3, v2, v5

    const-string v3, "các bạn đến từ trường Hirosaki phải không "

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x6a

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Uh, sao bạn biết"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x6b

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thật ra mình đã biết từ đầu rồi, mình chỉ muốn thử các bạn một chút cho chắc thôi"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x6c

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Mình là em gái của cô Toyotomi, Aiko"

    aput-object v3, v2, v5

    const-string v3, " mình có nhiệm vụ ở đây đợi các bạn"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x6d

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Nghe nói hiện giờ tên Sanosuke đang chiếm lĩnh và cai trị cả vùng miếu Chakuni"

    aput-object v3, v2, v5

    const-string v3, "có lẽ hắn cũng đã giam giữ cô Toyotomi ở đó"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x6e

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Muốn giết được hắn, các bạn phải có đủ 3 miếng phong ấn và dùng nó để lấy thanh Hỏa Long ở Đỉnh Gió"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x6f

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Giờ các bạn hãy lấy thẻ học sinh của mình để đi qua khu ký túc xá"

    aput-object v3, v2, v5

    const-string v3, "sau đó các bạn cứ đi thẳng sẽ đến miếu Chakuni"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x70

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Thẻ học sinh của mình cũng chính là miếng phong ấn thứ nhất"

    aput-object v3, v2, v5

    const-string v3, "2 miếng phong ấn còn lại do 2 Tamnin sinh đôi của trường Haruna giữ"

    aput-object v3, v2, v6

    const-string v3, "hiện giờ họ cũng đang trên đường đến miếu Chakuni, mình tin chắc các bạn sẽ gặp họ trên đường đi"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x71

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cám ơn bạn nhiều lắm, bây giờ bọn mình sẽ lập tức lên đường"

    aput-object v3, v2, v5

    const-string v3, "nếu có ai từ trường Hirosaki đến, bạn nhớ báo tin với họ dùm mình"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x72

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Ah, các bạn nhớ cẩn thận khi đi qua hang Aka đấy"

    aput-object v3, v2, v5

    const-string v3, "có một con ốc sên thành tinh khổng lồ canh trước cửa hang đó"

    aput-object v3, v2, v6

    const-string v3, " giết được nó thì mới có lối đi qua hang nhé"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x73

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Hình như đây là khu suối nước nóng Akagi..."

    aput-object v3, v2, v5

    const-string v3, "các học sinh của Haruna hay luyện công nơi đây..."

    aput-object v3, v2, v6

    const-string v3, "thử khám phá một vòng nào"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x74

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "cẩn thận đấy..."

    aput-object v3, v2, v5

    const-string v3, "đã lâu tớ chưa tắm suối nước nóng …"

    aput-object v3, v2, v6

    const-string v3, "các cậu ở đây canh giùm tớ nha, chiều ý con gái với nhé"

    aput-object v3, v2, v7

    const-string v3, "cấm nhìn trộm đó"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x75

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Vậy trong lúc Sakura tắm, tớ với cậu đi bắt vài con cua với vài con rùa tai đỏ làm lương khô vậy"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x76

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "OK, ai bắt được 20 con rùa tai đỏ trước thì người đó thắng"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x77

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "hừm...mình vẫn chưa bắt đủ 20 con "

    aput-object v3, v2, v5

    const-string v3, "mình mà thua Toniku sao "

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x78

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Các cậu làm gì mà lâu thế?"

    aput-object v3, v2, v5

    const-string v3, "làm tớ đợi các cậu nãy giờ nè"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x79

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "ah...bọn tớ chỉ thi thố một tí thôi mà"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x7a

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "hm..nhiệm vụ lần này rất quan trọng, các bạn phải cảnh giác một tí chứ"

    aput-object v3, v2, v5

    const-string v3, "thôi, chúng ta tiếp tục lên đường đi,tớ nghĩ miếu Chakuma không còn xa nữa đâu"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x7b

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Là bọn đàn em của tên Sanosuke"

    aput-object v3, v2, v5

    const-string v3, "bọn chúng đông quá, giờ phải làm sao đây"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x7c

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Toniku, cậu bảo vệ Sakura nhé, tôi sẽ liều với chúng một phen"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x7d

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Không được, nếu cả 3 chúng ta hợp sức chưa chắc đánh lại bọn chúng"

    aput-object v3, v2, v5

    const-string v3, "cậu không thể hy sinh vô ích như vậy được"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x7e

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Sakura nói đúng đó..."

    aput-object v3, v2, v5

    const-string v3, "tớ thấy có chiếc moto đằng kia"

    aput-object v3, v2, v6

    const-string v3, "cậu hãy chạy cùng Sakura thoát thân"

    aput-object v3, v2, v7

    const-string v3, "tôi sẽ ở lại đây cầm chân bọn chúng"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x7f

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Không"

    aput-object v3, v2, v5

    const-string v3, "chết thì cùng chết"

    aput-object v3, v2, v6

    const-string v3, "tôi không thể để cậu một mình trong tình huống như vậy được…"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x80

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Tôi biết"

    aput-object v3, v2, v5

    const-string v3, "nhưng nhiệm vụ giải cứu cô Toyotomi quan trọng hơn, nó là danh dự của chúng ta, là nhiệm vụ mà các học sinh như ta phải hoàn thành một khi thầy đã giao.."

    aput-object v3, v2, v6

    const-string v3, "Cậu và Sakura cứ đi trước, tôi sẽ đuổi theo sau mà, tôi mạnh hơn cậu nghĩ đấy, đây cũng là cách tốt đề đánh lạc hướng bọn xấu"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x81

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "hm....."

    aput-object v3, v2, v5

    const-string v3, "Cẩn thận!!.."

    aput-object v3, v2, v6

    const-string v3, "tôi sẽ tìm kiếm 2 miếng phong ấn còn lại và bắt tên Sanosuke phải đền tội"

    aput-object v3, v2, v7

    const-string v3, "tôi thề"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x82

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Vậy cậu đi nhanh lên"

    aput-object v3, v2, v5

    const-string v3, "tôi sẽ thu hút sự chú ý của bọn chúng"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x83

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Các ngươi là ai, sao lại đi qua nơi này"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x84

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Dạ, tụi con là học sinh của trường Hirosaki"

    aput-object v3, v2, v5

    const-string v3, "tụi con có nhiệm vụ quan trọng cần đi đến miếu Chakuni"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x85

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Học sinh của trường Hirosaki...."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x86

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Ta là người rất thích các câu đố"

    aput-object v3, v2, v5

    const-string v3, "nếu các người giải được 3 câu đố của ta thì ta sẽ cho các ngươi đi qua"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x87

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Câu đố ???"

    aput-object v3, v2, v5

    const-string v3, "tụi con cũng rất thích giải đố"

    aput-object v3, v2, v6

    const-string v3, "ông cứ đố xem sao"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x88

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "ha ha ha..."

    aput-object v3, v2, v5

    const-string v3, "được"

    aput-object v3, v2, v6

    const-string v3, "câu thứ nhất nhé"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x89

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Ba anh vác gậy đuổi nhau, mười hai cô gái làm ngơ đứng nhìn"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x8a

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Các ngươi chưa được phép qua nếu chưa giải được 3 câu đố của ta"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x8b

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Quả không hổ danh là học sinh trường Hirosaki"

    aput-object v3, v2, v5

    const-string v3, "các ngươi cứ giữ lấy cái đồng hồ..."

    aput-object v3, v2, v6

    const-string v3, "ta nghĩ đó là thứ các ngươi đang tìm kiếm đó"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x8c

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "....."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x8d

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Phải chăng ông là một trong ba tamnin của trường Haruna?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x8e

    const/16 v2, 0x8

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "ha ha ha..."

    aput-object v3, v2, v5

    const-string v3, "Khá lắm, khá lắm"

    aput-object v3, v2, v6

    const-string v3, "chiếc đồng hồ cũng chính là miếng phong ấn thứ 2 đó"

    aput-object v3, v2, v7

    const-string v3, "mà ta thấy thể lực của các ngươi còn yếu lắm"

    aput-object v3, v2, v8

    const-string v3, "chưa đủ sức chống lại tên Sanosuke đâu"

    aput-object v3, v2, v9

    const/4 v3, 0x5

    const-string v4, "muốn tăng lực hãy lấy viên lam ngọc ngàn năm từ con cá mập thành tinh"

    aput-object v4, v2, v3

    const/4 v3, 0x6

    const-string v4, "nó sẽ giúp ngươi tăng level và hồi phục máu"

    aput-object v4, v2, v3

    const/4 v3, 0x7

    const-string v4, "chúc các ngươi lên đường may mắn"

    aput-object v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x8f

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Có đứa bé kìa Sakura"

    aput-object v3, v2, v5

    const-string v3, "Không biết có chuyện gì mà thấy nó rầu rĩ vậy..."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x90

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Em ah, có chuyện gì xảy ra sao?"

    aput-object v3, v2, v5

    const-string v3, "có cần tụi chị giúp gì không?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x91

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Em làm mất cây sáo của gia tộc rồi"

    aput-object v3, v2, v5

    const-string v3, "mẹ mà biết là em no đòn"

    aput-object v3, v2, v6

    const-string v3, "hu hu hu.."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x92

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Thôi được rồi, bọn anh sẽ tìm về cho"

    aput-object v3, v2, v5

    const-string v3, "mà em có đi chơi ở đâu lung tung không?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x93

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "hu hu hu.."

    aput-object v3, v2, v5

    const-string v3, "em chỉ sang đảo Sasayaku bên cạnh chơi thôi"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x94

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Tụi chị sẽ đi tìm giúp em,"

    aput-object v3, v2, v5

    const-string v3, "em đứng ở đây đợi nhé và nhớ đừng có đi đâu lung tung nữa đó"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x95

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Hình như là cây sáo?"

    aput-object v3, v2, v5

    const-string v3, "để mình hỏi thử xem"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x96

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "ông cho con hỏi"

    aput-object v3, v2, v5

    const-string v3, "đây có phải là cây sáo của ông không ạ?"

    aput-object v3, v2, v6

    const-string v3, "hay là ông nhặt được ở đâu"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x97

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Sáo này ta nhặt được"

    aput-object v3, v2, v5

    const-string v3, "mà liên quan gì đến các ngươi chứ"

    aput-object v3, v2, v6

    const-string v3, "hỏi làm gì"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x98

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Dạ cây sáo này là của tụi con làm rơi"

    aput-object v3, v2, v5

    const-string v3, "ông cho con xin lại"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x99

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Của các ngươi àh?"

    aput-object v3, v2, v5

    const-string v3, "Ta cũng bị bọn hồn ma bên hang Uno chôm mất cái tượng kỳ lân mà có tìm lại được đâu"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x9a

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Ta già rồi, mắt yếu, không tìm được bức tượng nên sẽ lấy cây sáo này làm bầu bạn sớm hôm"

    aput-object v3, v2, v5

    const-string v3, "tại sao ta phải trả cho các ngươi chứ?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x9b

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Nếu tụi con tìm thấy bức tượng cho ông"

    aput-object v3, v2, v5

    const-string v3, "ông sẽ trả lại cây sáo cho tụi con chứ?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x9c

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "....."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x9d

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Được"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x9e

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cám ơn anh chị nhé"

    aput-object v3, v2, v5

    const-string v3, "anh chị thật là tốt bụng"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x9f

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Là ông già bị mất tượng kỳ lân???"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xa0

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Ha ha ha, đúng thế"

    aput-object v3, v2, v5

    const-string v3, "ta chính là đứa bé bị mất sáo..."

    aput-object v3, v2, v6

    const-string v3, "và cũng chính là ông già bị mất tượng kỳ lân"

    aput-object v3, v2, v7

    const-string v3, "và cũng là một trong ba tamnin của trường Haruna"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xa1

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Tamnin của trường Haruna?"

    aput-object v3, v2, v5

    const-string v3, "vậy ông có giữ miếng phong ấn còn lại không ạh?"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xa2

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Miếng phong ấn àh?"

    aput-object v3, v2, v5

    const-string v3, "Các ngươi đang giữ nó đó"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xa3

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Ah"

    aput-object v3, v2, v5

    const-string v3, "là cây sáo"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xa4

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Đúng"

    aput-object v3, v2, v5

    const-string v3, "khi có đủ 3 miếng phong ấn, ngươi hãy đến nơi cao nhất của Đỉnh Gió"

    aput-object v3, v2, v6

    const-string v3, "thanh Hỏa long sẽ được giải phong ấn"

    aput-object v3, v2, v7

    const-string v3, "Nhưng ngươi nên nhớ một điều.."

    aput-object v3, v2, v8

    const-string v3, "Sức mạnh ẩn chứa trong thanh Hỏa Long chỉ có tác dụng với tên Sanosuke thôi"

    aput-object v3, v2, v9

    const/4 v3, 0x5

    const-string v4, "Vì thế, hãy cẩn thận với tất cả bọn đàn em của hắn"

    aput-object v4, v2, v3

    const/4 v3, 0x6

    const-string v4, "Hãy đi đi và nhớ kỹ những điều ta dặn"

    aput-object v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xa5

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Onda"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xa6

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Có chuyện gì không Sakura?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xa7

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Tớ lo cho Toniku quá"

    aput-object v3, v2, v5

    const-string v3, "không biết giờ cậu ấy ra sao rồi"

    aput-object v3, v2, v6

    const-string v3, "cậu ấy đã vì chúng ta mà..."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xa8

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Uh, tớ biết mà"

    aput-object v3, v2, v5

    const-string v3, "chính vì thế chúng ta không thể làm phí công lao của cậu ấy được"

    aput-object v3, v2, v6

    const-string v3, "bây giờ chúng ta sẽ cùng nhau tới miếu Chakuni tiêu diệt tên Bạo Vũ Đao"

    aput-object v3, v2, v7

    const-string v3, "cứu cô Toyotomi rồi quay lại tìm cậu ấy"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xa9

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Nhưng mà tớ lo lắm"

    aput-object v3, v2, v5

    const-string v3, "Không thể yên tâm được"

    aput-object v3, v2, v6

    const-string v3, "Tớ muốn quay lại tìm cậu ấy..."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xaa

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, " Tớ nghĩ đến đây thì cậu có thể di trước thăm dò, mình sẽ tìm Toniku và theo sau...."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xab

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Uhm..."

    aput-object v3, v2, v5

    const-string v3, "Vậy cậu hãy quay lại tìm Toniku đi"

    aput-object v3, v2, v6

    const-string v3, "nhớ cẩn thận nha."

    aput-object v3, v2, v7

    const-string v3, "Tớ sẽ tìm càng nhiều thong tin về Sanosuke"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xac

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Cậu cũng phải cẩn thận đó"

    aput-object v3, v2, v5

    const-string v3, "tớ đi đây"

    aput-object v3, v2, v6

    const-string v3, "Chắc chắn chúng ta sẽ gặp nhau tại trường chứ"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xad

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Chắc chắn"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xae

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sakura..."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xaf

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Hừm..."

    aput-object v3, v2, v5

    const-string v3, "Khá khen cho ngươi"

    aput-object v3, v2, v6

    const-string v3, "Đã một lần chết mà còn chưa sợ"

    aput-object v3, v2, v7

    const-string v3, "Giờ lại dẫn xác đến đây, cứ lỳ lợm như bọn Ninja Xích Mao khác,..hahah..haha, rồi cũng gục ngã trước Tứ linh đao của ta"

    aput-object v3, v2, v8

    const-string v3, "Hhahahaha"

    aput-object v3, v2, v9

    const/4 v3, 0x5

    const-string v4, "ha ha ha ha..."

    aput-object v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xb0

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Tên Sanosuke chết tiệt kia"

    aput-object v3, v2, v5

    const-string v3, "Đừng tưởng ta sợ ngươi"

    aput-object v3, v2, v6

    const-string v3, "Mau thả cô Toyotomi ra, không thì đừng có trách"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xb1

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Ha ha ha ha..."

    aput-object v3, v2, v5

    const-string v3, "Ta sợ quá, sợ quá"

    aput-object v3, v2, v6

    const-string v3, "Ta sẽ hóa kiếp cho ngươi"

    aput-object v3, v2, v7

    const-string v3, "Như ta đã làm với dân làng của ngươi trước đây…hahahha.."

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xb2

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Con đã trả thù được cho dân làng, tên đầu tiên trong năm tên ác nhân ...."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb3

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Cuối cùng thì mình cũng đã hoàn thành nhiệm vụ"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb4

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Giỏi lắm Onda, Sakura và cả Toniku..."

    aput-object v3, v2, v5

    const-string v3, "quả là không uổng công kỳ vọng của ta"

    aput-object v3, v2, v6

    const-string v3, "ta già rồi, đúng là không nhanh chân bằng các con"

    aput-object v3, v2, v7

    const-string v3, "ha ha ha...."

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xb5

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cảm ơn các con nhiều nhé.., chỉ vì một phút bất cẩn mà các con phải chịu cực khổ vì ta"

    aput-object v3, v2, v5

    const-string v3, "Thôi, con hãy sang bên lớp học đi, em gái của ta và Toniku đang chờ hai đứa đó"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xb6

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Vâng..."

    aput-object v3, v2, v5

    const-string v3, "Con cũng muốn kết than với Aiko"

    aput-object v3, v2, v6

    const-string v3, "tụi con đi đây"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xb7

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Nhìn chúng nó mà tôi nghĩ đến hồi xưa..haizz..tuổi trẻ"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb8

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Toniku, cậu không sao chứ"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb9

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Không sao đâu, rất may là hai anh em song sinh trường tớ đến kịp lúc"

    aput-object v3, v2, v5

    const-string v3, "cậu ấy chỉ bị thương nhẹ thôi"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xba

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "tớ đã chăm sóc cậu ấy cẩn thận, bây giờ cậu ấy đã bình phục hoàn toàn rồi"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xbb

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Đúng đó, tớ nghe nói Toniku bị thương và được mang về đây."

    aput-object v3, v2, v5

    const-string v3, "Sau đó thầy hiệu trưởng cũng vừa tới đây thì nghe tin tên Sanosuke đã bị tiêu diệt"

    aput-object v3, v2, v6

    const-string v3, "cho nên thầy và Toniku cùng ở lại đây đợi chúng ta về luôn về luôn"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xbc

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "ừ mà cậu đi lâu quá đi"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xbd

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Uh, cả tất cả chúng ta đã cùng hoàn thành nhiệm vụ rất tốt"

    aput-object v3, v2, v5

    const-string v3, "cám ơn các cậu nhé"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xbe

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Tại sao phải cám ơn chứ?"

    aput-object v3, v2, v5

    const-string v3, "chúng ta là bạn mà"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xbf

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Ừ, chúng ta sẽ là bạn tốt của nhau"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xc0

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Muốn sử dụng được phi tiêu ta phải làm sao?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xc1

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Nhấn phím số 0 để chuyển qua dùng phi tiêu và nhấn phím 0 lần nữa để chuyển qua dùng kiếm ạ"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xc2

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Làm sao để có thể sử dụng được diều lượn"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xc3

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Để đeo diều lượn nhấn phím mũi tên lên hoặc phím số 2"

    aput-object v3, v2, v5

    const-string v3, "để bỏ diều lượn nhấn phím mũi tên xuống hoặc phím 8."

    aput-object v3, v2, v6

    const-string v3, "Để diều bay được lâu và cao phải nhấn liên tục phím mũi tên lên hoặc phím 2"

    aput-object v3, v2, v7

    const-string v3, "em nói đúng không thầy?"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xc4

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, " Giỏi lắm, giỏi lắm..."

    aput-object v3, v2, v5

    const-string v3, "Tập luyện nào, trong chủ Ninja, gồm tâm và đao, tâm không vững thì đao chém xuống.. mà chém xuống thì.. à mà..mà.. sao nữa ta.."

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xc5

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "ê, bắt được 20 con rùa rồi, tao thắng rồi nha"

    aput-object v3, v2, v5

    const-string v3, "Thôi mình đến chỗ Sakura đi, Sakura đang đợi đó"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xc6

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Hiện nay cô Toyotomi đang mất tích, tình hình đang rất nguy hiểm"

    aput-object v3, v2, v5

    const-string v3, "tất cả các học sinh đều phải trở về nhà"

    aput-object v3, v2, v6

    const-string v3, "nếu muốn đi qua, các ngươi phải đạt được ít nhất là cấp độ 13"

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xc7

    const/16 v2, 0x9

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "ha ha ha..."

    aput-object v3, v2, v5

    const-string v3, "Khá lắm, khá lắm"

    aput-object v3, v2, v6

    const-string v3, "chiếc đồng hồ cũng chính là miếng phong ấn thứ 2 đó"

    aput-object v3, v2, v7

    const-string v3, "mà ta thấy thể lực của các ngươi còn yếu lắm"

    aput-object v3, v2, v8

    const-string v3, "chưa đủ sức chống lại tên Sanosuke đâu"

    aput-object v3, v2, v9

    const/4 v3, 0x5

    const-string v4, "muốn tăng lực hãy lấy viên lam ngọc ngàn năm từ con cá mập thành tinh"

    aput-object v4, v2, v3

    const/4 v3, 0x6

    const-string v4, "nó sẽ giúp ngươi tăng level và hồi phục máu"

    aput-object v4, v2, v3

    const/4 v3, 0x7

    const-string v4, "tuy nhiên để giết được con cá đó thì ngươi phải đạt được cấp độ 20"

    aput-object v4, v2, v3

    const/16 v3, 0x8

    const-string v4, "hãy đi tập luyện thêm đi"

    aput-object v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xc8

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thể lực ngươi vẫn còn yếu lắm, hãy đi tập luyện để đạt được cấp độ 20"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xc9

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Onda"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xca

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Có chuyện gì vậy?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xcb

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sakura bảo phải đi gởi tin báo về trường bằng qua thuật của cậu ấy, cần nơi yên tĩnh.."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xcc

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Xong, lên đường tiếp nào"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xcd

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Tôi phải báo tin ngay"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xce

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thôi cậu tiếp tục đi đi, tớ sẽ đưa Sakura quay lại sau khi xong việc"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xcf

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Uh, nhanh lên đó, suốt ngày đòi đi chung với Sakura"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xd0

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Onda"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xd1

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Lên đường nào, nhanh chân nào"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xd2

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Mình chưa có diều lượn"

    aput-object v3, v2, v5

    const-string v3, "lên đây làm gì nhỉ"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xd3

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Sakura đang bị thương đợi mình mua thuốc mang về"

    aput-object v3, v2, v5

    const-string v3, "mình phải quay về nhanh thôi"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    sput-object v0, Ll;->c:[[Ljava/lang/String;

    new-array v0, v7, [[Ljava/lang/String;

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Anh chị chưa tìm được cây sáo àh"

    aput-object v2, v1, v5

    const-string v2, "anh chị tìm giúp em đi"

    aput-object v2, v1, v6

    aput-object v1, v0, v5

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Hãy mau đi đi và nhớ kỹ những điều ta dặn"

    aput-object v2, v1, v5

    aput-object v1, v0, v6

    sput-object v0, Ll;->d:[[Ljava/lang/String;

    new-array v0, v8, [[Ljava/lang/String;

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Bức tượng đâu?"

    aput-object v2, v1, v5

    const-string v2, "Ta không có bức tượng thì các ngươi cũng không có sáo"

    aput-object v2, v1, v6

    aput-object v1, v0, v5

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Ta sẽ giữ đúng lời hứa"

    aput-object v2, v1, v5

    const-string v2, "sáo của các ngươi đây"

    aput-object v2, v1, v6

    const-string v2, "đừng bao giờ quay lại tìm ta nữa đó"

    aput-object v2, v1, v7

    aput-object v1, v0, v6

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Đừng làm phiền ta nữa, mau đi đi"

    aput-object v2, v1, v5

    aput-object v1, v0, v7

    sput-object v0, Ll;->e:[[Ljava/lang/String;

    const/16 v0, 0xb

    new-array v0, v0, [[Ljava/lang/String;

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Trường Haruna? Đến đó làm gì?"

    aput-object v2, v1, v5

    const-string v2, "Cậu đến đó một mình đi, tớ phải luyện tập thêm!"

    aput-object v2, v1, v6

    aput-object v1, v0, v5

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Uhm, trình độ tớ còn thấp, không cùng cậu đi được.."

    aput-object v2, v1, v5

    const-string v2, "Nhưng tớ sẽ luyện tập thêm, 3 ngày nữa quay lại tìm tớ nhé!"

    aput-object v2, v1, v6

    aput-object v1, v0, v6

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Mấy hôm nay tớ bị con sói cắn.. chân đau quá"

    aput-object v2, v1, v5

    const-string v2, "Cậu rủ người khác cùng đi nhé!"

    aput-object v2, v1, v6

    aput-object v1, v0, v7

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Uhm, trường Haruna xa lắm, tao lại bị say xe.."

    aput-object v2, v1, v5

    const-string v2, "Sao mày không rủ thằng Toniku đi cùng nhỉ?"

    aput-object v2, v1, v6

    aput-object v1, v0, v8

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Nghe không, thầy hiệu trưởng bảo mày đi kìa, còn không đi nhanh lên?"

    aput-object v2, v1, v5

    const-string v2, "Mày không đi tao đánh cho đó !!"

    aput-object v2, v1, v6

    aput-object v1, v0, v9

    const/4 v1, 0x5

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thầy hiệu trưởng gọi mày kìa, không về tao đánh mày đó."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Cậu vừa hồi phục à? Nhanh thật đấy"

    aput-object v3, v2, v5

    const-string v3, "Tớ nghĩ cậu phải nghỉ ngơi thêm nhiều!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Cậu dám đánh nhau với tên Sanosuke à?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Sao cậu không dẫn con sói cùa cậu đi cùng?"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Mày giờ thì đánh đấm gì nữa."

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Haha, mày cũng có ngày này sao.."

    aput-object v3, v2, v5

    const-string v3, "Muốn đi theo làm đàn em của tao không!"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    sput-object v0, Ll;->f:[[Ljava/lang/String;

    new-array v0, v9, [[Ljava/lang/String;

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Vẫn chưa giải được câu đố của ta sao"

    aput-object v2, v1, v5

    const-string v2, "vậy thì chịu khó ở lại đây bầu bạn với ta đi nhé"

    aput-object v2, v1, v6

    const-string v2, "ha ha ha...."

    aput-object v2, v1, v7

    aput-object v1, v0, v5

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Khá lắm"

    aput-object v2, v1, v5

    const-string v2, "câu đố thứ 2 nhé:"

    aput-object v2, v1, v6

    const-string v2, "Cái gì lạ lắm, tên trùng một âm, nước đục chui lầm, thì tiêu đời cá"

    aput-object v2, v1, v7

    aput-object v1, v0, v6

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "câu đố cuối cùng đây"

    aput-object v2, v1, v5

    const-string v2, "mang cho ta cái gì vừa là áo vừa là nhà nhé"

    aput-object v2, v1, v6

    aput-object v1, v0, v7

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Thể lực ngươi vẫn còn yếu lắm, đi tập luyện tiếp đi"

    aput-object v2, v1, v5

    aput-object v1, v0, v8

    sput-object v0, Ll;->g:[[Ljava/lang/String;

    new-array v0, v8, [[Ljava/lang/String;

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Các bạn có thấy mắt kiếng của mình ở đâu không..."

    aput-object v2, v1, v5

    const-string v2, "mình bị bạn bè giấu mất mắt kiếng rồi"

    aput-object v2, v1, v6

    aput-object v1, v0, v5

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Cám ơn các bạn nhé..."

    aput-object v2, v1, v5

    const-string v2, "các bạn đến từ trường Hirosaki phải không"

    aput-object v2, v1, v6

    const-string v2, "các bạn cứ lấy thẻ của mình đi"

    aput-object v2, v1, v7

    aput-object v1, v0, v6

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Chúc các bạn lên đường may mắn nhé"

    aput-object v2, v1, v5

    aput-object v1, v0, v7

    sput-object v0, Ll;->h:[[Ljava/lang/String;

    const/4 v0, 0x5

    new-array v0, v0, [[Ljava/lang/String;

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Bọn mày là người từ bản khác đến ah?"

    aput-object v2, v1, v5

    const-string v2, "Trông mày không giống người ở đây"

    aput-object v2, v1, v6

    const-string v2, "mày nên đến gặp già làng đi"

    aput-object v2, v1, v7

    aput-object v1, v0, v5

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Mày lấy ở đâu cái áo đẹp thế?"

    aput-object v2, v1, v5

    const-string v2, "Đổi cho tao đi"

    aput-object v2, v1, v6

    aput-object v1, v0, v6

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Mặt tao hôm nay đang nổi mụn..."

    aput-object v2, v1, v5

    const-string v2, "tao không muốn nói chuyện với ai cả"

    aput-object v2, v1, v6

    aput-object v1, v0, v7

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Biến đi..."

    aput-object v2, v1, v5

    aput-object v1, v0, v8

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "what do nêm?"

    aput-object v2, v1, v5

    const-string v2, "người bản mày chào nhau vậy phải không?"

    aput-object v2, v1, v6

    aput-object v1, v0, v9

    sput-object v0, Ll;->i:[[Ljava/lang/String;

    new-array v0, v9, [[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Đồng phục của trường bạn đẹp quá"

    aput-object v2, v1, v5

    aput-object v1, v0, v5

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Cậu là Onda phải không?, tớ đã nghe kể rất nhiều về cậu"

    aput-object v2, v1, v5

    aput-object v1, v0, v6

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Rảnh không?"

    aput-object v2, v1, v5

    const-string v2, "tí đi uống cafe với mình nhé xinh tươi ơi"

    aput-object v2, v1, v6

    aput-object v1, v0, v7

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Nhỏ áo tím là bạn gái mày hả?"

    aput-object v2, v1, v5

    const-string v2, "Xinh thế."

    aput-object v2, v1, v6

    aput-object v1, v0, v8

    sput-object v0, Ll;->j:[[Ljava/lang/String;

    const/4 v0, 0x6

    new-array v0, v0, [[Ljava/lang/String;

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Ngươi còn chưa đi hả"

    aput-object v2, v1, v5

    const-string v2, "nếu không có vật liệu, ta không thể giúp người được"

    aput-object v2, v1, v6

    aput-object v1, v0, v5

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Ngươi giết chưa đủ số lượng ốc ma đen..."

    aput-object v2, v1, v5

    const-string v2, "hãy quay lại vách núi Ichidai đi"

    aput-object v2, v1, v6

    aput-object v1, v0, v6

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Đúng là ninja các ngươi giỏi thật"

    aput-object v2, v1, v5

    const-string v2, "ngươi có thể giúp ta giết chết con mực khổng lồ trên đỉnh vách Ichidai được không?"

    aput-object v2, v1, v6

    const-string v2, "sau khi ngươi giết chết được nó ta sẽ hướng dẫn ngươi cách sử dụng diều lượn"

    aput-object v2, v1, v7

    aput-object v1, v0, v7

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "Ta đã giữ đúng lời hứa, làm giúp ngươi một con diều lượn"

    aput-object v2, v1, v5

    const-string v2, "nhưng ta sẽ không hướng dẫn ngươi cách sử dụng diều lượn..."

    aput-object v2, v1, v6

    const-string v2, "nếu ngươi không giết chết con mực khổng lồ trả thù cho người làng Tone chúng ta"

    aput-object v2, v1, v7

    aput-object v1, v0, v8

    const/4 v1, 0x7

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "Ta đã để sẵn diều lượn ở trên đỉnh vách Ichidai"

    aput-object v2, v1, v5

    const-string v2, "ngươi hãy nghe kỹ những điều ta dặn đây"

    aput-object v2, v1, v6

    const-string v2, "để đeo diều lượn ngươi hãy đến chỗ con diều và nhấn phím mũi tên lên hoặc phím số 2"

    aput-object v2, v1, v7

    const-string v2, "để bỏ diều lượn nhấn phím mũi tên xuống hoặc phím 8"

    aput-object v2, v1, v8

    const-string v2, "để diều bay được lâu và cao phải nhấn liên tục phím mũi tên lên hoặc phím 2"

    aput-object v2, v1, v9

    const/4 v2, 0x5

    const-string v3, "Ah.. bạn gái ngươi đang bị thương nằm bên dãy nhà bên kia.."

    aput-object v3, v1, v2

    const/4 v2, 0x6

    const-string v3, "Nó đang mong các ngươi lắm, ta thấy vậy..."

    aput-object v3, v1, v2

    aput-object v1, v0, v9

    const/4 v1, 0x5

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Để sử dụng được diều lượn ngươi cần phải có thể lực thật tốt"

    aput-object v3, v2, v5

    const-string v3, "Hãy quay lại gặp ta khi ngươi đạt được cấp độ 10"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    sput-object v0, Ll;->k:[[Ljava/lang/String;

    const/16 v0, 0x10

    new-array v0, v0, [[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Con mau gặp cô Ayumi để khôi phục sức mạnh đi.."

    aput-object v2, v1, v5

    aput-object v1, v0, v5

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Cô Ayumi đứng đằng kia. Hãy mau đến gặp cô ấy!"

    aput-object v2, v1, v5

    aput-object v1, v0, v6

    new-array v1, v7, [Ljava/lang/String;

    const-string v2, "Con mới bị thương nặng, không nên tập luyện quá nhiều!"

    aput-object v2, v1, v5

    const-string v2, "Hãy nghỉ ngơi một thời gian rồi gặp ta!"

    aput-object v2, v1, v6

    aput-object v1, v0, v7

    const/4 v1, 0x5

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "Con tỉnh rồi đấy à!"

    aput-object v2, v1, v5

    const-string v2, "Tuy lần này bị thương khá nặng, nhưng con vẫn có thể hồi phục được."

    aput-object v2, v1, v6

    const-string v2, "Gần đây, bọn nhím lông nâu sinh sảnh ồ ạt, phá hoại mùa màng.."

    aput-object v2, v1, v7

    const-string v2, "Con hãy tìm giết 10 con nhím, như con đã từng làm.."

    aput-object v2, v1, v8

    const-string v2, "Rồi ta sẽ giúp con hồi phục khả năng khinh công!"

    aput-object v2, v1, v9

    aput-object v1, v0, v8

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Nhanh lên, sang khu luyện tập và giết những con nhím phá hoại mùa màng.."

    aput-object v2, v1, v5

    aput-object v1, v0, v9

    const/4 v1, 0x5

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Tốt lắm, con đã hồi phục tương đối thể lực."

    aput-object v3, v2, v5

    const-string v3, "Khinh công của con tuy không nhuần nhuyễn như xưa.."

    aput-object v3, v2, v6

    const-string v3, "..nhưng nếu tập luyện đều đặn, sẽ mang lại kết quả."

    aput-object v3, v2, v7

    const-string v3, "Thầy hiệu trưởng gọi con đấy, đến đó nhanh lên!"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Con hãy làm xong nhiệm vụ được giao, rồi đến đây gặp ta sau!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Onda! Chuyện lần trước ta giao, con vẫn là người thực hiện."

    aput-object v3, v2, v5

    const-string v3, "Nhưng lần này, con hãy dẫn theo Sakura đi cùng."

    aput-object v3, v2, v6

    const-string v3, "Hãy đi gọi nó quay về đây gặp ta! Con bé ấy bên khu thác nước."

    aput-object v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Hãy tìm Sakura bên dưới thác nước rồi quay về đây gặp ta!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Uhm tốt lắm.. Các con có thể sẵn sàng lên đường rồi."

    aput-object v3, v2, v5

    const-string v3, "Tuy nhiên, sức mạnh của Onda vẫn chưa hồi phục hẳn.."

    aput-object v3, v2, v6

    const-string v3, "..các con còn nhớ Toniku chứ! Hãy gọi nó đến đây!"

    aput-object v3, v2, v7

    const-string v3, "Toniku sẽ đi cùng các con!"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v9, [Ljava/lang/String;

    const-string v3, "Tốt lắm, các con đã đủ 1 nhóm!"

    aput-object v3, v2, v5

    const-string v3, "Tuy nhiên thể lực Onda còn hơi yếu, nên hãy luyện tập thêm.."

    aput-object v3, v2, v6

    const-string v3, "Khi nào con được cấp độ 6, ta sẽ cho phép lên đường!"

    aput-object v3, v2, v7

    const-string v3, "Toniku và Sakura cùng giúp bạn luyện tập nhé!"

    aput-object v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xb

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Đây là thông hành của ta. Các con có thể lên đường!"

    aput-object v3, v2, v5

    const-string v3, "Onda, lần này con không được chủ quan."

    aput-object v3, v2, v6

    const-string v3, "Sakura và Toniku hỗ trợ tốt Onda nhé"

    aput-object v3, v2, v7

    const-string v3, "Ta nghe nói cây cầu bắt qua sông Watamaro đã bị gãy.."

    aput-object v3, v2, v8

    const-string v3, "Vì thế các con hãy men theo con đường bên dưới chân cầu mà đi."

    aput-object v3, v2, v9

    const/4 v3, 0x5

    const-string v4, "Chúc các con may mắn!"

    aput-object v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Hãy tìm Toniku ở thôn Sanzuya rồi cùng quay về đây gặp ta!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Hãy nhanh chóng cùng bạn bè đến trường Haruna!"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Hãy mau đi gặp Toniku đi, nó đang đợi các con ở bên dãy lớp học đó"

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v7, [Ljava/lang/String;

    const-string v3, "Ta đang nhức đầu, không muốn bán buôn gì hết"

    aput-object v3, v2, v5

    const-string v3, "Đến chỗ khác mà mua"

    aput-object v3, v2, v6

    aput-object v2, v0, v1

    sput-object v0, Ll;->l:[[Ljava/lang/String;

    new-array v0, v6, [[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Cứ đi đường này sẽ đến trường Haruna, chúc may mắn!"

    aput-object v2, v1, v5

    aput-object v1, v0, v5

    sput-object v0, Ll;->m:[[Ljava/lang/String;

    const/4 v0, 0x5

    new-array v0, v0, [[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Ta đang bận, Con hãy đi tập luyện đi."

    aput-object v2, v1, v5

    aput-object v1, v0, v5

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Con vừa bị thương nặng, phải cẩn thận trong khi luyện tập"

    aput-object v2, v1, v5

    aput-object v1, v0, v6

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "..Con cần phải tập luyện cật lực để phục hồi sức mạnh ban đầu!"

    aput-object v2, v1, v5

    aput-object v1, v0, v7

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Ta đang bực, đừng có đến gần ta!"

    aput-object v2, v1, v5

    aput-object v1, v0, v8

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "À..à, nếu có đi đâu, con ghé mua dùm ta một cây kẹo mút nhé, tự dưng ta lại thèm kẹo mút!."

    aput-object v2, v1, v5

    aput-object v1, v0, v9

    sput-object v0, Ll;->n:[[Ljava/lang/String;

    new-array v0, v6, [Ljava/lang/String;

    const-string v1, "Ngươi không có đủ vàng."

    aput-object v1, v0, v5

    new-array v0, v6, [Ljava/lang/String;

    const-string v1, "Hãy hoàn thành nhiệm vụ được giao rồi quay lại gặp ta!"

    aput-object v1, v0, v5

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
