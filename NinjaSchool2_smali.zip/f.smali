.class final Lf;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:I


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf;->a:Ljava/lang/String;

    iput-object p2, p0, Lf;->b:Ljava/lang/String;

    iput p3, p0, Lf;->c:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    :try_start_0
    iget-object v0, p0, Lf;->a:Ljava/lang/String;

    invoke-static {v0}, Ljavay/microedition/io/Connector;->open(Ljava/lang/String;)Ljavax/microedition/io/Connection;

    move-result-object v0

    check-cast v0, Ljavax/wireless/messaging/MessageConnection;

    const-string v1, "text"

    invoke-interface {v0, v1}, Ljavax/wireless/messaging/MessageConnection;->newMessage(Ljava/lang/String;)Ljavax/wireless/messaging/Message;

    move-result-object v1

    check-cast v1, Ljavax/wireless/messaging/TextMessage;

    iget-object v2, p0, Lf;->a:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljavax/wireless/messaging/Message;->setAddress(Ljava/lang/String;)V

    iget-object v2, p0, Lf;->b:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljavax/wireless/messaging/TextMessage;->setPayloadText(Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljavax/wireless/messaging/MessageConnection;->send(Ljavax/wireless/messaging/Message;)V

    invoke-static {}, Lq;->c()V

    iget v0, p0, Lf;->c:I

    packed-switch v0, :pswitch_data_fa

    :goto_25
    return-void

    :pswitch_26  #0x0
    const/4 v0, 0x5

    sput v0, Lb;->g:I
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_29} :catch_2a

    goto :goto_25

    :catch_2a
    move-exception v0

    iget v0, p0, Lf;->c:I

    packed-switch v0, :pswitch_data_112

    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    const-string v0, "Không thể mua. Xin hãy thử lại sau."

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto :goto_25

    :pswitch_41  #0x1
    :try_start_41
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x0

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x32

    aput v2, v0, v1

    goto :goto_25

    :pswitch_4b  #0x2
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x1

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x32

    aput v2, v0, v1

    goto :goto_25

    :pswitch_55  #0x3
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x2

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1e

    aput v2, v0, v1

    goto :goto_25

    :pswitch_5f  #0x4
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x3

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x32

    aput v2, v0, v1

    goto :goto_25

    :pswitch_69  #0x5
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x4

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x32

    aput v2, v0, v1

    goto :goto_25

    :pswitch_73  #0x6
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x5

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1e

    aput v2, v0, v1

    goto :goto_25

    :pswitch_7d  #0x7
    const/4 v0, 0x1

    sput v0, Lg;->as:I

    sget-object v0, Lq;->bf:[I

    sget v1, Lq;->bh:I

    sget v2, Lg;->as:I

    aput v2, v0, v1

    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm sét"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x2

    aput v2, v0, v1

    sget v0, Lq;->bh:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bh:I

    invoke-static {}, Lq;->a()V

    invoke-static {}, Lb;->d()V

    goto :goto_25

    :pswitch_a4  #0x8
    const/4 v0, 0x2

    sput v0, Lg;->as:I

    sget-object v0, Lq;->bf:[I

    sget v1, Lq;->bh:I

    sget v2, Lg;->as:I

    aput v2, v0, v1

    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm lửa"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x3

    aput v2, v0, v1

    sget v0, Lq;->bh:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bh:I

    invoke-static {}, Lq;->a()V

    invoke-static {}, Lb;->d()V

    goto/16 :goto_25

    :pswitch_cc  #0x9
    const/4 v0, 0x3

    sput v0, Lg;->as:I

    sget-object v0, Lq;->bf:[I

    sget v1, Lq;->bh:I

    sget v2, Lg;->as:I

    aput v2, v0, v1

    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm băng"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x4

    aput v2, v0, v1

    sget v0, Lq;->bh:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bh:I

    invoke-static {}, Lq;->a()V

    invoke-static {}, Lb;->d()V
    :try_end_f2
    .catch Ljava/lang/Exception; {:try_start_41 .. :try_end_f2} :catch_2a

    goto/16 :goto_25

    :pswitch_f4  #0x0
    const/4 v0, 0x6

    sput v0, Lb;->g:I

    goto/16 :goto_25

    nop

    :pswitch_data_fa
    .packed-switch 0x0
        :pswitch_26  #00000000
        :pswitch_41  #00000001
        :pswitch_4b  #00000002
        :pswitch_55  #00000003
        :pswitch_5f  #00000004
        :pswitch_69  #00000005
        :pswitch_73  #00000006
        :pswitch_7d  #00000007
        :pswitch_a4  #00000008
        :pswitch_cc  #00000009
    .end packed-switch

    :pswitch_data_112
    .packed-switch 0x0
        :pswitch_f4  #00000000
    .end packed-switch
.end method
