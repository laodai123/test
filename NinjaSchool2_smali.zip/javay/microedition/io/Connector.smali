.class public Ljavay/microedition/io/Connector;
.super Ljava/lang/Object;

# interfaces
.implements Ljavax/wireless/messaging/MessageConnection;


# instance fields
.field private a:Ljavax/wireless/messaging/MessageConnection;


# direct methods
.method private constructor <init>(Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Ljavax/microedition/io/Connector;->open(Ljava/lang/String;)Ljavax/microedition/io/Connection;

    move-result-object v0

    check-cast v0, Ljavax/wireless/messaging/MessageConnection;

    iput-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    return-void
.end method

.method public static open(Ljava/lang/String;)Ljavax/microedition/io/Connection;
    .registers 3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Ljavay/microedition/io/Connector;->open(Ljava/lang/String;IZ)Ljavax/microedition/io/Connection;

    move-result-object v0

    return-object v0
.end method

.method public static open(Ljava/lang/String;I)Ljavax/microedition/io/Connection;
    .registers 3

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Ljavay/microedition/io/Connector;->open(Ljava/lang/String;IZ)Ljavax/microedition/io/Connection;

    move-result-object v0

    return-object v0
.end method

.method public static open(Ljava/lang/String;IZ)Ljavax/microedition/io/Connection;
    .registers 4

    const-string v0, "sms://"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_e

    new-instance v0, Ljavay/microedition/io/Connector;

    invoke-direct {v0, p0}, Ljavay/microedition/io/Connector;-><init>(Ljava/lang/String;)V

    :goto_d
    return-object v0

    :cond_e
    invoke-static {p0, p1, p2}, Ljavax/microedition/io/Connector;->open(Ljava/lang/String;IZ)Ljavax/microedition/io/Connection;

    move-result-object v0

    goto :goto_d
.end method

.method public static openDataInputStream(Ljava/lang/String;)Ljava/io/DataInputStream;
    .registers 2

    invoke-static {p0}, Ljavax/microedition/io/Connector;->openDataInputStream(Ljava/lang/String;)Ljava/io/DataInputStream;

    move-result-object v0

    return-object v0
.end method

.method public static openDataOutputStream(Ljava/lang/String;)Ljava/io/DataOutputStream;
    .registers 2

    invoke-static {p0}, Ljavax/microedition/io/Connector;->openDataOutputStream(Ljava/lang/String;)Ljava/io/DataOutputStream;

    move-result-object v0

    return-object v0
.end method

.method public static openInputStream(Ljava/lang/String;)Ljava/io/InputStream;
    .registers 2

    invoke-static {p0}, Ljavax/microedition/io/Connector;->openInputStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    return-object v0
.end method

.method public static openOutputStream(Ljava/lang/String;)Ljava/io/OutputStream;
    .registers 2

    invoke-static {p0}, Ljavax/microedition/io/Connector;->openOutputStream(Ljava/lang/String;)Ljava/io/OutputStream;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public close()V
    .registers 2

    iget-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    invoke-interface {v0}, Ljavax/wireless/messaging/MessageConnection;->close()V

    return-void
.end method

.method public newMessage(Ljava/lang/String;)Ljavax/wireless/messaging/Message;
    .registers 3

    iget-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    invoke-interface {v0, p1}, Ljavax/wireless/messaging/MessageConnection;->newMessage(Ljava/lang/String;)Ljavax/wireless/messaging/Message;

    move-result-object v0

    return-object v0
.end method

.method public newMessage(Ljava/lang/String;Ljava/lang/String;)Ljavax/wireless/messaging/Message;
    .registers 4

    iget-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    invoke-interface {v0, p1, p2}, Ljavax/wireless/messaging/MessageConnection;->newMessage(Ljava/lang/String;Ljava/lang/String;)Ljavax/wireless/messaging/Message;

    move-result-object v0

    return-object v0
.end method

.method public numberOfSegments(Ljavax/wireless/messaging/Message;)I
    .registers 3

    iget-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    invoke-interface {v0, p1}, Ljavax/wireless/messaging/MessageConnection;->numberOfSegments(Ljavax/wireless/messaging/Message;)I

    move-result v0

    return v0
.end method

.method public receive()Ljavax/wireless/messaging/Message;
    .registers 2

    iget-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    invoke-interface {v0}, Ljavax/wireless/messaging/MessageConnection;->receive()Ljavax/wireless/messaging/Message;

    move-result-object v0

    return-object v0
.end method

.method public send(Ljavax/wireless/messaging/Message;)V
    .registers 4

    if-nez p1, :cond_8

    new-instance v0, Ljava/lang/NullPointerException;

    invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V

    throw v0

    :cond_8
    const-wide/16 v0, 0x3e8

    :try_start_a
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_d
    .catch Ljava/lang/InterruptedException; {:try_start_a .. :try_end_d} :catch_e

    :goto_d
    return-void

    :catch_e
    move-exception v0

    goto :goto_d
.end method

.method public setMessageListener(Ljavax/wireless/messaging/MessageListener;)V
    .registers 3

    iget-object v0, p0, Ljavay/microedition/io/Connector;->a:Ljavax/wireless/messaging/MessageConnection;

    invoke-interface {v0, p1}, Ljavax/wireless/messaging/MessageConnection;->setMessageListener(Ljavax/wireless/messaging/MessageListener;)V

    return-void
.end method
