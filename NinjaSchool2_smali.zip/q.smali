.class public final Lq;
.super Ljavax/microedition/lcdui/Canvas;

# interfaces
.implements Ljava/lang/Runnable;
.implements Ljavax/microedition/lcdui/CommandListener;


# static fields
.field static A:I

.field static B:I

.field static C:[Z

.field static D:[Z

.field static E:I

.field static F:I

.field static G:I

.field static H:I

.field public static I:Z

.field public static J:Z

.field public static K:I

.field public static L:[I

.field public static M:[I

.field public static N:I

.field public static O:I

.field public static P:I

.field public static Q:I

.field public static R:I

.field public static S:I

.field public static T:I

.field public static U:Ljava/lang/String;

.field public static V:Ljava/lang/String;

.field public static W:I

.field public static X:I

.field public static Y:I

.field public static Z:I

.field public static a:Z

.field public static aA:Z

.field public static aB:I

.field public static aC:I

.field public static aD:I

.field public static aE:I

.field public static aF:I

.field public static aG:Z

.field public static aH:I

.field public static aI:I

.field public static aJ:I

.field public static aK:I

.field public static aL:I

.field public static aM:I

.field public static aN:Z

.field public static aO:I

.field public static aP:I

.field public static aQ:I

.field public static aR:[I

.field public static aS:[I

.field public static aT:[I

.field public static aU:[I

.field public static aV:[I

.field public static aW:I

.field public static aX:I

.field public static aY:[I

.field public static aZ:[I

.field public static aa:I

.field public static ab:I

.field public static ac:I

.field public static ad:I

.field public static ae:I

.field public static af:I

.field public static ag:I

.field public static ah:[I

.field public static ai:[I

.field public static aj:I

.field public static ak:I

.field public static al:I

.field public static am:I

.field public static an:I

.field public static ao:[Ljavax/microedition/lcdui/Image;

.field public static ap:[I

.field public static aq:Ljavax/microedition/lcdui/Image;

.field public static ar:Ljavax/microedition/lcdui/Image;

.field public static as:I

.field public static at:I

.field public static au:Z

.field public static av:I

.field public static aw:I

.field public static ax:I

.field public static ay:I

.field public static az:I

.field public static b:Z

.field private static bA:Z

.field private static bB:[[I

.field private static bC:[[I

.field private static bD:Z

.field private static bE:[[I

.field private static bF:[[I

.field private static bG:[[I

.field private static bH:[[I

.field private static bI:[I

.field private static bJ:[I

.field private static bK:[I

.field private static bL:[Ljava/lang/String;

.field private static bM:I

.field private static bN:I

.field private static bO:[[Ljava/lang/String;

.field private static bP:[I

.field private static bQ:[I

.field private static bR:Z

.field private static bS:I

.field private static bT:I

.field private static bU:I

.field private static bV:I

.field private static bW:I

.field private static bX:I

.field private static bY:I

.field private static bZ:I

.field public static ba:[I

.field public static bb:[I

.field public static bc:[I

.field public static bd:Z

.field public static be:[I

.field public static bf:[I

.field public static bg:[Ljava/lang/String;

.field public static bh:I

.field public static bi:I

.field public static bj:[Ljava/lang/String;

.field static bk:I

.field static bl:I

.field static bm:I

.field static bn:I

.field static bo:I

.field static bp:I

.field static bq:[[Ljava/lang/String;

.field static br:[I

.field public static bs:[I

.field public static bt:[Z

.field public static bu:I

.field public static bv:I

.field public static bw:[Ljava/lang/String;

.field public static bx:[Ljava/lang/String;

.field private static by:Z

.field private static bz:I

.field static c:Z

.field private static cA:[I

.field private static cB:[I

.field private static cC:I

.field private static cD:[I

.field private static cE:[I

.field private static cF:[I

.field private static cG:[I

.field private static cH:[I

.field private static cI:[I

.field private static cJ:[I

.field private static cK:[I

.field private static cL:[I

.field private static cM:[I

.field private static cN:[I

.field private static cO:[I

.field private static cP:[I

.field private static cQ:[I

.field private static cR:[I

.field private static cS:[I

.field private static cT:[I

.field private static cU:[I

.field private static cV:Z

.field private static cW:I

.field private static cX:Ljava/lang/String;

.field private static cY:I

.field private static cZ:[I

.field private static ca:I

.field private static cb:Z

.field private static cc:I

.field private static cd:I

.field private static ce:I

.field private static cf:I

.field private static cg:I

.field private static ch:I

.field private static ci:I

.field private static cj:I

.field private static ck:I

.field private static cl:I

.field private static cm:I

.field private static cn:I

.field private static co:I

.field private static cp:I

.field private static cq:I

.field private static cr:I

.field private static cs:Ljava/lang/String;

.field private static ct:I

.field private static cu:I

.field private static cv:I

.field private static cw:[I

.field private static cx:[I

.field private static cy:[I

.field private static cz:[I

.field static d:Z

.field private static dA:[I

.field private static dB:[I

.field private static dC:[I

.field private static dD:I

.field private static dE:I

.field private static dF:I

.field private static dG:I

.field private static dH:I

.field private static dI:I

.field private static dJ:[[Ljavax/microedition/lcdui/Image;

.field private static dK:[Ljavax/microedition/lcdui/Image;

.field private static dL:Ljavax/microedition/lcdui/Image;

.field private static dM:[Ljavax/microedition/lcdui/Image;

.field private static dN:Ljavax/microedition/lcdui/Image;

.field private static dO:[Ljavax/microedition/lcdui/Image;

.field private static dP:Ljavax/microedition/lcdui/Image;

.field private static dQ:[Ljavax/microedition/lcdui/Image;

.field private static dR:[Ljavax/microedition/lcdui/Image;

.field private static dS:Ljavax/microedition/lcdui/Image;

.field private static dT:[[Ljavax/microedition/lcdui/Image;

.field private static dU:[Ljavax/microedition/lcdui/Image;

.field private static dV:[Ljavax/microedition/lcdui/Image;

.field private static dW:[Ljavax/microedition/lcdui/Image;

.field private static dX:[Ljavax/microedition/lcdui/Image;

.field private static dY:[Ljavax/microedition/lcdui/Image;

.field private static dZ:[Ljavax/microedition/lcdui/Image;

.field private static da:[I

.field private static db:[I

.field private static dc:[I

.field private static dd:[I

.field private static de:[I

.field private static df:[I

.field private static dg:[I

.field private static dh:I

.field private static di:[I

.field private static dj:[I

.field private static dk:[I

.field private static dl:[I

.field private static dm:[Z

.field private static dn:I

.field private static do:[I

.field private static dp:[I

.field private static dq:[I

.field private static dr:[I

.field private static ds:[I

.field private static dt:[I

.field private static du:[I

.field private static dv:[I

.field private static dw:[Ljava/lang/String;

.field private static dx:[I

.field private static dy:[I

.field private static dz:[I

.field static e:Z

.field private static eA:J

.field private static eB:I

.field private static eC:I

.field private static eD:I

.field private static eE:I

.field private static eF:I

.field private static eG:I

.field private static eH:I

.field private static eI:I

.field private static eJ:I

.field private static eK:[I

.field private static eL:[I

.field private static eM:[I

.field private static eN:I

.field private static eO:I

.field private static eP:I

.field private static eQ:I

.field private static eR:[[Ljava/lang/String;

.field private static eS:I

.field private static eT:I

.field private static eU:I

.field private static eV:I

.field private static eW:I

.field private static eX:I

.field private static eY:Ljava/util/Random;

.field private static eZ:[I

.field private static ea:Ljavax/microedition/lcdui/Image;

.field private static eb:[Ljavax/microedition/lcdui/Image;

.field private static ec:[Ljavax/microedition/lcdui/Image;

.field private static ed:I

.field private static ee:I

.field private static ef:I

.field private static eg:I

.field private static eh:I

.field private static ei:I

.field private static ej:I

.field private static ek:I

.field private static el:I

.field private static em:Z

.field private static en:[Ljava/lang/String;

.field private static eo:I

.field private static ep:I

.field private static eq:I

.field private static er:Z

.field private static es:I

.field private static et:I

.field private static eu:I

.field private static ev:I

.field private static ew:I

.field private static ex:I

.field private static ey:I

.field private static ez:I

.field static f:Z

.field private static fA:[Ljava/lang/String;

.field private static fB:[Ljava/lang/String;

.field private static fC:[I

.field private static fD:[I

.field private static fE:[I

.field private static fF:[I

.field private static fG:[I

.field private static fH:Ljavax/microedition/lcdui/Image;

.field private static fI:Ljavax/microedition/lcdui/Image;

.field private static fJ:I

.field private static fK:I

.field private static fL:I

.field private static fM:I

.field private static fN:I

.field private static fO:I

.field private static fP:I

.field private static fQ:I

.field private static fR:I

.field private static fS:I

.field private static fT:I

.field private static fU:I

.field private static fV:I

.field private static fW:I

.field private static fX:I

.field private static fY:Ljava/lang/String;

.field private static fZ:[Ljavax/microedition/lcdui/Image;

.field private static fa:Z

.field private static fb:I

.field private static fc:Ljavax/microedition/lcdui/Image;

.field private static fd:I

.field private static fe:I

.field private static ff:[I

.field private static fg:I

.field private static fh:I

.field private static fi:[I

.field private static fj:[I

.field private static fk:[[Ljava/lang/String;

.field private static fl:[[I

.field private static fm:[Ljavax/microedition/lcdui/Image;

.field private static fn:I

.field private static fo:I

.field private static fp:I

.field private static fq:I

.field private static fr:[I

.field private static fs:[Ljava/lang/String;

.field private static ft:[I

.field private static fu:[Ljavax/microedition/lcdui/Image;

.field private static fv:I

.field private static fw:[Ljavax/microedition/lcdui/Image;

.field private static fx:I

.field private static fy:I

.field private static fz:I

.field static g:Z

.field private static ga:Z

.field private static gb:I

.field private static gc:I

.field private static gd:I

.field private static ge:I

.field private static gf:Ljava/lang/String;

.field private static gg:Ljava/lang/String;

.field private static gh:[Ljava/lang/String;

.field private static gi:I

.field static h:Z

.field public static i:Z

.field public static j:Z

.field public static k:Z

.field public static l:Z

.field public static m:Z

.field public static n:Z

.field public static o:Z

.field public static p:Z

.field public static q:Z

.field public static r:Z

.field public static s:Z

.field public static t:Z

.field public static final u:[[I

.field public static final v:[[I

.field static w:I

.field static x:Lq;

.field static y:Z

.field static z:Z


# direct methods
.method static constructor <clinit>()V
    .registers 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    sput-boolean v7, Lq;->by:Z

    sput-boolean v7, Lq;->a:Z

    sput-boolean v7, Lq;->b:Z

    const/16 v0, 0x28

    sput v0, Lq;->bz:I

    sput-boolean v6, Lq;->c:Z

    sput-boolean v7, Lq;->d:Z

    sput-boolean v7, Lq;->e:Z

    sput-boolean v7, Lq;->f:Z

    sput-boolean v7, Lq;->g:Z

    sput-boolean v7, Lq;->h:Z

    sput-boolean v7, Lq;->i:Z

    sput-boolean v7, Lq;->j:Z

    sput-boolean v7, Lq;->k:Z

    sput-boolean v7, Lq;->l:Z

    sput-boolean v7, Lq;->m:Z

    sput-boolean v7, Lq;->n:Z

    sput-boolean v7, Lq;->o:Z

    sput-boolean v7, Lq;->p:Z

    sput-boolean v7, Lq;->q:Z

    sput-boolean v7, Lq;->r:Z

    sput-boolean v7, Lq;->s:Z

    sput-boolean v7, Lq;->t:Z

    sput-boolean v7, Lq;->bA:Z

    const/16 v0, 0x26

    new-array v0, v0, [[I

    new-array v1, v5, [I

    fill-array-data v1, :array_1b6e

    aput-object v1, v0, v7

    new-array v1, v8, [I

    fill-array-data v1, :array_1b76

    aput-object v1, v0, v6

    new-array v1, v8, [I

    fill-array-data v1, :array_1b80

    aput-object v1, v0, v5

    const/4 v1, 0x4

    new-array v1, v1, [I

    fill-array-data v1, :array_1b8a

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v5, [I

    fill-array-data v2, :array_1b96

    aput-object v2, v0, v1

    new-array v1, v5, [I

    fill-array-data v1, :array_1b9e

    aput-object v1, v0, v9

    const/4 v1, 0x6

    new-array v2, v8, [I

    fill-array-data v2, :array_1ba6

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v8, [I

    fill-array-data v2, :array_1bb0

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v5, [I

    fill-array-data v2, :array_1bba

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v5, [I

    fill-array-data v2, :array_1bc2

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v5, [I

    fill-array-data v2, :array_1bca

    aput-object v2, v0, v1

    const/16 v1, 0xb

    new-array v2, v8, [I

    fill-array-data v2, :array_1bd2

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v5, [I

    fill-array-data v2, :array_1bdc

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v5, [I

    fill-array-data v2, :array_1be4

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v5, [I

    fill-array-data v2, :array_1bec

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v5, [I

    fill-array-data v2, :array_1bf4

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v5, [I

    fill-array-data v2, :array_1bfc

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v5, [I

    fill-array-data v2, :array_1c04

    aput-object v2, v0, v1

    const/16 v1, 0x12

    new-array v2, v5, [I

    fill-array-data v2, :array_1c0c

    aput-object v2, v0, v1

    const/16 v1, 0x13

    new-array v2, v5, [I

    fill-array-data v2, :array_1c14

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v5, [I

    fill-array-data v2, :array_1c1c

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v5, [I

    fill-array-data v2, :array_1c24

    aput-object v2, v0, v1

    const/16 v1, 0x16

    new-array v2, v5, [I

    fill-array-data v2, :array_1c2c

    aput-object v2, v0, v1

    const/16 v1, 0x17

    new-array v2, v5, [I

    fill-array-data v2, :array_1c34

    aput-object v2, v0, v1

    const/16 v1, 0x18

    new-array v2, v5, [I

    fill-array-data v2, :array_1c3c

    aput-object v2, v0, v1

    const/16 v1, 0x19

    new-array v2, v5, [I

    fill-array-data v2, :array_1c44

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v5, [I

    fill-array-data v2, :array_1c4c

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    new-array v2, v5, [I

    fill-array-data v2, :array_1c54

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    new-array v2, v5, [I

    fill-array-data v2, :array_1c5c

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v5, [I

    fill-array-data v2, :array_1c64

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    new-array v2, v5, [I

    fill-array-data v2, :array_1c6c

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    new-array v2, v5, [I

    fill-array-data v2, :array_1c74

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v5, [I

    fill-array-data v2, :array_1c7c

    aput-object v2, v0, v1

    const/16 v1, 0x21

    new-array v2, v5, [I

    fill-array-data v2, :array_1c84

    aput-object v2, v0, v1

    const/16 v1, 0x22

    new-array v2, v5, [I

    fill-array-data v2, :array_1c8c

    aput-object v2, v0, v1

    const/16 v1, 0x23

    new-array v2, v5, [I

    fill-array-data v2, :array_1c94

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v5, [I

    fill-array-data v2, :array_1c9c

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v5, [I

    fill-array-data v2, :array_1ca4

    aput-object v2, v0, v1

    sput-object v0, Lq;->u:[[I

    const/16 v0, 0x26

    new-array v0, v0, [[I

    new-array v1, v5, [I

    aput-object v1, v0, v7

    new-array v1, v8, [I

    aput v6, v1, v7

    aput v5, v1, v6

    aput-object v1, v0, v6

    new-array v1, v8, [I

    aput v8, v1, v7

    const/4 v2, 0x4

    aput v2, v1, v6

    aput-object v1, v0, v5

    const/4 v1, 0x4

    new-array v1, v1, [I

    aput v9, v1, v7

    const/4 v2, 0x6

    aput v2, v1, v6

    const/4 v2, 0x7

    aput v2, v1, v5

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v5, [I

    const/16 v3, 0x8

    aput v3, v2, v7

    aput-object v2, v0, v1

    new-array v1, v5, [I

    const/16 v2, 0x9

    aput v2, v1, v7

    aput-object v1, v0, v9

    const/4 v1, 0x6

    new-array v2, v8, [I

    const/16 v3, 0xa

    aput v3, v2, v7

    const/16 v3, 0xb

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v8, [I

    const/16 v3, 0xc

    aput v3, v2, v7

    const/16 v3, 0xd

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v5, [I

    const/16 v3, 0xe

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v5, [I

    const/16 v3, 0xf

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v5, [I

    const/16 v3, 0x10

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xb

    new-array v2, v8, [I

    const/16 v3, 0x11

    aput v3, v2, v7

    const/16 v3, 0x12

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v5, [I

    const/16 v3, 0x14

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v5, [I

    const/16 v3, 0x15

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v5, [I

    const/16 v3, 0x16

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v5, [I

    const/16 v3, 0x17

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v5, [I

    const/16 v3, 0x1a

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v5, [I

    const/16 v3, 0x1b

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x12

    new-array v2, v5, [I

    const/16 v3, 0x1c

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x13

    new-array v2, v5, [I

    const/16 v3, 0x1d

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v5, [I

    const/16 v3, 0x1f

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v5, [I

    const/16 v3, 0x20

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x16

    new-array v2, v5, [I

    const/16 v3, 0x22

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x17

    new-array v2, v5, [I

    const/16 v3, 0x23

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x18

    new-array v2, v5, [I

    const/16 v3, 0x24

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x19

    new-array v2, v5, [I

    const/16 v3, 0x26

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v5, [I

    const/16 v3, 0x27

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    new-array v2, v5, [I

    const/16 v3, 0x28

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    new-array v2, v5, [I

    const/16 v3, 0x29

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v5, [I

    const/16 v3, 0x2a

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    new-array v2, v5, [I

    const/16 v3, 0x2c

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    new-array v2, v5, [I

    const/16 v3, 0x2d

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v5, [I

    const/16 v3, 0x2e

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x21

    new-array v2, v5, [I

    const/16 v3, 0x30

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x22

    new-array v2, v5, [I

    const/16 v3, 0x32

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x23

    new-array v2, v5, [I

    const/16 v3, 0x35

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v5, [I

    const/16 v3, 0x36

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v5, [I

    const/16 v3, 0x37

    aput v3, v2, v7

    aput-object v2, v0, v1

    sput-object v0, Lq;->v:[[I

    const/16 v0, 0x26

    new-array v0, v0, [[I

    new-array v1, v5, [I

    aput-object v1, v0, v7

    new-array v1, v8, [I

    const/16 v2, 0x270

    aput v2, v1, v6

    aput-object v1, v0, v6

    new-array v1, v8, [I

    const/16 v2, 0xa8

    aput v2, v1, v6

    aput-object v1, v0, v5

    const/4 v1, 0x4

    new-array v1, v1, [I

    const/16 v2, 0x3a8

    aput v2, v1, v6

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v5, [I

    aput-object v2, v0, v1

    new-array v1, v5, [I

    aput-object v1, v0, v9

    const/4 v1, 0x6

    new-array v2, v8, [I

    const/16 v3, 0x300

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v8, [I

    const/16 v3, 0x210

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v5, [I

    const/16 v3, 0x210

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v5, [I

    const/16 v3, 0x210

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v5, [I

    const/16 v3, 0x570

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xb

    new-array v2, v8, [I

    const/16 v3, 0xa80

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v5, [I

    const/16 v3, 0x258

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v5, [I

    const/16 v3, 0x540

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v5, [I

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v5, [I

    const/16 v3, 0x258

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v5, [I

    const/16 v3, 0x7e0

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v5, [I

    const/16 v3, 0x4c8

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x12

    new-array v2, v6, [I

    const/16 v3, 0x330

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x13

    new-array v2, v5, [I

    const/16 v3, 0x978

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v5, [I

    const/16 v3, 0x48

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v5, [I

    const/16 v3, 0x888

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x16

    new-array v2, v5, [I

    const/16 v3, 0x78

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x17

    new-array v2, v5, [I

    const/16 v3, 0xa08

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x18

    new-array v2, v5, [I

    const/16 v3, 0xa50

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x19

    new-array v2, v5, [I

    const/16 v3, 0x678

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v5, [I

    const/16 v3, 0x1c8

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    new-array v2, v5, [I

    const/16 v3, 0x6c0

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    new-array v2, v5, [I

    const/16 v3, 0x468

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v5, [I

    const/16 v3, 0x690

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    new-array v2, v5, [I

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    new-array v2, v5, [I

    const/16 v3, 0x690

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v5, [I

    const/16 v3, 0x1b0

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x21

    new-array v2, v5, [I

    const/16 v3, 0x978

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x22

    new-array v2, v5, [I

    const/16 v3, 0xa50

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x23

    new-array v2, v5, [I

    const/16 v3, 0x1b0

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v5, [I

    const/16 v3, 0xdb0

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v5, [I

    const/16 v3, 0x258

    aput v3, v2, v7

    aput-object v2, v0, v1

    sput-object v0, Lq;->bB:[[I

    const/16 v0, 0x38

    new-array v0, v0, [[I

    const/16 v1, 0x1a

    new-array v1, v1, [I

    fill-array-data v1, :array_1cac

    aput-object v1, v0, v7

    const/16 v1, 0xc

    new-array v1, v1, [I

    fill-array-data v1, :array_1ce4

    aput-object v1, v0, v6

    const/4 v1, 0x7

    new-array v1, v1, [I

    fill-array-data v1, :array_1d00

    aput-object v1, v0, v5

    const/16 v1, 0x8

    new-array v1, v1, [I

    fill-array-data v1, :array_1d12

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v8, [I

    fill-array-data v2, :array_1d26

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v1, v1, [I

    fill-array-data v1, :array_1d30

    aput-object v1, v0, v9

    const/4 v1, 0x6

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1d4c

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1d66

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_1d76

    aput-object v2, v0, v1

    const/16 v1, 0x9

    const/16 v2, 0x11

    new-array v2, v2, [I

    fill-array-data v2, :array_1d9a

    aput-object v2, v0, v1

    const/16 v1, 0xa

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_1dc0

    aput-object v2, v0, v1

    const/16 v1, 0xb

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1dcc

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v5, [I

    fill-array-data v2, :array_1ddc

    aput-object v2, v0, v1

    const/16 v1, 0xd

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_1de4

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v5, [I

    fill-array-data v2, :array_1dfa

    aput-object v2, v0, v1

    const/16 v1, 0xf

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_1e02

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v9, [I

    fill-array-data v2, :array_1e0e

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v8, [I

    fill-array-data v2, :array_1e1c

    aput-object v2, v0, v1

    const/16 v1, 0x12

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1e26

    aput-object v2, v0, v1

    const/16 v1, 0x13

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1e36

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v9, [I

    fill-array-data v2, :array_1e46

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v5, [I

    fill-array-data v2, :array_1e54

    aput-object v2, v0, v1

    const/16 v1, 0x16

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_1e5c

    aput-object v2, v0, v1

    const/16 v1, 0x17

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_1e7a

    aput-object v2, v0, v1

    const/16 v1, 0x18

    const/4 v2, 0x7

    new-array v2, v2, [I

    fill-array-data v2, :array_1e90

    aput-object v2, v0, v1

    const/16 v1, 0x19

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_1ea2

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v5, [I

    fill-array-data v2, :array_1eb6

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_1ebe

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_1ed4

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v5, [I

    fill-array-data v2, :array_1ee0

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1ee8

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1f02

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v5, [I

    fill-array-data v2, :array_1f12

    aput-object v2, v0, v1

    const/16 v1, 0x21

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_1f1a

    aput-object v2, v0, v1

    const/16 v1, 0x22

    const/16 v2, 0xc

    new-array v2, v2, [I

    fill-array-data v2, :array_1f26

    aput-object v2, v0, v1

    const/16 v1, 0x23

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_1f42

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v5, [I

    fill-array-data v2, :array_1f56

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v9, [I

    fill-array-data v2, :array_1f5e

    aput-object v2, v0, v1

    const/16 v1, 0x26

    const/4 v2, 0x7

    new-array v2, v2, [I

    fill-array-data v2, :array_1f6c

    aput-object v2, v0, v1

    const/16 v1, 0x27

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_1f7e

    aput-object v2, v0, v1

    const/16 v1, 0x28

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_1f96

    aput-object v2, v0, v1

    const/16 v1, 0x29

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_1fac

    aput-object v2, v0, v1

    const/16 v1, 0x2a

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_1fca

    aput-object v2, v0, v1

    const/16 v1, 0x2b

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1fd6

    aput-object v2, v0, v1

    const/16 v1, 0x2c

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1fe6

    aput-object v2, v0, v1

    const/16 v1, 0x2d

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1ff6

    aput-object v2, v0, v1

    const/16 v1, 0x2e

    new-array v2, v5, [I

    fill-array-data v2, :array_2010

    aput-object v2, v0, v1

    const/16 v1, 0x2f

    new-array v2, v5, [I

    fill-array-data v2, :array_2018

    aput-object v2, v0, v1

    const/16 v1, 0x30

    new-array v2, v5, [I

    fill-array-data v2, :array_2020

    aput-object v2, v0, v1

    const/16 v1, 0x31

    new-array v2, v9, [I

    fill-array-data v2, :array_2028

    aput-object v2, v0, v1

    const/16 v1, 0x32

    new-array v2, v5, [I

    fill-array-data v2, :array_2036

    aput-object v2, v0, v1

    const/16 v1, 0x33

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_203e

    aput-object v2, v0, v1

    const/16 v1, 0x34

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_2058

    aput-object v2, v0, v1

    const/16 v1, 0x35

    new-array v2, v5, [I

    fill-array-data v2, :array_2064

    aput-object v2, v0, v1

    const/16 v1, 0x36

    new-array v2, v5, [I

    fill-array-data v2, :array_206c

    aput-object v2, v0, v1

    const/16 v1, 0x37

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_2074

    aput-object v2, v0, v1

    sput-object v0, Lq;->bC:[[I

    const/16 v0, 0x38

    new-array v0, v0, [[I

    const/16 v1, 0x1b

    new-array v1, v1, [I

    aput v6, v1, v8

    const/4 v2, 0x4

    aput v5, v1, v2

    const/4 v2, 0x6

    aput v6, v1, v2

    const/4 v2, 0x7

    aput v5, v1, v2

    const/16 v2, 0x9

    aput v8, v1, v2

    const/16 v2, 0xa

    const/4 v3, 0x4

    aput v3, v1, v2

    const/16 v2, 0xd

    aput v9, v1, v2

    const/16 v2, 0xe

    const/4 v3, 0x6

    aput v3, v1, v2

    const/16 v2, 0xf

    const/4 v3, 0x7

    aput v3, v1, v2

    const/16 v2, 0x10

    const/16 v3, 0x360

    aput v3, v1, v2

    const/16 v2, 0x11

    const/16 v3, 0x8

    aput v3, v1, v2

    const/16 v2, 0x12

    const/16 v3, 0x9

    aput v3, v1, v2

    const/16 v2, 0x13

    const/16 v3, 0xa

    aput v3, v1, v2

    const/16 v2, 0x14

    const/16 v3, 0xb

    aput v3, v1, v2

    const/16 v2, 0x15

    const/16 v3, 0xc

    aput v3, v1, v2

    const/16 v2, 0x16

    const/16 v3, 0xd

    aput v3, v1, v2

    const/16 v2, 0x17

    const/4 v3, 0x4

    aput v3, v1, v2

    const/16 v2, 0x18

    const/16 v3, 0x69

    aput v3, v1, v2

    aput-object v1, v0, v7

    const/16 v1, 0xc

    new-array v1, v1, [I

    aput v8, v1, v7

    aput v6, v1, v6

    aput v9, v1, v5

    const/4 v2, 0x4

    aput v2, v1, v8

    const/4 v2, -0x4

    aput v2, v1, v9

    const/4 v2, 0x6

    const/4 v3, -0x1

    aput v3, v1, v2

    const/4 v2, 0x7

    const/4 v3, -0x4

    aput v3, v1, v2

    const/16 v2, 0x8

    const/4 v3, -0x1

    aput v3, v1, v2

    const/16 v2, 0x9

    const/16 v3, 0xe

    aput v3, v1, v2

    const/16 v2, 0xa

    aput v5, v1, v2

    aput-object v1, v0, v6

    const/4 v1, 0x7

    new-array v1, v1, [I

    const/16 v2, 0x210

    aput v2, v1, v7

    const/16 v2, 0xf

    aput v2, v1, v8

    const/4 v2, 0x4

    const/16 v3, 0x10

    aput v3, v1, v2

    aput-object v1, v0, v5

    const/16 v1, 0x8

    new-array v1, v1, [I

    const/16 v2, 0x11

    aput v2, v1, v7

    const/16 v2, 0x12

    aput v2, v1, v6

    const/16 v2, 0x13

    aput v2, v1, v5

    const/16 v2, 0x14

    aput v2, v1, v8

    const/4 v2, 0x4

    const/16 v3, 0x15

    aput v3, v1, v2

    const/16 v2, 0x16

    aput v2, v1, v9

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v8, [I

    const/16 v3, 0x17

    aput v3, v2, v7

    const/16 v3, 0x6a

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v1, v1, [I

    const/4 v2, 0x6

    aput v2, v1, v6

    aput v8, v1, v5

    const/4 v2, 0x7

    aput v2, v1, v8

    const/4 v2, 0x4

    const/4 v3, -0x4

    aput v3, v1, v2

    const/4 v2, -0x1

    aput v2, v1, v9

    const/4 v2, 0x6

    const/16 v3, 0x8

    aput v3, v1, v2

    const/4 v2, 0x7

    const/4 v3, -0x4

    aput v3, v1, v2

    const/16 v2, 0x8

    const/4 v3, -0x1

    aput v3, v1, v2

    const/16 v2, 0xa

    const/16 v3, 0x18

    aput v3, v1, v2

    aput-object v1, v0, v9

    const/4 v1, 0x6

    const/16 v2, 0xb

    new-array v2, v2, [I

    const/16 v3, 0x19

    aput v3, v2, v5

    const/16 v3, 0x1a

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x1b

    aput v4, v2, v3

    const/16 v3, 0x1c

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x1d

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x1e

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-array v2, v2, [I

    const/16 v3, 0x1f

    aput v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const/16 v2, 0x10

    new-array v2, v2, [I

    const/16 v3, 0x9

    aput v3, v2, v7

    const/16 v3, 0x20

    aput v3, v2, v6

    const/16 v3, 0x21

    aput v3, v2, v5

    const/4 v3, 0x4

    const/16 v4, 0x22

    aput v4, v2, v3

    const/16 v3, 0x23

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x24

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x25

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x26

    aput v4, v2, v3

    const/16 v3, 0xc

    const/16 v4, 0x27

    aput v4, v2, v3

    const/16 v3, 0xd

    const/16 v4, 0x28

    aput v4, v2, v3

    const/16 v3, 0xe

    const/16 v4, 0x6b

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x9

    const/16 v2, 0x11

    new-array v2, v2, [I

    const/16 v3, 0x29

    aput v3, v2, v7

    const/16 v3, 0x138

    aput v3, v2, v5

    const/16 v3, 0x2a

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x2b

    aput v4, v2, v3

    const/16 v3, 0x2c

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x2d

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x2e

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x2f

    aput v4, v2, v3

    const/16 v3, 0xa

    const/4 v4, -0x3

    aput v4, v2, v3

    const/16 v3, 0xb

    const/4 v4, -0x1

    aput v4, v2, v3

    const/16 v3, 0xc

    const/4 v4, -0x3

    aput v4, v2, v3

    const/16 v3, 0xd

    const/16 v4, 0x30

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xa

    const/4 v2, 0x4

    new-array v2, v2, [I

    const/16 v3, 0x31

    aput v3, v2, v7

    const/16 v3, 0x420

    aput v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0xb

    const/4 v2, 0x6

    new-array v2, v2, [I

    const/16 v3, 0x32

    aput v3, v2, v6

    const/16 v3, 0x33

    aput v3, v2, v5

    const/16 v3, 0x34

    aput v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v5, [I

    const/16 v3, 0x35

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xd

    const/16 v2, 0x9

    new-array v2, v2, [I

    const/16 v3, 0x36

    aput v3, v2, v7

    const/16 v3, 0x37

    aput v3, v2, v6

    const/16 v3, 0x38

    aput v3, v2, v5

    const/16 v3, 0x39

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x3a

    aput v4, v2, v3

    const/16 v3, 0x3b

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x3c

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v5, [I

    const/16 v3, 0x3d

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0xf

    const/4 v2, 0x4

    new-array v2, v2, [I

    const/16 v3, 0x3e

    aput v3, v2, v7

    const/16 v3, 0x3f

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v9, [I

    const/16 v3, 0x40

    aput v3, v2, v7

    const/16 v3, 0x41

    aput v3, v2, v6

    const/16 v3, 0x42

    aput v3, v2, v5

    const/16 v3, 0x6c

    aput v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v8, [I

    const/16 v3, 0x43

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x12

    const/4 v2, 0x6

    new-array v2, v2, [I

    const/16 v3, 0x44

    aput v3, v2, v5

    const/4 v3, 0x4

    aput v8, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x13

    const/4 v2, 0x6

    new-array v2, v2, [I

    const/16 v3, 0x45

    aput v3, v2, v5

    const/4 v3, 0x4

    aput v8, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v9, [I

    const/16 v3, 0x46

    aput v3, v2, v7

    const/16 v3, 0x47

    aput v3, v2, v6

    const/4 v3, -0x4

    aput v3, v2, v5

    const/4 v3, -0x4

    aput v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v5, [I

    const/16 v3, 0x48

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x16

    const/16 v2, 0xd

    new-array v2, v2, [I

    const/16 v3, 0x49

    aput v3, v2, v7

    const/16 v3, 0x4a

    aput v3, v2, v6

    const/16 v3, 0x4b

    aput v3, v2, v5

    const/16 v3, 0x4c

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x4d

    aput v4, v2, v3

    const/16 v3, 0x4e

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0xc0

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0xc1

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0xc2

    aput v4, v2, v3

    const/16 v3, 0x9

    const/16 v4, 0xc3

    aput v4, v2, v3

    const/16 v3, 0xa

    const/16 v4, 0xc4

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x17

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_208a

    aput-object v2, v0, v1

    const/16 v1, 0x18

    new-array v2, v9, [I

    fill-array-data v2, :array_209e

    aput-object v2, v0, v1

    const/16 v1, 0x19

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_20ac

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v6, [I

    const/16 v3, 0x60

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_20c0

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    new-array v2, v8, [I

    fill-array-data v2, :array_20d4

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v6, [I

    const/16 v3, 0x68

    aput v3, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_20de

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_20f6

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v5, [I

    fill-array-data v2, :array_2106

    aput-object v2, v0, v1

    const/16 v1, 0x21

    new-array v2, v8, [I

    fill-array-data v2, :array_210e

    aput-object v2, v0, v1

    const/16 v1, 0x22

    const/16 v2, 0xc

    new-array v2, v2, [I

    fill-array-data v2, :array_2118

    aput-object v2, v0, v1

    const/16 v1, 0x23

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_2134

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v5, [I

    fill-array-data v2, :array_2148

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v9, [I

    fill-array-data v2, :array_2150

    aput-object v2, v0, v1

    const/16 v1, 0x26

    const/4 v2, 0x7

    new-array v2, v2, [I

    fill-array-data v2, :array_215e

    aput-object v2, v0, v1

    const/16 v1, 0x27

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_2170

    aput-object v2, v0, v1

    const/16 v1, 0x28

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_2188

    aput-object v2, v0, v1

    const/16 v1, 0x29

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_219e

    aput-object v2, v0, v1

    const/16 v1, 0x2a

    new-array v2, v8, [I

    fill-array-data v2, :array_21bc

    aput-object v2, v0, v1

    const/16 v1, 0x2b

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_21c6

    aput-object v2, v0, v1

    const/16 v1, 0x2c

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_21d6

    aput-object v2, v0, v1

    const/16 v1, 0x2d

    const/16 v2, 0xc

    new-array v2, v2, [I

    fill-array-data v2, :array_21e6

    aput-object v2, v0, v1

    const/16 v1, 0x2e

    new-array v2, v5, [I

    fill-array-data v2, :array_2202

    aput-object v2, v0, v1

    const/16 v1, 0x2f

    new-array v2, v5, [I

    fill-array-data v2, :array_220a

    aput-object v2, v0, v1

    const/16 v1, 0x30

    new-array v2, v5, [I

    fill-array-data v2, :array_2212

    aput-object v2, v0, v1

    const/16 v1, 0x31

    new-array v2, v9, [I

    fill-array-data v2, :array_221a

    aput-object v2, v0, v1

    const/16 v1, 0x32

    new-array v2, v5, [I

    fill-array-data v2, :array_2228

    aput-object v2, v0, v1

    const/16 v1, 0x33

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_2230

    aput-object v2, v0, v1

    const/16 v1, 0x34

    new-array v2, v8, [I

    fill-array-data v2, :array_224a

    aput-object v2, v0, v1

    const/16 v1, 0x35

    new-array v2, v5, [I

    fill-array-data v2, :array_2254

    aput-object v2, v0, v1

    const/16 v1, 0x36

    new-array v2, v5, [I

    fill-array-data v2, :array_225c

    aput-object v2, v0, v1

    const/16 v1, 0x37

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_2264

    aput-object v2, v0, v1

    sput-object v0, Lq;->bE:[[I

    const/16 v0, 0x38

    new-array v0, v0, [[I

    const/16 v1, 0x1b

    new-array v1, v1, [I

    fill-array-data v1, :array_2278

    aput-object v1, v0, v7

    const/16 v1, 0xc

    new-array v1, v1, [I

    aput v6, v1, v6

    const/4 v2, 0x4

    aput v2, v1, v5

    aput v9, v1, v8

    const/4 v2, 0x4

    const/16 v3, 0xe

    aput v3, v1, v2

    const/16 v2, 0xf

    aput v2, v1, v9

    const/4 v2, 0x6

    const/16 v3, 0x10

    aput v3, v1, v2

    const/4 v2, 0x7

    const/16 v3, 0x20

    aput v3, v1, v2

    const/16 v2, 0x8

    const/16 v3, 0x21

    aput v3, v1, v2

    const/16 v2, 0x9

    const/16 v3, 0x37

    aput v3, v1, v2

    const/16 v2, 0xa

    const/16 v3, 0x38

    aput v3, v1, v2

    const/16 v2, 0xb

    const/16 v3, 0x64

    aput v3, v1, v2

    aput-object v1, v0, v6

    const/4 v1, 0x7

    new-array v1, v1, [I

    fill-array-data v1, :array_22b2

    aput-object v1, v0, v5

    const/16 v1, 0x8

    new-array v1, v1, [I

    fill-array-data v1, :array_22c4

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v8, [I

    fill-array-data v2, :array_22d8

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v1, v1, [I

    aput v6, v1, v6

    aput v5, v1, v5

    aput v8, v1, v8

    const/4 v2, 0x4

    const/4 v3, 0x4

    aput v3, v1, v2

    aput v9, v1, v9

    const/4 v2, 0x6

    const/4 v3, 0x6

    aput v3, v1, v2

    const/4 v2, 0x7

    const/16 v3, 0x1a

    aput v3, v1, v2

    const/16 v2, 0x8

    const/16 v3, 0x1b

    aput v3, v1, v2

    const/16 v2, 0x9

    const/16 v3, 0x1c

    aput v3, v1, v2

    const/16 v2, 0xa

    const/16 v3, 0x1d

    aput v3, v1, v2

    const/16 v2, 0xb

    const/16 v3, 0x1e

    aput v3, v1, v2

    aput-object v1, v0, v9

    const/4 v1, 0x6

    const/16 v2, 0xb

    new-array v2, v2, [I

    aput v6, v2, v6

    const/16 v3, 0xa

    aput v3, v2, v5

    const/16 v3, 0xb

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0xc

    aput v4, v2, v3

    const/16 v3, 0xd

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0xe

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0xf

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x10

    aput v4, v2, v3

    const/16 v3, 0x9

    const/16 v4, 0x11

    aput v4, v2, v3

    const/16 v3, 0xa

    const/16 v4, 0x12

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_22e2

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const/16 v2, 0x10

    new-array v2, v2, [I

    aput v6, v2, v6

    aput v5, v2, v5

    const/16 v3, 0x17

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x22

    aput v4, v2, v3

    const/16 v3, 0x23

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x24

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x25

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x26

    aput v4, v2, v3

    const/16 v3, 0x9

    const/16 v4, 0x27

    aput v4, v2, v3

    const/16 v3, 0xa

    const/16 v4, 0x45

    aput v4, v2, v3

    const/16 v3, 0xb

    const/16 v4, 0x46

    aput v4, v2, v3

    const/16 v3, 0xc

    const/16 v4, 0x4b

    aput v4, v2, v3

    const/16 v3, 0xd

    const/16 v4, 0x55

    aput v4, v2, v3

    const/16 v3, 0xe

    const/16 v4, 0x56

    aput v4, v2, v3

    const/16 v3, 0xf

    const/16 v4, 0x57

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x9

    const/16 v2, 0x11

    new-array v2, v2, [I

    const/16 v3, 0xa

    aput v3, v2, v6

    const/16 v3, 0xb

    aput v3, v2, v5

    const/16 v3, 0x46

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x48

    aput v4, v2, v3

    const/16 v3, 0x49

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x4a

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x4b

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x4c

    aput v4, v2, v3

    const/16 v3, 0x9

    const/16 v4, 0x4d

    aput v4, v2, v3

    const/16 v3, 0xa

    const/16 v4, 0x4e

    aput v4, v2, v3

    const/16 v3, 0xb

    const/16 v4, 0x5e

    aput v4, v2, v3

    const/16 v3, 0xc

    const/16 v4, 0x7f

    aput v4, v2, v3

    const/16 v3, 0xd

    const/16 v4, 0x82

    aput v4, v2, v3

    const/16 v3, 0xe

    const/16 v4, 0x83

    aput v4, v2, v3

    const/16 v3, 0xf

    const/16 v4, 0x84

    aput v4, v2, v3

    const/16 v3, 0x10

    const/16 v4, 0x85

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0xa

    const/4 v2, 0x4

    new-array v2, v2, [I

    aput v6, v2, v6

    aput v5, v2, v5

    aput v8, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0xb

    const/4 v2, 0x6

    new-array v2, v2, [I

    aput v6, v2, v6

    aput v5, v2, v5

    aput v8, v2, v8

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput v4, v2, v3

    aput v9, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v5, [I

    fill-array-data v2, :array_22f2

    aput-object v2, v0, v1

    const/16 v1, 0xd

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_22fa

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v5, [I

    fill-array-data v2, :array_2310

    aput-object v2, v0, v1

    const/16 v1, 0xf

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_2318

    aput-object v2, v0, v1

    const/16 v1, 0x10

    new-array v2, v9, [I

    fill-array-data v2, :array_2324

    aput-object v2, v0, v1

    const/16 v1, 0x11

    new-array v2, v8, [I

    fill-array-data v2, :array_2332

    aput-object v2, v0, v1

    const/16 v1, 0x12

    const/4 v2, 0x6

    new-array v2, v2, [I

    aput v6, v2, v6

    aput v5, v2, v5

    aput v8, v2, v8

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput v4, v2, v3

    aput v9, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x13

    const/4 v2, 0x6

    new-array v2, v2, [I

    aput v6, v2, v6

    aput v5, v2, v5

    aput v8, v2, v8

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput v4, v2, v3

    aput v9, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x14

    new-array v2, v9, [I

    aput v6, v2, v6

    aput v5, v2, v5

    const/16 v3, 0xc

    aput v3, v2, v8

    aput-object v2, v0, v1

    const/16 v1, 0x15

    new-array v2, v5, [I

    aput v6, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x16

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_233c

    aput-object v2, v0, v1

    const/16 v1, 0x17

    const/16 v2, 0x9

    new-array v2, v2, [I

    const/16 v3, 0x12

    aput v3, v2, v7

    const/16 v3, 0x13

    aput v3, v2, v6

    const/16 v3, 0x14

    aput v3, v2, v5

    const/16 v3, 0x15

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x16

    aput v4, v2, v3

    const/16 v3, 0x17

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x18

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x19

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x18

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_235a

    aput-object v2, v0, v1

    const/16 v1, 0x19

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_236e

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    new-array v2, v5, [I

    fill-array-data v2, :array_2382

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    const/16 v2, 0xc

    new-array v2, v2, [I

    aput v9, v2, v5

    const/16 v3, 0xa

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x1e

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x1e

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    const/4 v2, 0x6

    new-array v2, v2, [I

    aput v9, v2, v7

    const/16 v3, 0xa

    aput v3, v2, v6

    const/16 v3, 0xf

    aput v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x1d

    new-array v2, v5, [I

    aput v9, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x1e

    const/16 v2, 0xb

    new-array v2, v2, [I

    aput v9, v2, v6

    const/16 v3, 0xa

    aput v3, v2, v5

    const/16 v3, 0xf

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x14

    aput v4, v2, v3

    const/4 v3, 0x6

    const/16 v4, 0x14

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0xf

    aput v4, v2, v3

    const/16 v3, 0xa

    const/16 v4, 0xf

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x1f

    const/4 v2, 0x6

    new-array v2, v2, [I

    aput v9, v2, v6

    aput v9, v2, v8

    aput v9, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x20

    new-array v2, v5, [I

    aput v9, v2, v7

    aput-object v2, v0, v1

    const/16 v1, 0x21

    const/4 v2, 0x4

    new-array v2, v2, [I

    aput v9, v2, v6

    const/16 v3, 0xa

    aput v3, v2, v5

    aput-object v2, v0, v1

    const/16 v1, 0x22

    const/16 v2, 0xc

    new-array v2, v2, [I

    const/16 v3, 0xf

    aput v3, v2, v7

    const/16 v3, 0x32

    aput v3, v2, v5

    const/16 v3, 0x50

    aput v3, v2, v8

    const/16 v3, 0x9

    const/16 v4, 0xf

    aput v4, v2, v3

    const/16 v3, 0xb

    aput v9, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x23

    const/16 v2, 0x8

    new-array v2, v2, [I

    aput v9, v2, v6

    const/16 v3, 0xa

    aput v3, v2, v8

    aput v9, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0xf

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x14

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x24

    new-array v2, v5, [I

    aput v8, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x25

    new-array v2, v9, [I

    fill-array-data v2, :array_238a

    aput-object v2, v0, v1

    const/16 v1, 0x26

    const/4 v2, 0x7

    new-array v2, v2, [I

    const/16 v3, 0x14

    aput v3, v2, v7

    const/16 v3, 0x19

    aput v3, v2, v6

    const/4 v3, 0x4

    aput v9, v2, v3

    const/16 v3, 0xa

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0xf

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x27

    const/16 v2, 0xa

    new-array v2, v2, [I

    const/16 v3, 0x14

    aput v3, v2, v7

    const/16 v3, 0x19

    aput v3, v2, v6

    aput v9, v2, v5

    const/16 v3, 0xa

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0xf

    aput v4, v2, v3

    const/4 v3, 0x6

    aput v9, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0xa

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x14

    aput v4, v2, v3

    const/16 v3, 0x9

    const/16 v4, 0x19

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x28

    const/16 v2, 0xa

    new-array v2, v2, [I

    aput v9, v2, v6

    const/16 v3, 0xf

    aput v3, v2, v5

    const/4 v3, 0x4

    aput v9, v2, v3

    aput v9, v2, v9

    const/4 v3, 0x6

    aput v9, v2, v3

    const/4 v3, 0x7

    aput v9, v2, v3

    const/16 v3, 0x8

    aput v9, v2, v3

    const/16 v3, 0x9

    aput v9, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x29

    const/16 v2, 0xd

    new-array v2, v2, [I

    const/16 v3, 0xa

    aput v3, v2, v7

    const/16 v3, 0xf

    aput v3, v2, v6

    const/16 v3, 0x19

    aput v3, v2, v5

    const/16 v3, 0x23

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x28

    aput v4, v2, v3

    const/16 v3, 0x2d

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x32

    aput v4, v2, v3

    const/4 v3, 0x7

    const/16 v4, 0x46

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x4b

    aput v4, v2, v3

    const/16 v3, 0x9

    const/16 v4, 0x50

    aput v4, v2, v3

    const/16 v3, 0xa

    const/16 v4, 0x55

    aput v4, v2, v3

    const/16 v3, 0xb

    const/16 v4, 0x5a

    aput v4, v2, v3

    aput-object v2, v0, v1

    const/16 v1, 0x2a

    new-array v2, v9, [I

    fill-array-data v2, :array_2398

    aput-object v2, v0, v1

    const/16 v1, 0x2b

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_23a6

    aput-object v2, v0, v1

    const/16 v1, 0x2c

    const/4 v2, 0x6

    new-array v2, v2, [I

    const/16 v3, 0x19

    aput v3, v2, v6

    const/16 v3, 0x1e

    aput v3, v2, v5

    const/16 v3, 0x23

    aput v3, v2, v8

    const/4 v3, 0x4

    const/16 v4, 0x28

    aput v4, v2, v3

    const/16 v3, 0x2d

    aput v3, v2, v9

    aput-object v2, v0, v1

    const/16 v1, 0x2d

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_23b6

    aput-object v2, v0, v1

    const/16 v1, 0x2e

    new-array v2, v5, [I

    aput v9, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x2f

    new-array v2, v5, [I

    fill-array-data v2, :array_23d0

    aput-object v2, v0, v1

    const/16 v1, 0x30

    new-array v2, v5, [I

    const/4 v3, 0x4

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x31

    new-array v2, v9, [I

    fill-array-data v2, :array_23d8

    aput-object v2, v0, v1

    const/16 v1, 0x32

    new-array v2, v5, [I

    const/4 v3, 0x4

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/16 v1, 0x33

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_23e6

    aput-object v2, v0, v1

    const/16 v1, 0x34

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_2400

    aput-object v2, v0, v1

    const/16 v1, 0x35

    new-array v2, v5, [I

    fill-array-data v2, :array_240c

    aput-object v2, v0, v1

    const/16 v1, 0x36

    new-array v2, v5, [I

    fill-array-data v2, :array_2414

    aput-object v2, v0, v1

    const/16 v1, 0x37

    const/16 v2, 0xc

    new-array v2, v2, [I

    aput v9, v2, v5

    const/16 v3, 0xa

    aput v3, v2, v9

    const/4 v3, 0x6

    const/16 v4, 0x1e

    aput v4, v2, v3

    const/16 v3, 0x8

    const/16 v4, 0x1e

    aput v4, v2, v3

    aput-object v2, v0, v1

    sput-object v0, Lq;->bF:[[I

    const/16 v0, 0xa

    new-array v0, v0, [[I

    new-array v1, v5, [I

    fill-array-data v1, :array_241c

    aput-object v1, v0, v7

    new-array v1, v5, [I

    fill-array-data v1, :array_2424

    aput-object v1, v0, v6

    new-array v1, v5, [I

    fill-array-data v1, :array_242c

    aput-object v1, v0, v5

    new-array v1, v5, [I

    fill-array-data v1, :array_2434

    aput-object v1, v0, v8

    const/4 v1, 0x4

    new-array v2, v5, [I

    fill-array-data v2, :array_243c

    aput-object v2, v0, v1

    new-array v1, v5, [I

    fill-array-data v1, :array_2444

    aput-object v1, v0, v9

    const/4 v1, 0x6

    new-array v2, v5, [I

    fill-array-data v2, :array_244c

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v5, [I

    fill-array-data v2, :array_2454

    aput-object v2, v0, v1

    const/16 v1, 0x8

    new-array v2, v5, [I

    fill-array-data v2, :array_245c

    aput-object v2, v0, v1

    const/16 v1, 0x9

    new-array v2, v5, [I

    fill-array-data v2, :array_2464

    aput-object v2, v0, v1

    sput-object v0, Lq;->bG:[[I

    new-array v0, v6, [[I

    new-array v1, v8, [I

    fill-array-data v1, :array_246c

    aput-object v1, v0, v7

    sput-object v0, Lq;->bH:[[I

    const/16 v0, 0xd4

    new-array v0, v0, [I

    aput v6, v0, v7

    aput v6, v0, v6

    aput v6, v0, v5

    aput v6, v0, v8

    const/4 v1, 0x4

    aput v6, v0, v1

    aput v6, v0, v9

    const/4 v1, 0x6

    aput v6, v0, v1

    const/4 v1, 0x7

    aput v6, v0, v1

    const/16 v1, 0x8

    aput v6, v0, v1

    const/16 v1, 0x9

    aput v5, v0, v1

    const/16 v1, 0xa

    aput v6, v0, v1

    const/16 v1, 0xb

    aput v5, v0, v1

    const/16 v1, 0xc

    aput v6, v0, v1

    const/16 v1, 0xd

    aput v5, v0, v1

    const/16 v1, 0xf

    aput v5, v0, v1

    const/16 v1, 0x11

    aput v6, v0, v1

    const/16 v1, 0x13

    aput v6, v0, v1

    const/16 v1, 0x15

    aput v6, v0, v1

    const/16 v1, 0x19

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0x1b

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0x1c

    aput v9, v0, v1

    const/16 v1, 0x1d

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0x1f

    aput v9, v0, v1

    const/16 v1, 0x20

    aput v5, v0, v1

    const/16 v1, 0x21

    aput v6, v0, v1

    const/16 v1, 0x22

    aput v6, v0, v1

    const/16 v1, 0x23

    aput v6, v0, v1

    const/16 v1, 0x24

    aput v5, v0, v1

    const/16 v1, 0x25

    aput v6, v0, v1

    const/16 v1, 0x26

    aput v6, v0, v1

    const/16 v1, 0x27

    aput v6, v0, v1

    const/16 v1, 0x28

    aput v6, v0, v1

    const/16 v1, 0x2a

    aput v8, v0, v1

    const/16 v1, 0x2c

    aput v8, v0, v1

    const/16 v1, 0x2e

    aput v8, v0, v1

    const/16 v1, 0x30

    aput v8, v0, v1

    const/16 v1, 0x31

    aput v5, v0, v1

    const/16 v1, 0x32

    aput v6, v0, v1

    const/16 v1, 0x34

    aput v6, v0, v1

    const/16 v1, 0x36

    const/4 v2, 0x6

    aput v2, v0, v1

    const/16 v1, 0x38

    const/4 v2, 0x6

    aput v2, v0, v1

    const/16 v1, 0x3a

    const/4 v2, 0x6

    aput v2, v0, v1

    const/16 v1, 0x3c

    const/4 v2, 0x6

    aput v2, v0, v1

    const/16 v1, 0x3d

    aput v8, v0, v1

    const/16 v1, 0x3f

    aput v8, v0, v1

    const/16 v1, 0x41

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x43

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x44

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x45

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x46

    aput v6, v0, v1

    const/16 v1, 0x49

    aput v6, v0, v1

    const/16 v1, 0x4a

    aput v5, v0, v1

    const/16 v1, 0x4b

    aput v6, v0, v1

    const/16 v1, 0x4c

    aput v5, v0, v1

    const/16 v1, 0x4d

    aput v6, v0, v1

    const/16 v1, 0x4e

    aput v5, v0, v1

    const/16 v1, 0x4f

    aput v6, v0, v1

    const/16 v1, 0x51

    aput v6, v0, v1

    const/16 v1, 0x53

    aput v6, v0, v1

    const/16 v1, 0x55

    aput v6, v0, v1

    const/16 v1, 0x57

    aput v8, v0, v1

    const/16 v1, 0x59

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x5c

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x5e

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x61

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x63

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x66

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x67

    aput v8, v0, v1

    const/16 v1, 0x68

    aput v6, v0, v1

    const/16 v1, 0x69

    aput v6, v0, v1

    const/16 v1, 0x6b

    aput v6, v0, v1

    const/16 v1, 0x6c

    aput v6, v0, v1

    const/16 v1, 0x6d

    aput v6, v0, v1

    const/16 v1, 0x6e

    aput v6, v0, v1

    const/16 v1, 0x6f

    aput v6, v0, v1

    const/16 v1, 0x70

    aput v6, v0, v1

    const/16 v1, 0x72

    aput v6, v0, v1

    const/16 v1, 0x74

    aput v8, v0, v1

    const/16 v1, 0x75

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x78

    aput v8, v0, v1

    const/16 v1, 0x7a

    aput v8, v0, v1

    const/16 v1, 0x7b

    aput v8, v0, v1

    const/16 v1, 0x7d

    aput v8, v0, v1

    const/16 v1, 0x7e

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x80

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x82

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x83

    aput v6, v0, v1

    const/16 v1, 0x84

    aput v8, v0, v1

    const/16 v1, 0x85

    aput v6, v0, v1

    const/16 v1, 0x86

    aput v6, v0, v1

    const/16 v1, 0x88

    aput v6, v0, v1

    const/16 v1, 0x89

    aput v6, v0, v1

    const/16 v1, 0x8a

    aput v6, v0, v1

    const/16 v1, 0x8b

    aput v6, v0, v1

    const/16 v1, 0x8c

    aput v8, v0, v1

    const/16 v1, 0x8e

    aput v6, v0, v1

    const/16 v1, 0x90

    aput v8, v0, v1

    const/16 v1, 0x91

    aput v6, v0, v1

    const/16 v1, 0x93

    aput v6, v0, v1

    const/16 v1, 0x94

    aput v8, v0, v1

    const/16 v1, 0x97

    aput v6, v0, v1

    const/16 v1, 0x99

    aput v6, v0, v1

    const/16 v1, 0x9a

    aput v6, v0, v1

    const/16 v1, 0x9c

    aput v6, v0, v1

    const/16 v1, 0x9d

    aput v6, v0, v1

    const/16 v1, 0x9e

    aput v6, v0, v1

    const/16 v1, 0x9f

    aput v8, v0, v1

    const/16 v1, 0xa0

    aput v6, v0, v1

    const/16 v1, 0xa2

    aput v6, v0, v1

    const/16 v1, 0xa3

    aput v8, v0, v1

    const/16 v1, 0xa4

    aput v6, v0, v1

    const/16 v1, 0xa5

    aput v8, v0, v1

    const/16 v1, 0xa7

    aput v8, v0, v1

    const/16 v1, 0xa9

    aput v8, v0, v1

    const/16 v1, 0xac

    aput v8, v0, v1

    const/16 v1, 0xaf

    aput v9, v0, v1

    const/16 v1, 0xb1

    aput v9, v0, v1

    const/16 v1, 0xb4

    aput v6, v0, v1

    const/16 v1, 0xb5

    aput v6, v0, v1

    const/16 v1, 0xb7

    aput v6, v0, v1

    const/16 v1, 0xb9

    aput v6, v0, v1

    const/16 v1, 0xba

    aput v6, v0, v1

    const/16 v1, 0xbb

    aput v8, v0, v1

    const/16 v1, 0xbc

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0xbe

    aput v6, v0, v1

    const/16 v1, 0xbf

    aput v8, v0, v1

    const/16 v1, 0xc0

    aput v6, v0, v1

    const/16 v1, 0xc1

    aput v5, v0, v1

    const/16 v1, 0xc2

    aput v6, v0, v1

    const/16 v1, 0xc3

    aput v5, v0, v1

    const/16 v1, 0xc4

    aput v6, v0, v1

    const/16 v1, 0xc6

    aput v6, v0, v1

    const/16 v1, 0xc7

    aput v6, v0, v1

    const/16 v1, 0xc8

    aput v6, v0, v1

    const/16 v1, 0xc9

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0xcb

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0xcd

    aput v8, v0, v1

    const/16 v1, 0xce

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0xd0

    aput v8, v0, v1

    sput-object v0, Lq;->bI:[I

    const/16 v0, 0xd4

    new-array v0, v0, [I

    aput v6, v0, v7

    aput v6, v0, v5

    const/4 v1, 0x4

    aput v6, v0, v1

    aput v6, v0, v9

    const/4 v1, 0x7

    aput v6, v0, v1

    const/16 v1, 0x9

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0xb

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0xc

    aput v6, v0, v1

    const/16 v1, 0xd

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0x15

    aput v6, v0, v1

    const/16 v1, 0x1b

    aput v6, v0, v1

    const/16 v1, 0x20

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0x22

    aput v6, v0, v1

    const/16 v1, 0x24

    aput v6, v0, v1

    const/16 v1, 0x25

    aput v6, v0, v1

    const/16 v1, 0x27

    aput v6, v0, v1

    const/16 v1, 0x28

    aput v5, v0, v1

    const/16 v1, 0x4c

    aput v6, v0, v1

    const/16 v1, 0x4e

    aput v5, v0, v1

    const/16 v1, 0x57

    aput v5, v0, v1

    const/16 v1, 0x58

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x59

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x5a

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x5b

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x5c

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x5d

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x5e

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x5f

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x60

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x61

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x62

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x63

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x64

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x65

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x66

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x67

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x69

    aput v6, v0, v1

    const/16 v1, 0x6a

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x6b

    aput v6, v0, v1

    const/16 v1, 0x6c

    aput v6, v0, v1

    const/16 v1, 0x6d

    aput v6, v0, v1

    const/16 v1, 0x6e

    aput v6, v0, v1

    const/16 v1, 0x6f

    aput v6, v0, v1

    const/16 v1, 0x70

    aput v6, v0, v1

    const/16 v1, 0x71

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x72

    aput v6, v0, v1

    const/16 v1, 0x73

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x74

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x75

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x76

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x77

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x78

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x79

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x7a

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x7b

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x7c

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x7d

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x7e

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x7f

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x80

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x81

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x82

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x84

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x87

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x8c

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x8d

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x8f

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x90

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x92

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x94

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x95

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x96

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x98

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0x9b

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xa5

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xa6

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xa7

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xa8

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xa9

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xaa

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xab

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xac

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xad

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xae

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xaf

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb0

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb1

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb2

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb3

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb4

    aput v5, v0, v1

    const/16 v1, 0xb5

    aput v8, v0, v1

    const/16 v1, 0xb6

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb7

    aput v8, v0, v1

    const/16 v1, 0xb8

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xb9

    aput v6, v0, v1

    const/16 v1, 0xba

    aput v6, v0, v1

    const/16 v1, 0xbb

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xbc

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xbd

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xbe

    aput v6, v0, v1

    const/16 v1, 0xbf

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xc3

    aput v6, v0, v1

    const/16 v1, 0xc5

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xc9

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xca

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xcb

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xcc

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xcd

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xce

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xcf

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xd0

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xd1

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xd2

    const/4 v2, -0x1

    aput v2, v0, v1

    const/16 v1, 0xd3

    const/4 v2, -0x1

    aput v2, v0, v1

    sput-object v0, Lq;->bJ:[I

    const/16 v0, 0xd4

    new-array v0, v0, [I

    aput v6, v0, v6

    aput v5, v0, v5

    aput v8, v0, v8

    const/4 v1, 0x4

    const/4 v2, 0x4

    aput v2, v0, v1

    aput v9, v0, v9

    const/4 v1, 0x6

    const/4 v2, 0x6

    aput v2, v0, v1

    const/4 v1, 0x7

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x8

    const/16 v2, 0x8

    aput v2, v0, v1

    const/16 v1, 0x9

    const/16 v2, 0x9

    aput v2, v0, v1

    const/16 v1, 0xa

    const/16 v2, 0xa

    aput v2, v0, v1

    const/16 v1, 0xb

    const/16 v2, 0xb

    aput v2, v0, v1

    const/16 v1, 0xc

    const/16 v2, 0xc

    aput v2, v0, v1

    const/16 v1, 0xd

    const/16 v2, 0xd

    aput v2, v0, v1

    const/16 v1, 0xe

    const/16 v2, 0xe

    aput v2, v0, v1

    const/16 v1, 0xf

    const/16 v2, 0xf

    aput v2, v0, v1

    const/16 v1, 0x10

    const/16 v2, 0x10

    aput v2, v0, v1

    const/16 v1, 0x11

    const/16 v2, 0x11

    aput v2, v0, v1

    const/16 v1, 0x12

    const/16 v2, 0x12

    aput v2, v0, v1

    const/16 v1, 0x13

    const/16 v2, 0x13

    aput v2, v0, v1

    const/16 v1, 0x14

    const/16 v2, 0x14

    aput v2, v0, v1

    const/16 v1, 0x15

    const/16 v2, 0x15

    aput v2, v0, v1

    const/16 v1, 0x16

    const/16 v2, 0x16

    aput v2, v0, v1

    const/16 v1, 0x17

    const/16 v2, 0x17

    aput v2, v0, v1

    const/16 v1, 0x18

    const/16 v2, 0x18

    aput v2, v0, v1

    const/16 v1, 0x19

    const/16 v2, 0x19

    aput v2, v0, v1

    const/16 v1, 0x1a

    const/16 v2, 0x1a

    aput v2, v0, v1

    const/16 v1, 0x1b

    const/16 v2, 0x1b

    aput v2, v0, v1

    const/16 v1, 0x1c

    const/16 v2, 0x1c

    aput v2, v0, v1

    const/16 v1, 0x1d

    const/16 v2, 0x1d

    aput v2, v0, v1

    const/16 v1, 0x1e

    const/16 v2, 0x1e

    aput v2, v0, v1

    const/16 v1, 0x1f

    const/16 v2, 0x1f

    aput v2, v0, v1

    const/16 v1, 0x20

    const/16 v2, 0x20

    aput v2, v0, v1

    const/16 v1, 0x21

    const/16 v2, 0x21

    aput v2, v0, v1

    const/16 v1, 0x22

    const/16 v2, 0x22

    aput v2, v0, v1

    const/16 v1, 0x23

    const/16 v2, 0x23

    aput v2, v0, v1

    const/16 v1, 0x24

    const/16 v2, 0x24

    aput v2, v0, v1

    const/16 v1, 0x25

    const/16 v2, 0x25

    aput v2, v0, v1

    const/16 v1, 0x26

    const/16 v2, 0x26

    aput v2, v0, v1

    const/16 v1, 0x27

    const/16 v2, 0x27

    aput v2, v0, v1

    const/16 v1, 0x28

    const/16 v2, 0x28

    aput v2, v0, v1

    const/16 v1, 0x29

    const/16 v2, 0x29

    aput v2, v0, v1

    const/16 v1, 0x2a

    const/16 v2, 0x2a

    aput v2, v0, v1

    const/16 v1, 0x2b

    const/16 v2, 0x2b

    aput v2, v0, v1

    const/16 v1, 0x2c

    const/16 v2, 0x2c

    aput v2, v0, v1

    const/16 v1, 0x2d

    const/16 v2, 0x2d

    aput v2, v0, v1

    const/16 v1, 0x2e

    const/16 v2, 0x2e

    aput v2, v0, v1

    const/16 v1, 0x2f

    const/16 v2, 0x2f

    aput v2, v0, v1

    const/16 v1, 0x30

    const/16 v2, 0x30

    aput v2, v0, v1

    const/16 v1, 0x31

    const/16 v2, 0x31

    aput v2, v0, v1

    const/16 v1, 0x32

    const/16 v2, 0x32

    aput v2, v0, v1

    const/16 v1, 0x33

    const/16 v2, 0x33

    aput v2, v0, v1

    const/16 v1, 0x34

    const/16 v2, 0x34

    aput v2, v0, v1

    const/16 v1, 0x35

    const/16 v2, 0x35

    aput v2, v0, v1

    const/16 v1, 0x36

    const/16 v2, 0x36

    aput v2, v0, v1

    const/16 v1, 0x37

    const/16 v2, 0x37

    aput v2, v0, v1

    const/16 v1, 0x38

    const/16 v2, 0x38

    aput v2, v0, v1

    const/16 v1, 0x39

    const/16 v2, 0x39

    aput v2, v0, v1

    const/16 v1, 0x3a

    const/16 v2, 0x3a

    aput v2, v0, v1

    const/16 v1, 0x3b

    const/16 v2, 0x3b

    aput v2, v0, v1

    const/16 v1, 0x3c

    const/16 v2, 0x3c

    aput v2, v0, v1

    const/16 v1, 0x3d

    const/16 v2, 0x3d

    aput v2, v0, v1

    const/16 v1, 0x3e

    const/16 v2, 0x3e

    aput v2, v0, v1

    const/16 v1, 0x3f

    const/16 v2, 0x3f

    aput v2, v0, v1

    const/16 v1, 0x40

    const/16 v2, 0x40

    aput v2, v0, v1

    const/16 v1, 0x41

    const/16 v2, 0x41

    aput v2, v0, v1

    const/16 v1, 0x42

    const/16 v2, 0x42

    aput v2, v0, v1

    const/16 v1, 0x43

    const/16 v2, 0x43

    aput v2, v0, v1

    const/16 v1, 0x44

    const/16 v2, 0x44

    aput v2, v0, v1

    const/16 v1, 0x45

    const/16 v2, 0x45

    aput v2, v0, v1

    const/16 v1, 0x46

    const/16 v2, 0x46

    aput v2, v0, v1

    const/16 v1, 0x47

    const/16 v2, 0x47

    aput v2, v0, v1

    const/16 v1, 0x48

    const/16 v2, 0x48

    aput v2, v0, v1

    const/16 v1, 0x49

    const/16 v2, 0x49

    aput v2, v0, v1

    const/16 v1, 0x4a

    const/16 v2, 0x4a

    aput v2, v0, v1

    const/16 v1, 0x4b

    const/16 v2, 0x4b

    aput v2, v0, v1

    const/16 v1, 0x4c

    const/16 v2, 0x4c

    aput v2, v0, v1

    const/16 v1, 0x4d

    const/16 v2, 0x4d

    aput v2, v0, v1

    const/16 v1, 0x4e

    const/16 v2, 0x4e

    aput v2, v0, v1

    const/16 v1, 0x4f

    const/16 v2, 0x4f

    aput v2, v0, v1

    const/16 v1, 0x50

    const/16 v2, 0x50

    aput v2, v0, v1

    const/16 v1, 0x51

    const/16 v2, 0x51

    aput v2, v0, v1

    const/16 v1, 0x52

    const/16 v2, 0x52

    aput v2, v0, v1

    const/16 v1, 0x53

    const/16 v2, 0x53

    aput v2, v0, v1

    const/16 v1, 0x54

    const/16 v2, 0x54

    aput v2, v0, v1

    const/16 v1, 0x55

    const/16 v2, 0x55

    aput v2, v0, v1

    const/16 v1, 0x56

    const/16 v2, 0x56

    aput v2, v0, v1

    const/16 v1, 0x57

    const/16 v2, 0x57

    aput v2, v0, v1

    const/16 v1, 0x58

    const/16 v2, 0x58

    aput v2, v0, v1

    const/16 v1, 0x59

    const/16 v2, 0x59

    aput v2, v0, v1

    const/16 v1, 0x5a

    const/16 v2, 0x5a

    aput v2, v0, v1

    const/16 v1, 0x5b

    const/16 v2, 0x5b

    aput v2, v0, v1

    const/16 v1, 0x5c

    const/16 v2, 0x5c

    aput v2, v0, v1

    const/16 v1, 0x5d

    const/16 v2, 0x5d

    aput v2, v0, v1

    const/16 v1, 0x5e

    const/16 v2, 0x5e

    aput v2, v0, v1

    const/16 v1, 0x5f

    const/16 v2, 0x5f

    aput v2, v0, v1

    const/16 v1, 0x60

    const/16 v2, 0x60

    aput v2, v0, v1

    const/16 v1, 0x61

    const/16 v2, 0x61

    aput v2, v0, v1

    const/16 v1, 0x62

    const/16 v2, 0x62

    aput v2, v0, v1

    const/16 v1, 0x63

    const/16 v2, 0x63

    aput v2, v0, v1

    const/16 v1, 0x64

    const/16 v2, 0x64

    aput v2, v0, v1

    const/16 v1, 0x65

    const/16 v2, 0x65

    aput v2, v0, v1

    const/16 v1, 0x66

    const/16 v2, 0x66

    aput v2, v0, v1

    const/16 v1, 0x67

    const/16 v2, 0x67

    aput v2, v0, v1

    const/16 v1, 0x68

    const/16 v2, 0x68

    aput v2, v0, v1

    const/16 v1, 0x69

    const/16 v2, 0x69

    aput v2, v0, v1

    const/16 v1, 0x6a

    const/16 v2, 0x6a

    aput v2, v0, v1

    const/16 v1, 0x6b

    const/16 v2, 0x6b

    aput v2, v0, v1

    const/16 v1, 0x6c

    const/16 v2, 0x6c

    aput v2, v0, v1

    const/16 v1, 0x6d

    const/16 v2, 0x6d

    aput v2, v0, v1

    const/16 v1, 0x6e

    const/16 v2, 0x6e

    aput v2, v0, v1

    const/16 v1, 0x6f

    const/16 v2, 0x6f

    aput v2, v0, v1

    const/16 v1, 0x70

    const/16 v2, 0x70

    aput v2, v0, v1

    const/16 v1, 0x71

    const/16 v2, 0x71

    aput v2, v0, v1

    const/16 v1, 0x72

    const/16 v2, 0x72

    aput v2, v0, v1

    const/16 v1, 0x73

    const/16 v2, 0x73

    aput v2, v0, v1

    const/16 v1, 0x74

    const/16 v2, 0x74

    aput v2, v0, v1

    const/16 v1, 0x75

    const/16 v2, 0x75

    aput v2, v0, v1

    const/16 v1, 0x76

    const/16 v2, 0x76

    aput v2, v0, v1

    const/16 v1, 0x77

    const/16 v2, 0x77

    aput v2, v0, v1

    const/16 v1, 0x78

    const/16 v2, 0x78

    aput v2, v0, v1

    const/16 v1, 0x79

    const/16 v2, 0x79

    aput v2, v0, v1

    const/16 v1, 0x7a

    const/16 v2, 0x7a

    aput v2, v0, v1

    const/16 v1, 0x7b

    const/16 v2, 0x7b

    aput v2, v0, v1

    const/16 v1, 0x7c

    const/16 v2, 0x7c

    aput v2, v0, v1

    const/16 v1, 0x7d

    const/16 v2, 0x7d

    aput v2, v0, v1

    const/16 v1, 0x7e

    const/16 v2, 0x7e

    aput v2, v0, v1

    const/16 v1, 0x7f

    const/16 v2, 0x7f

    aput v2, v0, v1

    const/16 v1, 0x80

    const/16 v2, 0x80

    aput v2, v0, v1

    const/16 v1, 0x81

    const/16 v2, 0x81

    aput v2, v0, v1

    const/16 v1, 0x82

    const/16 v2, 0x82

    aput v2, v0, v1

    const/16 v1, 0x83

    const/16 v2, 0x83

    aput v2, v0, v1

    const/16 v1, 0x84

    const/16 v2, 0x84

    aput v2, v0, v1

    const/16 v1, 0x85

    const/16 v2, 0x85

    aput v2, v0, v1

    const/16 v1, 0x86

    const/16 v2, 0x86

    aput v2, v0, v1

    const/16 v1, 0x87

    const/16 v2, 0x87

    aput v2, v0, v1

    const/16 v1, 0x88

    const/16 v2, 0x88

    aput v2, v0, v1

    const/16 v1, 0x89

    const/16 v2, 0x89

    aput v2, v0, v1

    const/16 v1, 0x8a

    const/16 v2, 0x8a

    aput v2, v0, v1

    const/16 v1, 0x8b

    const/16 v2, 0x8b

    aput v2, v0, v1

    const/16 v1, 0x8c

    const/16 v2, 0x8c

    aput v2, v0, v1

    const/16 v1, 0x8d

    const/16 v2, 0x8d

    aput v2, v0, v1

    const/16 v1, 0x8e

    const/16 v2, 0x8e

    aput v2, v0, v1

    const/16 v1, 0x8f

    const/16 v2, 0x8f

    aput v2, v0, v1

    const/16 v1, 0x90

    const/16 v2, 0x90

    aput v2, v0, v1

    const/16 v1, 0x91

    const/16 v2, 0x91

    aput v2, v0, v1

    const/16 v1, 0x92

    const/16 v2, 0x92

    aput v2, v0, v1

    const/16 v1, 0x93

    const/16 v2, 0x93

    aput v2, v0, v1

    const/16 v1, 0x94

    const/16 v2, 0x94

    aput v2, v0, v1

    const/16 v1, 0x95

    const/16 v2, 0x95

    aput v2, v0, v1

    const/16 v1, 0x96

    const/16 v2, 0x96

    aput v2, v0, v1

    const/16 v1, 0x97

    const/16 v2, 0x97

    aput v2, v0, v1

    const/16 v1, 0x98

    const/16 v2, 0x98

    aput v2, v0, v1

    const/16 v1, 0x99

    const/16 v2, 0x99

    aput v2, v0, v1

    const/16 v1, 0x9a

    const/16 v2, 0x9a

    aput v2, v0, v1

    const/16 v1, 0x9b

    const/16 v2, 0x9b

    aput v2, v0, v1

    const/16 v1, 0x9c

    const/16 v2, 0x9c

    aput v2, v0, v1

    const/16 v1, 0x9d

    const/16 v2, 0x9d

    aput v2, v0, v1

    const/16 v1, 0x9e

    const/16 v2, 0x9e

    aput v2, v0, v1

    const/16 v1, 0x9f

    const/16 v2, 0x9f

    aput v2, v0, v1

    const/16 v1, 0xa0

    const/16 v2, 0xa0

    aput v2, v0, v1

    const/16 v1, 0xa1

    const/16 v2, 0xa1

    aput v2, v0, v1

    const/16 v1, 0xa2

    const/16 v2, 0xa2

    aput v2, v0, v1

    const/16 v1, 0xa3

    const/16 v2, 0xa3

    aput v2, v0, v1

    const/16 v1, 0xa4

    const/16 v2, 0xa4

    aput v2, v0, v1

    const/16 v1, 0xa5

    const/16 v2, 0xa5

    aput v2, v0, v1

    const/16 v1, 0xa6

    const/16 v2, 0xa6

    aput v2, v0, v1

    const/16 v1, 0xa7

    const/16 v2, 0xa7

    aput v2, v0, v1

    const/16 v1, 0xa8

    const/16 v2, 0xa8

    aput v2, v0, v1

    const/16 v1, 0xa9

    const/16 v2, 0xa9

    aput v2, v0, v1

    const/16 v1, 0xaa

    const/16 v2, 0xaa

    aput v2, v0, v1

    const/16 v1, 0xab

    const/16 v2, 0xab

    aput v2, v0, v1

    const/16 v1, 0xac

    const/16 v2, 0xac

    aput v2, v0, v1

    const/16 v1, 0xad

    const/16 v2, 0xad

    aput v2, v0, v1

    const/16 v1, 0xae

    const/16 v2, 0xae

    aput v2, v0, v1

    const/16 v1, 0xaf

    const/16 v2, 0xaf

    aput v2, v0, v1

    const/16 v1, 0xb0

    const/16 v2, 0xb0

    aput v2, v0, v1

    const/16 v1, 0xb1

    const/16 v2, 0xb1

    aput v2, v0, v1

    const/16 v1, 0xb2

    const/16 v2, 0xb2

    aput v2, v0, v1

    const/16 v1, 0xb3

    const/16 v2, 0xb3

    aput v2, v0, v1

    const/16 v1, 0xb4

    const/16 v2, 0xb4

    aput v2, v0, v1

    const/16 v1, 0xb5

    const/16 v2, 0xb5

    aput v2, v0, v1

    const/16 v1, 0xb6

    const/16 v2, 0xb6

    aput v2, v0, v1

    const/16 v1, 0xb7

    const/16 v2, 0xb7

    aput v2, v0, v1

    const/16 v1, 0xb8

    const/16 v2, 0xb8

    aput v2, v0, v1

    const/16 v1, 0xb9

    const/16 v2, 0xb9

    aput v2, v0, v1

    const/16 v1, 0xba

    const/16 v2, 0xba

    aput v2, v0, v1

    const/16 v1, 0xbb

    const/16 v2, 0xbb

    aput v2, v0, v1

    const/16 v1, 0xbc

    const/16 v2, 0xbc

    aput v2, v0, v1

    const/16 v1, 0xbd

    const/16 v2, 0xbd

    aput v2, v0, v1

    const/16 v1, 0xbe

    const/16 v2, 0xbe

    aput v2, v0, v1

    const/16 v1, 0xbf

    const/16 v2, 0xbf

    aput v2, v0, v1

    const/16 v1, 0xc0

    const/16 v2, 0xc0

    aput v2, v0, v1

    const/16 v1, 0xc1

    const/16 v2, 0xc1

    aput v2, v0, v1

    const/16 v1, 0xc2

    const/16 v2, 0xc2

    aput v2, v0, v1

    const/16 v1, 0xc3

    const/16 v2, 0xc3

    aput v2, v0, v1

    const/16 v1, 0xc4

    const/16 v2, 0xc4

    aput v2, v0, v1

    const/16 v1, 0xc5

    const/16 v2, 0xc5

    aput v2, v0, v1

    const/16 v1, 0xc6

    const/16 v2, 0xc6

    aput v2, v0, v1

    const/16 v1, 0xc7

    const/16 v2, 0xc7

    aput v2, v0, v1

    const/16 v1, 0xc8

    const/16 v2, 0xc8

    aput v2, v0, v1

    const/16 v1, 0xc9

    const/16 v2, 0xc9

    aput v2, v0, v1

    const/16 v1, 0xca

    const/16 v2, 0xca

    aput v2, v0, v1

    const/16 v1, 0xcb

    const/16 v2, 0xcb

    aput v2, v0, v1

    const/16 v1, 0xcc

    const/16 v2, 0xcc

    aput v2, v0, v1

    const/16 v1, 0xcd

    const/16 v2, 0xcd

    aput v2, v0, v1

    const/16 v1, 0xce

    const/16 v2, 0xce

    aput v2, v0, v1

    const/16 v1, 0xcf

    const/16 v2, 0xcf

    aput v2, v0, v1

    const/16 v1, 0xd0

    const/16 v2, 0xd0

    aput v2, v0, v1

    const/16 v1, 0xd1

    const/16 v2, 0xd1

    aput v2, v0, v1

    const/16 v1, 0xd2

    const/16 v2, 0xd2

    aput v2, v0, v1

    const/16 v1, 0xd3

    const/16 v2, 0xd3

    aput v2, v0, v1

    sput-object v0, Lq;->bK:[I

    new-array v0, v9, [Ljava/lang/String;

    const-string v1, "Chơi mới"

    aput-object v1, v0, v7

    const-string v1, "Chơi tiếp"

    aput-object v1, v0, v6

    const-string v1, "Chỉ dẫn"

    aput-object v1, v0, v5

    const-string v1, "Cập nhật game"

    aput-object v1, v0, v8

    const/4 v1, 0x4

    const-string v2, "Thoát"

    aput-object v2, v0, v1

    sput-object v0, Lq;->bL:[Ljava/lang/String;

    new-array v0, v6, [[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v2, "Chúng ta đi thôi!"

    aput-object v2, v1, v7

    aput-object v1, v0, v7

    sput-object v0, Lq;->bO:[[Ljava/lang/String;

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_2476

    sput-object v0, Lq;->bP:[I

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_2482

    sput-object v0, Lq;->bQ:[I

    const/4 v0, -0x1

    sput v0, Lq;->w:I

    sput-boolean v6, Lq;->y:Z

    const/16 v0, 0xe

    new-array v0, v0, [Z

    sput-object v0, Lq;->C:[Z

    const/16 v0, 0xe

    new-array v0, v0, [Z

    sput-object v0, Lq;->D:[Z

    sput v7, Lq;->bS:I

    const-string v0, ""

    sput-object v0, Lq;->cs:Ljava/lang/String;

    sput-boolean v7, Lq;->au:Z

    sput-boolean v7, Lq;->aA:Z

    new-array v0, v6, [Ljava/lang/String;

    const-string v1, ""

    aput-object v1, v0, v7

    sput-object v0, Lq;->en:[Ljava/lang/String;

    sput v7, Lq;->eq:I

    const/4 v0, -0x1

    sput v0, Lq;->aE:I

    sput v6, Lq;->ex:I

    const/16 v0, 0xa

    sput v0, Lq;->aM:I

    const/4 v0, -0x1

    sput v0, Lq;->aQ:I

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    sput-boolean v7, Lq;->bd:Z

    const/4 v0, 0x6

    new-array v0, v0, [I

    sput-object v0, Lq;->bf:[I

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    sput-object v0, Lq;->bg:[Ljava/lang/String;

    sput v5, Lq;->bh:I

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    sput-object v0, Lq;->eY:Ljava/util/Random;

    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_248e

    sput-object v0, Lq;->eZ:[I

    sput-boolean v7, Lq;->fa:Z

    const/4 v0, 0x7

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "x1xx"

    aput-object v1, v0, v7

    const-string v1, "x2xx"

    aput-object v1, v0, v6

    const-string v1, "x3xx"

    aput-object v1, v0, v5

    const-string v1, "x4xx"

    aput-object v1, v0, v8

    const/4 v1, 0x4

    const-string v2, "x5xx"

    aput-object v2, v0, v1

    const-string v1, "x6xx"

    aput-object v1, v0, v9

    const/4 v1, 0x6

    const-string v2, "x7xx"

    aput-object v2, v0, v1

    sput-object v0, Lq;->bj:[Ljava/lang/String;

    sput v7, Lq;->bk:I

    sput v7, Lq;->fb:I

    sput v7, Lq;->bl:I

    const/4 v0, 0x4

    new-array v0, v0, [I

    const/4 v1, 0x6

    aput v1, v0, v6

    const/16 v1, 0xf

    aput v1, v0, v5

    const/16 v1, 0x14

    aput v1, v0, v8

    sput-object v0, Lq;->ff:[I

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_24aa

    sput-object v0, Lq;->fi:[I

    new-array v0, v5, [[Ljava/lang/String;

    const/4 v1, 0x6

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "Bình HP nhỏ"

    aput-object v2, v1, v7

    const-string v2, "Bình HP vừa"

    aput-object v2, v1, v6

    const-string v2, "Bình HP to"

    aput-object v2, v1, v5

    const-string v2, "Bình MP nhỏ"

    aput-object v2, v1, v8

    const/4 v2, 0x4

    const-string v3, "Bình MP vừa"

    aput-object v3, v1, v2

    const-string v2, "Bình MP to"

    aput-object v2, v1, v9

    aput-object v1, v0, v7

    const/4 v1, 0x4

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "Thuốc"

    aput-object v2, v1, v7

    const-string v2, "Gươm sét"

    aput-object v2, v1, v6

    const-string v2, "Gươm lửa"

    aput-object v2, v1, v5

    const-string v2, "Gươm băng"

    aput-object v2, v1, v8

    aput-object v1, v0, v6

    sput-object v0, Lq;->bq:[[Ljava/lang/String;

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_24c4

    sput-object v0, Lq;->fj:[I

    new-array v0, v5, [[Ljava/lang/String;

    const/4 v1, 0x6

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "5000vnđ / 50 bình"

    aput-object v2, v1, v7

    const-string v2, "10000vnđ / 50 bình"

    aput-object v2, v1, v6

    const-string v2, "10000vnđ / 30 bình"

    aput-object v2, v1, v5

    const-string v2, "5000vnđ / 50 bình"

    aput-object v2, v1, v8

    const/4 v2, 0x4

    const-string v3, "10000vnđ / 30 bình"

    aput-object v3, v1, v2

    const-string v2, "10000vnđ / 50 bình"

    aput-object v2, v1, v9

    aput-object v1, v0, v7

    const/4 v1, 0x4

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "5000vnđ"

    aput-object v2, v1, v7

    const-string v2, "5000vnđ"

    aput-object v2, v1, v6

    const-string v2, "10000vnđ"

    aput-object v2, v1, v5

    const-string v2, "15000vnđ"

    aput-object v2, v1, v8

    aput-object v1, v0, v6

    sput-object v0, Lq;->fk:[[Ljava/lang/String;

    new-array v0, v5, [[I

    const/4 v1, 0x6

    new-array v1, v1, [I

    fill-array-data v1, :array_24d0

    aput-object v1, v0, v7

    const/4 v1, 0x4

    new-array v1, v1, [I

    fill-array-data v1, :array_24e0

    aput-object v1, v0, v6

    sput-object v0, Lq;->fl:[[I

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_24ec

    sput-object v0, Lq;->fr:[I

    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Bình HP nhỏ"

    aput-object v1, v0, v7

    const-string v1, "Bình HP vừa"

    aput-object v1, v0, v6

    const-string v1, "Bình HP to"

    aput-object v1, v0, v5

    const-string v1, "Bình MP nhỏ"

    aput-object v1, v0, v8

    const/4 v1, 0x4

    const-string v2, "Bình MP vừa"

    aput-object v2, v0, v1

    const-string v1, "Bình MP to"

    aput-object v1, v0, v9

    sput-object v0, Lq;->fs:[Ljava/lang/String;

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_2506

    sput-object v0, Lq;->br:[I

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_2516

    sput-object v0, Lq;->ft:[I

    const/4 v0, 0x6

    new-array v0, v0, [I

    sput-object v0, Lq;->bs:[I

    sput v7, Lq;->fv:I

    new-array v0, v9, [Ljava/lang/String;

    const-string v1, "Sử dụng item"

    aput-object v1, v0, v7

    const-string v1, "Chọn vũ khí"

    aput-object v1, v0, v6

    const-string v1, "Xem bản đồ"

    aput-object v1, v0, v5

    const-string v1, "Xem nhiệm vụ"

    aput-object v1, v0, v8

    const/4 v1, 0x4

    const-string v2, "Thoát"

    aput-object v2, v0, v1

    sput-object v0, Lq;->fA:[Ljava/lang/String;

    const/16 v0, 0x15

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Trường Hirosaki"

    aput-object v1, v0, v7

    const-string v1, "Khu luyện tập"

    aput-object v1, v0, v6

    const-string v1, "Thác nước"

    aput-object v1, v0, v5

    const-string v1, "Làng Suzuya"

    aput-object v1, v0, v8

    const/4 v1, 0x4

    const-string v2, "Làng Tone"

    aput-object v2, v0, v1

    const-string v1, "Vách đá Ichidai"

    aput-object v1, v0, v9

    const/4 v1, 0x6

    const-string v2, "đỉnh Ichidai"

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const-string v2, "đồi Kokoro"

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const-string v2, "Cánh đồng Fuki"

    aput-object v2, v0, v1

    const/16 v1, 0x9

    const-string v2, "Trường Haruna"

    aput-object v2, v0, v1

    const/16 v1, 0xa

    const-string v2, "Ký túc xá"

    aput-object v2, v0, v1

    const/16 v1, 0xb

    const-string v2, "Hang Aka"

    aput-object v2, v0, v1

    const/16 v1, 0xc

    const-string v2, "Suối NN Akagi"

    aput-object v2, v0, v1

    const/16 v1, 0xd

    const-string v2, "Bờ biển"

    aput-object v2, v0, v1

    const/16 v1, 0xe

    const-string v2, "Làng chài"

    aput-object v2, v0, v1

    const/16 v1, 0xf

    const-string v2, "Biển"

    aput-object v2, v0, v1

    const/16 v1, 0x10

    const-string v2, "đảo Sasayaku"

    aput-object v2, v0, v1

    const/16 v1, 0x11

    const-string v2, "Hang Uno"

    aput-object v2, v0, v1

    const/16 v1, 0x12

    const-string v2, "đồng hoang"

    aput-object v2, v0, v1

    const/16 v1, 0x13

    const-string v2, "đỉnh gió"

    aput-object v2, v0, v1

    const/16 v1, 0x14

    const-string v2, "Miếu Chakumi"

    aput-object v2, v0, v1

    sput-object v0, Lq;->fB:[Ljava/lang/String;

    const/16 v0, 0x16

    new-array v0, v0, [I

    fill-array-data v0, :array_2526

    sput-object v0, Lq;->fC:[I

    const/16 v0, 0x15

    new-array v0, v0, [Z

    sput-object v0, Lq;->bt:[Z

    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_2556

    sput-object v0, Lq;->fD:[I

    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_2584

    sput-object v0, Lq;->fE:[I

    const/16 v0, 0x15

    new-array v0, v0, [I

    const/16 v1, 0x12

    aput v1, v0, v7

    const/16 v1, 0x24

    aput v1, v0, v6

    const/16 v1, 0xe

    aput v1, v0, v5

    const/16 v1, 0x3a

    aput v1, v0, v8

    const/4 v1, 0x4

    const/16 v2, 0x65

    aput v2, v0, v1

    const/16 v1, 0xf

    aput v1, v0, v9

    const/4 v1, 0x6

    const/4 v2, 0x7

    aput v2, v0, v1

    const/4 v1, 0x7

    aput v5, v0, v1

    const/16 v1, 0x8

    const/16 v2, 0xc

    aput v2, v0, v1

    const/16 v1, 0x9

    const/16 v2, 0x23

    aput v2, v0, v1

    const/16 v1, 0xa

    const/16 v2, 0xe

    aput v2, v0, v1

    const/16 v1, 0xb

    aput v9, v0, v1

    const/16 v1, 0xc

    aput v6, v0, v1

    const/16 v1, 0xd

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0xe

    aput v5, v0, v1

    const/16 v1, 0x10

    const/4 v2, 0x7

    aput v2, v0, v1

    const/16 v1, 0x11

    aput v6, v0, v1

    const/16 v1, 0x12

    const/4 v2, 0x4

    aput v2, v0, v1

    const/16 v1, 0x13

    aput v6, v0, v1

    const/16 v1, 0x14

    aput v5, v0, v1

    sput-object v0, Lq;->fF:[I

    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_25b2

    sput-object v0, Lq;->fG:[I

    const-string v0, "Chuyển đến"

    sput-object v0, Lq;->fY:Ljava/lang/String;

    sput v9, Lq;->bu:I

    new-array v0, v8, [Ljava/lang/String;

    const-string v1, ""

    aput-object v1, v0, v7

    const-string v1, ""

    aput-object v1, v0, v6

    const-string v1, ""

    aput-object v1, v0, v5

    sput-object v0, Lq;->bw:[Ljava/lang/String;

    new-array v0, v8, [Ljava/lang/String;

    const-string v1, ""

    aput-object v1, v0, v7

    const-string v1, ""

    aput-object v1, v0, v6

    const-string v1, ""

    aput-object v1, v0, v5

    sput-object v0, Lq;->bx:[Ljava/lang/String;

    return-void

    nop

    :array_1b6e
    .array-data 4
        0x2
        0x3
    .end array-data

    :array_1b76
    .array-data 4
        0x2
        0x1
        0x3
    .end array-data

    :array_1b80
    .array-data 4
        0x2
        0x6
        0x3
    .end array-data

    :array_1b8a
    .array-data 4
        0x2
        0x1
        0x5
        0x3
    .end array-data

    :array_1b96
    .array-data 4
        0x2
        0x3
    .end array-data

    :array_1b9e
    .array-data 4
        0x2
        0x3
    .end array-data

    :array_1ba6
    .array-data 4
        0x2
        0x1
        0x3
    .end array-data

    :array_1bb0
    .array-data 4
        0x2
        0x7
        0x3
    .end array-data

    :array_1bba
    .array-data 4
        0x7
        0x3
    .end array-data

    :array_1bc2
    .array-data 4
        0x7
        0x3
    .end array-data

    :array_1bca
    .array-data 4
        0x6
        0x3
    .end array-data

    :array_1bd2
    .array-data 4
        0x2
        0x8
        0x3
    .end array-data

    :array_1bdc
    .array-data 4
        0x9
        0x3
    .end array-data

    :array_1be4
    .array-data 4
        0x9
        0x3
    .end array-data

    :array_1bec
    .array-data 4
        0x2
        0x3
    .end array-data

    :array_1bf4
    .array-data 4
        0x6
        0x3
    .end array-data

    :array_1bfc
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c04
    .array-data 4
        0x6
        0x3
    .end array-data

    :array_1c0c
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c14
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c1c
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c24
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c2c
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c34
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c3c
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c44
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c4c
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c54
    .array-data 4
        0xb
        0x3
    .end array-data

    :array_1c5c
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c64
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c6c
    .array-data 4
        0x2
        0x3
    .end array-data

    :array_1c74
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1c7c
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c84
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c8c
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c94
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1c9c
    .array-data 4
        0xa
        0x3
    .end array-data

    :array_1ca4
    .array-data 4
        0x1
        0x3
    .end array-data

    :array_1cac
    .array-data 4
        0x8
        0x9
        0xf
        0xe
        0xa
        0x4
        0x4
        0x4
        0x18
        0x4
        0x4
        0x1c
        0x19
        0x4
        0x4
        0x4
        0x16
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x10
        0x11
        0x3
    .end array-data

    :array_1ce4
    .array-data 4
        0x9
        0xf
        0x22
        0xa
        0x7
        0x1
        0x1
        0x2
        0x2
        0x4
        0xf
        0x3
    .end array-data

    :array_1d00
    .array-data 4
        0x15
        0x8
        0x10
        0x4
        0x4
        0x11
        0x3
    .end array-data

    :array_1d12
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x7
        0x3
    .end array-data

    :array_1d26
    .array-data 4
        0x4
        0x11
        0x3
    .end array-data

    :array_1d30
    .array-data 4
        0x8
        0x9
        0xf
        0x22
        0x1
        0x1
        0xa
        0x2
        0x2
        0x7
        0x4
        0x3
    .end array-data

    :array_1d4c
    .array-data 4
        0x8
        0xb
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x7
        0x1b
        0x3
    .end array-data

    :array_1d66
    .array-data 4
        0x8
        0x1e
        0xb
        0x4
        0x11
        0x3
    .end array-data

    :array_1d76
    .array-data 4
        0xa
        0x4
        0x4
        0x24
        0x4
        0x4
        0x4
        0x4
        0x4
        0x23
        0x24
        0x25
        0x4
        0x4
        0x11
        0x3
    .end array-data

    :array_1d9a
    .array-data 4
        0x4
        0x24
        0x20
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x14
        0x1
        0x26
        0x2
        0x4
        0x7
        0x11
        0x3
    .end array-data

    :array_1dc0
    .array-data 4
        0x4
        0x27
        0x5
        0x3
    .end array-data

    :array_1dcc
    .array-data 4
        0x6
        0x4
        0x4
        0x4
        0x28
        0x3
    .end array-data

    :array_1ddc
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1de4
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x29
        0x3
    .end array-data

    :array_1dfa
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1e02
    .array-data 4
        0x4
        0x4
        0x2a
        0x3
    .end array-data

    :array_1e0e
    .array-data 4
        0x4
        0x4
        0x4
        0x11
        0x3
    .end array-data

    :array_1e1c
    .array-data 4
        0x4
        0x2b
        0x3
    .end array-data

    :array_1e26
    .array-data 4
        0x2d
        0x2c
        0x4
        0x7
        0x11
        0x3
    .end array-data

    :array_1e36
    .array-data 4
        0x2d
        0x2c
        0x4
        0x7
        0x11
        0x3
    .end array-data

    :array_1e46
    .array-data 4
        0x4
        0x4
        0x1
        0x2
        0x3
    .end array-data

    :array_1e54
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1e5c
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x1d
        0x3
    .end array-data

    :array_1e7a
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1e90
    .array-data 4
        0x4
        0x4
        0x2e
        0x4
        0x4
        0x2f
        0x3
    .end array-data

    :array_1ea2
    .array-data 4
        0x8
        0x4
        0x4
        0x4
        0x4
        0x4
        0x7
        0x3
    .end array-data

    :array_1eb6
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1ebe
    .array-data 4
        0x30
        0x4
        0x4
        0x4
        0x4
        0x23
        0x24
        0xf
        0x3
    .end array-data

    :array_1ed4
    .array-data 4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1ee0
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1ee8
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f02
    .array-data 4
        0x4
        0x4
        0x31
        0x4
        0x4
        0x3
    .end array-data

    :array_1f12
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1f1a
    .array-data 4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f26
    .array-data 4
        0x8
        0xb
        0x7
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f42
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f56
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_1f5e
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f6c
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f7e
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1f96
    .array-data 4
        0x4
        0x32
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1fac
    .array-data 4
        0x4
        0x33
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x34
        0x4
        0x3
    .end array-data

    :array_1fca
    .array-data 4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1fd6
    .array-data 4
        0x4
        0x4
        0x23
        0x24
        0x11
        0x3
    .end array-data

    :array_1fe6
    .array-data 4
        0xf
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_1ff6
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x23
        0x35
        0x3
    .end array-data

    :array_2010
    .array-data 4
        0x36
        0x3
    .end array-data

    :array_2018
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_2020
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_2028
    .array-data 4
        0x4
        0x4
        0x4
        0x4
        0x3
    .end array-data

    :array_2036
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_203e
    .array-data 4
        0x4
        0x33
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x34
        0x37
        0x3
    .end array-data

    :array_2058
    .array-data 4
        0x4
        0x33
        0x4
        0x3
    .end array-data

    :array_2064
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_206c
    .array-data 4
        0x4
        0x3
    .end array-data

    :array_2074
    .array-data 4
        0x30
        0x4
        0x4
        0x4
        0x4
        0x23
        0x24
        0xf
        0x3
    .end array-data

    :array_208a
    .array-data 4
        0x4f
        0x50
        0x51
        0x52
        0x53
        0x54
        0x55
        0x56
    .end array-data

    :array_209e
    .array-data 4
        0x57
        0x58
        -0x1
        0x59
        0x5a
    .end array-data

    :array_20ac
    .array-data 4
        -0x1
        0x5b
        0x5c
        0x5d
        0x5e
        0x5f
        -0x1
        -0x1
    .end array-data

    :array_20c0
    .array-data 4
        0x480
        0x61
        0x62
        0x63
        0x64
        -0x1
        -0x1
        0x4
    .end array-data

    :array_20d4
    .array-data 4
        0x65
        0x66
        0x67
    .end array-data

    :array_20de
    .array-data 4
        0x69
        0x6a
        0x6b
        0x6c
        0x6d
        0x6e
        0x6f
        0x70
        0x71
        0x72
    .end array-data

    :array_20f6
    .array-data 4
        0x73
        0x74
        -0x1
        0x75
        0x76
        -0x1
    .end array-data

    :array_2106
    .array-data 4
        0x77
        -0x1
    .end array-data

    :array_210e
    .array-data 4
        0x78
        0x79
        0x7a
    .end array-data

    :array_2118
    .array-data 4
        -0x1
        -0x1
        -0x1
        0x7b
        0x7c
        0x7d
        0x7e
        0x7f
        0x80
        0x81
        0x82
        -0x1
    .end array-data

    :array_2134
    .array-data 4
        0x83
        0x84
        0x85
        0x86
        0x87
        0x88
        0x89
        -0x1
    .end array-data

    :array_2148
    .array-data 4
        0x8a
        -0x1
    .end array-data

    :array_2150
    .array-data 4
        0x8b
        0x8c
        0x8d
        0x8e
        -0x1
    .end array-data

    :array_215e
    .array-data 4
        0x8f
        0x90
        0x91
        0x92
        0x93
        0x94
        -0x1
    .end array-data

    :array_2170
    .array-data 4
        0x95
        0x96
        0x97
        0x98
        0x99
        0x9a
        0x9b
        0x9c
        0x9d
        -0x1
    .end array-data

    :array_2188
    .array-data 4
        0x9e
        -0x1
        0x9f
        0xa0
        0xa1
        0xa2
        0xa3
        0xa4
        -0x1
    .end array-data

    :array_219e
    .array-data 4
        0xa5
        -0x1
        0xa6
        0xa7
        0xa8
        0xa9
        0xaa
        0xab
        0xac
        0xad
        -0x1
        0xae
        -0x1
    .end array-data

    :array_21bc
    .array-data 4
        0xaf
        0xb0
        0xb1
    .end array-data

    :array_21c6
    .array-data 4
        0xb2
        0xb3
        -0x1
        -0x1
        0x9
        -0x1
    .end array-data

    :array_21d6
    .array-data 4
        0x5
        0xb4
        0xb5
        0xb6
        0xb7
        -0x1
    .end array-data

    :array_21e6
    .array-data 4
        0xb8
        0xb9
        0xba
        0xbb
        0xbc
        0xbd
        0xbe
        0xbf
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_2202
    .array-data 4
        -0x1
        -0x1
    .end array-data

    :array_220a
    .array-data 4
        0xc5
        -0x1
    .end array-data

    :array_2212
    .array-data 4
        0xc6
        -0x1
    .end array-data

    :array_221a
    .array-data 4
        0x8b
        0x8c
        0x8d
        0xc7
        -0x1
    .end array-data

    :array_2228
    .array-data 4
        0xc8
        -0x1
    .end array-data

    :array_2230
    .array-data 4
        0xc9
        -0x1
        0xca
        0xcb
        0xcc
        0xcd
        0xce
        0xcf
        -0x1
        -0x1
        -0x1
    .end array-data

    :array_224a
    .array-data 4
        0xd0
        -0x1
        0xd1
    .end array-data

    :array_2254
    .array-data 4
        0xd2
        -0x1
    .end array-data

    :array_225c
    .array-data 4
        0xd3
        -0x1
    .end array-data

    :array_2264
    .array-data 4
        0x288
        0x61
        0x62
        0x63
        0x64
        -0x1
        -0x1
        0x4
    .end array-data

    :array_2278
    .array-data 4
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0x8
        0x9
        0x27
        0x28
        0x29
        0x2a
        0x2b
        0x2c
        0x2d
        0x32
        0x33
        0x34
        0x35
        0x36
        0x37
        0x38
        0x39
        0x4b
        0x4d
        0x4e
    .end array-data

    :array_22b2
    .array-data 4
        0x1
        0x2
        0x3
        0x50
        0x50
        0x51
        0x5c
    .end array-data

    :array_22c4
    .array-data 4
        0x14
        0x15
        0x1e
        0x1f
        0x20
        0x21
        0x28
        0x32
    .end array-data

    :array_22d8
    .array-data 4
        0x1
        0xa
        0xb
    .end array-data

    :array_22e2
    .array-data 4
        0x1
        0x2
        0x3
        0x14
        0x15
        0x16
    .end array-data

    :array_22f2
    .array-data 4
        0xa
        0xb
    .end array-data

    :array_22fa
    .array-data 4
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
    .end array-data

    :array_2310
    .array-data 4
        0xa
        0xb
    .end array-data

    :array_2318
    .array-data 4
        0xa
        0xb
        0xc
        0xd
    .end array-data

    :array_2324
    .array-data 4
        0xa
        0xb
        0x14
        0x19
        0x1a
    .end array-data

    :array_2332
    .array-data 4
        0xa
        0xb
        0xc
    .end array-data

    :array_233c
    .array-data 4
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
        0x13
        0x14
        0x15
        0x16
    .end array-data

    :array_235a
    .array-data 4
        0x12
        0x1c
        0x1e
        0x20
        0x22
        0x24
        0x26
        0x2d
    .end array-data

    :array_236e
    .array-data 4
        0x12
        0x13
        0x14
        0x15
        0x16
        0x17
        0x18
        0x19
    .end array-data

    :array_2382
    .array-data 4
        0x14
        0x15
    .end array-data

    :array_238a
    .array-data 4
        0x5
        0xa
        0xf
        0x14
        0x19
    .end array-data

    :array_2398
    .array-data 4
        0x5
        0xa
        0xf
        0x14
        0x19
    .end array-data

    :array_23a6
    .array-data 4
        0xa
        0xf
        0x14
        0x23
        0x2d
        0x32
    .end array-data

    :array_23b6
    .array-data 4
        0x5
        0xa
        0xf
        0x14
        0x19
        0x1e
        0x23
        0x28
        0x2d
        0x32
        0x37
    .end array-data

    :array_23d0
    .array-data 4
        0x14
        0xb
    .end array-data

    :array_23d8
    .array-data 4
        0x5
        0xa
        0xf
        0x14
        0x19
    .end array-data

    :array_23e6
    .array-data 4
        0x5
        0xa
        0xf
        0x14
        0x19
        0x1e
        0x23
        0x23
        0x23
        0x23
        0x24
    .end array-data

    :array_2400
    .array-data 4
        0x5
        0xa
        0x23
        0x28
    .end array-data

    :array_240c
    .array-data 4
        0x1
        0x5
    .end array-data

    :array_2414
    .array-data 4
        0x1
        0x5
    .end array-data

    :array_241c
    .array-data 4
        0x150
        0xf0
    .end array-data

    :array_2424
    .array-data 4
        0x258
        0xf0
    .end array-data

    :array_242c
    .array-data 4
        0x330
        0x120
    .end array-data

    :array_2434
    .array-data 4
        0x228
        0x60
    .end array-data

    :array_243c
    .array-data 4
        0x78
        0x90
    .end array-data

    :array_2444
    .array-data 4
        0x168
        0x90
    .end array-data

    :array_244c
    .array-data 4
        0x270
        0x90
    .end array-data

    :array_2454
    .array-data 4
        0x198
        0x90
    .end array-data

    :array_245c
    .array-data 4
        0x78
        0xc0
    .end array-data

    :array_2464
    .array-data 4
        0x1b0
        0x150
    .end array-data

    :array_246c
    .array-data 4
        0x2
        0x1bc
        0x198
    .end array-data

    :array_2476
    .array-data 4
        -0x1
        0x2
        0x1
        -0x2
    .end array-data

    :array_2482
    .array-data 4
        -0x3
        0x2
        -0x1
        0x1
    .end array-data

    :array_248e
    .array-data 4
        0xb
        0xc
        0xc
        0xb
        0xb
        -0x1
        -0x1
        0xc
        -0x1
        0xb
        0xb
        -0x1
    .end array-data

    :array_24aa
    .array-data 4
        0xbb6610
        0xd37a1f
        0xeb953e
        0xfeba75
        0xffd1a2
        0xffffff
        0xffd1a2
        0xfeba75
        0xeb953e
        0xd37a1f
        0xbb6610
    .end array-data

    :array_24c4
    .array-data 4
        -0x1
        0x5
        0xa
        0xf
    .end array-data

    :array_24d0
    .array-data 4
        0xc8
        0x258
        0x5dc
        0xc8
        0x258
        0x4b0
    .end array-data

    :array_24e0
    .array-data 4
        0x2710
        0x3a98
        0xc350
        0x30d40
    .end array-data

    :array_24ec
    .array-data 4
        0xbb6610
        0xd37a1f
        0xeb953e
        0xfeba75
        0xffd1a2
        0xffffff
        0xffd1a2
        0xfeba75
        0xeb953e
        0xd37a1f
        0xbb6610
    .end array-data

    :array_2506
    .array-data 4
        0x5
        0x2
        0x1
        0x5
        0x2
        0x1
    .end array-data

    :array_2516
    .array-data 4
        0x64
        0x190
        0x3e8
        0x64
        0xc8
        0x12c
    .end array-data

    :array_2526
    .array-data 4
        0x5a
        0x64
        0x6e
        0x78
        0x82
        0x6e
        0x8c
        0xa0
        0xbe
        0xdc
        0x104
        0x122
        0x154
        0x168
        0x186
        0x19a
        0x1ae
        0x1cc
        0x1ea
        0x230
        0x29e
        0x2ee
    .end array-data

    :array_2556
    .array-data 4
        0xda
        0xb8
        0xd3
        0xb3
        0x96
        0x61
        0x4a
        0x67
        0x8b
        0x93
        0xb1
        0xd2
        0xde
        0xc2
        0xae
        0xa6
        0xae
        0x4a
        0x3a
        0x2e
        0x1a
    .end array-data

    :array_2584
    .array-data 4
        0xa9
        0xb0
        0xc4
        0xcc
        0xe1
        0xca
        0x96
        0x94
        0xaf
        0x8e
        0x8b
        0x77
        0x5a
        0x3a
        0x56
        0x3a
        0x22
        0x3a
        0x5a
        0x76
        0x26
    .end array-data

    :array_25b2
    .array-data 4
        0x11
        0x9
        0x5
        0x11
        0x8
        0x4b
        0xd
        0x9
        0xa
        0x11
        0xa
        0x26
        0xa
        0xb
        0x10
        0x9
        0xc
        0x1c
        0xc
        0x1b
        0x8
    .end array-data
.end method

.method public constructor <init>()V
    .registers 5

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljavax/microedition/lcdui/Canvas;-><init>()V

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Canvas;->setFullScreenMode(Z)V

    invoke-static {}, Ljava/lang/System;->gc()V

    sput-object p0, Lq;->x:Lq;

    invoke-direct {p0}, Lq;->Q()V

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Canvas;->getKeyCode(I)I

    move-result v0

    const/16 v3, -0x14

    if-ne v0, v3, :cond_58

    move v0, v1

    :goto_1b
    sput-boolean v0, Lq;->bR:Z

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Displayable;->getWidth()I

    move-result v0

    sput v0, Lq;->E:I

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Displayable;->getHeight()I

    move-result v0

    sput v0, Lq;->F:I

    sget v0, Lq;->E:I

    div-int/lit8 v0, v0, 0x2

    sput v0, Lq;->G:I

    sget v0, Lq;->F:I

    div-int/lit8 v0, v0, 0x2

    sput v0, Lq;->H:I

    sput-boolean v2, Lb;->j:Z

    invoke-static {}, Lb;->f()I

    move-result v0

    if-ne v0, v1, :cond_3e

    move v2, v1

    :cond_3e
    sput-boolean v2, Lb;->a:Z

    invoke-static {}, Lb;->c()V

    invoke-static {}, Lb;->a()V

    sget v0, Lq;->G:I

    sget-object v2, Lb;->i:Ljavax/microedition/lcdui/Font;

    sget-object v3, Lb;->f:[Ljava/lang/String;

    aget-object v1, v3, v1

    invoke-virtual {v2, v1}, Ljavax/microedition/lcdui/Font;->stringWidth(Ljava/lang/String;)I

    move-result v1

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    sput v0, Lb;->h:I

    return-void

    :cond_58
    move v0, v2

    goto :goto_1b
.end method

.method private static A()V
    .registers 1

    const/4 v0, 0x0

    invoke-static {}, Lc;->a()V

    invoke-static {}, Lq;->z()V

    sput-object v0, Ls;->b:Ljavax/microedition/lcdui/Image;

    sput-object v0, Ld;->b:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lj;->a()V

    sput-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dP:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lt;->a()V

    invoke-static {}, Lm;->a()V

    sput-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-static {}, La;->a()V

    invoke-static {}, Ln;->a()V

    invoke-static {}, Lg;->g()V

    sput-object v0, Lq;->dJ:[[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method private static B()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lq;->dO:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->ea:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lq;->A()V

    return-void
.end method

.method private static C()V
    .registers 5

    const/4 v4, 0x3

    sget-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    :goto_a
    if-lt v0, v4, :cond_31

    :cond_c
    :goto_c
    sget v0, Lq;->aP:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aR:[I

    sget v0, Lq;->aP:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aS:[I

    sget v0, Lq;->aP:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aT:[I

    sget v0, Lq;->aP:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aU:[I

    sget v0, Lq;->aP:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aV:[I

    sget v0, Lq;->aP:I

    new-array v0, v0, [I

    sput-object v0, Lq;->eK:[I

    return-void

    :cond_31
    :try_start_31
    sget-object v1, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/c/v"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_4e} :catch_51

    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :catch_51
    move-exception v0

    goto :goto_c
.end method

.method private static D()V
    .registers 2

    sget-object v0, Lq;->dP:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_12

    :try_start_4
    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_3d

    const-string v0, "/i/l.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->dP:Ljavax/microedition/lcdui/Image;
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_12} :catch_46

    :cond_12
    :goto_12
    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aY:[I

    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->aZ:[I

    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->ba:[I

    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->bb:[I

    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->bc:[I

    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->eL:[I

    sget v0, Lq;->aW:I

    new-array v0, v0, [I

    sput-object v0, Lq;->eM:[I

    return-void

    :cond_3d
    :try_start_3d
    const-string v0, "/i/b.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->dP:Ljavax/microedition/lcdui/Image;
    :try_end_45
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_45} :catch_46

    goto :goto_12

    :catch_46
    move-exception v0

    goto :goto_12
.end method

.method private static E()V
    .registers 5

    const/4 v0, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    sput v0, Lq;->K:I

    invoke-static {}, Lq;->R()V

    const/4 v0, 0x3

    sput v0, LMidlet;->d:I

    const/16 v0, 0x6d

    sput v0, Lq;->as:I

    sput v3, Lq;->bM:I

    const/4 v0, 0x2

    :try_start_12
    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dO:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/u/t20.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lq;->dO:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    const-string v2, "/u/t21.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    const-string v0, "/u/tt.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->ea:Ljavax/microedition/lcdui/Image;
    :try_end_32
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_32} :catch_78

    :goto_32
    sput v3, Lq;->ax:I

    sput v3, Lq;->az:I

    sput v3, Lq;->aw:I

    sput v3, Lq;->ay:I

    sput v4, Lq;->eg:I

    sput v4, Lq;->ef:I

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0x1e

    sput v0, Lq;->bX:I

    sget v0, Lq;->F:I

    sput v0, Lq;->bY:I

    const/16 v0, 0x1e

    sput v0, Lq;->bT:I

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0x32

    sput v0, Lq;->bU:I

    sget v0, Lq;->bT:I

    sget v1, Lq;->bU:I

    add-int/2addr v0, v1

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bW:I

    sput v0, Lq;->bV:I

    invoke-static {}, LMidlet;->a()Z

    move-result v0

    if-eqz v0, :cond_75

    sput v4, Lq;->bS:I

    :goto_65
    const-string v0, "microedition.platform"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    new-instance v0, Ljava/lang/Thread;

    sget-object v1, LMidlet;->b:LMidlet;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :cond_75
    sput v3, Lq;->bS:I

    goto :goto_65

    :catch_78
    move-exception v0

    goto :goto_32
.end method

.method private static F()V
    .registers 4

    const/4 v3, 0x0

    sget v0, Lq;->eV:I

    sget-object v1, Lq;->eR:[[Ljava/lang/String;

    sget v2, Lq;->eP:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-ge v0, v1, :cond_18

    sget-object v0, Lq;->eR:[[Ljava/lang/String;

    sget v1, Lq;->eP:I

    aget-object v0, v0, v1

    array-length v0, v0

    sput v0, Lq;->eV:I

    sput v3, Lq;->eU:I

    :goto_17
    return-void

    :cond_18
    sget v0, Lq;->eP:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eP:I

    sput v3, Lq;->eV:I

    sput v3, Lq;->eU:I

    goto :goto_17
.end method

.method private static G()V
    .registers 2

    invoke-static {}, Lg;->f()Z

    move-result v0

    if-eqz v0, :cond_2f

    const/4 v0, 0x5

    sput v0, Lq;->eD:I

    sget v0, Lq;->aH:I

    sget v1, Lg;->at:I

    if-ge v0, v1, :cond_30

    const/4 v0, 0x1

    :goto_10
    sput v0, Lq;->eE:I

    sget v0, Lg;->at:I

    sget v1, Lq;->eE:I

    shl-int/lit8 v1, v1, 0x5

    add-int/2addr v0, v1

    sput v0, Lq;->eI:I

    sget v0, Lq;->eE:I

    mul-int/lit8 v0, v0, 0x6

    sput v0, Lq;->eC:I

    sget v0, Lq;->aK:I

    sget v1, Lq;->aL:I

    shr-int/lit8 v1, v1, 0x1

    if-ge v0, v1, :cond_2f

    sget v0, Lq;->eE:I

    shl-int/lit8 v0, v0, 0x3

    sput v0, Lq;->eC:I

    :cond_2f
    return-void

    :cond_30
    const/4 v0, -0x1

    goto :goto_10
.end method

.method private static H()V
    .registers 6

    const/4 v1, 0x1

    const/4 v2, -0x1

    const/4 v0, 0x0

    :goto_3
    sget v3, Lq;->cv:I

    if-lt v0, v3, :cond_8

    :goto_7
    return-void

    :cond_8
    sget-object v3, Lq;->cy:[I

    aget v3, v3, v0

    if-ne v3, v1, :cond_43

    sget-object v3, Lq;->cw:[I

    aget v4, v3, v0

    sget-object v5, Lq;->cz:[I

    aget v5, v5, v0

    add-int/2addr v4, v5

    aput v4, v3, v0

    sget-object v3, Lq;->cw:[I

    aget v3, v3, v0

    sget v4, Lq;->ay:I

    if-lt v3, v4, :cond_3f

    sget-object v3, Lq;->cw:[I

    aget v3, v3, v0

    sget v4, Lq;->ay:I

    sget v5, Lq;->ab:I

    add-int/2addr v4, v5

    if-gt v3, v4, :cond_3f

    sget-object v3, Lq;->cx:[I

    aget v3, v3, v0

    sget v4, Lq;->az:I

    if-lt v3, v4, :cond_3f

    sget-object v3, Lq;->cx:[I

    aget v3, v3, v0

    sget v4, Lq;->az:I

    sget v5, Lq;->ac:I

    add-int/2addr v4, v5

    if-le v3, v4, :cond_46

    :cond_3f
    sget-object v3, Lq;->cy:[I

    aput v2, v3, v0

    :cond_43
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_46
    sget v3, Lg;->at:I

    sget-object v4, Lq;->cw:[I

    aget v4, v4, v0

    sub-int/2addr v3, v4

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    sget v4, Lg;->aB:I

    if-ge v3, v4, :cond_43

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    sget-object v4, Lq;->cx:[I

    aget v4, v4, v0

    sub-int/2addr v3, v4

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    sget v4, Lg;->aC:I

    if-ge v3, v4, :cond_43

    sget v3, Lg;->ax:I

    const/4 v4, 0x5

    if-ne v3, v4, :cond_8d

    sget v3, Lg;->ar:I

    if-nez v3, :cond_8d

    sget-object v3, Lq;->cB:[I

    aget v3, v3, v0

    const/4 v4, 0x3

    if-ge v3, v4, :cond_8d

    sget-object v1, Lq;->cz:[I

    sget-object v2, Lq;->cz:[I

    aget v2, v2, v0

    neg-int v2, v2

    aput v2, v1, v0

    sget-object v1, Lq;->cw:[I

    aget v2, v1, v0

    sget-object v3, Lq;->cz:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    goto/16 :goto_7

    :cond_8d
    sget-object v3, Lq;->cA:[I

    aget v3, v3, v0

    sget-object v4, Lq;->cw:[I

    aget v4, v4, v0

    sget v5, Lg;->at:I

    if-ge v4, v5, :cond_a2

    :goto_99
    invoke-static {v3, v1}, Lg;->a(II)V

    sget-object v1, Lq;->cy:[I

    aput v2, v1, v0

    goto/16 :goto_7

    :cond_a2
    move v1, v2

    goto :goto_99
.end method

.method private static I()V
    .registers 6

    const/4 v1, 0x0

    const/4 v2, -0x1

    move v0, v1

    :goto_3
    sget v3, Lq;->cC:I

    if-lt v0, v3, :cond_8

    :goto_7
    return-void

    :cond_8
    sget-object v3, Lq;->cF:[I

    aget v3, v3, v0

    if-eqz v3, :cond_73

    sget-object v3, Lq;->cD:[I

    aget v4, v3, v0

    sget-object v5, Lq;->cG:[I

    aget v5, v5, v0

    add-int/2addr v4, v5

    aput v4, v3, v0

    sget-object v3, Lq;->cE:[I

    aget v4, v3, v0

    sget-object v5, Lq;->cH:[I

    aget v5, v5, v0

    add-int/2addr v4, v5

    aput v4, v3, v0

    sget-object v3, Lq;->cH:[I

    aget v4, v3, v0

    add-int/lit8 v4, v4, 0x1

    aput v4, v3, v0

    sget-object v3, Lq;->cE:[I

    aget v3, v3, v0

    sget v4, Lq;->az:I

    sget v5, Lq;->ac:I

    add-int/2addr v4, v5

    if-le v3, v4, :cond_3b

    sget-object v3, Lq;->cF:[I

    aput v1, v3, v0

    :cond_3b
    sget v3, Lg;->at:I

    sget-object v4, Lq;->cD:[I

    aget v4, v4, v0

    sub-int/2addr v3, v4

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    sget v4, Lg;->aB:I

    if-ge v3, v4, :cond_73

    sget v3, Lg;->au:I

    sget v4, Lg;->aC:I

    sub-int/2addr v3, v4

    sget-object v4, Lq;->cE:[I

    aget v4, v4, v0

    sub-int/2addr v3, v4

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    sget v4, Lg;->aC:I

    if-ge v3, v4, :cond_73

    sget-object v1, Lq;->cI:[I

    aget v3, v1, v0

    sget-object v1, Lq;->cD:[I

    aget v1, v1, v0

    sget v4, Lg;->at:I

    if-ge v1, v4, :cond_71

    const/4 v1, 0x1

    :goto_69
    invoke-static {v3, v1}, Lg;->a(II)V

    sget-object v1, Lq;->cF:[I

    aput v2, v1, v0

    goto :goto_7

    :cond_71
    move v1, v2

    goto :goto_69

    :cond_73
    add-int/lit8 v0, v0, 0x1

    goto :goto_3
.end method

.method private static final J()V
    .registers 4

    const/4 v3, 0x0

    sget v0, Lq;->ay:I

    sget v1, Lq;->aw:I

    if-ne v0, v1, :cond_d

    sget v0, Lq;->az:I

    sget v1, Lq;->ax:I

    if-eq v0, v1, :cond_6b

    :cond_d
    sget v0, Lq;->aw:I

    sget v1, Lq;->ay:I

    sub-int/2addr v0, v1

    shl-int/lit8 v0, v0, 0x2

    sput v0, Lq;->ef:I

    sget v0, Lq;->ax:I

    sget v1, Lq;->az:I

    sub-int/2addr v0, v1

    shl-int/lit8 v0, v0, 0x2

    sput v0, Lq;->eg:I

    sget v0, Lq;->eh:I

    sget v1, Lq;->ef:I

    add-int/2addr v0, v1

    sput v0, Lq;->eh:I

    sget v0, Lq;->ay:I

    sget v1, Lq;->eh:I

    shr-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sput v0, Lq;->ay:I

    sget v0, Lq;->eh:I

    and-int/lit8 v0, v0, 0xf

    sput v0, Lq;->eh:I

    sget v0, Lq;->ei:I

    sget v1, Lq;->eg:I

    add-int/2addr v0, v1

    sput v0, Lq;->ei:I

    sget v0, Lq;->az:I

    sget v1, Lq;->ei:I

    shr-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sput v0, Lq;->az:I

    sget v0, Lq;->ei:I

    and-int/lit8 v0, v0, 0xf

    sput v0, Lq;->ei:I

    sget v0, Lq;->ay:I

    if-gez v0, :cond_51

    sput v3, Lq;->ay:I

    :cond_51
    sget v0, Lq;->ay:I

    sget v1, Lq;->ej:I

    if-le v0, v1, :cond_5b

    sget v0, Lq;->ej:I

    sput v0, Lq;->ay:I

    :cond_5b
    sget v0, Lq;->az:I

    if-gez v0, :cond_61

    sput v3, Lq;->az:I

    :cond_61
    sget v0, Lq;->az:I

    sget v1, Lq;->ek:I

    if-le v0, v1, :cond_6b

    sget v0, Lq;->ek:I

    sput v0, Lq;->az:I

    :cond_6b
    sget v0, Lq;->w:I

    if-ltz v0, :cond_b1

    sget v0, Lq;->ay:I

    sget-object v1, Lq;->bP:[I

    sget v2, Lq;->w:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lq;->ay:I

    sget v0, Lq;->az:I

    sget-object v1, Lq;->bQ:[I

    sget v2, Lq;->w:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lq;->az:I

    sget v0, Lq;->w:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->w:I

    const/4 v1, 0x4

    if-ne v0, v1, :cond_91

    const/4 v0, -0x1

    sput v0, Lq;->w:I

    :cond_91
    sget v0, Lq;->ay:I

    if-gez v0, :cond_97

    sput v3, Lq;->ay:I

    :cond_97
    sget v0, Lq;->ay:I

    sget v1, Lq;->ej:I

    if-le v0, v1, :cond_a1

    sget v0, Lq;->ej:I

    sput v0, Lq;->ay:I

    :cond_a1
    sget v0, Lq;->az:I

    if-gez v0, :cond_a7

    sput v3, Lq;->az:I

    :cond_a7
    sget v0, Lq;->az:I

    sget v1, Lq;->ek:I

    if-le v0, v1, :cond_b1

    sget v0, Lq;->ek:I

    sput v0, Lq;->az:I

    :cond_b1
    sget v0, Lq;->ay:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->W:I

    if-gez v0, :cond_be

    sput v3, Lq;->W:I

    :cond_be
    sget v0, Lq;->az:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    sput v0, Lq;->X:I

    sget v0, Lq;->W:I

    sget v1, Lq;->ct:I

    add-int/2addr v0, v1

    sput v0, Lq;->Y:I

    sget v0, Lq;->X:I

    sget v1, Lq;->cu:I

    add-int/2addr v0, v1

    sput v0, Lq;->Z:I

    sget v0, Lq;->X:I

    if-gez v0, :cond_d9

    sput v3, Lq;->X:I

    :cond_d9
    sget v0, Lq;->Z:I

    sget v1, Lj;->b:I

    add-int/lit8 v1, v1, -0x1

    if-le v0, v1, :cond_e7

    sget v0, Lj;->b:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->Z:I

    :cond_e7
    return-void
.end method

.method private static K()Z
    .registers 9

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v3, -0x1

    const/4 v1, 0x0

    const/4 v4, 0x1

    sget-boolean v0, Lq;->aA:Z

    if-nez v0, :cond_16

    sget v0, Lq;->cr:I

    if-le v0, v4, :cond_15

    sget v0, Lq;->cr:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lq;->cr:I

    sput-boolean v4, Lq;->J:Z

    :cond_15
    :goto_15
    return v1

    :cond_16
    sget-boolean v0, Lq;->er:Z

    if-eqz v0, :cond_54

    sget-object v0, Lq;->D:[Z

    const/4 v2, 0x5

    aget-boolean v0, v0, v2

    if-nez v0, :cond_29

    sget-object v0, Lq;->D:[Z

    const/16 v2, 0x9

    aget-boolean v0, v0, v2

    if-eqz v0, :cond_40

    :cond_29
    invoke-static {}, Lq;->c()V

    sget-boolean v0, Lq;->bd:Z

    if-eqz v0, :cond_4b

    invoke-static {}, Lq;->F()V

    sget v0, Lq;->eP:I

    sget v2, Lq;->eO:I

    if-ne v0, v2, :cond_40

    sput-boolean v1, Lq;->bd:Z

    sput-boolean v1, Lq;->er:Z

    invoke-static {}, Lq;->y()V

    :cond_40
    :goto_40
    sget-object v0, Lq;->C:[Z

    const/4 v2, 0x5

    aput-boolean v1, v0, v2

    sget-object v0, Lq;->D:[Z

    const/4 v2, 0x5

    aput-boolean v1, v0, v2

    goto :goto_15

    :cond_4b
    sget-boolean v0, Ls;->a:Z

    if-eqz v0, :cond_40

    sput v1, Ls;->c:I

    sput-boolean v1, Lq;->er:Z

    goto :goto_40

    :cond_54
    sget v0, Lq;->cr:I

    sget v2, Lq;->cq:I

    if-ge v0, v2, :cond_68

    sget v0, Lq;->cr:I

    sget v2, Lq;->cq:I

    sget v5, Lq;->cr:I

    sub-int/2addr v2, v5

    shr-int/lit8 v2, v2, 0x1

    add-int/lit8 v2, v2, 0x1

    add-int/2addr v0, v2

    sput v0, Lq;->cr:I

    :cond_68
    sget-boolean v0, Lq;->em:Z

    if-eqz v0, :cond_78

    sget v0, Lq;->eo:I

    sget v2, Lq;->ep:I

    if-ge v0, v2, :cond_b8

    sget v0, Lq;->eo:I

    add-int/lit8 v0, v0, 0x2

    sput v0, Lq;->eo:I

    :cond_78
    :goto_78
    sget v0, Lq;->eq:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eq:I

    sget-object v2, Lq;->bF:[[I

    sget v5, Lq;->el:I

    aget-object v2, v2, v5

    sget v5, Lq;->aB:I

    aget v2, v2, v5

    if-lt v0, v2, :cond_40

    sget-object v0, Lq;->bF:[[I

    sget v2, Lq;->el:I

    aget-object v0, v0, v2

    sget v2, Lq;->aB:I

    aget v0, v0, v2

    sput v0, Lq;->eq:I

    sget-object v0, Lq;->bC:[[I

    sget v2, Lq;->el:I

    aget-object v0, v0, v2

    sget v2, Lq;->aB:I

    aget v0, v0, v2

    packed-switch v0, :pswitch_data_b4c

    :pswitch_a3  #0xc, 0xd, 0x12, 0x17, 0x1a, 0x1f, 0x21
    goto :goto_40

    :pswitch_a4  #0x1
    sget-object v0, Lq;->bE:[[I

    sget v2, Lq;->el:I

    aget-object v0, v0, v2

    sget v2, Lq;->aB:I

    aget v0, v0, v2

    invoke-static {v0}, Lq;->k(I)V

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto :goto_40

    :cond_b8
    sget v0, Lq;->ep:I

    sput v0, Lq;->eo:I

    goto :goto_78

    :pswitch_bd  #0x35
    sget-object v0, Ll;->b:[Ljava/lang/String;

    sget v2, Lq;->G:I

    sget v3, Lq;->H:I

    add-int/lit8 v3, v3, 0x32

    invoke-static {v0, v4, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    sput-boolean v4, Lq;->er:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_d2  #0x3
    sget v0, Lq;->el:I

    const/16 v2, 0x2c

    if-ne v0, v2, :cond_e1

    const/16 v0, 0xc

    sput v0, Lg;->a:I

    const/16 v0, 0x1f

    invoke-static {v0}, Lq;->j(I)V

    :cond_e1
    sget v0, Lq;->el:I

    const/16 v2, 0x33

    if-ne v0, v2, :cond_ef

    sput-boolean v1, Lg;->bm:Z

    sput-boolean v1, Lg;->O:Z

    sput v3, Lg;->Q:I

    sput v3, Lg;->bn:I

    :cond_ef
    sget v0, Lq;->as:I

    const/16 v2, 0x8

    if-ne v0, v2, :cond_100

    sget-boolean v0, Lq;->i:Z

    if-nez v0, :cond_100

    sput-boolean v4, Lq;->i:Z

    const/16 v0, 0x24

    invoke-static {v0}, Lq;->j(I)V

    :cond_100
    sget v0, Lq;->as:I

    if-ne v0, v8, :cond_112

    sget-boolean v0, Lq;->h:Z

    if-nez v0, :cond_112

    sput-boolean v4, Lq;->h:Z

    const/4 v0, 0x3

    sput v0, Lg;->bc:I

    const-string v0, "Giết 20 ốc ma đen"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    :cond_112
    sget v0, Lq;->el:I

    const/16 v2, 0x1c

    if-ne v0, v2, :cond_11e

    sput-boolean v1, Lg;->p:Z

    sput v3, Lg;->a:I

    sput v3, Lg;->bc:I

    :cond_11e
    sget v0, Lq;->el:I

    const/16 v2, 0x1e

    if-ne v0, v2, :cond_12e

    const-string v0, "Có miếng phong ấn thứ nhất"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sput v8, Lg;->a:I

    const/4 v0, 0x0

    sput-object v0, Lc;->b:Ljavax/microedition/lcdui/Image;

    :cond_12e
    sget v0, Lq;->as:I

    const/16 v2, 0xc

    if-ne v0, v2, :cond_141

    sget-boolean v0, Lg;->q:Z

    if-eqz v0, :cond_141

    sput v8, Lg;->bc:I

    const-string v0, "Giết 20 rùa biển"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sput-boolean v1, Lg;->q:Z

    :cond_141
    sget v0, Lq;->el:I

    const/16 v2, 0x30

    if-ne v0, v2, :cond_150

    const-string v0, "Tập luyện để đạt cấp độ 13"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    const/16 v0, 0xa

    sput v0, Lg;->a:I

    :cond_150
    sget v0, Lq;->el:I

    const/16 v2, 0x2f

    if-ne v0, v2, :cond_15c

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    :cond_15c
    sget v0, Lq;->as:I

    const/16 v2, 0xe

    if-ne v0, v2, :cond_172

    sget-boolean v0, Lq;->o:Z

    if-nez v0, :cond_172

    sput-boolean v4, Lq;->o:Z

    sput v1, Lg;->D:I

    const/16 v0, 0x18

    invoke-static {v0}, Lq;->j(I)V

    const/4 v0, 0x5

    sput v0, Lg;->a:I

    :cond_172
    sget v0, Lq;->el:I

    const/16 v2, 0x25

    if-ne v0, v2, :cond_17f

    const-string v0, "Có miếng phong ấn thứ hai"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sput v8, Lg;->a:I

    :cond_17f
    sget v0, Lq;->as:I

    const/16 v2, 0xd

    if-ne v0, v2, :cond_18b

    sget-boolean v0, Lq;->n:Z

    if-nez v0, :cond_18b

    sput-boolean v4, Lq;->n:Z

    :cond_18b
    sget v0, Lq;->as:I

    const/16 v2, 0xf

    if-ne v0, v2, :cond_19e

    sget-boolean v0, Lg;->u:Z

    if-eqz v0, :cond_19e

    const-string v0, "Có miếng phong ấn thứ ba"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    const/16 v0, 0x9

    sput v0, Lg;->a:I

    :cond_19e
    sget v0, Lq;->el:I

    const/16 v2, 0x2d

    if-ne v0, v2, :cond_1be

    sput v3, Lg;->bA:I

    const/16 v0, 0x6f0

    sput v0, Lg;->bo:I

    const/16 v0, 0x168

    sput v0, Lg;->bp:I

    sput v4, Lg;->bs:I

    const/16 v0, 0x9

    sput v0, Lg;->bn:I

    const/16 v0, 0x9

    invoke-static {v0}, Lg;->d(I)V

    const/16 v0, 0x1f

    invoke-static {v0}, Lq;->j(I)V

    :cond_1be
    sget v0, Lq;->as:I

    const/16 v2, 0x14

    if-ne v0, v2, :cond_1d0

    sget-boolean v0, Lq;->r:Z

    if-nez v0, :cond_1d0

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_1d0

    sput-boolean v4, Lq;->r:Z

    sput-boolean v1, Lq;->aN:Z

    :cond_1d0
    sget v0, Lq;->el:I

    const/16 v2, 0x2d

    if-ne v0, v2, :cond_1e5

    sput-boolean v4, Lq;->t:Z

    sput-boolean v4, Lq;->a:Z

    sput-boolean v1, Lq;->er:Z

    sput-boolean v1, Lq;->aN:Z

    sput-boolean v1, Lq;->bD:Z

    sput v3, Lg;->a:I

    invoke-static {}, Lq;->a()V

    :cond_1e5
    sget v0, Lq;->as:I

    const/16 v2, 0x9

    if-ne v0, v2, :cond_1f5

    sget-boolean v0, Lq;->s:Z

    if-nez v0, :cond_1f5

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_1f5

    sput-boolean v4, Lq;->s:Z

    :cond_1f5
    sget v0, Lq;->as:I

    const/16 v2, 0xf

    if-ne v0, v2, :cond_201

    sget-boolean v0, Lq;->p:Z

    if-nez v0, :cond_201

    sput-boolean v4, Lq;->p:Z

    :cond_201
    sget v0, Lq;->as:I

    const/16 v2, 0x10

    if-ne v0, v2, :cond_20d

    sget-boolean v0, Lq;->q:Z

    if-nez v0, :cond_20d

    sput-boolean v4, Lq;->q:Z

    :cond_20d
    sget v0, Lq;->as:I

    if-ne v0, v8, :cond_21d

    sget-boolean v0, Lg;->n:Z

    if-eqz v0, :cond_21d

    sget-boolean v0, Lg;->o:Z

    if-nez v0, :cond_21d

    sput-boolean v4, Lg;->o:Z

    sput v7, Lg;->a:I

    :cond_21d
    sget v0, Lq;->el:I

    const/16 v2, 0x31

    if-ne v0, v2, :cond_231

    const-string v0, "Có miếng phong ấn thứ hai"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    const/16 v0, 0xb

    sput v0, Lg;->a:I

    const/16 v0, 0x22

    invoke-static {v0}, Lq;->j(I)V

    :cond_231
    sput-boolean v1, Lq;->aA:Z

    sput-boolean v4, Lq;->J:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_23d  #0x5
    sget v0, Lq;->as:I

    sget-object v2, Lq;->bE:[[I

    sget v4, Lq;->el:I

    aget-object v2, v2, v4

    sget v4, Lq;->aB:I

    aget v2, v2, v4

    sget v4, Lg;->au:I

    add-int/lit8 v4, v4, -0x32

    invoke-static {v0, v2, v4, v3}, Lq;->b(IIII)V

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_258  #0x9
    sget-object v0, Lq;->bG:[[I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aget-object v0, v0, v2

    aget v0, v0, v1

    sget v2, Lq;->ad:I

    sub-int/2addr v0, v2

    sput v0, Lq;->ay:I

    sget-object v0, Lq;->bG:[[I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aget-object v0, v0, v2

    aget v0, v0, v4

    sget v2, Lq;->ae:I

    sub-int/2addr v0, v2

    sput v0, Lq;->az:I

    sget v0, Lq;->ay:I

    if-gez v0, :cond_288

    sput v1, Lq;->ay:I

    :cond_288
    sget v0, Lq;->ay:I

    sget v2, Lq;->ej:I

    if-le v0, v2, :cond_292

    sget v0, Lq;->ej:I

    sput v0, Lq;->ay:I

    :cond_292
    sget v0, Lq;->az:I

    if-gez v0, :cond_298

    sput v1, Lq;->az:I

    :cond_298
    sget v0, Lq;->az:I

    sget v2, Lq;->ek:I

    if-le v0, v2, :cond_2a2

    sget v0, Lq;->ek:I

    sput v0, Lq;->az:I

    :cond_2a2
    sget v0, Lq;->ay:I

    sput v0, Lq;->aw:I

    sget v0, Lq;->az:I

    sput v0, Lq;->ax:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_2b2  #0xa
    sget-object v0, Lq;->bG:[[I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aget-object v0, v0, v2

    aget v0, v0, v1

    sget v2, Lq;->ad:I

    sub-int/2addr v0, v2

    sput v0, Lq;->aw:I

    sget-object v0, Lq;->bG:[[I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aget-object v0, v0, v2

    aget v0, v0, v4

    sget v2, Lq;->ae:I

    sub-int/2addr v0, v2

    sput v0, Lq;->ax:I

    sget v0, Lq;->aw:I

    if-gez v0, :cond_2e2

    sput v1, Lq;->aw:I

    :cond_2e2
    sget v0, Lq;->aw:I

    sget v2, Lq;->ej:I

    if-le v0, v2, :cond_2ec

    sget v0, Lq;->ej:I

    sput v0, Lq;->aw:I

    :cond_2ec
    sget v0, Lq;->ax:I

    if-gez v0, :cond_2f2

    sput v1, Lq;->ax:I

    :cond_2f2
    sget v0, Lq;->ax:I

    sget v2, Lq;->ek:I

    if-le v0, v2, :cond_2fc

    sget v0, Lq;->ek:I

    sput v0, Lq;->ax:I

    :cond_2fc
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_304  #0x8
    sput-boolean v1, Lg;->aY:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_30e  #0xf
    sput-boolean v4, Lq;->em:Z

    sget-object v0, Ll;->a:[Ljava/lang/String;

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aget-object v0, v0, v2

    sget v2, Lq;->ab:I

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v2}, LMidlet;->a(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lq;->en:[Ljava/lang/String;

    sget v0, Lq;->cq:I

    shr-int/lit8 v0, v0, 0x1

    sget-object v2, Lq;->en:[Ljava/lang/String;

    array-length v2, v2

    shl-int/lit8 v2, v2, 0x3

    sub-int/2addr v0, v2

    sput v0, Lq;->ep:I

    const/4 v2, 0x3

    if-ge v0, v2, :cond_339

    sput v7, Lq;->ep:I

    :cond_339
    sget-object v0, Lq;->en:[Ljava/lang/String;

    array-length v0, v0

    neg-int v0, v0

    shl-int/lit8 v0, v0, 0x3

    sput v0, Lq;->eo:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_349  #0xe
    sget v0, Lq;->ay:I

    add-int/lit8 v0, v0, 0x2

    sput v0, Lq;->ay:I

    sput v0, Lq;->aw:I

    sget v0, Lq;->ay:I

    sget-object v2, Lq;->bG:[[I

    sget-object v3, Lq;->bE:[[I

    sget v4, Lq;->el:I

    aget-object v3, v3, v4

    sget v4, Lq;->aB:I

    aget v3, v3, v4

    aget-object v2, v2, v3

    aget v2, v2, v1

    sget v3, Lq;->ad:I

    sub-int/2addr v2, v3

    if-le v0, v2, :cond_40

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_370  #0x22
    sget v0, Lq;->ay:I

    add-int/lit8 v0, v0, -0x2

    sput v0, Lq;->ay:I

    sput v0, Lq;->aw:I

    sget v0, Lq;->ay:I

    sget-object v2, Lq;->bG:[[I

    sget-object v3, Lq;->bE:[[I

    sget v4, Lq;->el:I

    aget-object v3, v3, v4

    sget v4, Lq;->aB:I

    aget v3, v3, v4

    aget-object v2, v2, v3

    aget v2, v2, v1

    sget v3, Lq;->ad:I

    sub-int/2addr v2, v3

    if-ge v0, v2, :cond_40

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_397  #0x4
    sget v0, Lg;->ax:I

    if-eq v0, v4, :cond_3a1

    sget v0, Lg;->ax:I

    const/16 v2, 0x12

    if-ne v0, v2, :cond_40

    :cond_3a1
    sput-boolean v1, Lq;->em:Z

    sget-object v0, Lq;->bI:[I

    sget-object v2, Lq;->bE:[[I

    sget v5, Lq;->el:I

    aget-object v2, v2, v5

    sget v5, Lq;->aB:I

    aget v2, v2, v5

    aget v0, v0, v2

    packed-switch v0, :pswitch_data_bbe

    move v0, v1

    move v2, v1

    :goto_3b6
    add-int/lit8 v0, v0, -0x28

    sget v5, Lq;->as:I

    if-ne v5, v8, :cond_4ae

    sget-object v5, Lq;->bI:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    const/4 v6, 0x7

    if-ne v5, v6, :cond_4ae

    sget-boolean v5, Lg;->n:Z

    if-nez v5, :cond_4ae

    sget-object v5, Lq;->bK:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    const/16 v6, 0x5e

    if-ne v5, v6, :cond_4ae

    sget-object v3, Ll;->c:[[Ljava/lang/String;

    sget-object v5, Lq;->bK:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    aget-object v3, v3, v5

    const/16 v5, 0xd

    invoke-static {v3, v5, v2, v0}, Lq;->a([Ljava/lang/String;III)V

    :goto_3fa
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    sput-boolean v4, Lq;->er:Z

    goto/16 :goto_40

    :pswitch_404  #0x0
    sget v2, Lg;->at:I

    sget v0, Lg;->au:I

    goto :goto_3b6

    :pswitch_409  #0x1
    sget-object v0, Lc;->d:[I

    sget-object v2, Lq;->bJ:[I

    sget-object v5, Lq;->bE:[[I

    sget v6, Lq;->el:I

    aget-object v5, v5, v6

    sget v6, Lq;->aB:I

    aget v5, v5, v6

    aget v2, v2, v5

    aget v2, v0, v2

    sget-object v0, Lc;->e:[I

    sget-object v5, Lq;->bJ:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    aget v0, v0, v5

    goto :goto_3b6

    :pswitch_42e  #0x2
    sget-object v0, Lg;->K:[I

    sget-object v2, Lq;->bJ:[I

    sget-object v5, Lq;->bE:[[I

    sget v6, Lq;->el:I

    aget-object v5, v5, v6

    sget v6, Lq;->aB:I

    aget v5, v5, v6

    aget v2, v2, v5

    aget v2, v0, v2

    sget-object v0, Lg;->L:[I

    sget-object v5, Lq;->bJ:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    aget v0, v0, v5

    goto/16 :goto_3b6

    :pswitch_454  #0x4
    sget-object v0, Ln;->g:[I

    sget-object v2, Lq;->bJ:[I

    sget-object v5, Lq;->bE:[[I

    sget v6, Lq;->el:I

    aget-object v5, v5, v6

    sget v6, Lq;->aB:I

    aget v5, v5, v6

    aget v2, v2, v5

    aget v2, v0, v2

    sget-object v0, Ln;->h:[I

    sget-object v5, Lq;->bJ:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    aget v0, v0, v5

    goto/16 :goto_3b6

    :pswitch_47a  #0x3
    sget v0, Lq;->el:I

    const/16 v2, 0x18

    if-ne v0, v2, :cond_494

    sget v0, Lq;->aB:I

    if-nez v0, :cond_494

    sget v0, Lq;->W:I

    mul-int/lit8 v0, v0, 0x18

    sget v2, Lq;->ct:I

    add-int/2addr v2, v0

    sget v0, Lq;->Z:I

    mul-int/lit8 v0, v0, 0x18

    sget v5, Lq;->cu:I

    sub-int/2addr v0, v5

    goto/16 :goto_3b6

    :cond_494
    sget v2, Lg;->R:I

    sget v0, Lg;->S:I

    goto/16 :goto_3b6

    :pswitch_49a  #0x5
    sget v2, Le;->a:I

    sget v0, Le;->b:I

    add-int/lit8 v0, v0, -0x14

    goto/16 :goto_3b6

    :pswitch_4a2  #0x6
    sget v2, Li;->a:I

    sget v0, Li;->b:I

    goto/16 :goto_3b6

    :pswitch_4a8  #0x7
    sget v2, Lg;->bo:I

    sget v0, Lg;->bp:I

    goto/16 :goto_3b6

    :cond_4ae
    sget v5, Lq;->as:I

    if-ne v5, v8, :cond_4e0

    sget-object v5, Lq;->bI:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    const/4 v6, 0x7

    if-ne v5, v6, :cond_4e0

    sget-boolean v5, Lg;->n:Z

    if-eqz v5, :cond_4e0

    sget-object v3, Ll;->c:[[Ljava/lang/String;

    sget-object v5, Lq;->bK:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    aget-object v3, v3, v5

    const/16 v5, 0xe

    invoke-static {v3, v5, v2, v0}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_3fa

    :cond_4e0
    sget v5, Lq;->as:I

    const/16 v6, 0x9

    if-ne v5, v6, :cond_51f

    sget-object v5, Lq;->bI:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    if-ne v5, v4, :cond_51f

    sget-object v5, Lq;->bJ:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    if-nez v5, :cond_51f

    sget-object v3, Ll;->c:[[Ljava/lang/String;

    sget-object v5, Lq;->bK:[I

    sget-object v6, Lq;->bE:[[I

    sget v7, Lq;->el:I

    aget-object v6, v6, v7

    sget v7, Lq;->aB:I

    aget v6, v6, v7

    aget v5, v5, v6

    aget-object v3, v3, v5

    const/16 v5, 0xf

    invoke-static {v3, v5, v2, v0}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_3fa

    :cond_51f
    sget-object v5, Ll;->c:[[Ljava/lang/String;

    sget-object v6, Lq;->bK:[I

    sget-object v7, Lq;->bE:[[I

    sget v8, Lq;->el:I

    aget-object v7, v7, v8

    sget v8, Lq;->aB:I

    aget v7, v7, v8

    aget v6, v6, v7

    aget-object v5, v5, v6

    invoke-static {v5, v3, v2, v0}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_3fa

    :pswitch_536  #0x27
    sput-boolean v1, Lg;->H:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_540  #0x18
    sget v0, Ld;->c:I

    if-nez v0, :cond_546

    sput v4, Ld;->c:I

    :cond_546
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_54e  #0x28
    sput-boolean v1, Lq;->g:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_558  #0x19
    sput v7, Ld;->c:I

    sget-object v0, Lc;->d:[I

    aget v2, v0, v4

    add-int/lit8 v2, v2, -0x30

    aput v2, v0, v4

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_56a  #0x1c
    sget v0, Ls;->c:I

    if-nez v0, :cond_570

    sput v4, Ls;->c:I

    :cond_570
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    sput-boolean v4, Lq;->er:Z

    goto/16 :goto_40

    :pswitch_57a  #0x16
    move v0, v1

    :goto_57b
    sget v2, Lg;->F:I

    if-ge v0, v2, :cond_40

    sget-object v2, Lg;->K:[I

    aget v2, v2, v0

    sget-object v3, Lq;->bE:[[I

    sget v5, Lq;->el:I

    aget-object v3, v3, v5

    sget v5, Lq;->aB:I

    aget v3, v3, v5

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x28

    if-gt v2, v3, :cond_5a0

    sput-boolean v4, Lg;->H:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :cond_5a0
    add-int/lit8 v0, v0, 0x1

    goto :goto_57b

    :pswitch_5a3  #0x6
    sput v3, Lq;->aE:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_5ad  #0x10
    sget-object v0, Lg;->I:[Z

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aput-boolean v4, v0, v2

    sget-object v0, Lg;->K:[I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aget v0, v0, v2

    add-int/lit16 v0, v0, 0xc8

    sput v0, Lg;->J:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_5d5  #0x15
    sget-object v0, Lg;->K:[I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    aput v2, v0, v1

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_5eb  #0x11
    sget-boolean v0, Lq;->c:Z

    if-eqz v0, :cond_5f1

    sput-boolean v1, Lq;->c:Z

    :cond_5f1
    sget v0, Lg;->at:I

    sget v2, Lj;->n:I

    sput v2, Lg;->at:I

    sput v2, Lg;->aS:I

    sget v2, Lj;->o:I

    sput v2, Lg;->au:I

    sput v2, Lg;->aT:I

    sget v2, Lq;->as:I

    const/16 v5, 0x69

    if-ne v2, v5, :cond_607

    sput-boolean v4, Lq;->d:Z

    :cond_607
    sget v2, Lq;->as:I

    if-nez v2, :cond_613

    sget-boolean v2, Lq;->d:Z

    if-eqz v2, :cond_613

    sput-boolean v1, Lq;->d:Z

    sput-boolean v4, Lq;->e:Z

    :cond_613
    sget v2, Lq;->as:I

    const/16 v5, 0x6a

    if-ne v2, v5, :cond_621

    sget-boolean v2, Lq;->e:Z

    if-eqz v2, :cond_621

    sput-boolean v1, Lq;->e:Z

    sput-boolean v4, Lq;->f:Z

    :cond_621
    sget v2, Lq;->as:I

    if-nez v2, :cond_637

    sget-boolean v2, Lq;->f:Z

    if-eqz v2, :cond_637

    const/16 v2, 0x168

    sput v2, Lg;->at:I

    sput v2, Lg;->aS:I

    const/16 v2, 0x120

    sput v2, Lg;->au:I

    sput v2, Lg;->aT:I

    sput v3, Lg;->aF:I

    :cond_637
    sget v2, Lq;->as:I

    const/16 v5, 0x6b

    if-ne v2, v5, :cond_653

    sget-boolean v2, Lq;->f:Z

    if-eqz v2, :cond_653

    const/16 v2, 0x198

    sput v2, Lg;->at:I

    sput v2, Lg;->aS:I

    const/16 v2, 0x198

    sput v2, Lg;->au:I

    sput v2, Lg;->aT:I

    sput v4, Lg;->aF:I

    sput-boolean v1, Lq;->f:Z

    sput-boolean v4, Lq;->g:Z

    :cond_653
    sget v2, Lq;->as:I

    const/16 v5, 0x6c

    if-ne v2, v5, :cond_68c

    sget v2, Lg;->bo:I

    if-ge v2, v0, :cond_6b5

    sput-boolean v4, Lg;->bm:Z

    const/16 v0, 0x558

    sput v0, Lg;->at:I

    const/16 v0, 0x198

    sput v0, Lg;->au:I

    sput v4, Lg;->aF:I

    const/16 v0, 0x3a7

    sput v0, Lg;->bo:I

    const/16 v0, 0x198

    sput v0, Lg;->bp:I

    sput v4, Lg;->bA:I

    const/16 v0, 0x570

    sput v0, Lg;->R:I

    const/16 v0, 0x198

    sput v0, Lg;->S:I

    sput v4, Lg;->ad:I

    sput v4, Lg;->ax:I

    sput v3, Lq;->aQ:I

    sget-object v0, Lq;->bE:[[I

    sget v1, Lq;->el:I

    aget-object v0, v0, v1

    sget v1, Lq;->aB:I

    const/4 v2, 0x3

    aput v2, v0, v1

    :cond_68c
    :goto_68c
    sget v0, Lq;->as:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_6a0

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_6a0

    sput v4, Lg;->aF:I

    const/16 v0, 0x468

    sput v0, Lg;->at:I

    const/16 v0, 0x180

    sput v0, Lg;->au:I

    :cond_6a0
    invoke-static {}, Lq;->A()V

    sput-boolean v4, LMidlet;->f:Z

    sget-object v0, Lq;->bE:[[I

    sget v1, Lq;->el:I

    aget-object v0, v0, v1

    sget v1, Lq;->aB:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->i(I)V

    move v1, v4

    goto/16 :goto_15

    :cond_6b5
    sput-boolean v1, Lg;->bm:Z

    const/16 v0, 0x48

    sput v0, Lg;->at:I

    const/16 v0, 0x78

    sput v0, Lg;->au:I

    sput v4, Lg;->aF:I

    const/16 v0, 0x60

    sput v0, Lg;->R:I

    const/16 v0, 0x78

    sput v0, Lg;->S:I

    sput v4, Lg;->ad:I

    sput v4, Lg;->ax:I

    sput v3, Lq;->aQ:I

    sget-object v0, Lq;->bE:[[I

    sget v1, Lq;->el:I

    aget-object v0, v0, v1

    sget v1, Lq;->aB:I

    aput v7, v0, v1

    goto :goto_68c

    :pswitch_6da  #0x7
    sput-boolean v4, Lg;->aY:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_6e4  #0x2
    sget-object v0, Lq;->bE:[[I

    sget v2, Lq;->el:I

    aget-object v0, v0, v2

    sget v2, Lq;->aB:I

    aget v0, v0, v2

    invoke-static {v0}, Lq;->l(I)V

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_6f9  #0xb
    sget v0, Lq;->as:I

    const/16 v2, 0xd

    if-ne v0, v2, :cond_747

    sget v0, Lq;->ad:I

    rsub-int v0, v0, 0x4f8

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->aw:I

    sget v0, Lq;->ae:I

    rsub-int v0, v0, 0x108

    add-int/lit8 v0, v0, -0x46

    sput v0, Lq;->ax:I

    sput v4, Lg;->V:I

    sput v4, Lg;->bs:I

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, -0x18

    sput v0, Lg;->R:I

    sget v0, Lg;->at:I

    add-int/lit8 v0, v0, 0x18

    sput v0, Lg;->bo:I

    :goto_71f
    sget v0, Lq;->aw:I

    if-gez v0, :cond_725

    sput v1, Lq;->aw:I

    :cond_725
    sget v0, Lq;->aw:I

    sget v2, Lq;->ej:I

    if-le v0, v2, :cond_72f

    sget v0, Lq;->ej:I

    sput v0, Lq;->aw:I

    :cond_72f
    sget v0, Lq;->ax:I

    if-gez v0, :cond_735

    sput v1, Lq;->ax:I

    :cond_735
    sget v0, Lq;->ax:I

    sget v2, Lq;->ek:I

    if-le v0, v2, :cond_73f

    sget v0, Lq;->ek:I

    sput v0, Lq;->ax:I

    :cond_73f
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :cond_747
    sget v0, Le;->a:I

    sget v2, Lq;->ad:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->aw:I

    sget v0, Le;->b:I

    sget v2, Lq;->ae:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x46

    sput v0, Lq;->ax:I

    goto :goto_71f

    :pswitch_75a  #0x1b
    sput-boolean v1, Ln;->a:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_764  #0x1e
    sput-boolean v4, Ln;->a:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_76e  #0x23
    sput-boolean v4, Lq;->bD:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_778  #0x24
    sput-boolean v1, Lq;->bD:Z

    sget v0, Lq;->as:I

    if-ne v0, v8, :cond_795

    sput v8, Lg;->Q:I

    sput v8, Lg;->bn:I

    invoke-static {v8}, Lg;->b(I)V

    sput-boolean v4, Lg;->O:Z

    sput-boolean v4, Lg;->bm:Z

    const/16 v0, 0x7c8

    sput v0, Lg;->at:I

    const/16 v0, 0xf0

    sput v0, Lg;->au:I

    sput v4, Lg;->aF:I

    sput v4, Lg;->V:I

    :cond_795
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_79d  #0x25
    sget-object v0, Lc;->d:[I

    sget-object v2, Lq;->bH:[[I

    sget-object v3, Lq;->bE:[[I

    sget v5, Lq;->el:I

    aget-object v3, v3, v5

    sget v5, Lq;->aB:I

    aget v3, v3, v5

    aget-object v2, v2, v3

    aget v2, v2, v1

    sget-object v3, Lq;->bH:[[I

    sget-object v5, Lq;->bE:[[I

    sget v6, Lq;->el:I

    aget-object v5, v5, v6

    sget v6, Lq;->aB:I

    aget v5, v5, v6

    aget-object v3, v3, v5

    aget v3, v3, v4

    aput v3, v0, v2

    sget-object v0, Lc;->e:[I

    sget-object v2, Lq;->bH:[[I

    sget-object v3, Lq;->bE:[[I

    sget v4, Lq;->el:I

    aget-object v3, v3, v4

    sget v4, Lq;->aB:I

    aget v3, v3, v4

    aget-object v2, v2, v3

    aget v2, v2, v1

    sget-object v3, Lq;->bH:[[I

    sget-object v4, Lq;->bE:[[I

    sget v5, Lq;->el:I

    aget-object v4, v4, v5

    sget v5, Lq;->aB:I

    aget v4, v4, v5

    aget-object v3, v3, v4

    aget v3, v3, v7

    aput v3, v0, v2

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_7ed  #0x20
    sget-object v0, Lq;->bE:[[I

    sget v2, Lq;->el:I

    aget-object v0, v0, v2

    sget v2, Lq;->aB:I

    aget v0, v0, v2

    sput v0, Lg;->ao:I

    sput-boolean v1, Lg;->O:Z

    sput v7, Lg;->V:I

    sget v0, Lg;->R:I

    sget v2, Lg;->ao:I

    if-le v0, v2, :cond_814

    move v0, v3

    :goto_804
    sput v0, Lg;->ad:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->T:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :cond_814
    move v0, v4

    goto :goto_804

    :pswitch_816  #0x30
    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->bq:I

    sget v0, Lg;->bA:I

    if-ne v0, v4, :cond_83a

    sget v0, Lg;->bo:I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    if-lt v0, v2, :cond_40

    sput v4, Lg;->bs:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :cond_83a
    sget v0, Lg;->bo:I

    sget-object v2, Lq;->bE:[[I

    sget v3, Lq;->el:I

    aget-object v2, v2, v3

    sget v3, Lq;->aB:I

    aget v2, v2, v3

    if-gt v0, v2, :cond_40

    sput v4, Lg;->bs:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_852  #0x26
    sget-object v0, Lq;->bE:[[I

    sget v2, Lq;->el:I

    aget-object v0, v0, v2

    sget v2, Lq;->aB:I

    aget v0, v0, v2

    sput v0, Lg;->ad:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_866  #0x13
    sput-boolean v4, Lg;->O:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_870  #0x14
    sput-boolean v1, Lg;->O:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_87a  #0x29
    sput-boolean v4, Lg;->h:Z

    const-string v0, "Tìm gươm của Sakura"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_889  #0x2a
    sput-boolean v1, Lg;->h:Z

    sput-boolean v4, Lg;->O:Z

    const-string v0, "Về gặp thầy hiệu trưởng"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_89a  #0x2b
    const/16 v0, 0x2710

    sput v0, Lg;->bL:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_8a6  #0x2c
    sput v1, Lg;->bL:I

    sput v4, Lg;->bs:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_8b2  #0x2d
    sput-boolean v1, Lg;->aY:Z

    sget v0, Lg;->bo:I

    sget v2, Lq;->ad:I

    sub-int/2addr v0, v2

    sput v0, Lq;->aw:I

    sget v0, Lg;->bp:I

    sget v2, Lq;->ae:I

    sub-int/2addr v0, v2

    sput v0, Lq;->ax:I

    sget v0, Lq;->aw:I

    if-gez v0, :cond_8c8

    sput v1, Lq;->aw:I

    :cond_8c8
    sget v0, Lq;->aw:I

    sget v2, Lq;->ej:I

    if-le v0, v2, :cond_8d2

    sget v0, Lq;->ej:I

    sput v0, Lq;->aw:I

    :cond_8d2
    sget v0, Lq;->ax:I

    if-gez v0, :cond_8d8

    sput v1, Lq;->ax:I

    :cond_8d8
    sget v0, Lq;->ax:I

    sget v2, Lq;->ek:I

    if-le v0, v2, :cond_8e2

    sget v0, Lq;->ek:I

    sput v0, Lq;->ax:I

    :cond_8e2
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_8ea  #0x2e
    sget v0, Lg;->au:I

    sget v2, Lg;->bp:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x64

    if-ge v0, v2, :cond_90c

    sget v0, Lg;->at:I

    sget v2, Lg;->bo:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x64

    if-ge v0, v2, :cond_90c

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :cond_90c
    sget v0, Lg;->bo:I

    sget v2, Lg;->at:I

    if-ge v0, v2, :cond_916

    sput v7, Lg;->bs:I

    sput v4, Lg;->bA:I

    :cond_916
    sget v0, Lg;->bo:I

    sget v2, Lg;->at:I

    if-le v0, v2, :cond_920

    sput v7, Lg;->bs:I

    sput v3, Lg;->bA:I

    :cond_920
    sget v0, Lg;->bp:I

    sget v2, Lg;->au:I

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x64

    if-lt v0, v2, :cond_930

    const/4 v0, 0x3

    sput v0, Lg;->bs:I

    :cond_930
    :pswitch_930  #0x2f
    sget v0, Lg;->bo:I

    sget v2, Lq;->W:I

    mul-int/lit8 v2, v2, 0x18

    if-lt v0, v2, :cond_948

    sget v0, Lg;->bp:I

    sget v2, Lq;->Z:I

    mul-int/lit8 v2, v2, 0x18

    if-gt v0, v2, :cond_948

    sget v0, Lg;->bo:I

    sget v2, Lq;->Y:I

    mul-int/lit8 v2, v2, 0x18

    if-le v0, v2, :cond_956

    :cond_948
    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    sput v3, Lg;->bn:I

    sput v1, Lg;->bL:I

    sput-boolean v1, Lg;->bm:Z

    goto/16 :goto_40

    :cond_956
    sget v0, Lg;->bo:I

    sget v2, Lg;->bp:I

    invoke-static {v0, v2, v7}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_97c

    sget v0, Lg;->bo:I

    const/16 v2, 0x168

    if-lt v0, v2, :cond_979

    sput v3, Lg;->bA:I

    :goto_968
    const/16 v0, 0x14

    sput v0, Lg;->bL:I

    sput v8, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->bq:I

    const/4 v0, 0x7

    sput v0, Lg;->br:I

    goto/16 :goto_40

    :cond_979
    sput v4, Lg;->bA:I

    goto :goto_968

    :cond_97c
    sget v0, Lg;->bo:I

    const/16 v2, 0x168

    if-lt v0, v2, :cond_992

    sput v3, Lg;->bA:I

    :goto_984
    const/16 v0, 0x14

    sput v0, Lg;->bL:I

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->bq:I

    goto/16 :goto_40

    :cond_992
    sput v4, Lg;->bA:I

    goto :goto_984

    :pswitch_995  #0x31
    sput v4, Lg;->ad:I

    sput-boolean v1, Lg;->O:Z

    sget v0, Lg;->R:I

    sget v2, Lq;->Y:I

    mul-int/lit8 v2, v2, 0x18

    add-int/lit8 v2, v2, 0x14

    if-le v0, v2, :cond_9b7

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    const/16 v0, 0x9c0

    sput v0, Lg;->R:I

    const/16 v0, 0x108

    sput v0, Lg;->S:I

    sput v3, Lg;->ad:I

    sput v4, Lg;->V:I

    goto/16 :goto_40

    :cond_9b7
    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    add-int/2addr v0, v2

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    invoke-static {v0, v2, v8}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_9d6

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x6

    sput v0, Lg;->T:I

    const/4 v0, 0x3

    sput v0, Lg;->V:I

    const/16 v0, -0xa

    sput v0, Lg;->U:I

    goto/16 :goto_40

    :cond_9d6
    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    invoke-static {v0, v2, v7}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_9ed

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    sget v2, Lq;->aC:I

    add-int/lit8 v2, v2, -0x1

    mul-int/2addr v0, v2

    sput v0, Lg;->T:I

    goto/16 :goto_40

    :cond_9ed
    sget v0, Lg;->V:I

    const/4 v2, 0x3

    if-eq v0, v2, :cond_40

    sput v8, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->T:I

    sput v8, Lg;->U:I

    goto/16 :goto_40

    :pswitch_9fe  #0x32
    sget-object v0, Lo;->b:Lo;

    new-instance v2, Lh;

    sget-object v3, Lc;->d:[I

    aget v3, v3, v1

    sget-object v5, Lc;->e:[I

    aget v5, v5, v1

    add-int/lit8 v5, v5, -0x5

    const/16 v6, 0xd

    invoke-direct {v2, v3, v5, v6}, Lh;-><init>(III)V

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sput-boolean v4, Lg;->u:Z

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_a1e  #0x33
    sput v3, Lg;->aF:I

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_a28  #0x34
    sput v3, Lg;->ad:I

    sput-boolean v1, Lg;->O:Z

    sget v0, Lg;->R:I

    sget v2, Lq;->W:I

    mul-int/lit8 v2, v2, 0x18

    if-ge v0, v2, :cond_a3e

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    sput v3, Lg;->Q:I

    goto/16 :goto_40

    :cond_a3e
    sget v0, Lg;->R:I

    sget v2, Lg;->Z:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    sget v2, Lg;->S:I

    sget v3, Lg;->aa:I

    sub-int/2addr v2, v3

    const/16 v3, 0x8

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_a61

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x6

    sput v0, Lg;->T:I

    const/4 v0, 0x3

    sput v0, Lg;->V:I

    const/16 v0, -0xa

    sput v0, Lg;->U:I

    goto/16 :goto_40

    :cond_a61
    sget v0, Lg;->R:I

    sget v2, Lg;->S:I

    invoke-static {v0, v2, v7}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_a78

    sput v7, Lg;->V:I

    sget v0, Lg;->ad:I

    sget v2, Lq;->aC:I

    add-int/lit8 v2, v2, -0x1

    mul-int/2addr v0, v2

    sput v0, Lg;->T:I

    goto/16 :goto_40

    :cond_a78
    sget v0, Lg;->V:I

    const/4 v2, 0x3

    if-eq v0, v2, :cond_40

    sput v8, Lg;->V:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->T:I

    sput v8, Lg;->U:I

    goto/16 :goto_40

    :pswitch_a89  #0x37
    sput v3, Lg;->bA:I

    sput-boolean v1, Lg;->bm:Z

    sget v0, Lg;->bo:I

    sget v2, Lq;->W:I

    mul-int/lit8 v2, v2, 0x18

    if-ge v0, v2, :cond_a9f

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    sput v3, Lg;->bn:I

    goto/16 :goto_40

    :cond_a9f
    sget v0, Lg;->bo:I

    sget v2, Lg;->bw:I

    sub-int/2addr v0, v2

    add-int/lit8 v0, v0, -0x1

    sget v2, Lg;->bp:I

    sget v3, Lg;->bx:I

    sub-int/2addr v2, v3

    const/16 v3, 0x8

    invoke-static {v0, v2, v3}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_ac2

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x6

    sput v0, Lg;->bq:I

    const/4 v0, 0x3

    sput v0, Lg;->bs:I

    const/16 v0, -0xa

    sput v0, Lg;->br:I

    goto/16 :goto_40

    :cond_ac2
    sget v0, Lg;->bo:I

    sget v2, Lg;->bp:I

    invoke-static {v0, v2, v7}, Lj;->a(III)Z

    move-result v0

    if-eqz v0, :cond_ad9

    sput v7, Lg;->bs:I

    sget v0, Lg;->bA:I

    sget v2, Lq;->aC:I

    add-int/lit8 v2, v2, -0x1

    mul-int/2addr v0, v2

    sput v0, Lg;->bq:I

    goto/16 :goto_40

    :cond_ad9
    sget v0, Lg;->bs:I

    const/4 v2, 0x3

    if-eq v0, v2, :cond_40

    sput v8, Lg;->bs:I

    sget v0, Lg;->bA:I

    mul-int/lit8 v0, v0, 0x3

    sput v0, Lg;->bq:I

    sput v8, Lg;->br:I

    goto/16 :goto_40

    :pswitch_aea  #0x36
    const-string v0, "Cửa hang chưa được mở"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sget v0, Lq;->aB:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aB:I

    goto/16 :goto_40

    :pswitch_af7  #0x1d
    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    invoke-static {}, Lj;->b()V

    invoke-static {}, Lq;->z()V

    const/4 v0, 0x0

    sput-object v0, Ls;->b:Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Ld;->b:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lc;->a()V

    const/4 v0, 0x0

    sput-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dP:Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dR:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-static {}, Lt;->a()V

    invoke-static {}, Lm;->a()V

    invoke-static {}, La;->a()V

    invoke-static {}, Ln;->a()V

    invoke-static {}, Lg;->g()V

    const/4 v0, 0x0

    sput-object v0, Lq;->dJ:[[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dT:[[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dU:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dV:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->ec:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->dK:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-static {}, Lg;->h()V

    invoke-static {}, Lq;->E()V

    move v1, v4

    goto/16 :goto_15

    nop

    :pswitch_data_b4c
    .packed-switch 0x1
        :pswitch_a4  #00000001
        :pswitch_6e4  #00000002
        :pswitch_d2  #00000003
        :pswitch_397  #00000004
        :pswitch_23d  #00000005
        :pswitch_5a3  #00000006
        :pswitch_6da  #00000007
        :pswitch_304  #00000008
        :pswitch_258  #00000009
        :pswitch_2b2  #0000000a
        :pswitch_6f9  #0000000b
        :pswitch_a3  #0000000c
        :pswitch_a3  #0000000d
        :pswitch_349  #0000000e
        :pswitch_30e  #0000000f
        :pswitch_5ad  #00000010
        :pswitch_5eb  #00000011
        :pswitch_a3  #00000012
        :pswitch_866  #00000013
        :pswitch_870  #00000014
        :pswitch_5d5  #00000015
        :pswitch_57a  #00000016
        :pswitch_a3  #00000017
        :pswitch_540  #00000018
        :pswitch_558  #00000019
        :pswitch_a3  #0000001a
        :pswitch_75a  #0000001b
        :pswitch_56a  #0000001c
        :pswitch_af7  #0000001d
        :pswitch_764  #0000001e
        :pswitch_a3  #0000001f
        :pswitch_7ed  #00000020
        :pswitch_a3  #00000021
        :pswitch_370  #00000022
        :pswitch_76e  #00000023
        :pswitch_778  #00000024
        :pswitch_79d  #00000025
        :pswitch_852  #00000026
        :pswitch_536  #00000027
        :pswitch_54e  #00000028
        :pswitch_87a  #00000029
        :pswitch_889  #0000002a
        :pswitch_89a  #0000002b
        :pswitch_8a6  #0000002c
        :pswitch_8b2  #0000002d
        :pswitch_8ea  #0000002e
        :pswitch_930  #0000002f
        :pswitch_816  #00000030
        :pswitch_995  #00000031
        :pswitch_9fe  #00000032
        :pswitch_a1e  #00000033
        :pswitch_a28  #00000034
        :pswitch_bd  #00000035
        :pswitch_aea  #00000036
        :pswitch_a89  #00000037
    .end packed-switch

    :pswitch_data_bbe
    .packed-switch 0x0
        :pswitch_404  #00000000
        :pswitch_409  #00000001
        :pswitch_42e  #00000002
        :pswitch_47a  #00000003
        :pswitch_454  #00000004
        :pswitch_49a  #00000005
        :pswitch_4a2  #00000006
        :pswitch_4a8  #00000007
    .end packed-switch
.end method

.method private static L()V
    .registers 9

    const/16 v8, 0xa

    const/4 v5, -0x1

    const/4 v7, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x0

    move v6, v4

    :goto_7
    sget v0, Lq;->dn:I

    if-lt v6, v0, :cond_c

    return-void

    :cond_c
    sget-object v0, Lq;->dq:[I

    aget v0, v0, v6

    if-eqz v0, :cond_e8

    sget v0, Lg;->au:I

    sget v2, Lg;->aA:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v0, v2

    sget-object v2, Lq;->dp:[I

    aget v2, v2, v6

    add-int/lit8 v2, v2, -0x7

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v8, :cond_64

    sget v0, Lg;->at:I

    sget-object v2, Lq;->do:[I

    aget v2, v2, v6

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v8, :cond_64

    sget v0, Lq;->aj:I

    sget-object v2, Lq;->du:[I

    aget v2, v2, v6

    add-int/2addr v0, v2

    sput v0, Lq;->aj:I

    sput-boolean v1, Lq;->J:Z

    sget-object v0, Lq;->dq:[I

    const/16 v2, 0x12d

    aput v2, v0, v6

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "+"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v2, Lq;->du:[I

    aget v2, v2, v6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lq;->do:[I

    aget v2, v2, v6

    sget-object v3, Lq;->dp:[I

    aget v3, v3, v6

    add-int/lit8 v3, v3, -0xf

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :cond_64
    sget-object v0, Lq;->do:[I

    aget v2, v0, v6

    sget-object v3, Lq;->dr:[I

    aget v3, v3, v6

    add-int/2addr v2, v3

    aput v2, v0, v6

    sget-object v0, Lq;->dp:[I

    aget v2, v0, v6

    sget-object v3, Lq;->ds:[I

    aget v3, v3, v6

    add-int/2addr v2, v3

    aput v2, v0, v6

    sget-object v0, Lq;->dr:[I

    aget v0, v0, v6

    if-le v0, v1, :cond_88

    sget-object v0, Lq;->dr:[I

    aget v2, v0, v6

    add-int/lit8 v2, v2, -0x1

    aput v2, v0, v6

    :cond_88
    sget-object v0, Lq;->dr:[I

    aget v0, v0, v6

    if-ge v0, v5, :cond_96

    sget-object v0, Lq;->dr:[I

    aget v2, v0, v6

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v6

    :cond_96
    sget-object v0, Lq;->ds:[I

    aget v0, v0, v6

    const/16 v2, 0x14

    if-ge v0, v2, :cond_a6

    sget-object v0, Lq;->ds:[I

    aget v2, v0, v6

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v6

    :cond_a6
    sget-object v0, Lq;->dq:[I

    aget v2, v0, v6

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v6

    sget-object v0, Lq;->dq:[I

    aget v0, v0, v6

    const/16 v2, 0xc8

    if-le v0, v2, :cond_ba

    sget-object v0, Lq;->dq:[I

    aput v4, v0, v6

    :cond_ba
    sget-object v0, Lq;->dq:[I

    aget v0, v0, v6

    rem-int/lit8 v0, v0, 0x14

    const/16 v2, 0x12

    if-le v0, v2, :cond_ed

    sget-object v0, Lq;->dt:[I

    aput v4, v0, v6

    :goto_c8
    sget-object v0, Lq;->dp:[I

    aget v0, v0, v6

    if-ltz v0, :cond_e4

    sget-object v0, Lq;->dp:[I

    aget v0, v0, v6

    sget v2, Lj;->d:I

    if-ge v0, v2, :cond_e4

    sget-object v0, Lq;->do:[I

    aget v0, v0, v6

    sget v2, Lj;->c:I

    if-ge v0, v2, :cond_e4

    sget-object v0, Lq;->do:[I

    aget v0, v0, v6

    if-gez v0, :cond_101

    :cond_e4
    sget-object v0, Lq;->dq:[I

    aput v4, v0, v6

    :cond_e8
    :goto_e8
    add-int/lit8 v0, v6, 0x1

    move v6, v0

    goto/16 :goto_7

    :cond_ed
    sget-object v0, Lq;->dq:[I

    aget v0, v0, v6

    rem-int/lit8 v0, v0, 0x14

    const/16 v2, 0x10

    if-le v0, v2, :cond_fc

    sget-object v0, Lq;->dt:[I

    aput v1, v0, v6

    goto :goto_c8

    :cond_fc
    sget-object v0, Lq;->dt:[I

    aput v7, v0, v6

    goto :goto_c8

    :cond_101
    sget-object v0, Lq;->ds:[I

    aget v0, v0, v6

    if-le v0, v7, :cond_e8

    sget-object v0, Lq;->do:[I

    aget v0, v0, v6

    sget-object v2, Lq;->dp:[I

    aget v2, v2, v6

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-ne v0, v7, :cond_e8

    sget-object v0, Lq;->dp:[I

    sget-object v2, Lq;->dp:[I

    aget v2, v2, v6

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    aput v2, v0, v6

    sget-object v0, Lq;->ds:[I

    aget v0, v0, v6

    if-le v0, v7, :cond_135

    sget-object v0, Lq;->ds:[I

    sget-object v2, Lq;->ds:[I

    aget v2, v2, v6

    shr-int/lit8 v2, v2, 0x1

    neg-int v2, v2

    aput v2, v0, v6

    goto :goto_e8

    :cond_135
    sget-object v0, Lq;->dr:[I

    aput v4, v0, v6

    sget-object v0, Lq;->ds:[I

    aput v4, v0, v6

    goto :goto_e8
.end method

.method private static M()V
    .registers 3

    sget-boolean v0, Lq;->bd:Z

    if-eqz v0, :cond_2e

    sget v0, Lq;->eV:I

    sget-object v1, Lq;->eR:[[Ljava/lang/String;

    sget v2, Lq;->eP:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-ge v0, v1, :cond_2e

    sget v0, Lq;->eU:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eU:I

    sget-object v1, Lq;->eR:[[Ljava/lang/String;

    sget v2, Lq;->eP:I

    aget-object v1, v1, v2

    sget v2, Lq;->eV:I

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lt v0, v1, :cond_2e

    const/4 v0, 0x0

    sput v0, Lq;->eU:I

    sget v0, Lq;->eV:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eV:I

    :cond_2e
    return-void
.end method

.method private static N()V
    .registers 2

    sget v0, Lq;->at:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->at:I

    const/16 v1, 0x2710

    if-ne v0, v1, :cond_d

    const/4 v0, 0x0

    sput v0, Lq;->at:I

    :cond_d
    invoke-static {}, Lq;->M()V

    invoke-static {}, Lq;->J()V

    invoke-static {}, Lq;->P()V

    invoke-static {}, Lq;->K()Z

    move-result v0

    if-eqz v0, :cond_1d

    :goto_1c
    return-void

    :cond_1d
    invoke-static {}, Lg;->c()V

    invoke-static {}, Lg;->b()V

    goto :goto_1c
.end method

.method private static O()V
    .registers 15

    const/16 v14, 0xa

    const/4 v13, 0x1

    const/4 v5, -0x1

    const/4 v7, 0x2

    const/4 v1, 0x0

    move v12, v1

    :goto_7
    sget v0, Lq;->cY:I

    if-lt v12, v0, :cond_c

    return-void

    :cond_c
    sget-object v0, Lq;->dc:[I

    aget v0, v0, v12

    if-eqz v0, :cond_e9

    sget v0, Lg;->au:I

    sget v2, Lg;->aA:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v0, v2

    sget-object v2, Lq;->db:[I

    aget v2, v2, v12

    add-int/lit8 v2, v2, -0x7

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v14, :cond_73

    sget v0, Lg;->at:I

    sget-object v2, Lq;->da:[I

    aget v2, v2, v12

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v14, :cond_73

    sget-object v0, Lq;->cZ:[I

    aget v0, v0, v12

    if-nez v0, :cond_ee

    sget v0, Lg;->aL:I

    sget-object v2, Lq;->dg:[I

    aget v2, v2, v12

    add-int/2addr v0, v2

    sput v0, Lg;->aL:I

    sget v2, Lg;->aM:I

    if-le v0, v2, :cond_4a

    sget v0, Lg;->aM:I

    sput v0, Lg;->aL:I

    :cond_4a
    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "+"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v2, Lq;->dg:[I

    aget v2, v2, v12

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lq;->da:[I

    aget v2, v2, v12

    sget-object v3, Lq;->db:[I

    aget v3, v3, v12

    add-int/lit8 v3, v3, -0xf

    move v4, v1

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    :goto_6b
    sput-boolean v13, Lq;->J:Z

    sget-object v0, Lq;->dc:[I

    const/16 v2, 0x12d

    aput v2, v0, v12

    :cond_73
    sget-object v0, Lq;->da:[I

    aget v2, v0, v12

    sget-object v3, Lq;->dd:[I

    aget v3, v3, v12

    add-int/2addr v2, v3

    aput v2, v0, v12

    sget-object v0, Lq;->db:[I

    aget v2, v0, v12

    sget-object v3, Lq;->de:[I

    aget v3, v3, v12

    add-int/2addr v2, v3

    aput v2, v0, v12

    sget-object v0, Lq;->dd:[I

    aget v0, v0, v12

    if-le v0, v13, :cond_97

    sget-object v0, Lq;->dd:[I

    aget v2, v0, v12

    add-int/lit8 v2, v2, -0x1

    aput v2, v0, v12

    :cond_97
    sget-object v0, Lq;->dd:[I

    aget v0, v0, v12

    if-ge v0, v5, :cond_a5

    sget-object v0, Lq;->dd:[I

    aget v2, v0, v12

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v12

    :cond_a5
    sget-object v0, Lq;->de:[I

    aget v0, v0, v12

    const/16 v2, 0x14

    if-ge v0, v2, :cond_b5

    sget-object v0, Lq;->de:[I

    aget v2, v0, v12

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v12

    :cond_b5
    sget-object v0, Lq;->dc:[I

    aget v2, v0, v12

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v12

    sget-object v0, Lq;->dc:[I

    aget v0, v0, v12

    const/16 v2, 0xc8

    if-le v0, v2, :cond_c9

    sget-object v0, Lq;->dc:[I

    aput v1, v0, v12

    :cond_c9
    sget-object v0, Lq;->db:[I

    aget v0, v0, v12

    sget v2, Lj;->d:I

    if-ge v0, v2, :cond_e5

    sget-object v0, Lq;->db:[I

    aget v0, v0, v12

    if-ltz v0, :cond_e5

    sget-object v0, Lq;->da:[I

    aget v0, v0, v12

    sget v2, Lj;->c:I

    if-ge v0, v2, :cond_e5

    sget-object v0, Lq;->da:[I

    aget v0, v0, v12

    if-gez v0, :cond_123

    :cond_e5
    sget-object v0, Lq;->dc:[I

    aput v1, v0, v12

    :cond_e9
    :goto_e9
    add-int/lit8 v0, v12, 0x1

    move v12, v0

    goto/16 :goto_7

    :cond_ee
    sget v0, Lg;->aN:I

    sget-object v2, Lq;->dg:[I

    aget v2, v2, v12

    add-int/2addr v0, v2

    sput v0, Lg;->aN:I

    sget v2, Lg;->aO:I

    if-le v0, v2, :cond_ff

    sget v0, Lg;->aO:I

    sput v0, Lg;->aN:I

    :cond_ff
    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "+"

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v2, Lq;->dg:[I

    aget v2, v2, v12

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    sget-object v0, Lq;->da:[I

    aget v8, v0, v12

    sget-object v0, Lq;->db:[I

    aget v0, v0, v12

    add-int/lit8 v9, v0, -0xf

    move v10, v1

    move v11, v5

    invoke-static/range {v6 .. v11}, Lq;->a(Ljava/lang/String;IIIII)V

    goto/16 :goto_6b

    :cond_123
    sget-object v0, Lq;->de:[I

    aget v0, v0, v12

    if-le v0, v7, :cond_e9

    sget-object v0, Lq;->da:[I

    aget v0, v0, v12

    sget-object v2, Lq;->db:[I

    aget v2, v2, v12

    invoke-static {v0, v2}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-ne v0, v7, :cond_e9

    sget-object v0, Lq;->db:[I

    sget-object v2, Lq;->db:[I

    aget v2, v2, v12

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    aput v2, v0, v12

    sget-object v0, Lq;->de:[I

    aget v0, v0, v12

    if-le v0, v7, :cond_157

    sget-object v0, Lq;->de:[I

    sget-object v2, Lq;->de:[I

    aget v2, v2, v12

    shr-int/lit8 v2, v2, 0x1

    neg-int v2, v2

    aput v2, v0, v12

    goto :goto_e9

    :cond_157
    sget-object v0, Lq;->dd:[I

    aput v1, v0, v12

    sget-object v0, Lq;->de:[I

    aput v1, v0, v12

    goto :goto_e9
.end method

.method private static P()V
    .registers 3

    sget-boolean v0, Lq;->aN:Z

    if-eqz v0, :cond_16d

    sget-object v0, Lq;->u:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_184

    :cond_11
    :goto_11
    :pswitch_11  #0x3, 0x5
    return-void

    :pswitch_12  #0x2
    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto :goto_11

    :pswitch_26  #0x1
    sget v0, Lg;->at:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    if-le v0, v1, :cond_11

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto :goto_11

    :pswitch_48  #0x4
    sget v0, Lg;->at:I

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    if-le v0, v1, :cond_11

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto :goto_11

    :pswitch_65  #0x6
    sget v0, Lg;->at:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    if-ge v0, v1, :cond_11

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto :goto_11

    :pswitch_87  #0x7
    sget v0, Lg;->ax:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_91

    sget v0, Lg;->ax:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_11

    :cond_91
    sget v0, Lg;->au:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    if-ne v0, v1, :cond_11

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto/16 :goto_11

    :pswitch_b4  #0x8
    sget v0, Lg;->bo:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    if-le v0, v1, :cond_11

    sget v0, Lg;->bo:I

    sget v1, Lg;->at:I

    if-gt v0, v1, :cond_dd

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    :goto_d5
    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto/16 :goto_11

    :cond_dd
    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    add-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lq;->g(I)V

    goto :goto_d5

    :pswitch_ed  #0x9
    sget v0, Lg;->at:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    if-ge v0, v1, :cond_11

    sget-object v0, Lq;->bB:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->at:I

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    goto/16 :goto_11

    :pswitch_118  #0xa
    sget v0, Lg;->at:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    if-le v0, v1, :cond_11

    sget-object v0, Lq;->bB:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->at:I

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    goto/16 :goto_11

    :pswitch_143  #0xb
    sget v0, Lg;->at:I

    sget-object v1, Lq;->bB:[[I

    sget v2, Lq;->aM:I

    aget-object v1, v1, v2

    sget v2, Lq;->aO:I

    aget v1, v1, v2

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x28

    if-ge v0, v1, :cond_11

    sget-object v0, Lq;->v:[[I

    sget v1, Lq;->aM:I

    aget-object v0, v0, v1

    sget v1, Lq;->aO:I

    aget v0, v0, v1

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    goto/16 :goto_11

    :cond_16d
    sget v0, Lq;->aM:I

    const/16 v1, 0xa

    if-ne v0, v1, :cond_11

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-static {v0}, Ljavax/microedition/lcdui/Display;->getDisplay(Ljavax/microedition/midlet/MIDlet;)Ljavax/microedition/lcdui/Display;

    move-result-object v0

    sget-object v1, LMidlet;->a:Lq;

    invoke-virtual {v0, v1}, Ljavax/microedition/lcdui/Display;->setCurrent(Ljavax/microedition/lcdui/Displayable;)V

    const/4 v0, 0x0

    sput v0, Lq;->aM:I

    goto/16 :goto_11

    nop

    :pswitch_data_184
    .packed-switch 0x1
        :pswitch_26  #00000001
        :pswitch_12  #00000002
        :pswitch_11  #00000003
        :pswitch_48  #00000004
        :pswitch_11  #00000005
        :pswitch_65  #00000006
        :pswitch_87  #00000007
        :pswitch_b4  #00000008
        :pswitch_ed  #00000009
        :pswitch_118  #0000000a
        :pswitch_143  #0000000b
    .end packed-switch
.end method

.method private Q()V
    .registers 9

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v2, "/prefix.txt"

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    :goto_10
    :try_start_10
    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_170

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb;->e:Ljava/lang/String;

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v2, Ljava/lang/StringBuffer;

    sget-object v3, Lb;->e:Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v3, " doc len"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_37
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_37} :catch_176

    :goto_37
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v2, "/sms.txt"

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    :goto_46
    :try_start_46
    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_17c

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v2, ","

    invoke-static {v0, v2}, Lq;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    array-length v0, v2

    new-array v0, v0, [Ljava/lang/String;

    sput-object v0, Lq;->bj:[Ljava/lang/String;

    move v0, v1

    :goto_61
    array-length v1, v2

    if-lt v0, v1, :cond_187

    const/4 v0, 0x2

    new-array v0, v0, [[Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v3, 0x6

    new-array v3, v3, [Ljava/lang/String;

    const/4 v4, 0x0

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x4

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x5

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x2

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x5

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x3

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x4

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x4

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x5

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x5

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x5

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    aput-object v3, v0, v1

    const/4 v1, 0x1

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/String;

    const/4 v4, 0x0

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x4

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x4

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x2

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x5

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x3

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "sms://"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, Lq;->bj:[Ljava/lang/String;

    const/4 v7, 0x6

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    aput-object v3, v0, v1

    sput-object v0, Lb;->d:[[Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "sms://"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    aget-object v1, v2, v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb;->b:Ljava/lang/String;
    :try_end_16f
    .catch Ljava/lang/Exception; {:try_start_46 .. :try_end_16f} :catch_182

    :goto_16f
    return-void

    :cond_170
    int-to-char v3, v3

    :try_start_171
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;
    :try_end_174
    .catch Ljava/lang/Exception; {:try_start_171 .. :try_end_174} :catch_176

    goto/16 :goto_10

    :catch_176
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto/16 :goto_37

    :cond_17c
    int-to-char v3, v3

    :try_start_17d
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;
    :try_end_180
    .catch Ljava/lang/Exception; {:try_start_17d .. :try_end_180} :catch_182

    goto/16 :goto_46

    :catch_182
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_16f

    :cond_187
    :try_start_187
    sget-object v1, Lq;->bj:[Ljava/lang/String;

    aget-object v3, v2, v0

    aput-object v3, v1, v0

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "dau so "

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_1ab
    .catch Ljava/lang/Exception; {:try_start_187 .. :try_end_1ab} :catch_182

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_61
.end method

.method private static R()V
    .registers 1

    const/4 v0, 0x0

    sput v0, Lq;->bl:I

    sput v0, Lq;->bk:I

    sput v0, Lq;->fb:I

    return-void
.end method

.method private static S()V
    .registers 5

    const/4 v4, 0x4

    const/4 v0, 0x0

    sget v1, Lq;->ae:I

    add-int/lit8 v1, v1, -0x28

    sput v1, Lq;->fn:I

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x32

    sput v1, Lq;->fo:I

    sput v0, Lq;->fp:I

    sget-object v1, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_1b

    new-array v1, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_19
    if-lt v1, v4, :cond_1c

    :cond_1b
    return-void

    :cond_1c
    :try_start_1c
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/bd"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_39
    .catch Ljava/io/IOException; {:try_start_1c .. :try_end_39} :catch_3d

    :goto_39
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_19

    :catch_3d
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_39
.end method

.method private static T()V
    .registers 7

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x0

    sget v0, Lq;->ae:I

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->fn:I

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x32

    sput v0, Lq;->fo:I

    sget v0, Lg;->ar:I

    if-ne v0, v2, :cond_2d

    sput v2, Lq;->fp:I

    :goto_16
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_21

    new-array v0, v6, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    move v2, v1

    :goto_1f
    if-lt v2, v6, :cond_47

    :cond_21
    sget-object v0, Lq;->fu:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_2c

    new-array v0, v5, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->fu:[Ljavax/microedition/lcdui/Image;

    move v0, v1

    :goto_2a
    if-lt v0, v5, :cond_6d

    :cond_2c
    :goto_2c
    return-void

    :cond_2d
    sget v0, Lg;->as:I

    if-nez v0, :cond_36

    sput v1, Lq;->fp:I

    :cond_33
    :goto_33
    sput v1, Lg;->ar:I

    goto :goto_16

    :cond_36
    const/4 v0, 0x2

    :goto_37
    if-ge v0, v5, :cond_33

    sget-object v2, Lq;->bf:[I

    aget v2, v2, v0

    sget v3, Lg;->as:I

    if-ne v2, v3, :cond_44

    sput v0, Lq;->fp:I

    goto :goto_33

    :cond_44
    add-int/lit8 v0, v0, 0x1

    goto :goto_37

    :cond_47
    :try_start_47
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/u/bd"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v0, v2
    :try_end_64
    .catch Ljava/io/IOException; {:try_start_47 .. :try_end_64} :catch_68

    :goto_64
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_1f

    :catch_68
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_64

    :cond_6d
    :try_start_6d
    sget-object v1, Lq;->fu:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/wpt"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_8a
    .catch Ljava/io/IOException; {:try_start_6d .. :try_end_8a} :catch_8d

    add-int/lit8 v0, v0, 0x1

    goto :goto_2a

    :catch_8d
    move-exception v0

    goto :goto_2c
.end method

.method private static U()V
    .registers 5

    const/4 v4, 0x4

    sget v0, Lq;->ae:I

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->fx:I

    const/4 v0, 0x0

    sput-object v0, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_16

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    move v1, v0

    :goto_14
    if-lt v1, v4, :cond_17

    :cond_16
    return-void

    :cond_17
    :try_start_17
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/bd"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_34
    .catch Ljava/io/IOException; {:try_start_17 .. :try_end_34} :catch_38

    :goto_34
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_14

    :catch_38
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_34
.end method

.method private static V()V
    .registers 3

    const/16 v2, -0x28

    sget v0, Lq;->ab:I

    rsub-int v0, v0, 0x118

    sput v0, Lq;->fV:I

    sget v0, Lq;->ac:I

    rsub-int v0, v0, 0x118

    sput v0, Lq;->fW:I

    const/4 v0, 0x0

    sput v0, Lq;->fL:I

    :try_start_11
    const-string v0, "/wm.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->fH:Ljavax/microedition/lcdui/Image;

    const-string v0, "/u/x.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->fI:Ljavax/microedition/lcdui/Image;
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_21} :catch_63

    :goto_21
    sget-object v0, Lq;->fD:[I

    sget v1, Lq;->fX:I

    aget v0, v0, v1

    sput v0, Lq;->fJ:I

    sget-object v0, Lq;->fE:[I

    sget v1, Lq;->fX:I

    aget v0, v0, v1

    sput v0, Lq;->fK:I

    invoke-static {}, Lq;->X()V

    sget v0, Lq;->fJ:I

    sget v1, Lq;->ad:I

    sub-int/2addr v0, v1

    sput v0, Lq;->fN:I

    sget v0, Lq;->fK:I

    sget v1, Lq;->ae:I

    sub-int/2addr v0, v1

    sput v0, Lq;->fO:I

    sget v0, Lq;->fT:I

    if-ge v0, v2, :cond_48

    sput v2, Lq;->fT:I

    :cond_48
    sget v0, Lq;->fT:I

    sget v1, Lq;->fV:I

    if-le v0, v1, :cond_52

    sget v0, Lq;->fV:I

    sput v0, Lq;->fT:I

    :cond_52
    sget v0, Lq;->fU:I

    if-ge v0, v2, :cond_58

    sput v2, Lq;->fU:I

    :cond_58
    sget v0, Lq;->fU:I

    sget v1, Lq;->fW:I

    if-le v0, v1, :cond_62

    sget v0, Lq;->fW:I

    sput v0, Lq;->fU:I

    :cond_62
    return-void

    :catch_63
    move-exception v0

    goto :goto_21
.end method

.method private static W()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lq;->fH:Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->fI:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method private static X()V
    .registers 4

    const/16 v3, 0x8

    const/4 v0, -0x1

    sput v0, Lq;->fL:I

    const-string v0, ""

    sput-object v0, Lq;->fY:Ljava/lang/String;

    const/4 v0, 0x0

    :goto_a
    sget-object v1, Lq;->bt:[Z

    array-length v1, v1

    if-lt v0, v1, :cond_10

    :goto_f
    return-void

    :cond_10
    sget v1, Lq;->fJ:I

    sget-object v2, Lq;->fD:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    if-ge v1, v3, :cond_31

    sget v1, Lq;->fK:I

    sget-object v2, Lq;->fE:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    if-ge v1, v3, :cond_31

    sput v0, Lq;->fL:I

    const-string v0, "Chuyển đến"

    sput-object v0, Lq;->fY:Ljava/lang/String;

    goto :goto_f

    :cond_31
    add-int/lit8 v0, v0, 0x1

    goto :goto_a
.end method

.method private static Y()V
    .registers 3

    const/4 v0, 0x3

    :try_start_1
    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->fZ:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/u/m0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lq;->fZ:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    const-string v2, "/u/m1.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lq;->fZ:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    const-string v2, "/u/m2.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_24} :catch_25

    :goto_24
    return-void

    :catch_25
    move-exception v0

    goto :goto_24
.end method

.method public static final a(I)I
    .registers 1

    if-lez p0, :cond_3

    :goto_2
    return p0

    :cond_3
    neg-int p0, p0

    goto :goto_2
.end method

.method public static a()V
    .registers 12

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget v0, Lg;->ax:I

    if-nez v0, :cond_d

    sget v0, Lg;->aM:I

    if-eqz v0, :cond_13

    :cond_d
    sget v0, Lq;->as:I

    const/16 v3, 0x63

    if-ne v0, v3, :cond_14

    :cond_13
    :goto_13
    return-void

    :cond_14
    const/16 v0, 0x1f4

    new-array v7, v0, [I

    sget-wide v4, Lq;->eA:J

    const-wide/16 v8, 0x0

    cmp-long v0, v4, v8

    if-lez v0, :cond_30

    sget v0, Lq;->ez:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sget-wide v8, Lq;->eA:J

    sub-long/2addr v4, v8

    const-wide/16 v8, 0x3e8

    div-long/2addr v4, v8

    long-to-int v3, v4

    add-int/2addr v0, v3

    sput v0, Lq;->ez:I

    :cond_30
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sput-wide v4, Lq;->eA:J

    sget-boolean v0, Lq;->a:Z

    if-eqz v0, :cond_5db

    move v0, v1

    :goto_3b
    aput v0, v7, v2

    sget v0, Lq;->ez:I

    aput v0, v7, v1

    sget v0, Lq;->as:I

    aput v0, v7, v6

    const/4 v0, 0x3

    sget v3, Lq;->at:I

    aput v3, v7, v0

    sget v0, Lq;->aj:I

    aput v0, v7, v10

    const/4 v3, 0x5

    sget-boolean v0, Lg;->H:Z

    if-eqz v0, :cond_5de

    move v0, v1

    :goto_54
    aput v0, v7, v3

    sget v0, Lg;->P:I

    aput v0, v7, v11

    const/4 v0, 0x7

    sget v3, Lg;->Q:I

    aput v3, v7, v0

    const/16 v0, 0x8

    sget v3, Lq;->aQ:I

    aput v3, v7, v0

    const/16 v0, 0x9

    sget v3, Lg;->as:I

    aput v3, v7, v0

    const/16 v3, 0xa

    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_5e1

    move v0, v1

    :goto_72
    aput v0, v7, v3

    const/16 v3, 0xb

    sget-boolean v0, Lg;->bm:Z

    if-eqz v0, :cond_5e4

    move v0, v1

    :goto_7b
    aput v0, v7, v3

    const/16 v3, 0xc

    sget-boolean v0, Lq;->c:Z

    if-eqz v0, :cond_5e7

    move v0, v1

    :goto_84
    aput v0, v7, v3

    const/16 v3, 0xd

    sget-boolean v0, Lq;->d:Z

    if-eqz v0, :cond_5ea

    move v0, v1

    :goto_8d
    aput v0, v7, v3

    const/16 v3, 0xe

    sget-boolean v0, Lq;->e:Z

    if-eqz v0, :cond_5ed

    move v0, v1

    :goto_96
    aput v0, v7, v3

    const/16 v3, 0xf

    sget-boolean v0, Lq;->f:Z

    if-eqz v0, :cond_5f0

    move v0, v1

    :goto_9f
    aput v0, v7, v3

    const/16 v3, 0x10

    sget-boolean v0, Lq;->g:Z

    if-eqz v0, :cond_5f3

    move v0, v1

    :goto_a8
    aput v0, v7, v3

    const/16 v3, 0x11

    sget-boolean v0, Lq;->h:Z

    if-eqz v0, :cond_5f6

    move v0, v1

    :goto_b1
    aput v0, v7, v3

    const/16 v4, 0x12

    const/16 v3, 0x13

    sget-boolean v0, Ln;->a:Z

    if-eqz v0, :cond_5f9

    move v0, v1

    :goto_bc
    aput v0, v7, v4

    move v0, v3

    move v4, v2

    :goto_c0
    sget-object v3, Lq;->bt:[Z

    array-length v3, v3

    if-lt v4, v3, :cond_5fc

    move v4, v2

    :goto_c6
    sget-object v3, Lq;->br:[I

    array-length v3, v3

    if-lt v4, v3, :cond_60e

    add-int/lit8 v4, v0, 0x1

    sget-boolean v3, Lg;->f:Z

    if-eqz v3, :cond_61b

    move v3, v1

    :goto_d2
    aput v3, v7, v0

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->i:Z

    if-eqz v0, :cond_61e

    move v0, v1

    :goto_db
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->h:Z

    if-eqz v0, :cond_621

    move v0, v1

    :goto_e4
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->g:Z

    if-eqz v0, :cond_624

    move v0, v1

    :goto_ed
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->au:Z

    if-eqz v0, :cond_627

    move v0, v1

    :goto_f6
    aput v0, v7, v3

    add-int/lit8 v0, v4, 0x1

    sget v3, Lg;->aq:I

    aput v3, v7, v4

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->ar:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->at:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->au:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->av:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aw:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->ax:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->ay:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->az:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aA:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aB:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aC:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aD:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aE:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aF:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aG:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aH:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aI:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aJ:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aK:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aL:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aM:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aN:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aO:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aP:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aQ:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aR:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aS:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aT:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aU:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aV:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aW:I

    aput v4, v7, v0

    add-int/lit8 v4, v3, 0x1

    sget v0, Lg;->aX:I

    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->aY:Z

    if-eqz v0, :cond_62a

    move v0, v1

    :goto_1c5
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->aZ:Z

    if-eqz v0, :cond_62d

    move v0, v1

    :goto_1ce
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->ba:Z

    if-eqz v0, :cond_630

    move v0, v1

    :goto_1d7
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->bb:Z

    if-eqz v0, :cond_633

    move v0, v1

    :goto_1e0
    aput v0, v7, v3

    add-int/lit8 v0, v4, 0x1

    sget v3, Lg;->bc:I

    aput v3, v7, v4

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bd:I

    aput v4, v7, v0

    add-int/lit8 v4, v3, 0x1

    sget v0, Lg;->be:I

    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->bf:Z

    if-eqz v0, :cond_636

    move v0, v1

    :goto_1fb
    aput v0, v7, v4

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bh:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bi:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bj:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bk:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bl:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->ed:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->ee:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->av:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->aw:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->ax:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->ef:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->eg:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->eh:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->ei:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->ay:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->az:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->ej:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->ek:I

    aput v4, v7, v0

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->aN:Z

    if-eqz v0, :cond_639

    move v0, v1

    :goto_270
    aput v0, v7, v3

    add-int/lit8 v0, v4, 0x1

    sget v3, Lq;->aM:I

    aput v3, v7, v4

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->aO:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->aE:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->es:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->et:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->eu:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->ev:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->ew:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->ex:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->ey:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->aF:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->R:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->S:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->T:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->U:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->V:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->W:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->X:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->Y:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->Z:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->aa:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->ab:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->ac:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->ad:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->ae:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->af:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->ag:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->ah:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->ai:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->aj:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->ak:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->al:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->am:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->an:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bo:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bp:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bq:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->br:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bs:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bt:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bu:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bv:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bw:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bx:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->by:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bz:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bA:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bB:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bC:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bD:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bE:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bF:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bG:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bH:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bI:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bJ:I

    aput v4, v7, v0

    add-int/lit8 v4, v3, 0x1

    sget v0, Lg;->bK:I

    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->i:Z

    if-eqz v0, :cond_63c

    move v0, v1

    :goto_3cf
    aput v0, v7, v4

    sget-boolean v0, Lq;->j:Z

    if-eqz v0, :cond_3db

    sget-boolean v0, Lg;->s:Z

    if-nez v0, :cond_3db

    sput-boolean v2, Lq;->j:Z

    :cond_3db
    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->j:Z

    if-eqz v0, :cond_63f

    move v0, v1

    :goto_3e2
    aput v0, v7, v3

    sget v0, Lq;->as:I

    const/16 v3, 0xc

    if-ne v0, v3, :cond_3fa

    sget v0, Lg;->bc:I

    if-ne v0, v10, :cond_3fa

    sget v0, Lg;->bh:I

    sget-object v3, Lc;->h:[I

    sget v5, Lg;->bc:I

    aget v3, v3, v5

    if-ge v0, v3, :cond_3fa

    sput-boolean v2, Lq;->k:Z

    :cond_3fa
    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->k:Z

    if-eqz v0, :cond_642

    move v0, v1

    :goto_401
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->l:Z

    if-eqz v0, :cond_645

    move v0, v1

    :goto_40a
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->m:Z

    if-eqz v0, :cond_648

    move v0, v1

    :goto_413
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->n:Z

    if-eqz v0, :cond_64b

    move v0, v1

    :goto_41c
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->o:Z

    if-eqz v0, :cond_64e

    move v0, v1

    :goto_425
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->p:Z

    if-eqz v0, :cond_651

    move v0, v1

    :goto_42e
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->q:Z

    if-eqz v0, :cond_654

    move v0, v1

    :goto_437
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->r:Z

    if-eqz v0, :cond_657

    move v0, v1

    :goto_440
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->s:Z

    if-eqz v0, :cond_65a

    move v0, v1

    :goto_449
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lq;->t:Z

    if-eqz v0, :cond_65d

    move v0, v1

    :goto_452
    aput v0, v7, v3

    sget-boolean v0, Lq;->bA:Z

    if-eqz v0, :cond_460

    sget v0, Lg;->aW:I

    const/16 v3, 0xd

    if-ge v0, v3, :cond_460

    sput-boolean v2, Lq;->bA:Z

    :cond_460
    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->bA:Z

    if-eqz v0, :cond_660

    move v0, v1

    :goto_467
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->j:Z

    if-eqz v0, :cond_663

    move v0, v1

    :goto_470
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->k:Z

    if-eqz v0, :cond_666

    move v0, v1

    :goto_479
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->l:Z

    if-eqz v0, :cond_669

    move v0, v1

    :goto_482
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lt;->m:Z

    if-eqz v0, :cond_66c

    move v0, v1

    :goto_48b
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->m:Z

    if-eqz v0, :cond_66f

    move v0, v1

    :goto_494
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->n:Z

    if-eqz v0, :cond_672

    move v0, v1

    :goto_49d
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->o:Z

    if-eqz v0, :cond_675

    move v0, v1

    :goto_4a6
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->p:Z

    if-eqz v0, :cond_678

    move v0, v1

    :goto_4af
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->r:Z

    if-eqz v0, :cond_67b

    move v0, v1

    :goto_4b8
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->s:Z

    if-eqz v0, :cond_67e

    move v0, v1

    :goto_4c1
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->t:Z

    if-eqz v0, :cond_681

    move v0, v1

    :goto_4ca
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->u:Z

    if-eqz v0, :cond_684

    move v0, v1

    :goto_4d3
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->q:Z

    if-eqz v0, :cond_687

    move v0, v1

    :goto_4dc
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->v:Z

    if-eqz v0, :cond_68a

    move v0, v1

    :goto_4e5
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->w:Z

    if-eqz v0, :cond_68d

    move v0, v1

    :goto_4ee
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->x:Z

    if-eqz v0, :cond_690

    move v0, v1

    :goto_4f7
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->y:Z

    if-eqz v0, :cond_693

    move v0, v1

    :goto_500
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->z:Z

    if-eqz v0, :cond_696

    move v0, v1

    :goto_509
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->A:Z

    if-eqz v0, :cond_699

    move v0, v1

    :goto_512
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lg;->B:Z

    if-eqz v0, :cond_69c

    move v0, v1

    :goto_51b
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_69f

    move v0, v1

    :goto_524
    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lm;->g:Z

    if-eqz v0, :cond_6a2

    move v0, v1

    :goto_52d
    aput v0, v7, v4

    add-int/lit8 v4, v3, 0x1

    sget v0, Lg;->D:I

    aput v0, v7, v3

    add-int/lit8 v3, v4, 0x1

    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_6a5

    move v0, v1

    :goto_53c
    aput v0, v7, v4

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->el:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->aB:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lg;->bL:I

    aput v4, v7, v3

    add-int/lit8 v3, v0, 0x1

    sget v4, Lg;->bn:I

    aput v4, v7, v0

    add-int/lit8 v4, v3, 0x1

    sget-boolean v0, Lg;->ap:Z

    if-eqz v0, :cond_6a8

    move v0, v1

    :goto_55d
    aput v0, v7, v3

    add-int/lit8 v0, v4, 0x1

    sget v3, Lg;->a:I

    aput v3, v7, v4

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->bi:I

    aput v4, v7, v0

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->bh:I

    aput v4, v7, v3

    move v3, v6

    :goto_572
    if-lt v3, v11, :cond_6ab

    add-int/lit8 v3, v0, 0x1

    sget v4, Lq;->aW:I

    aput v4, v7, v0

    sget v0, Lq;->aW:I

    if-lez v0, :cond_5ca

    add-int/lit8 v0, v3, 0x1

    sget v4, Lq;->aX:I

    aput v4, v7, v3

    sget-object v3, Lq;->ba:[I

    if-eqz v3, :cond_58e

    move v4, v2

    :goto_589
    sget-object v3, Lq;->ba:[I

    array-length v3, v3

    if-lt v4, v3, :cond_6bf

    :cond_58e
    sget-object v3, Lq;->eM:[I

    if-eqz v3, :cond_598

    move v4, v2

    :goto_593
    sget-object v3, Lq;->eM:[I

    array-length v3, v3

    if-lt v4, v3, :cond_6cc

    :cond_598
    sget-object v3, Lq;->eL:[I

    if-eqz v3, :cond_5a2

    move v4, v2

    :goto_59d
    sget-object v3, Lq;->eL:[I

    array-length v3, v3

    if-lt v4, v3, :cond_6d9

    :cond_5a2
    sget-object v3, Lq;->bb:[I

    if-eqz v3, :cond_5ac

    move v4, v2

    :goto_5a7
    sget-object v3, Lq;->bb:[I

    array-length v3, v3

    if-lt v4, v3, :cond_6e6

    :cond_5ac
    sget-object v3, Lq;->bc:[I

    if-eqz v3, :cond_5b6

    move v4, v2

    :goto_5b1
    sget-object v3, Lq;->bc:[I

    array-length v3, v3

    if-lt v4, v3, :cond_6f3

    :cond_5b6
    sget-object v3, Lq;->aY:[I

    if-eqz v3, :cond_5c0

    move v4, v2

    :goto_5bb
    sget-object v3, Lq;->aY:[I

    array-length v3, v3

    if-lt v4, v3, :cond_700

    :cond_5c0
    sget-object v3, Lq;->aZ:[I

    if-eqz v3, :cond_5ca

    move v4, v2

    :goto_5c5
    sget-object v3, Lq;->aZ:[I

    array-length v3, v3

    if-lt v4, v3, :cond_70d

    :cond_5ca
    const-string v0, "ninjasave"

    array-length v3, v7

    shl-int/lit8 v4, v3, 0x2

    new-array v4, v4, [B

    :goto_5d1
    if-lt v2, v3, :cond_71a

    invoke-static {v0, v4}, LMidlet;->a(Ljava/lang/String;[B)V

    invoke-static {v1}, LMidlet;->a(Z)V

    goto/16 :goto_13

    :cond_5db
    move v0, v2

    goto/16 :goto_3b

    :cond_5de
    move v0, v2

    goto/16 :goto_54

    :cond_5e1
    move v0, v2

    goto/16 :goto_72

    :cond_5e4
    move v0, v2

    goto/16 :goto_7b

    :cond_5e7
    move v0, v2

    goto/16 :goto_84

    :cond_5ea
    move v0, v2

    goto/16 :goto_8d

    :cond_5ed
    move v0, v2

    goto/16 :goto_96

    :cond_5f0
    move v0, v2

    goto/16 :goto_9f

    :cond_5f3
    move v0, v2

    goto/16 :goto_a8

    :cond_5f6
    move v0, v2

    goto/16 :goto_b1

    :cond_5f9
    move v0, v2

    goto/16 :goto_bc

    :cond_5fc
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->bt:[Z

    aget-boolean v5, v5, v4

    if-eqz v5, :cond_60c

    move v5, v1

    :goto_605
    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_c0

    :cond_60c
    move v5, v2

    goto :goto_605

    :cond_60e
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->br:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_c6

    :cond_61b
    move v3, v2

    goto/16 :goto_d2

    :cond_61e
    move v0, v2

    goto/16 :goto_db

    :cond_621
    move v0, v2

    goto/16 :goto_e4

    :cond_624
    move v0, v2

    goto/16 :goto_ed

    :cond_627
    move v0, v2

    goto/16 :goto_f6

    :cond_62a
    move v0, v2

    goto/16 :goto_1c5

    :cond_62d
    move v0, v2

    goto/16 :goto_1ce

    :cond_630
    move v0, v2

    goto/16 :goto_1d7

    :cond_633
    move v0, v2

    goto/16 :goto_1e0

    :cond_636
    move v0, v2

    goto/16 :goto_1fb

    :cond_639
    move v0, v2

    goto/16 :goto_270

    :cond_63c
    move v0, v2

    goto/16 :goto_3cf

    :cond_63f
    move v0, v2

    goto/16 :goto_3e2

    :cond_642
    move v0, v2

    goto/16 :goto_401

    :cond_645
    move v0, v2

    goto/16 :goto_40a

    :cond_648
    move v0, v2

    goto/16 :goto_413

    :cond_64b
    move v0, v2

    goto/16 :goto_41c

    :cond_64e
    move v0, v2

    goto/16 :goto_425

    :cond_651
    move v0, v2

    goto/16 :goto_42e

    :cond_654
    move v0, v2

    goto/16 :goto_437

    :cond_657
    move v0, v2

    goto/16 :goto_440

    :cond_65a
    move v0, v2

    goto/16 :goto_449

    :cond_65d
    move v0, v2

    goto/16 :goto_452

    :cond_660
    move v0, v2

    goto/16 :goto_467

    :cond_663
    move v0, v2

    goto/16 :goto_470

    :cond_666
    move v0, v2

    goto/16 :goto_479

    :cond_669
    move v0, v2

    goto/16 :goto_482

    :cond_66c
    move v0, v2

    goto/16 :goto_48b

    :cond_66f
    move v0, v2

    goto/16 :goto_494

    :cond_672
    move v0, v2

    goto/16 :goto_49d

    :cond_675
    move v0, v2

    goto/16 :goto_4a6

    :cond_678
    move v0, v2

    goto/16 :goto_4af

    :cond_67b
    move v0, v2

    goto/16 :goto_4b8

    :cond_67e
    move v0, v2

    goto/16 :goto_4c1

    :cond_681
    move v0, v2

    goto/16 :goto_4ca

    :cond_684
    move v0, v2

    goto/16 :goto_4d3

    :cond_687
    move v0, v2

    goto/16 :goto_4dc

    :cond_68a
    move v0, v2

    goto/16 :goto_4e5

    :cond_68d
    move v0, v2

    goto/16 :goto_4ee

    :cond_690
    move v0, v2

    goto/16 :goto_4f7

    :cond_693
    move v0, v2

    goto/16 :goto_500

    :cond_696
    move v0, v2

    goto/16 :goto_509

    :cond_699
    move v0, v2

    goto/16 :goto_512

    :cond_69c
    move v0, v2

    goto/16 :goto_51b

    :cond_69f
    move v0, v2

    goto/16 :goto_524

    :cond_6a2
    move v0, v2

    goto/16 :goto_52d

    :cond_6a5
    move v0, v2

    goto/16 :goto_53c

    :cond_6a8
    move v0, v2

    goto/16 :goto_55d

    :cond_6ab
    add-int/lit8 v4, v0, 0x1

    sget-object v5, Lq;->bf:[I

    aget v5, v5, v3

    aput v5, v7, v0

    add-int/lit8 v0, v4, 0x1

    sget-object v5, Lq;->bs:[I

    aget v5, v5, v3

    aput v5, v7, v4

    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_572

    :cond_6bf
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->ba:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_589

    :cond_6cc
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->eM:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_593

    :cond_6d9
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->eL:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_59d

    :cond_6e6
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->bb:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_5a7

    :cond_6f3
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->bc:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_5b1

    :cond_700
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->aY:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_5bb

    :cond_70d
    add-int/lit8 v3, v0, 0x1

    sget-object v5, Lq;->aZ:[I

    aget v5, v5, v4

    aput v5, v7, v0

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_5c5

    :cond_71a
    shl-int/lit8 v5, v2, 0x2

    aget v6, v7, v2

    shr-int/lit8 v6, v6, 0x18

    aput-byte v6, v4, v5

    shl-int/lit8 v5, v2, 0x2

    add-int/lit8 v5, v5, 0x1

    aget v6, v7, v2

    ushr-int/lit8 v6, v6, 0x10

    int-to-byte v6, v6

    aput-byte v6, v4, v5

    shl-int/lit8 v5, v2, 0x2

    add-int/lit8 v5, v5, 0x2

    aget v6, v7, v2

    ushr-int/lit8 v6, v6, 0x8

    int-to-byte v6, v6

    aput-byte v6, v4, v5

    shl-int/lit8 v5, v2, 0x2

    add-int/lit8 v5, v5, 0x3

    aget v6, v7, v2

    int-to-byte v6, v6

    aput-byte v6, v4, v5

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_5d1
.end method

.method public static a(II)V
    .registers 3

    sput p0, Lq;->ed:I

    sput p1, Lq;->ee:I

    const/4 v0, 0x1

    sput v0, Lq;->av:I

    return-void
.end method

.method public static final a(III)V
    .registers 7

    const/4 v3, 0x1

    add-int/lit8 v0, p0, 0x1

    sput v0, Lq;->aP:I

    invoke-static {}, Lq;->C()V

    const/4 v0, 0x0

    mul-int/lit8 v1, p1, 0x18

    add-int/lit8 v1, v1, 0xc

    mul-int/lit8 v2, p2, 0x18

    invoke-static {v0, v1, v2}, Lq;->d(III)V

    if-ne p0, v3, :cond_25

    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    invoke-static {v3, v0, v1}, Lq;->d(III)V

    sput v3, Lq;->aQ:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    sget v2, Lg;->aF:I

    aput v2, v0, v1

    :cond_25
    return-void
.end method

.method public static a(IIII)V
    .registers 6

    const/4 v1, 0x1

    sput v1, Lq;->dI:I

    sput v1, Lq;->am:I

    sput p0, Lq;->ak:I

    sput p1, Lq;->al:I

    sput p2, Lq;->an:I

    sput p3, Lq;->dH:I

    sget v0, Lq;->an:I

    if-ne v0, v1, :cond_15

    const/4 v0, 0x0

    sput v0, Lq;->dG:I

    :goto_14
    return-void

    :cond_15
    const/4 v0, 0x2

    sput v0, Lq;->dG:I

    goto :goto_14
.end method

.method public static a(IIIII)V
    .registers 9

    const/4 v3, 0x1

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, Lq;->dn:I

    if-lt v0, v2, :cond_c

    :cond_7
    sget v2, Lq;->dn:I

    if-ne v0, v2, :cond_15

    :goto_b
    return-void

    :cond_c
    sget-object v2, Lq;->dq:[I

    aget v2, v2, v0

    if-eqz v2, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_15
    sget-object v2, Lq;->do:[I

    aput p0, v2, v0

    sget-object v2, Lq;->dp:[I

    aput p1, v2, v0

    sget-object v2, Lq;->dr:[I

    aput p2, v2, v0

    sget-object v2, Lq;->ds:[I

    aput p3, v2, v0

    sget-object v2, Lq;->dq:[I

    aput v3, v2, v0

    sget-object v2, Lq;->du:[I

    aput p4, v2, v0

    const/16 v2, 0xa0

    if-ge p4, v2, :cond_36

    sget-object v2, Lq;->dv:[I

    aput v1, v2, v0

    goto :goto_b

    :cond_36
    const/16 v1, 0x258

    if-ge p4, v1, :cond_3f

    sget-object v1, Lq;->dv:[I

    aput v3, v1, v0

    goto :goto_b

    :cond_3f
    sget-object v1, Lq;->dv:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    goto :goto_b
.end method

.method public static a(IIIIII)V
    .registers 11

    const/4 v4, 0x1

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, Lq;->cY:I

    if-lt v0, v2, :cond_c

    :cond_7
    sget v2, Lq;->cY:I

    if-ne v0, v2, :cond_15

    :goto_b
    return-void

    :cond_c
    sget-object v2, Lq;->dc:[I

    aget v2, v2, v0

    if-eqz v2, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_15
    sget-object v2, Lq;->da:[I

    aput p0, v2, v0

    sget-object v2, Lq;->db:[I

    aput p1, v2, v0

    sget-object v2, Lq;->dd:[I

    aput p2, v2, v0

    sget-object v2, Lq;->de:[I

    const/4 v3, -0x5

    aput v3, v2, v0

    sget-object v2, Lq;->dc:[I

    aput v4, v2, v0

    sget-object v2, Lq;->dg:[I

    aput p4, v2, v0

    sget-object v2, Lq;->cZ:[I

    aput p5, v2, v0

    const/16 v2, 0x64

    if-ge p4, v2, :cond_3b

    sget-object v2, Lq;->df:[I

    aput v1, v2, v0

    goto :goto_b

    :cond_3b
    const/16 v1, 0xc8

    if-ge p4, v1, :cond_44

    sget-object v1, Lq;->df:[I

    aput v4, v1, v0

    goto :goto_b

    :cond_44
    sget-object v1, Lq;->df:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    goto :goto_b
.end method

.method public static final a(IIIIZ)V
    .registers 8

    const/4 v1, -0x1

    const/4 v0, 0x0

    :goto_2
    sget v2, Lq;->dh:I

    if-lt v0, v2, :cond_a

    move v0, v1

    :cond_7
    if-ne v0, v1, :cond_13

    :goto_9
    return-void

    :cond_a
    sget-object v2, Lq;->ah:[I

    aget v2, v2, v0

    if-eq v2, v1, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_13
    sget-object v1, Lq;->ah:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->di:[I

    aput p0, v1, v0

    sget-object v1, Lq;->dj:[I

    aput p1, v1, v0

    sget-object v1, Lq;->ai:[I

    aput p2, v1, v0

    sget-object v1, Lq;->dl:[I

    aput p3, v1, v0

    sget-object v1, Lq;->dm:[Z

    aput-boolean p4, v1, v0

    goto :goto_9
.end method

.method public static a(Ljava/lang/String;)V
    .registers 2

    sput-object p0, Lq;->cX:Ljava/lang/String;

    const/4 v0, 0x0

    sput v0, Lq;->cW:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->cV:Z

    return-void
.end method

.method public static final a(Ljava/lang/String;IIIII)V
    .registers 10

    const/4 v2, 0x0

    const/4 v1, -0x1

    move v0, v2

    :goto_3
    const/4 v3, 0x5

    if-lt v0, v3, :cond_a

    move v0, v1

    :cond_7
    if-ne v0, v1, :cond_13

    :goto_9
    return-void

    :cond_a
    sget-object v3, Lq;->dB:[I

    aget v3, v3, v0

    if-eq v3, v1, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_13
    sget-object v1, Lq;->dw:[Ljava/lang/String;

    aput-object p0, v1, v0

    sget-object v1, Lq;->dx:[I

    aput p2, v1, v0

    sget-object v1, Lq;->dy:[I

    aput p3, v1, v0

    sget-object v1, Lq;->dz:[I

    aput v2, v1, v0

    sget-object v1, Lq;->dA:[I

    aput p5, v1, v0

    sget-object v1, Lq;->dB:[I

    aput v2, v1, v0

    sget-object v1, Lq;->dC:[I

    aput p1, v1, v0

    goto :goto_9
.end method

.method private static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 9

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    sget-boolean v0, Lq;->I:Z

    if-eqz v0, :cond_d1

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_d1

    sget v0, Lq;->P:I

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ab:I

    sget v2, Lq;->aa:I

    invoke-virtual {p0, v1, v1, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;

    if-eqz v0, :cond_28

    sget-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;

    sget v2, Lq;->N:I

    sget v3, Lq;->O:I

    invoke-virtual {p0, v0, v2, v3, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    move v0, v1

    :goto_26
    if-lt v0, v6, :cond_85

    :cond_28
    sget-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v5

    if-eqz v0, :cond_3f

    sget v0, Lq;->ay:I

    sget-object v2, Lq;->be:[I

    aget v2, v2, v5

    shr-int/2addr v0, v2

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v5

    rem-int/2addr v0, v2

    neg-int v0, v0

    :goto_3b
    sget v2, Lq;->ab:I

    if-lt v0, v2, :cond_95

    :cond_3f
    sget-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    if-eqz v0, :cond_56

    sget v0, Lq;->ay:I

    sget-object v2, Lq;->be:[I

    aget v2, v2, v6

    shr-int/2addr v0, v2

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v6

    rem-int/2addr v0, v2

    neg-int v0, v0

    :goto_52
    sget v2, Lq;->ab:I

    if-lt v0, v2, :cond_a4

    :cond_56
    sget-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v7

    if-eqz v0, :cond_6d

    sget v0, Lq;->ay:I

    sget-object v2, Lq;->be:[I

    aget v2, v2, v7

    shr-int/2addr v0, v2

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v7

    rem-int/2addr v0, v2

    neg-int v0, v0

    :goto_69
    sget v2, Lq;->ab:I

    if-lt v0, v2, :cond_b3

    :cond_6d
    sget-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    if-eqz v0, :cond_84

    sget v0, Lq;->ay:I

    sget-object v2, Lq;->be:[I

    aget v2, v2, v1

    shr-int/2addr v0, v2

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v1

    rem-int/2addr v0, v2

    neg-int v0, v0

    :goto_80
    sget v2, Lq;->ab:I

    if-lt v0, v2, :cond_c2

    :cond_84
    return-void

    :cond_85
    sget-object v2, Lq;->aq:Ljavax/microedition/lcdui/Image;

    sget-object v3, Lq;->L:[I

    aget v3, v3, v0

    sget-object v4, Lq;->M:[I

    aget v4, v4, v0

    invoke-virtual {p0, v2, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_26

    :cond_95
    sget-object v2, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v5

    sget v3, Lq;->T:I

    invoke-virtual {p0, v2, v0, v3, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v5

    add-int/2addr v0, v2

    goto :goto_3b

    :cond_a4
    sget-object v2, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v6

    sget v3, Lq;->S:I

    invoke-virtual {p0, v2, v0, v3, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v6

    add-int/2addr v0, v2

    goto :goto_52

    :cond_b3
    sget-object v2, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v7

    sget v3, Lq;->R:I

    invoke-virtual {p0, v2, v0, v3, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v7

    add-int/2addr v0, v2

    goto :goto_69

    :cond_c2
    sget-object v2, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v1

    sget v3, Lq;->Q:I

    invoke-virtual {p0, v2, v0, v3, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v2, Lq;->ap:[I

    aget v2, v2, v1

    add-int/2addr v0, v2

    goto :goto_80

    :cond_d1
    sget v0, Lq;->P:I

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ab:I

    sget v2, Lq;->ac:I

    invoke-virtual {p0, v1, v1, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_84

    sget-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;

    sget v2, Lq;->N:I

    sget v3, Lq;->O:I

    invoke-virtual {p0, v0, v2, v3, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    move v0, v1

    :goto_eb
    if-ge v0, v6, :cond_84

    sget-object v1, Lq;->aq:Ljavax/microedition/lcdui/Image;

    sget-object v2, Lq;->L:[I

    aget v2, v2, v0

    sget-object v3, Lq;->M:[I

    aget v3, v3, v0

    invoke-virtual {p0, v1, v2, v3, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_eb
.end method

.method public static a(Z)V
    .registers 10

    const/4 v8, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "ninjasave"

    invoke-static {v0}, LMidlet;->b(Ljava/lang/String;)[B

    move-result-object v3

    array-length v0, v3

    shr-int/lit8 v0, v0, 0x2

    new-array v6, v0, [I

    move v0, v1

    :goto_10
    array-length v4, v6

    if-lt v0, v4, :cond_55e

    aget v0, v6, v1

    if-ne v0, v2, :cond_589

    move v0, v2

    :goto_18
    sput-boolean v0, Lq;->a:Z

    aget v0, v6, v2

    sput v0, Lq;->ez:I

    aget v0, v6, v5

    sput v0, Lq;->as:I

    const/4 v0, 0x3

    aget v0, v6, v0

    sput v0, Lq;->at:I

    const/4 v0, 0x4

    aget v0, v6, v0

    sput v0, Lq;->aj:I

    const/4 v0, 0x5

    aget v0, v6, v0

    if-ne v0, v2, :cond_58c

    move v0, v2

    :goto_32
    sput-boolean v0, Lg;->H:Z

    aget v0, v6, v8

    sput v0, Lg;->P:I

    const/4 v0, 0x7

    aget v0, v6, v0

    sput v0, Lg;->Q:I

    const/16 v0, 0x8

    aget v0, v6, v0

    sput v0, Lq;->aQ:I

    const/16 v0, 0x9

    aget v0, v6, v0

    sput v0, Lg;->as:I

    const/16 v0, 0xa

    aget v0, v6, v0

    if-ne v0, v2, :cond_58f

    move v0, v2

    :goto_50
    sput-boolean v0, Lg;->O:Z

    const/16 v0, 0xb

    aget v0, v6, v0

    if-ne v0, v2, :cond_592

    move v0, v2

    :goto_59
    sput-boolean v0, Lg;->bm:Z

    const/16 v0, 0xc

    aget v0, v6, v0

    if-ne v0, v2, :cond_595

    move v0, v2

    :goto_62
    sput-boolean v0, Lq;->c:Z

    const/16 v0, 0xd

    aget v0, v6, v0

    if-ne v0, v2, :cond_598

    move v0, v2

    :goto_6b
    sput-boolean v0, Lq;->d:Z

    const/16 v0, 0xe

    aget v0, v6, v0

    if-ne v0, v2, :cond_59b

    move v0, v2

    :goto_74
    sput-boolean v0, Lq;->e:Z

    const/16 v0, 0xf

    aget v0, v6, v0

    if-ne v0, v2, :cond_59e

    move v0, v2

    :goto_7d
    sput-boolean v0, Lq;->f:Z

    const/16 v0, 0x10

    aget v0, v6, v0

    if-ne v0, v2, :cond_5a1

    move v0, v2

    :goto_86
    sput-boolean v0, Lq;->g:Z

    const/16 v0, 0x11

    aget v0, v6, v0

    if-ne v0, v2, :cond_5a4

    move v0, v2

    :goto_8f
    sput-boolean v0, Lq;->h:Z

    const/16 v4, 0x12

    const/16 v3, 0x13

    sget-boolean v0, Ln;->a:Z

    if-eqz v0, :cond_5a7

    move v0, v2

    :goto_9a
    aput v0, v6, v4

    move v0, v3

    move v4, v1

    :goto_9e
    sget-object v3, Lq;->bt:[Z

    array-length v3, v3

    if-lt v4, v3, :cond_5aa

    move v4, v1

    :goto_a4
    sget-object v3, Lq;->br:[I

    array-length v3, v3

    if-lt v4, v3, :cond_5bc

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    if-ne v0, v2, :cond_5c9

    move v0, v2

    :goto_b0
    sput-boolean v0, Lg;->f:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5cc

    move v0, v2

    :goto_b9
    sput-boolean v0, Lg;->i:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_5cf

    move v0, v2

    :goto_c2
    sput-boolean v0, Lg;->h:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5d2

    move v0, v2

    :goto_cb
    sput-boolean v0, Lg;->g:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_5d5

    move v0, v2

    :goto_d4
    sput-boolean v0, Lq;->au:Z

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aq:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->ar:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->at:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->au:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->av:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aw:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->ax:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->ay:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->az:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aA:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aB:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aC:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aD:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aE:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aF:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aG:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aH:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aI:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aJ:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aK:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aL:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aM:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aN:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aO:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aP:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aQ:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aR:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aS:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aT:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aU:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aV:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aW:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aX:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    if-ne v0, v2, :cond_5d8

    move v0, v2

    :goto_1a3
    sput-boolean v0, Lg;->aY:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5db

    move v0, v2

    :goto_1ac
    sput-boolean v0, Lg;->aZ:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_5de

    move v0, v2

    :goto_1b5
    sput-boolean v0, Lg;->ba:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5e1

    move v0, v2

    :goto_1be
    sput-boolean v0, Lg;->bb:Z

    add-int/lit8 v0, v4, 0x1

    aget v3, v6, v4

    sput v3, Lg;->bc:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bd:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->be:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    if-ne v0, v2, :cond_5e4

    move v0, v2

    :goto_1d9
    sput-boolean v0, Lg;->bf:Z

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bh:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bi:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bj:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bk:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bl:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->ed:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->ee:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->av:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->aw:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->ax:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->ef:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->eg:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->eh:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->ei:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->ay:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->az:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->ej:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->ek:I

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5e7

    move v0, v2

    :goto_24e
    sput-boolean v0, Lq;->aN:Z

    add-int/lit8 v0, v4, 0x1

    aget v3, v6, v4

    sput v3, Lq;->aM:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->aO:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->aE:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->es:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->et:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->eu:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->ev:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->ew:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->ex:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->ey:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->aF:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->R:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->S:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->T:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->U:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->V:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->W:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->X:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->Y:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->Z:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->aa:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->ab:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->ac:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->ad:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->ae:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->af:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->ag:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->ah:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->ai:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->aj:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->ak:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->al:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->am:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->an:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bo:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bp:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bq:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->br:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bs:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bt:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bu:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bv:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bw:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bx:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->by:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bz:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bA:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bB:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bC:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bD:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bE:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bF:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bG:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bH:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bI:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bJ:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bK:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    if-ne v0, v2, :cond_5ea

    move v0, v2

    :goto_3ad
    sput-boolean v0, Lq;->i:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5ed

    move v0, v2

    :goto_3b6
    sput-boolean v0, Lq;->j:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_5f0

    move v0, v2

    :goto_3bf
    sput-boolean v0, Lq;->k:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5f3

    move v0, v2

    :goto_3c8
    sput-boolean v0, Lq;->l:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_5f6

    move v0, v2

    :goto_3d1
    sput-boolean v0, Lq;->m:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5f9

    move v0, v2

    :goto_3da
    sput-boolean v0, Lq;->n:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_5fc

    move v0, v2

    :goto_3e3
    sput-boolean v0, Lq;->o:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_5ff

    move v0, v2

    :goto_3ec
    sput-boolean v0, Lq;->p:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_602

    move v0, v2

    :goto_3f5
    sput-boolean v0, Lq;->q:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_605

    move v0, v2

    :goto_3fe
    sput-boolean v0, Lq;->r:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_608

    move v0, v2

    :goto_407
    sput-boolean v0, Lq;->s:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_60b

    move v0, v2

    :goto_410
    sput-boolean v0, Lq;->t:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_60e

    move v0, v2

    :goto_419
    sput-boolean v0, Lq;->bA:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_611

    move v0, v2

    :goto_422
    sput-boolean v0, Lg;->j:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_614

    move v0, v2

    :goto_42b
    sput-boolean v0, Lg;->k:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_617

    move v0, v2

    :goto_434
    sput-boolean v0, Lg;->l:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_61a

    move v0, v2

    :goto_43d
    sput-boolean v0, Lt;->m:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_61d

    move v0, v2

    :goto_446
    sput-boolean v0, Lg;->m:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_620

    move v0, v2

    :goto_44f
    sput-boolean v0, Lg;->n:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_623

    move v0, v2

    :goto_458
    sput-boolean v0, Lg;->o:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_626

    move v0, v2

    :goto_461
    sput-boolean v0, Lg;->p:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_629

    move v0, v2

    :goto_46a
    sput-boolean v0, Lg;->r:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_62c

    move v0, v2

    :goto_473
    sput-boolean v0, Lg;->s:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_62f

    move v0, v2

    :goto_47c
    sput-boolean v0, Lg;->t:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_632

    move v0, v2

    :goto_485
    sput-boolean v0, Lg;->u:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_635

    move v0, v2

    :goto_48e
    sput-boolean v0, Lg;->q:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_638

    move v0, v2

    :goto_497
    sput-boolean v0, Lg;->v:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_63b

    move v0, v2

    :goto_4a0
    sput-boolean v0, Lg;->w:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_63e

    move v0, v2

    :goto_4a9
    sput-boolean v0, Lg;->x:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_641

    move v0, v2

    :goto_4b2
    sput-boolean v0, Lg;->y:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_644

    move v0, v2

    :goto_4bb
    sput-boolean v0, Lg;->z:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_647

    move v0, v2

    :goto_4c4
    sput-boolean v0, Lg;->A:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_64a

    move v0, v2

    :goto_4cd
    sput-boolean v0, Lg;->B:Z

    add-int/lit8 v4, v3, 0x1

    aget v0, v6, v3

    if-ne v0, v2, :cond_64d

    move v0, v2

    :goto_4d6
    sput-boolean v0, Lg;->C:Z

    add-int/lit8 v3, v4, 0x1

    aget v0, v6, v4

    if-ne v0, v2, :cond_650

    move v0, v2

    :goto_4df
    sput-boolean v0, Lm;->g:Z

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->D:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    if-ne v0, v2, :cond_653

    move v0, v2

    :goto_4ee
    sput-boolean v0, Lq;->aA:Z

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lq;->el:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->aB:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    sput v3, Lg;->bL:I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->bn:I

    add-int/lit8 v0, v3, 0x1

    aget v3, v6, v3

    if-ne v3, v2, :cond_656

    :goto_50e
    sput-boolean v2, Lg;->ap:Z

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    sput v0, Lg;->a:I

    add-int/lit8 v3, v2, 0x1

    aget v0, v6, v2

    sput v0, Lq;->bi:I

    add-int/lit8 v0, v3, 0x1

    aget v2, v6, v3

    sput v2, Lq;->bh:I

    move v2, v5

    :goto_523
    if-lt v2, v8, :cond_659

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    sput v0, Lq;->aW:I

    if-lez v0, :cond_55d

    add-int/lit8 v0, v2, 0x1

    aget v2, v6, v2

    sput v2, Lq;->aX:I

    move v3, v1

    :goto_534
    :try_start_534
    sget-object v2, Lq;->ba:[I

    array-length v2, v2

    if-lt v3, v2, :cond_690

    move v3, v1

    :goto_53a
    sget-object v2, Lq;->eM:[I

    array-length v2, v2

    if-lt v3, v2, :cond_69d

    move v3, v1

    :goto_540
    sget-object v2, Lq;->eL:[I

    array-length v2, v2

    if-lt v3, v2, :cond_6aa

    move v3, v1

    :goto_546
    sget-object v2, Lq;->bb:[I

    array-length v2, v2

    if-lt v3, v2, :cond_6b7

    move v3, v1

    :goto_54c
    sget-object v2, Lq;->bc:[I

    array-length v2, v2

    if-lt v3, v2, :cond_6c4

    move v3, v1

    :goto_552
    sget-object v2, Lq;->aY:[I

    array-length v2, v2

    if-lt v3, v2, :cond_6d1

    move v2, v1

    :goto_558
    sget-object v1, Lq;->aZ:[I

    array-length v1, v1
    :try_end_55b
    .catch Ljava/lang/Exception; {:try_start_534 .. :try_end_55b} :catch_6eb

    if-lt v2, v1, :cond_6de

    :cond_55d
    :goto_55d
    return-void

    :cond_55e
    shl-int/lit8 v4, v0, 0x2

    aget-byte v4, v3, v4

    shl-int/lit8 v4, v4, 0x18

    shl-int/lit8 v7, v0, 0x2

    add-int/lit8 v7, v7, 0x1

    aget-byte v7, v3, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x10

    add-int/2addr v4, v7

    shl-int/lit8 v7, v0, 0x2

    add-int/lit8 v7, v7, 0x2

    aget-byte v7, v3, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x8

    add-int/2addr v4, v7

    shl-int/lit8 v7, v0, 0x2

    add-int/lit8 v7, v7, 0x3

    aget-byte v7, v3, v7

    and-int/lit16 v7, v7, 0xff

    add-int/2addr v4, v7

    aput v4, v6, v0

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_10

    :cond_589
    move v0, v1

    goto/16 :goto_18

    :cond_58c
    move v0, v1

    goto/16 :goto_32

    :cond_58f
    move v0, v1

    goto/16 :goto_50

    :cond_592
    move v0, v1

    goto/16 :goto_59

    :cond_595
    move v0, v1

    goto/16 :goto_62

    :cond_598
    move v0, v1

    goto/16 :goto_6b

    :cond_59b
    move v0, v1

    goto/16 :goto_74

    :cond_59e
    move v0, v1

    goto/16 :goto_7d

    :cond_5a1
    move v0, v1

    goto/16 :goto_86

    :cond_5a4
    move v0, v1

    goto/16 :goto_8f

    :cond_5a7
    move v0, v1

    goto/16 :goto_9a

    :cond_5aa
    sget-object v7, Lq;->bt:[Z

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    if-ne v0, v2, :cond_5ba

    move v0, v2

    :goto_5b3
    aput-boolean v0, v7, v4

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_9e

    :cond_5ba
    move v0, v1

    goto :goto_5b3

    :cond_5bc
    sget-object v7, Lq;->br:[I

    add-int/lit8 v3, v0, 0x1

    aget v0, v6, v0

    aput v0, v7, v4

    add-int/lit8 v4, v4, 0x1

    move v0, v3

    goto/16 :goto_a4

    :cond_5c9
    move v0, v1

    goto/16 :goto_b0

    :cond_5cc
    move v0, v1

    goto/16 :goto_b9

    :cond_5cf
    move v0, v1

    goto/16 :goto_c2

    :cond_5d2
    move v0, v1

    goto/16 :goto_cb

    :cond_5d5
    move v0, v1

    goto/16 :goto_d4

    :cond_5d8
    move v0, v1

    goto/16 :goto_1a3

    :cond_5db
    move v0, v1

    goto/16 :goto_1ac

    :cond_5de
    move v0, v1

    goto/16 :goto_1b5

    :cond_5e1
    move v0, v1

    goto/16 :goto_1be

    :cond_5e4
    move v0, v1

    goto/16 :goto_1d9

    :cond_5e7
    move v0, v1

    goto/16 :goto_24e

    :cond_5ea
    move v0, v1

    goto/16 :goto_3ad

    :cond_5ed
    move v0, v1

    goto/16 :goto_3b6

    :cond_5f0
    move v0, v1

    goto/16 :goto_3bf

    :cond_5f3
    move v0, v1

    goto/16 :goto_3c8

    :cond_5f6
    move v0, v1

    goto/16 :goto_3d1

    :cond_5f9
    move v0, v1

    goto/16 :goto_3da

    :cond_5fc
    move v0, v1

    goto/16 :goto_3e3

    :cond_5ff
    move v0, v1

    goto/16 :goto_3ec

    :cond_602
    move v0, v1

    goto/16 :goto_3f5

    :cond_605
    move v0, v1

    goto/16 :goto_3fe

    :cond_608
    move v0, v1

    goto/16 :goto_407

    :cond_60b
    move v0, v1

    goto/16 :goto_410

    :cond_60e
    move v0, v1

    goto/16 :goto_419

    :cond_611
    move v0, v1

    goto/16 :goto_422

    :cond_614
    move v0, v1

    goto/16 :goto_42b

    :cond_617
    move v0, v1

    goto/16 :goto_434

    :cond_61a
    move v0, v1

    goto/16 :goto_43d

    :cond_61d
    move v0, v1

    goto/16 :goto_446

    :cond_620
    move v0, v1

    goto/16 :goto_44f

    :cond_623
    move v0, v1

    goto/16 :goto_458

    :cond_626
    move v0, v1

    goto/16 :goto_461

    :cond_629
    move v0, v1

    goto/16 :goto_46a

    :cond_62c
    move v0, v1

    goto/16 :goto_473

    :cond_62f
    move v0, v1

    goto/16 :goto_47c

    :cond_632
    move v0, v1

    goto/16 :goto_485

    :cond_635
    move v0, v1

    goto/16 :goto_48e

    :cond_638
    move v0, v1

    goto/16 :goto_497

    :cond_63b
    move v0, v1

    goto/16 :goto_4a0

    :cond_63e
    move v0, v1

    goto/16 :goto_4a9

    :cond_641
    move v0, v1

    goto/16 :goto_4b2

    :cond_644
    move v0, v1

    goto/16 :goto_4bb

    :cond_647
    move v0, v1

    goto/16 :goto_4c4

    :cond_64a
    move v0, v1

    goto/16 :goto_4cd

    :cond_64d
    move v0, v1

    goto/16 :goto_4d6

    :cond_650
    move v0, v1

    goto/16 :goto_4df

    :cond_653
    move v0, v1

    goto/16 :goto_4ee

    :cond_656
    move v2, v1

    goto/16 :goto_50e

    :cond_659
    sget-object v3, Lq;->bf:[I

    add-int/lit8 v4, v0, 0x1

    aget v0, v6, v0

    aput v0, v3, v2

    sget-object v0, Lq;->bf:[I

    aget v0, v0, v2

    packed-switch v0, :pswitch_data_6ee

    :goto_668
    sget-object v3, Lq;->bs:[I

    add-int/lit8 v0, v4, 0x1

    aget v4, v6, v4

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_523

    :pswitch_674  #0x1
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    const-string v3, "Gươm sét"

    aput-object v3, v0, v2

    goto :goto_668

    :pswitch_67b  #0x2
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    const-string v3, "Gươm lửa"

    aput-object v3, v0, v2

    goto :goto_668

    :pswitch_682  #0x3
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    const-string v3, "Gươm băng"

    aput-object v3, v0, v2

    goto :goto_668

    :pswitch_689  #0x4
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    const-string v3, "Gươm hỏa long"

    aput-object v3, v0, v2

    goto :goto_668

    :cond_690
    :try_start_690
    sget-object v4, Lq;->ba:[I

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    aput v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    move v0, v2

    goto/16 :goto_534

    :cond_69d
    sget-object v4, Lq;->eM:[I

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    aput v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    move v0, v2

    goto/16 :goto_53a

    :cond_6aa
    sget-object v4, Lq;->eL:[I

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    aput v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    move v0, v2

    goto/16 :goto_540

    :cond_6b7
    sget-object v4, Lq;->bb:[I

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    aput v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    move v0, v2

    goto/16 :goto_546

    :cond_6c4
    sget-object v4, Lq;->bc:[I

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    aput v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    move v0, v2

    goto/16 :goto_54c

    :cond_6d1
    sget-object v4, Lq;->aY:[I

    add-int/lit8 v2, v0, 0x1

    aget v0, v6, v0

    aput v0, v4, v3

    add-int/lit8 v3, v3, 0x1

    move v0, v2

    goto/16 :goto_552

    :cond_6de
    sget-object v3, Lq;->aZ:[I

    add-int/lit8 v1, v0, 0x1

    aget v0, v6, v0

    aput v0, v3, v2
    :try_end_6e6
    .catch Ljava/lang/Exception; {:try_start_690 .. :try_end_6e6} :catch_6eb

    add-int/lit8 v2, v2, 0x1

    move v0, v1

    goto/16 :goto_558

    :catch_6eb
    move-exception v0

    goto/16 :goto_55d

    :pswitch_data_6ee
    .packed-switch 0x1
        :pswitch_674  #00000001
        :pswitch_67b  #00000002
        :pswitch_682  #00000003
        :pswitch_689  #00000004
    .end packed-switch
.end method

.method public static a([Ljava/lang/String;III)V
    .registers 11

    const/16 v2, 0x78

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v1, 0x0

    sput p1, Lq;->eQ:I

    sput p2, Lq;->eS:I

    sput p3, Lq;->eT:I

    array-length v0, p0

    sput v0, Lq;->eO:I

    sput v1, Lq;->eP:I

    sget v0, Lq;->eO:I

    new-array v0, v0, [[Ljava/lang/String;

    sput-object v0, Lq;->eR:[[Ljava/lang/String;

    if-ne p1, v5, :cond_56

    sget v0, Lq;->ab:I

    add-int/lit8 v0, v0, -0x2

    sput v0, Lq;->eW:I

    sput v1, Lq;->ay:I

    :goto_20
    sget v0, Lq;->eW:I

    if-ge v0, v2, :cond_26

    sput v2, Lq;->eW:I

    :cond_26
    move v0, v1

    :goto_27
    sget v2, Lq;->eO:I

    if-lt v0, v2, :cond_5d

    sget v0, Lq;->eS:I

    sget v2, Lq;->eW:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v0, v2

    sget v2, Lq;->ay:I

    sub-int/2addr v0, v2

    sput v0, Lq;->eX:I

    if-ge v0, v6, :cond_3b

    sput v6, Lq;->eX:I

    :cond_3b
    sget v0, Lq;->eX:I

    sget v2, Lq;->eW:I

    add-int/2addr v0, v2

    sget v2, Lq;->ab:I

    add-int/lit8 v2, v2, -0x2

    if-le v0, v2, :cond_4f

    sget v0, Lq;->ab:I

    add-int/lit8 v0, v0, -0x2

    sget v2, Lq;->eW:I

    sub-int/2addr v0, v2

    sput v0, Lq;->eX:I

    :cond_4f
    sput-boolean v5, Lq;->bd:Z

    sput v1, Lq;->eU:I

    sput v1, Lq;->eV:I

    return-void

    :cond_56
    sget v0, Lq;->ab:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eW:I

    goto :goto_20

    :cond_5d
    sget-object v2, Lq;->eR:[[Ljava/lang/String;

    aget-object v3, p0, v0

    sget v4, Lq;->eW:I

    add-int/lit8 v4, v4, -0x14

    invoke-static {v3, v4}, LMidlet;->b(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_27
.end method

.method private static a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;
    .registers 9

    const/4 v6, -0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    invoke-virtual {p0, p1, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v0

    move v2, v1

    :goto_b
    if-ne v0, v6, :cond_24

    add-int/lit8 v0, v2, 0x1

    new-array v5, v0, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v3

    move v0, v1

    move v2, v1

    :goto_17
    if-ne v3, v6, :cond_2c

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v5, v0

    return-object v5

    :cond_24
    add-int/2addr v0, v4

    invoke-virtual {p0, p1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v0

    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_2c
    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v5, v0

    add-int v1, v3, v4

    invoke-virtual {p0, p1, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    add-int/lit8 v0, v0, 0x1

    move v2, v1

    goto :goto_17
.end method

.method static b()V
    .registers 3

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    const/16 v2, 0xe

    if-lt v0, v2, :cond_7

    return-void

    :cond_7
    sget-object v2, Lq;->C:[Z

    aput-boolean v1, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2
.end method

.method public static final b(I)V
    .registers 9

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x0

    sput v1, Lq;->cv:I

    if-nez p0, :cond_a

    sput v1, Lq;->cv:I

    :cond_9
    return-void

    :cond_a
    sget-object v0, Lq;->dJ:[[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_1f

    filled-new-array {v7, v6}, [I

    move-result-object v0

    const-class v2, Ljavax/microedition/lcdui/Image;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dJ:[[Ljavax/microedition/lcdui/Image;

    move v2, v1

    :goto_1d
    if-lt v2, v7, :cond_52

    :cond_1f
    const/16 v0, 0xa

    sput v0, Lq;->cv:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cw:[I

    sget v0, Lq;->cv:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cx:[I

    sget v0, Lq;->cv:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cy:[I

    sget v0, Lq;->cv:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cz:[I

    sget v0, Lq;->cv:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cA:[I

    sget v0, Lq;->cv:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cB:[I

    move v0, v1

    :goto_46
    sget v1, Lq;->cv:I

    if-ge v0, v1, :cond_9

    sget-object v1, Lq;->cy:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_46

    :cond_52
    move v0, v1

    :goto_53
    if-lt v0, v6, :cond_59

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_1d

    :cond_59
    :try_start_59
    sget-object v3, Lq;->dJ:[[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v2

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/c/ar"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v0
    :try_end_7c
    .catch Ljava/io/IOException; {:try_start_59 .. :try_end_7c} :catch_7f

    :goto_7c
    add-int/lit8 v0, v0, 0x1

    goto :goto_53

    :catch_7f
    move-exception v3

    goto :goto_7c
.end method

.method public static b(II)V
    .registers 3

    const/4 v0, 0x1

    sput v0, Lq;->dF:I

    sput p0, Lq;->dD:I

    sput p1, Lq;->dE:I

    return-void
.end method

.method private static b(IIII)V
    .registers 4

    sput p0, Lq;->aE:I

    sput p1, Lq;->es:I

    sput p2, Lq;->et:I

    sput p3, Lq;->aF:I

    return-void
.end method

.method public static final b(IIIII)V
    .registers 8

    const/4 v1, -0x1

    const/4 v0, 0x0

    :goto_2
    sget v2, Lq;->cv:I

    if-lt v0, v2, :cond_a

    move v0, v1

    :cond_7
    if-ne v0, v1, :cond_13

    :goto_9
    return-void

    :cond_a
    sget-object v2, Lq;->cy:[I

    aget v2, v2, v0

    if-eq v2, v1, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_13
    sget-object v1, Lq;->cy:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->cw:[I

    aput p0, v1, v0

    sget-object v1, Lq;->cx:[I

    aput p1, v1, v0

    sget-object v1, Lq;->cz:[I

    aput p2, v1, v0

    sget-object v1, Lq;->cA:[I

    aput p3, v1, v0

    sget-object v1, Lq;->cB:[I

    aput p4, v1, v0

    goto :goto_9
.end method

.method public static b(Ljava/lang/String;)V
    .registers 3

    const/16 v0, 0x64

    invoke-static {p0, v0}, LMidlet;->a(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lq;->gh:[Ljava/lang/String;

    sget v0, Lq;->ae:I

    sget-object v1, Lq;->gh:[Ljava/lang/String;

    array-length v1, v1

    mul-int/lit8 v1, v1, 0x9

    sub-int/2addr v0, v1

    sput v0, Lq;->bv:I

    return-void
.end method

.method private static b(Ljavax/microedition/lcdui/Graphics;)V
    .registers 9

    const/16 v7, 0x18

    const/16 v4, 0x17

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget-boolean v0, Lq;->cb:Z

    if-eqz v0, :cond_c

    :goto_b
    return-void

    :cond_c
    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p0, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    sget-object v0, Lg;->N:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v5

    invoke-virtual {p0, v0, v5, v2, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    invoke-virtual {p0, v5}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->cl:I

    add-int/lit8 v0, v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, v4, v2, v0, v1}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const/16 v0, 0x8

    sget v1, Lq;->cl:I

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, v4, v0, v1, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const/16 v0, 0xe

    sget v1, Lq;->cl:I

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {p0, v4, v0, v1, v6}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const/high16 v0, 0xff0000

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lg;->aL:I

    sget v1, Lq;->cl:I

    mul-int/2addr v0, v1

    sget v1, Lg;->aM:I

    div-int/2addr v0, v1

    invoke-virtual {p0, v7, v6, v0, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/high16 v1, 0x550000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    add-int/lit8 v1, v0, 0x18

    sget v3, Lq;->cl:I

    sub-int v0, v3, v0

    invoke-virtual {p0, v1, v6, v0, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/16 v0, 0xff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lg;->aN:I

    sget v1, Lq;->cl:I

    mul-int/2addr v0, v1

    sget v1, Lg;->aO:I

    div-int/2addr v0, v1

    const/16 v1, 0x9

    invoke-virtual {p0, v7, v1, v0, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/high16 v1, 0x550000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    add-int/lit8 v1, v0, 0x18

    const/16 v3, 0x9

    sget v4, Lq;->cl:I

    sub-int v0, v4, v0

    invoke-virtual {p0, v1, v3, v0, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x6effc3

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lg;->aX:I

    sget v1, Lq;->cl:I

    mul-int/2addr v0, v1

    sget-object v1, Lg;->c:[I

    sget v3, Lg;->aW:I

    add-int/lit8 v3, v3, -0x1

    aget v1, v1, v3

    div-int/2addr v0, v1

    const/16 v1, 0xf

    invoke-virtual {p0, v7, v1, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/16 v1, 0x4c32

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    add-int/lit8 v1, v0, 0x18

    const/16 v3, 0xf

    sget v4, Lq;->cl:I

    sub-int v0, v4, v0

    invoke-virtual {p0, v1, v3, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "lv:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lg;->aW:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    sget v3, Lq;->cn:I

    const/4 v4, 0x7

    move-object v0, p0

    invoke-static/range {v0 .. v5}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    sget v1, Lq;->aj:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, "$"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    sget v3, Lq;->co:I

    const/4 v4, 0x7

    move-object v0, p0

    invoke-static/range {v0 .. v5}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    goto/16 :goto_b
.end method

.method public static final b(III)Z
    .registers 8

    const/4 v2, 0x1

    const/4 v1, 0x0

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_7

    :cond_6
    :goto_6
    return v1

    :cond_7
    if-ne p0, v2, :cond_1f

    move v0, v1

    :goto_a
    sget-object v3, Lq;->cU:[I

    aget v3, v3, v0

    const/4 v4, -0x1

    if-ne v3, v4, :cond_6

    sget-object v3, Lq;->cU:[I

    aput v1, v3, v0

    sget-object v1, Lq;->cS:[I

    aput p1, v1, v0

    sget-object v1, Lq;->cT:[I

    aput p2, v1, v0

    move v1, v2

    goto :goto_6

    :cond_1f
    move v0, v2

    goto :goto_a
.end method

.method static c()V
    .registers 3

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    const/16 v2, 0xe

    if-lt v0, v2, :cond_7

    return-void

    :cond_7
    sget-object v2, Lq;->D:[Z

    aput-boolean v1, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2
.end method

.method public static final c(I)V
    .registers 5

    const/4 v2, 0x1

    const/4 v1, 0x0

    sput v1, Lq;->aP:I

    sget v0, Lq;->aQ:I

    const/4 v3, -0x1

    if-ne v0, v3, :cond_40

    move v0, v1

    :goto_a
    if-ne v0, v2, :cond_22

    sput v2, Lq;->aP:I

    invoke-static {}, Lq;->C()V

    sget v2, Lg;->at:I

    sget v3, Lg;->au:I

    invoke-static {v1, v2, v3}, Lq;->d(III)V

    sput v1, Lq;->aQ:I

    sget-object v1, Lq;->aT:[I

    sget v2, Lq;->aQ:I

    sget v3, Lg;->aF:I

    aput v3, v1, v2

    :cond_22
    const/16 v1, 0x6c

    if-ne p0, v1, :cond_2c

    const/16 v1, 0x24

    const/4 v2, 0x4

    invoke-static {v0, v1, v2}, Lq;->a(III)V

    :cond_2c
    const/16 v1, 0xd

    if-ne p0, v1, :cond_3f

    sget v1, Lq;->aP:I

    if-nez v1, :cond_3f

    sget-boolean v1, Lg;->bm:Z

    if-eqz v1, :cond_3f

    const/16 v1, 0xa

    const/16 v2, 0xb

    invoke-static {v0, v1, v2}, Lq;->a(III)V

    :cond_3f
    return-void

    :cond_40
    move v0, v2

    goto :goto_a
.end method

.method private static c(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x1

    sput-boolean v9, Lq;->J:Z

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p0, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    const/4 v0, -0x1

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, -0x1

    sget v3, Lq;->ce:I

    add-int/lit8 v3, v3, 0x2

    const/16 v4, 0x64

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-virtual {p0, v9}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-boolean v0, Lq;->cb:Z

    if-nez v0, :cond_49

    sget v0, Lq;->cd:I

    sget v1, Lq;->ce:I

    const/16 v3, 0xf

    invoke-virtual {p0, v9, v0, v1, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lq;->U:Ljava/lang/String;

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x3

    invoke-static {p0, v0, v10, v1, v9}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->V:Ljava/lang/String;

    sget v1, Lq;->ce:I

    add-int/lit8 v1, v1, -0x3

    sget v3, Lq;->cd:I

    add-int/lit8 v3, v3, 0x3

    invoke-static {p0, v0, v1, v3, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :goto_48
    return-void

    :cond_49
    sget v0, Lq;->cd:I

    add-int/lit8 v0, v0, 0x21

    sget v1, Lq;->ce:I

    const/16 v3, 0xf

    invoke-virtual {p0, v9, v0, v1, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lq;->U:Ljava/lang/String;

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x24

    invoke-static {p0, v0, v10, v1, v9}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->V:Ljava/lang/String;

    sget v1, Lq;->ce:I

    add-int/lit8 v1, v1, -0x3

    sget v3, Lq;->cd:I

    add-int/lit8 v3, v3, 0x24

    invoke-static {p0, v0, v1, v3, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const/16 v0, 0x1100

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x23

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x21

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1e

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1c

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1a

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0xc

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x18

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x12

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x10

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x2

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x4

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x6

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0xe

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0xbfae62

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x5

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x11

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x22

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1d

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0xdfcd9f

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x3

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0xf

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1b

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x333333

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x7

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x13

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x1f

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v5}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x90653b

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0x19

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->cg:I

    sget v1, Lq;->cd:I

    add-int/lit8 v1, v1, 0xd

    sget v3, Lq;->ci:I

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v9

    sget v1, Lq;->cd:I

    invoke-virtual {p0, v0, v9, v1, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v2

    sget v1, Lq;->ce:I

    add-int/lit8 v1, v1, 0x0

    sget v3, Lq;->cd:I

    const/16 v4, 0x18

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget v0, Lg;->aL:I

    sget v1, Lq;->cl:I

    mul-int/2addr v0, v1

    sget v1, Lg;->aM:I

    div-int/2addr v0, v1

    const/high16 v1, 0x770000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->cj:I

    sget v3, Lq;->ck:I

    invoke-virtual {p0, v1, v3, v0, v5}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/high16 v1, 0xcc0000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->cj:I

    sget v3, Lq;->ck:I

    add-int/lit8 v3, v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0, v1, v3, v0, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lg;->aN:I

    sget v1, Lq;->cl:I

    mul-int/2addr v0, v1

    sget v1, Lg;->aO:I

    div-int/2addr v0, v1

    const/16 v1, 0x77

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->cj:I

    sget v3, Lq;->ck:I

    add-int/lit8 v3, v3, 0xc

    invoke-virtual {p0, v1, v3, v0, v5}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/16 v1, 0xcc

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->cj:I

    sget v3, Lq;->ck:I

    add-int/lit8 v3, v3, 0xe

    sget v4, Lq;->cp:I

    add-int/lit8 v4, v4, -0x2

    invoke-virtual {p0, v1, v3, v0, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    sget v1, Lq;->aj:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    sget v0, Lq;->ce:I

    add-int/lit8 v3, v0, -0x12

    sget v0, Lq;->cd:I

    add-int/lit8 v4, v0, 0x6

    move-object v0, p0

    invoke-static/range {v0 .. v5}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    sget v0, Lg;->aX:I

    sget v1, Lq;->cm:I

    mul-int/2addr v0, v1

    sget-object v1, Lg;->c:[I

    sget v3, Lg;->aW:I

    add-int/lit8 v3, v3, -0x1

    aget v1, v1, v3

    div-int/2addr v0, v1

    const v1, 0x170a5

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/16 v1, 0x1f

    sget v3, Lq;->cd:I

    add-int/lit8 v3, v3, 0x1f

    invoke-virtual {p0, v1, v3, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0xffff

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/16 v1, 0x1f

    sget v3, Lq;->cd:I

    add-int/lit8 v3, v3, 0x20

    invoke-virtual {p0, v1, v3, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    sget v1, Lg;->aW:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0x1a

    sget v0, Lq;->cd:I

    add-int/lit8 v7, v0, 0xb

    move-object v3, p0

    move v8, v5

    invoke-static/range {v3 .. v8}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    sget-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    sget v1, Lg;->ar:I

    aget-object v0, v0, v1

    const/16 v1, 0x2b

    sget v3, Lq;->cd:I

    add-int/lit8 v3, v3, 0x10

    invoke-virtual {p0, v0, v1, v3, v10}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    sget-object v1, Lq;->br:[I

    aget v1, v1, v9

    sget-object v3, Lq;->br:[I

    aget v2, v3, v2

    add-int/2addr v1, v2

    sget-object v2, Lq;->br:[I

    aget v2, v2, v5

    add-int/2addr v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    sget v0, Lq;->ce:I

    add-int/lit8 v6, v0, -0x1d

    sget v0, Lq;->cd:I

    add-int/lit8 v7, v0, 0x13

    move-object v3, p0

    move v8, v5

    invoke-static/range {v3 .. v8}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    sget-object v1, Lq;->br:[I

    aget v1, v1, v10

    sget-object v2, Lq;->br:[I

    const/4 v3, 0x4

    aget v2, v2, v3

    add-int/2addr v1, v2

    sget-object v2, Lq;->br:[I

    aget v2, v2, v11

    add-int/2addr v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    sget v0, Lq;->ce:I

    add-int/lit8 v6, v0, -0x9

    sget v0, Lq;->cd:I

    add-int/lit8 v7, v0, 0x13

    move-object v3, p0

    move v8, v5

    invoke-static/range {v3 .. v8}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    goto/16 :goto_48
.end method

.method public static final c(II)Z
    .registers 7

    const/4 v2, 0x1

    const/4 v4, -0x1

    const/4 v1, 0x0

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_8

    :cond_7
    :goto_7
    return v1

    :cond_8
    sget-object v0, Lq;->cQ:[I

    aget v0, v0, v1

    if-ne v0, v4, :cond_23

    move v0, v1

    :goto_f
    sget-object v3, Lq;->cQ:[I

    aget v3, v3, v0

    if-ne v3, v4, :cond_7

    sget-object v3, Lq;->cQ:[I

    aput v1, v3, v0

    sget-object v1, Lq;->cO:[I

    aput p0, v1, v0

    sget-object v1, Lq;->cP:[I

    aput p1, v1, v0

    move v1, v2

    goto :goto_7

    :cond_23
    move v0, v2

    goto :goto_f
.end method

.method public static final c(III)Z
    .registers 8

    const/4 v2, 0x1

    const/4 v4, -0x1

    const/4 v1, 0x0

    sget-object v0, Lq;->cL:[I

    aget v0, v0, v1

    if-ne v0, v4, :cond_11

    move v0, v1

    :goto_a
    sget-object v3, Lq;->cL:[I

    aget v3, v3, v0

    if-eq v3, v4, :cond_13

    :goto_10
    return v1

    :cond_11
    move v0, v2

    goto :goto_a

    :cond_13
    sget-object v3, Lq;->cL:[I

    aput v1, v3, v0

    sget-object v1, Lq;->cN:[I

    aput p2, v1, v0

    sget-object v1, Lq;->cJ:[I

    aput p0, v1, v0

    sget-object v1, Lq;->cK:[I

    aput p1, v1, v0

    move v1, v2

    goto :goto_10
.end method

.method public static d()V
    .registers 5

    const/4 v4, 0x4

    sget-object v0, Lq;->dK:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dK:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    :goto_a
    if-lt v0, v4, :cond_d

    :cond_c
    return-void

    :cond_d
    :try_start_d
    sget-object v1, Lq;->dK:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/arr"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_2a} :catch_2d

    :goto_2a
    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :catch_2d
    move-exception v1

    goto :goto_2a
.end method

.method public static final d(I)V
    .registers 9

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x0

    sput v3, Lq;->aW:I

    const/4 v0, 0x4

    if-ne p0, v0, :cond_16

    sput v4, Lq;->aW:I

    invoke-static {}, Lq;->D()V

    const/16 v0, 0x34

    const/16 v1, 0x9

    invoke-static {v3, v0, v1}, Lq;->e(III)V

    :cond_16
    const/16 v0, 0x66

    if-ne p0, v0, :cond_33

    sput v5, Lq;->aW:I

    invoke-static {}, Lq;->D()V

    const/16 v0, 0xb

    invoke-static {v3, v5, v0}, Lq;->e(III)V

    const/16 v0, 0x8

    const/16 v1, 0xb

    invoke-static {v4, v0, v1}, Lq;->e(III)V

    const/4 v0, 0x2

    const/16 v1, 0x11

    const/16 v2, 0xb

    invoke-static {v0, v1, v2}, Lq;->e(III)V

    :cond_33
    if-ne p0, v5, :cond_5e

    sget-boolean v0, Lg;->n:Z

    if-eqz v0, :cond_5e

    sput v7, Lq;->aW:I

    invoke-static {}, Lq;->D()V

    const/16 v0, 0xd

    invoke-static {v3, v0, v6}, Lq;->e(III)V

    const/16 v0, 0xd

    invoke-static {v4, v0, v7}, Lq;->e(III)V

    const/4 v0, 0x2

    const/16 v1, 0xe

    invoke-static {v0, v1, v6}, Lq;->e(III)V

    const/16 v0, 0xe

    invoke-static {v5, v0, v7}, Lq;->e(III)V

    const/4 v0, 0x4

    const/16 v1, 0xf

    invoke-static {v0, v1, v6}, Lq;->e(III)V

    const/16 v0, 0xf

    invoke-static {v6, v0, v7}, Lq;->e(III)V

    :cond_5e
    const/16 v0, 0xe

    if-ne p0, v0, :cond_77

    sget-boolean v0, Lg;->w:Z

    if-nez v0, :cond_77

    sget v0, Lg;->D:I

    const/4 v1, 0x2

    if-ge v0, v1, :cond_77

    sput v4, Lq;->aW:I

    invoke-static {}, Lq;->D()V

    const/16 v0, 0x31

    const/16 v1, 0x12

    invoke-static {v3, v0, v1}, Lq;->e(III)V

    :cond_77
    return-void
.end method

.method private static d(III)V
    .registers 5

    sget-object v0, Lq;->aR:[I

    aput p1, v0, p0

    sget-object v0, Lq;->aS:[I

    aput p2, v0, p0

    sget-object v0, Lq;->aU:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    sget-object v0, Lq;->aT:[I

    const/4 v1, 0x1

    aput v1, v0, p0

    return-void
.end method

.method private static d(Ljavax/microedition/lcdui/Graphics;)V
    .registers 6

    const/4 v3, -0x1

    const/4 v0, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {p0, v1, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, 0x2

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, 0x2

    invoke-virtual {p0, v3, v3, v1, v2}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->ab:I

    sget v2, Lq;->cr:I

    invoke-virtual {p0, v0, v0, v1, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-boolean v1, Lq;->cb:Z

    if-eqz v1, :cond_40

    sget v1, Lq;->F:I

    sget v2, Lq;->cr:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x1

    sget v2, Lq;->ab:I

    sget v3, Lq;->cr:I

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :goto_36
    sget-boolean v1, Lq;->em:Z

    if-eqz v1, :cond_3f

    :goto_3a
    sget-object v1, Lq;->en:[Ljava/lang/String;

    array-length v1, v1

    if-lt v0, v1, :cond_4c

    :cond_3f
    return-void

    :cond_40
    sget v1, Lq;->F:I

    add-int/lit8 v1, v1, -0xd

    sget v2, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    goto :goto_36

    :cond_4c
    sget-object v1, Lq;->en:[Ljava/lang/String;

    aget-object v1, v1, v0

    sget v2, Lq;->ad:I

    sget v3, Lq;->eo:I

    shl-int/lit8 v4, v0, 0x4

    add-int/2addr v3, v4

    const/4 v4, 0x2

    invoke-static {p0, v1, v2, v3, v4}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3a
.end method

.method public static d(II)Z
    .registers 10

    const/4 v7, -0x5

    const/4 v0, 0x1

    const/16 v6, 0x32

    const/4 v1, 0x0

    sget v2, Lq;->eD:I

    if-eq v2, v0, :cond_e

    sget v2, Lq;->eD:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_7c

    :cond_e
    sget v2, Lq;->aK:I

    sub-int/2addr v2, p0

    sput v2, Lq;->aK:I

    if-gtz v2, :cond_69

    sput v1, Lq;->aK:I

    sput v7, Lq;->eH:I

    shl-int/lit8 v2, p1, 0x3

    neg-int v2, v2

    sput v2, Lq;->eC:I

    sput v1, Lq;->eJ:I

    const/4 v2, 0x6

    sput v2, Lq;->eD:I

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    const/4 v4, 0x4

    const/4 v5, -0x6

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    const/4 v4, -0x7

    invoke-static {v2, v3, v7, v4, v6}, Lq;->a(IIIII)V

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    const/4 v4, -0x4

    const/4 v5, -0x8

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    const/4 v4, 0x5

    const/16 v5, -0x9

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    const/16 v4, -0xa

    invoke-static {v2, v3, v1, v4, v6}, Lq;->a(IIIII)V

    sget v1, Lg;->bc:I

    if-ne v1, v0, :cond_68

    sget-boolean v1, Lg;->h:Z

    if-eqz v1, :cond_68

    sget v1, Lq;->aH:I

    sget v2, Lq;->aI:I

    invoke-static {v1, v2}, Lq;->a(II)V

    sget v1, Lq;->aH:I

    sget v2, Lq;->aI:I

    add-int/lit8 v2, v2, -0x1c

    invoke-static {v1, v2}, Lq;->b(II)V

    :cond_68
    :goto_68
    return v0

    :cond_69
    sput v1, Lq;->eH:I

    sput p1, Lq;->eE:I

    const/4 v0, 0x7

    sput v0, Lq;->eD:I

    const/16 v0, 0xa

    sput v0, Lq;->eJ:I

    sput v1, Lq;->eF:I

    sget v0, Lg;->aK:I

    if-gt p0, v0, :cond_7e

    sput v1, Lq;->eI:I

    :cond_7c
    :goto_7c
    move v0, v1

    goto :goto_68

    :cond_7e
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    add-int/lit8 v0, v0, 0x2

    sput v0, Lq;->eI:I

    goto :goto_7c
.end method

.method public static e(II)I
    .registers 4

    sget-object v0, Lq;->eY:Ljava/util/Random;

    sub-int v1, p1, p0

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    add-int/2addr v0, p0

    return v0
.end method

.method public static e()V
    .registers 1

    const/16 v0, 0x8

    sput v0, Lq;->cC:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cD:[I

    sget v0, Lq;->cC:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cE:[I

    sget v0, Lq;->cC:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cF:[I

    sget v0, Lq;->cC:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cG:[I

    sget v0, Lq;->cC:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cH:[I

    sget v0, Lq;->cC:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cI:[I

    :try_start_26
    const-string v0, "/e/b.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->dL:Ljavax/microedition/lcdui/Image;
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_2e} :catch_2f

    :goto_2e
    return-void

    :catch_2f
    move-exception v0

    goto :goto_2e
.end method

.method public static e(I)V
    .registers 8

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x0

    sget-boolean v0, Lg;->l:Z

    if-eqz v0, :cond_8

    :cond_7
    :goto_7
    return-void

    :cond_8
    const/16 v0, 0x1e

    sput v0, Lq;->eB:I

    sput-boolean v1, Lq;->aG:Z

    const/16 v0, 0x67

    if-ne p0, v0, :cond_7

    sput-boolean v5, Lq;->aG:Z

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_1f

    new-array v0, v6, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    move v0, v1

    :goto_1d
    if-lt v0, v6, :cond_49

    :cond_1f
    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v0

    sput v0, Lq;->eG:I

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v0

    sput v0, Lq;->aJ:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0xa

    add-int/lit8 v0, v0, 0xc

    sput v0, Lq;->aH:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0xa

    sput v0, Lq;->aI:I

    sput v5, Lq;->eD:I

    const/4 v0, -0x1

    sput v0, Lq;->eE:I

    sput v1, Lq;->eF:I

    goto :goto_7

    :cond_49
    :try_start_49
    sget-object v2, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/mob/b0"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v0
    :try_end_66
    .catch Ljava/lang/Exception; {:try_start_49 .. :try_end_66} :catch_69

    :goto_66
    add-int/lit8 v0, v0, 0x1

    goto :goto_1d

    :catch_69
    move-exception v2

    goto :goto_66
.end method

.method private static e(III)V
    .registers 5

    sget-object v0, Lq;->aY:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p1

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Lq;->aZ:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p2

    add-int/lit8 v1, v1, 0x18

    aput v1, v0, p0

    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-eq v0, v1, :cond_1e

    sget v0, Lq;->as:I

    const/16 v1, 0x66

    if-ne v0, v1, :cond_24

    :cond_1e
    sget-object v0, Lq;->ba:[I

    const/4 v1, 0x2

    aput v1, v0, p0

    :goto_23
    return-void

    :cond_24
    sget-object v0, Lq;->ba:[I

    const/4 v1, 0x1

    aput v1, v0, p0

    goto :goto_23
.end method

.method private static e(Ljavax/microedition/lcdui/Graphics;)V
    .registers 9

    const/16 v2, 0xa

    const/4 v4, -0x1

    const/4 v7, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v3

    neg-int v3, v3

    invoke-virtual {p0, v0, v3}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    sget v0, Lq;->E:I

    add-int/lit8 v0, v0, 0x2

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, 0x2

    invoke-virtual {p0, v4, v4, v0, v3}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    sget-object v0, Lq;->eR:[[Ljava/lang/String;

    sget v3, Lq;->eP:I

    aget-object v0, v0, v3

    array-length v0, v0

    sput v0, Lq;->eN:I

    sget v0, Lq;->eT:I

    sget v3, Lq;->az:I

    sub-int/2addr v0, v3

    sget v3, Lq;->eN:I

    shl-int/lit8 v3, v3, 0x4

    sub-int v3, v0, v3

    const/4 v0, 0x1

    if-ge v3, v2, :cond_fa

    move v0, v1

    :goto_35
    const v3, 0xffffff

    invoke-virtual {p0, v3}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v3, Lq;->eX:I

    add-int/lit8 v4, v2, -0x5

    sget v5, Lq;->eW:I

    sget v6, Lq;->eN:I

    shl-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x7

    invoke-virtual {p0, v3, v4, v5, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/16 v3, 0x4400

    invoke-virtual {p0, v3}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v3, Lq;->eX:I

    add-int/lit8 v3, v3, -0x1

    add-int/lit8 v4, v2, -0x5

    sget v5, Lq;->eW:I

    add-int/lit8 v5, v5, 0x1

    sget v6, Lq;->eN:I

    shl-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x7

    invoke-virtual {p0, v3, v4, v5, v6}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    move v3, v1

    :goto_63
    sget v4, Lq;->eV:I

    if-lt v3, v4, :cond_e1

    sget v3, Lq;->eV:I

    sget-object v4, Lq;->eR:[[Ljava/lang/String;

    sget v5, Lq;->eP:I

    aget-object v4, v4, v5

    array-length v4, v4

    if-ge v3, v4, :cond_91

    sget-object v3, Lq;->eR:[[Ljava/lang/String;

    sget v4, Lq;->eP:I

    aget-object v3, v3, v4

    sget v4, Lq;->eV:I

    aget-object v3, v3, v4

    sget v4, Lq;->eU:I

    invoke-virtual {v3, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    sget v4, Lq;->eX:I

    sget v5, Lq;->eW:I

    shr-int/lit8 v5, v5, 0x1

    add-int/2addr v4, v5

    sget v5, Lq;->eV:I

    shl-int/lit8 v5, v5, 0x4

    add-int/2addr v2, v5

    invoke-static {p0, v3, v4, v2, v7}, LMidlet;->b(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :cond_91
    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v2, Lq;->cd:I

    add-int/lit8 v2, v2, 0x21

    sget v3, Lq;->ce:I

    const/16 v4, 0xf

    invoke-virtual {p0, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-boolean v1, Lq;->bD:Z

    if-nez v1, :cond_cd

    if-eqz v0, :cond_cd

    sget v0, Lq;->eS:I

    sget v1, Lq;->ay:I

    add-int/lit8 v1, v1, 0xa

    if-le v0, v1, :cond_cd

    sget v0, Lq;->eS:I

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, -0xa

    if-ge v0, v1, :cond_cd

    sget-object v0, Lq;->dS:Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->eS:I

    sget v2, Lq;->ay:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    sget v2, Lq;->eT:I

    sget v3, Lq;->az:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, 0x2

    const/16 v3, 0x11

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_cd
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/16 v1, 0x8

    if-ge v0, v1, :cond_e0

    const-string v0, "Tiếp tục"

    sget v1, Lq;->ad:I

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    invoke-static {p0, v0, v1, v2, v7}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :cond_e0
    return-void

    :cond_e1
    sget-object v4, Lq;->eR:[[Ljava/lang/String;

    sget v5, Lq;->eP:I

    aget-object v4, v4, v5

    aget-object v4, v4, v3

    sget v5, Lq;->eX:I

    sget v6, Lq;->eW:I

    shr-int/lit8 v6, v6, 0x1

    add-int/2addr v5, v6

    shl-int/lit8 v6, v3, 0x4

    add-int/2addr v6, v2

    invoke-static {p0, v4, v5, v6, v7}, LMidlet;->b(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_63

    :cond_fa
    move v2, v3

    goto/16 :goto_35
.end method

.method public static f()V
    .registers 2

    sget v0, Lq;->as:I

    const/16 v1, 0x67

    if-ne v0, v1, :cond_b

    sget v0, Lq;->bi:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_4d

    :cond_b
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_16

    sget v0, Lq;->bi:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_4d

    :cond_16
    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_21

    sget v0, Lq;->bi:I

    const/4 v1, 0x3

    if-eq v0, v1, :cond_4d

    :cond_21
    sget v0, Lq;->as:I

    const/16 v1, 0x66

    if-ne v0, v1, :cond_2c

    sget v0, Lq;->bi:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_4d

    :cond_2c
    sget v0, Lq;->as:I

    const/16 v1, 0x11

    if-ne v0, v1, :cond_37

    sget v0, Lq;->bi:I

    const/4 v1, 0x5

    if-eq v0, v1, :cond_4d

    :cond_37
    sget v0, Lq;->as:I

    const/16 v1, 0x10

    if-ne v0, v1, :cond_42

    sget v0, Lq;->bi:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_4d

    :cond_42
    sget v0, Lq;->as:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_6b

    sget v0, Lq;->bi:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_6b

    :cond_4d
    :try_start_4d
    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "/i/bk"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lq;->bi:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, ".png"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->dN:Ljavax/microedition/lcdui/Image;
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_4d .. :try_end_6a} :catch_6f

    :goto_6a
    return-void

    :cond_6b
    const/4 v0, 0x0

    sput-object v0, Lq;->dN:Ljavax/microedition/lcdui/Image;

    goto :goto_6a

    :catch_6f
    move-exception v0

    goto :goto_6a
.end method

.method public static f(I)V
    .registers 7

    const/4 v5, -0x1

    const/16 v2, 0x9

    const/4 v0, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x1

    sput-boolean v4, Lq;->aN:Z

    sput-boolean v4, Lq;->aA:Z

    if-nez p0, :cond_14

    sget-boolean v1, Lq;->c:Z

    if-eqz v1, :cond_14

    invoke-static {v4}, Lq;->j(I)V

    :cond_13
    :goto_13
    return-void

    :cond_14
    const/16 v1, 0x69

    if-ne p0, v1, :cond_20

    sput-boolean v3, Lg;->H:Z

    sput-boolean v4, Lg;->aY:Z

    invoke-static {v3}, Lq;->j(I)V

    goto :goto_13

    :cond_20
    if-nez p0, :cond_2c

    sget-boolean v1, Lq;->d:Z

    if-eqz v1, :cond_2c

    sput v5, Lg;->aF:I

    invoke-static {v0}, Lq;->j(I)V

    goto :goto_13

    :cond_2c
    const/16 v1, 0x6a

    if-ne p0, v1, :cond_3f

    sget-boolean v1, Lq;->e:Z

    if-eqz v1, :cond_3f

    sput v3, Lg;->aF:I

    sput-boolean v3, Lg;->aY:Z

    sput-boolean v3, Ln;->a:Z

    const/4 v0, 0x3

    invoke-static {v0}, Lq;->j(I)V

    goto :goto_13

    :cond_3f
    if-nez p0, :cond_50

    sget-boolean v1, Lq;->f:Z

    if-eqz v1, :cond_50

    const/4 v0, 0x4

    invoke-static {v0}, Lq;->j(I)V

    sput-boolean v3, Lg;->H:Z

    sput-boolean v4, Lg;->aY:Z

    sput-boolean v3, Lq;->bD:Z

    goto :goto_13

    :cond_50
    const/16 v1, 0x6b

    if-ne p0, v1, :cond_be

    sget-boolean v1, Lq;->f:Z

    if-eqz v1, :cond_be

    const/16 v1, 0xc8

    sput v1, Lg;->aM:I

    sput v1, Lg;->aL:I

    const/16 v1, 0xc8

    sput v1, Lg;->aO:I

    sput v1, Lg;->aN:I

    const/16 v1, 0x14

    sput v1, Lg;->aJ:I

    const/4 v1, 0x5

    sput v1, Lg;->aK:I

    sput v3, Lg;->aW:I

    sput v4, Lg;->aX:I

    sput v4, Lg;->as:I

    const/16 v1, 0x6b

    sput v1, Lg;->Q:I

    const/16 v1, 0x78

    sput v1, Lg;->R:I

    const/16 v1, 0x120

    sput v1, Lg;->S:I

    sput v3, Lg;->V:I

    sput-boolean v3, Lq;->bD:Z

    invoke-static {p0}, Lg;->b(I)V

    sget-object v1, Lq;->bf:[I

    aput v4, v1, v4

    sget-object v1, Lq;->bf:[I

    const/16 v2, 0x64

    aput v2, v1, v3

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, "Gươm tre"

    aput-object v2, v1, v4

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, "Phi tiêu"

    aput-object v2, v1, v3

    sget-object v1, Lq;->bs:[I

    aput v4, v1, v4

    sget-object v1, Lq;->bs:[I

    aput v3, v1, v3

    sput v0, Lq;->bh:I

    :goto_a4
    const/4 v1, 0x6

    if-lt v0, v1, :cond_ad

    const/4 v0, 0x5

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_ad
    sget-object v1, Lq;->bf:[I

    aput v5, v1, v0

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, ""

    aput-object v2, v1, v0

    sget-object v1, Lq;->bs:[I

    aput v5, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_a4

    :cond_be
    if-nez p0, :cond_cc

    sget-boolean v1, Lq;->g:Z

    if-eqz v1, :cond_cc

    sput-boolean v4, Lg;->f:Z

    const/4 v0, 0x6

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_cc
    if-ne p0, v0, :cond_e0

    sget v1, Lg;->bc:I

    if-ne v1, v3, :cond_e0

    sget-boolean v1, Lg;->h:Z

    if-nez v1, :cond_e0

    sget-boolean v1, Lg;->bf:Z

    if-nez v1, :cond_e0

    const/4 v0, 0x7

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_e0
    if-ne p0, v0, :cond_10b

    sget v1, Lg;->bc:I

    if-ne v1, v3, :cond_10b

    sget-boolean v1, Lg;->h:Z

    if-eqz v1, :cond_10b

    sput v0, Lg;->Q:I

    const/16 v0, 0xf0

    sput v0, Lg;->R:I

    const/16 v0, 0x210

    sput v0, Lg;->S:I

    sput v3, Lg;->V:I

    sput-boolean v4, Lg;->O:Z

    invoke-static {p0}, Lg;->b(I)V

    sget-boolean v0, Lg;->bf:Z

    if-nez v0, :cond_106

    const/16 v0, 0x8

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_106
    invoke-static {v2}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_10b
    const/4 v1, 0x3

    if-ne p0, v1, :cond_12f

    sget v1, Lg;->bc:I

    if-ne v1, v0, :cond_12f

    sget-boolean v0, Lg;->bm:Z

    if-nez v0, :cond_12f

    const/4 v0, 0x3

    sput v0, Lg;->bn:I

    const/16 v0, 0x510

    sput v0, Lg;->bo:I

    const/16 v0, 0x198

    sput v0, Lg;->bp:I

    sput v3, Lg;->bA:I

    sput v3, Lg;->bs:I

    invoke-static {p0}, Lg;->d(I)V

    const/16 v0, 0xa

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_12f
    const/4 v0, 0x3

    if-ne p0, v0, :cond_145

    sget-boolean v0, Lg;->i:Z

    if-nez v0, :cond_145

    sput-boolean v4, Lq;->aN:Z

    sput-boolean v4, Lq;->aA:Z

    sput v4, Lq;->av:I

    sput v4, Lq;->bi:I

    const/16 v0, 0xc

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_145
    const/16 v0, 0x67

    if-ne p0, v0, :cond_14d

    sput v3, Lq;->bi:I

    goto/16 :goto_13

    :cond_14d
    const/16 v0, 0x6c

    if-ne p0, v0, :cond_18b

    const/16 v0, 0x6c

    sput v0, Lg;->bn:I

    const/16 v0, 0x30

    sput v0, Lg;->bo:I

    const/16 v0, 0x108

    sput v0, Lg;->bp:I

    sput v3, Lg;->bA:I

    sput v3, Lg;->bs:I

    sput-boolean v4, Lg;->bm:Z

    invoke-static {p0}, Lg;->d(I)V

    const/16 v0, 0x6c

    sput v0, Lg;->Q:I

    const/16 v0, 0x48

    sput v0, Lg;->R:I

    const/16 v0, 0x108

    sput v0, Lg;->S:I

    sput v3, Lg;->ad:I

    sput v3, Lg;->V:I

    const/16 v0, 0x60

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    const/16 v0, 0x108

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    sput v3, Lg;->aF:I

    const/16 v0, 0xb

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_18b
    const/16 v0, 0x63

    if-ne p0, v0, :cond_1aa

    const/16 v0, 0x480

    sput v0, Lg;->at:I

    const/16 v0, 0x108

    sput v0, Lg;->au:I

    sput-boolean v3, Lg;->aY:Z

    const/16 v0, 0xe

    invoke-static {v0}, Lq;->j(I)V

    sget v0, Lq;->ac:I

    rsub-int v0, v0, 0x108

    sput v0, Lq;->ax:I

    const/16 v0, 0x438

    sput v0, Lq;->aw:I

    goto/16 :goto_13

    :cond_1aa
    const/4 v0, 0x4

    if-ne p0, v0, :cond_1b8

    sget-boolean v0, Lq;->h:Z

    if-nez v0, :cond_1b8

    const/16 v0, 0xf

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_1b8
    const/16 v0, 0x8

    if-ne p0, v0, :cond_1c7

    sget-boolean v0, Lq;->i:Z

    if-nez v0, :cond_1c7

    const/16 v0, 0x10

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_1c7
    const/4 v0, 0x4

    if-ne p0, v0, :cond_20b

    sget-boolean v0, Lg;->n:Z

    if-eqz v0, :cond_20b

    sget-boolean v0, Lg;->o:Z

    if-nez v0, :cond_20b

    const/4 v0, 0x4

    sput v0, Lg;->bn:I

    sput v3, Lg;->bs:I

    sput-boolean v4, Lg;->bm:Z

    sget v0, Lg;->aF:I

    if-eq v0, v5, :cond_1e3

    sget v0, Lg;->at:I

    const/16 v1, 0x5a0

    if-lt v0, v1, :cond_1f7

    :cond_1e3
    const/16 v0, 0x3c0

    sput v0, Lg;->bo:I

    const/16 v0, 0xf0

    sput v0, Lg;->bp:I

    sput v3, Lg;->bA:I

    invoke-static {p0}, Lg;->d(I)V

    const/16 v0, 0x11

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_1f7
    const/16 v0, 0x348

    sput v0, Lg;->bo:I

    const/16 v0, 0xd8

    sput v0, Lg;->bp:I

    sput v5, Lg;->bA:I

    invoke-static {p0}, Lg;->d(I)V

    const/16 v0, 0x25

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_20b
    if-ne p0, v2, :cond_226

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_226

    sget-boolean v0, Lq;->s:Z

    if-nez v0, :cond_226

    const/16 v0, 0x480

    sput v0, Lg;->R:I

    const/16 v0, 0x180

    sput v0, Lg;->S:I

    sput v3, Lg;->ad:I

    const/16 v0, 0x1e

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_226
    if-ne p0, v2, :cond_237

    sget-boolean v0, Lg;->o:Z

    if-eqz v0, :cond_237

    sget-boolean v0, Lg;->p:Z

    if-eqz v0, :cond_237

    const/16 v0, 0x12

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_237
    if-ne p0, v2, :cond_244

    sget-boolean v0, Lg;->o:Z

    if-nez v0, :cond_244

    const/16 v0, 0x13

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_244
    const/16 v0, 0xc

    if-ne p0, v0, :cond_253

    sget-boolean v0, Lg;->q:Z

    if-eqz v0, :cond_253

    const/16 v0, 0x14

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_253
    const/16 v0, 0xd

    if-ne p0, v0, :cond_262

    sget-boolean v0, Lq;->n:Z

    if-nez v0, :cond_262

    const/16 v0, 0x16

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_262
    const/16 v0, 0x64

    if-ne p0, v0, :cond_271

    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_271

    const/16 v0, 0x20

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_271
    const/16 v0, 0xe

    if-ne p0, v0, :cond_280

    sget-boolean v0, Lq;->o:Z

    if-nez v0, :cond_280

    const/16 v0, 0x17

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_280
    const/16 v0, 0xe

    if-ne p0, v0, :cond_28f

    sget-boolean v0, Lg;->t:Z

    if-nez v0, :cond_28f

    const/16 v0, 0x18

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_28f
    const/16 v0, 0xe

    if-ne p0, v0, :cond_2a4

    sget-boolean v0, Lg;->t:Z

    if-eqz v0, :cond_2a4

    sget v0, Lg;->aW:I

    const/16 v1, 0x14

    if-ge v0, v1, :cond_2a4

    const/16 v0, 0x22

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_2a4
    const/16 v0, 0xf

    if-ne p0, v0, :cond_2b3

    sget-boolean v0, Lq;->p:Z

    if-nez v0, :cond_2b3

    const/16 v0, 0x19

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_2b3
    const/16 v0, 0xf

    if-ne p0, v0, :cond_2ca

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_2ca

    sget-boolean v0, Lg;->A:Z

    if-eqz v0, :cond_2ca

    sget-boolean v0, Lg;->u:Z

    if-nez v0, :cond_2ca

    const/16 v0, 0x1b

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_2ca
    const/16 v0, 0x10

    if-ne p0, v0, :cond_2d9

    sget-boolean v0, Lq;->q:Z

    if-nez v0, :cond_2d9

    const/16 v0, 0x1a

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_2d9
    const/16 v0, 0x14

    if-ne p0, v0, :cond_2ec

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_2ec

    sget-boolean v0, Lq;->r:Z

    if-nez v0, :cond_2ec

    const/16 v0, 0x1d

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_2ec
    if-ne p0, v2, :cond_310

    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_310

    sget-boolean v0, Lq;->t:Z

    if-nez v0, :cond_310

    sput v5, Lg;->bA:I

    const/16 v0, 0x6f0

    sput v0, Lg;->bo:I

    const/16 v0, 0x168

    sput v0, Lg;->bp:I

    sput v3, Lg;->bs:I

    sput v2, Lg;->bn:I

    sput v4, Lg;->bL:I

    invoke-static {v2}, Lg;->d(I)V

    const/16 v0, 0x1f

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_310
    const/16 v0, 0x8

    if-ne p0, v0, :cond_31f

    sget-boolean v0, Lg;->o:Z

    if-nez v0, :cond_31f

    const/16 v0, 0x24

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13

    :cond_31f
    const/16 v0, 0x65

    if-ne p0, v0, :cond_13

    sget-boolean v0, Lg;->m:Z

    if-nez v0, :cond_13

    const/16 v0, 0x23

    invoke-static {v0}, Lq;->j(I)V

    goto/16 :goto_13
.end method

.method private static f(Ljavax/microedition/lcdui/Graphics;)V
    .registers 4

    const/4 v2, -0x1

    sget v0, Lq;->E:I

    add-int/lit8 v0, v0, 0x2

    sget v1, Lq;->F:I

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {p0, v2, v2, v0, v1}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-static {p0}, Lq;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->ay:I

    neg-int v0, v0

    sget v1, Lq;->az:I

    neg-int v1, v1

    invoke-virtual {p0, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-static {p0}, Lj;->b(Ljavax/microedition/lcdui/Graphics;)V

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_3c

    invoke-static {p0}, Lj;->c(Ljavax/microedition/lcdui/Graphics;)V

    :goto_22
    invoke-static {p0}, Lj;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lg;->b(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lg;->c(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lc;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lj;->e(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lq;->d(Ljavax/microedition/lcdui/Graphics;)V

    sget-boolean v0, Lq;->bd:Z

    if-eqz v0, :cond_3b

    invoke-static {p0}, Lq;->e(Ljavax/microedition/lcdui/Graphics;)V

    :cond_3b
    return-void

    :cond_3c
    invoke-static {p0}, Lj;->d(Ljavax/microedition/lcdui/Graphics;)V

    goto :goto_22
.end method

.method public static final g()V
    .registers 5

    const/16 v4, 0x30

    const/16 v2, 0x8

    const/4 v3, 0x0

    sget v0, Lq;->as:I

    sput v0, Lq;->fX:I

    sget v0, Lq;->as:I

    const/16 v1, 0x6b

    if-ne v0, v1, :cond_fe

    sput v2, Lq;->fX:I

    :cond_11
    :goto_11
    sget v0, Lq;->E:I

    sput v0, Lq;->ab:I

    sget v0, Lq;->F:I

    const/16 v1, 0xd0

    if-lt v0, v1, :cond_128

    const/4 v0, 0x1

    sput-boolean v0, Lq;->cb:Z

    const/16 v0, 0x32

    sput v0, Lq;->cf:I

    sget v0, Lq;->F:I

    sget v1, Lq;->cf:I

    sub-int/2addr v0, v1

    sput v0, Lq;->ac:I

    sget v0, Lq;->ab:I

    sput v0, Lq;->ce:I

    sput v3, Lq;->cc:I

    sget v0, Lq;->ac:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->cd:I

    :goto_35
    sget v0, Lq;->F:I

    div-int/lit8 v0, v0, 0x6

    sput v0, Lq;->cq:I

    if-ge v0, v4, :cond_3f

    sput v4, Lq;->cq:I

    :cond_3f
    sget v0, Lq;->ab:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lq;->ad:I

    sget v0, Lq;->ac:I

    shr-int/lit8 v0, v0, 0x1

    sput v0, Lq;->ae:I

    sget v0, Lq;->ac:I

    mul-int/lit8 v0, v0, 0x3

    div-int/lit8 v0, v0, 0x4

    sput v0, Lq;->af:I

    sget v0, Lq;->ab:I

    div-int/lit8 v0, v0, 0x6

    sput v0, Lq;->ag:I

    sget v0, Lq;->ab:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x2

    sput v0, Lq;->ct:I

    sget v0, Lq;->ac:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x2

    sput v0, Lq;->cu:I

    sget v0, Lq;->ab:I

    rem-int/lit8 v0, v0, 0x18

    if-eqz v0, :cond_77

    sget v0, Lq;->ct:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->ct:I

    :cond_77
    sget v0, Lj;->a:I

    add-int/lit8 v0, v0, -0x1

    sget v1, Lj;->f:I

    mul-int/2addr v0, v1

    sget v1, Lq;->ab:I

    sub-int/2addr v0, v1

    sput v0, Lq;->ej:I

    sget v0, Lj;->b:I

    add-int/lit8 v0, v0, -0x1

    sget v1, Lj;->f:I

    mul-int/2addr v0, v1

    sget v1, Lq;->ac:I

    sub-int/2addr v0, v1

    sput v0, Lq;->ek:I

    sget v0, Lg;->at:I

    sget v1, Lq;->ad:I

    sub-int/2addr v0, v1

    sget v1, Lq;->ag:I

    sget v2, Lg;->aF:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    sput v0, Lq;->aw:I

    sput v0, Lq;->ay:I

    sget v0, Lg;->au:I

    sget v1, Lq;->af:I

    sub-int/2addr v0, v1

    sput v0, Lq;->ax:I

    sput v0, Lq;->az:I

    sget v0, Lq;->ay:I

    if-gez v0, :cond_ad

    sput v3, Lq;->ay:I

    :cond_ad
    sget v0, Lq;->ay:I

    sget v1, Lq;->ej:I

    if-le v0, v1, :cond_b7

    sget v0, Lq;->ej:I

    sput v0, Lq;->ay:I

    :cond_b7
    sget v0, Lq;->az:I

    if-gez v0, :cond_bd

    sput v3, Lq;->az:I

    :cond_bd
    sget v0, Lq;->az:I

    sget v1, Lq;->ek:I

    if-le v0, v1, :cond_c7

    sget v0, Lq;->ek:I

    sput v0, Lq;->az:I

    :cond_c7
    sget v0, Lq;->ay:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->W:I

    if-gez v0, :cond_d4

    sput v3, Lq;->W:I

    :cond_d4
    sget v0, Lq;->az:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    sput v0, Lq;->X:I

    sget v0, Lq;->W:I

    sget v1, Lq;->ct:I

    add-int/2addr v0, v1

    sput v0, Lq;->Y:I

    sget v0, Lq;->X:I

    sget v1, Lq;->cu:I

    add-int/2addr v0, v1

    sput v0, Lq;->Z:I

    sget v0, Lq;->X:I

    if-gez v0, :cond_ef

    sput v3, Lq;->X:I

    :cond_ef
    sget v0, Lq;->Z:I

    sget v1, Lj;->b:I

    add-int/lit8 v1, v1, -0x1

    if-le v0, v1, :cond_fd

    sget v0, Lj;->b:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->Z:I

    :cond_fd
    return-void

    :cond_fe
    sget v0, Lq;->as:I

    const/16 v1, 0x6c

    if-ne v0, v1, :cond_109

    const/4 v0, 0x3

    sput v0, Lq;->fX:I

    goto/16 :goto_11

    :cond_109
    sget v0, Lq;->as:I

    const/16 v1, 0x67

    if-ne v0, v1, :cond_114

    const/4 v0, 0x2

    sput v0, Lq;->fX:I

    goto/16 :goto_11

    :cond_114
    sget v0, Lq;->as:I

    const/16 v1, 0x6a

    if-ne v0, v1, :cond_11e

    sput v2, Lq;->fX:I

    goto/16 :goto_11

    :cond_11e
    sget v0, Lq;->as:I

    const/16 v1, 0x69

    if-ne v0, v1, :cond_11

    sput v3, Lq;->fX:I

    goto/16 :goto_11

    :cond_128
    const/16 v0, 0x10

    sput v0, Lq;->cf:I

    sget v0, Lq;->F:I

    sget v1, Lq;->cf:I

    sub-int/2addr v0, v1

    sput v0, Lq;->ac:I

    sput-boolean v3, Lq;->cb:Z

    sput v3, Lq;->cf:I

    sget v0, Lq;->ab:I

    sput v0, Lq;->ce:I

    sput v3, Lq;->cc:I

    sget v0, Lq;->ac:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->cd:I

    sget v0, Lq;->ab:I

    div-int/lit8 v0, v0, 0x3

    sput v0, Lq;->cl:I

    add-int/lit8 v0, v0, 0x1d

    sput v0, Lq;->cn:I

    sget v0, Lq;->cl:I

    add-int/lit8 v0, v0, 0x32

    sput v0, Lq;->co:I

    goto/16 :goto_35
.end method

.method public static g(I)V
    .registers 3

    const/4 v1, 0x0

    sput v1, Lq;->eq:I

    sput p0, Lq;->el:I

    sput v1, Lq;->aB:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->aA:Z

    sput-boolean v1, Lq;->er:Z

    invoke-static {}, Lq;->b()V

    invoke-static {}, Lq;->c()V

    return-void
.end method

.method private static g(Ljavax/microedition/lcdui/Graphics;)V
    .registers 15

    const/16 v13, 0x13

    const/4 v12, 0x2

    const/4 v9, 0x3

    const/16 v11, 0x14

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p0, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-static {p0}, Lq;->c(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lq;->b(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->E:I

    sget v1, Lq;->F:I

    invoke-virtual {p0, v2, v2, v0, v1}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, -0x13

    const/16 v3, 0x81

    const/16 v4, 0x66

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0xd

    sget v1, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v2, v0, v1, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "Mua"

    sget v1, Lq;->F:I

    add-int/lit8 v1, v1, -0xd

    invoke-static {p0, v0, v9, v1, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Quay lại"

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, -0x3

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xd

    const/4 v4, 0x1

    invoke-static {p0, v0, v1, v3, v4}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const v0, 0xbb6611

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, -0x12

    const/16 v3, 0x7e

    const/16 v4, 0x63

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v0, 0x642200

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3d

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, -0x10

    const/16 v3, 0x7b

    const/16 v4, 0x61

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->bp:I

    if-nez v0, :cond_149

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Tiền: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lq;->aj:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v1, Lq;->ad:I

    sget v3, Lq;->bm:I

    add-int/lit8 v3, v3, -0x8

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :goto_a3
    move v10, v2

    :goto_a4
    if-lt v10, v9, :cond_15e

    move v0, v2

    :goto_a7
    const/4 v1, 0x4

    if-lt v0, v1, :cond_1d9

    sget-object v0, Lq;->fi:[I

    sget v1, Lq;->fh:I

    aget v0, v0, v1

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->bo:I

    if-nez v0, :cond_216

    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, -0xa

    sget v1, Lq;->bn:I

    mul-int/lit8 v1, v1, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, 0xa

    invoke-virtual {p0, v0, v1, v13, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    :goto_c7
    sget v0, Lq;->bp:I

    if-nez v0, :cond_228

    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lq;->bq:[[Ljava/lang/String;

    sget v3, Lq;->bo:I

    aget-object v1, v1, v3

    sget v3, Lq;->bn:I

    aget-object v1, v1, v3

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget-object v1, Lq;->fl:[[I

    sget v3, Lq;->bo:I

    aget-object v1, v1, v3

    sget v3, Lq;->bn:I

    aget v1, v1, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v1, Lq;->ad:I

    sget v3, Lq;->bm:I

    add-int/lit8 v3, v3, 0x3a

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :goto_105
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v2

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->bm:I

    add-int/lit8 v2, v2, -0x13

    invoke-virtual {p0, v0, v1, v2, v11}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->bm:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v12

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->bm:I

    add-int/lit8 v2, v2, 0x53

    const/16 v3, 0x24

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v9

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->bm:I

    add-int/lit8 v2, v2, 0x53

    const/16 v3, 0x28

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    return-void

    :cond_149
    sget-object v0, Lq;->bq:[[Ljava/lang/String;

    sget v1, Lq;->bo:I

    aget-object v0, v0, v1

    sget v1, Lq;->bn:I

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    sget v3, Lq;->bm:I

    add-int/lit8 v3, v3, -0x8

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto/16 :goto_a3

    :cond_15e
    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, -0xa

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, 0xa

    invoke-virtual {p0, v0, v1, v13, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, 0x32

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, 0xa

    invoke-virtual {p0, v0, v1, v13, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x4a1900

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, -0xa

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, 0xa

    invoke-virtual {p0, v0, v1, v11, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, 0x32

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, 0xa

    invoke-virtual {p0, v0, v1, v11, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    aget-object v1, v0, v2

    mul-int/lit8 v3, v10, 0xf

    const/16 v4, 0xd

    const/16 v5, 0xf

    sget v0, Lq;->fg:I

    mul-int/lit8 v6, v10, 0x14

    add-int v7, v0, v6

    sget v0, Lq;->bm:I

    add-int/lit8 v8, v0, 0x14

    move-object v0, p0

    move v6, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v1, v0, v1

    mul-int/lit8 v3, v10, 0xf

    const/16 v4, 0xd

    const/16 v5, 0xf

    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, 0x3c

    mul-int/lit8 v6, v10, 0x14

    add-int v7, v0, v6

    sget v0, Lq;->bm:I

    add-int/lit8 v8, v0, 0x14

    move-object v0, p0

    move v6, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_a4

    :cond_1d9
    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->fg:I

    add-int/lit8 v1, v1, 0xa

    mul-int/lit8 v3, v0, 0x14

    add-int/2addr v1, v3

    sget v3, Lq;->bm:I

    add-int/lit8 v3, v3, 0x20

    invoke-virtual {p0, v1, v3, v13, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0x4a1900

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->fg:I

    add-int/lit8 v1, v1, 0xa

    mul-int/lit8 v3, v0, 0x14

    add-int/2addr v1, v3

    sget v3, Lq;->bm:I

    add-int/lit8 v3, v3, 0x20

    const/16 v4, 0x12

    invoke-virtual {p0, v1, v3, v4, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v1, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    aget-object v1, v1, v0

    sget v3, Lq;->fg:I

    add-int/lit8 v3, v3, 0x14

    mul-int/lit8 v4, v0, 0x14

    add-int/2addr v3, v4

    sget v4, Lq;->bm:I

    add-int/lit8 v4, v4, 0x2a

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_a7

    :cond_216
    sget v0, Lq;->fg:I

    add-int/lit8 v0, v0, 0xa

    sget v1, Lq;->bn:I

    mul-int/lit8 v1, v1, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->bm:I

    add-int/lit8 v1, v1, 0x20

    invoke-virtual {p0, v0, v1, v13, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    goto/16 :goto_c7

    :cond_228
    sget-object v0, Lq;->fk:[[Ljava/lang/String;

    sget v1, Lq;->bo:I

    aget-object v0, v0, v1

    sget v1, Lq;->bn:I

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    sget v3, Lq;->bm:I

    add-int/lit8 v3, v3, 0x3a

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto/16 :goto_105
.end method

.method public static h()V
    .registers 5

    const/4 v4, 0x2

    const/4 v0, 0x0

    invoke-static {}, Lq;->i()V

    sget-boolean v1, Lq;->cb:Z

    if-nez v1, :cond_a

    :goto_9
    return-void

    :cond_a
    :try_start_a
    sget-object v1, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_15

    const/4 v1, 0x2

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    :goto_13
    if-lt v0, v4, :cond_53

    :cond_15
    sget-object v0, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v0

    sput v0, Lq;->cg:I

    sget-object v0, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v0

    sput v0, Lq;->ch:I

    sget v0, Lq;->ab:I

    sget v1, Lq;->cg:I

    sub-int/2addr v0, v1

    sget v1, Lq;->ch:I

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->ci:I

    const/16 v0, 0x4e

    sput v0, Lq;->cj:I

    sget v0, Lq;->cd:I

    add-int/lit8 v0, v0, 0x7

    sput v0, Lq;->ck:I

    sget v0, Lq;->ab:I

    add-int/lit16 v0, v0, -0x86

    sput v0, Lq;->cl:I

    sget v0, Lq;->ab:I

    add-int/lit8 v0, v0, -0x54

    sput v0, Lq;->cm:I

    const/4 v0, 0x5

    sput v0, Lq;->cp:I

    goto :goto_9

    :catch_51
    move-exception v0

    goto :goto_9

    :cond_53
    sget-object v1, Lq;->dQ:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/c"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_70
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_70} :catch_51

    add-int/lit8 v0, v0, 0x1

    goto :goto_13
.end method

.method public static h(I)V
    .registers 5

    invoke-static {}, Lq;->w()V

    sput p0, Lq;->gc:I

    const/4 v0, 0x1

    if-ne p0, v0, :cond_16

    const-string v0, "Không thể chuyển. Vì bạn chưa từng đi bộ đến đây!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    :cond_15
    :goto_15
    return-void

    :cond_16
    const/4 v0, 0x3

    if-ne p0, v0, :cond_27

    const-string v0, "Không cần phải chuyển vì bạn đang ở vị trí này!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto :goto_15

    :cond_27
    const/4 v0, 0x2

    if-ne p0, v0, :cond_80

    sget v0, Lq;->fX:I

    sget v1, Lq;->fL:I

    if-ge v0, v1, :cond_71

    sget v0, Lq;->fX:I

    :goto_32
    sget v1, Lq;->fX:I

    sget v2, Lq;->fL:I

    if-le v1, v2, :cond_74

    sget v1, Lq;->fX:I

    :goto_3a
    const/4 v2, 0x0

    move v3, v0

    :goto_3c
    if-le v3, v1, :cond_77

    shl-int/lit8 v0, v2, 0x1

    div-int/lit8 v0, v0, 0x3

    sput v0, Lq;->gd:I

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "Chuyển đến đây phải trả "

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$. Bạn có "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget v1, Lq;->aj:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$. Chuyển?"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "Chuyển"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, "Không"

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto :goto_15

    :cond_71
    sget v0, Lq;->fL:I

    goto :goto_32

    :cond_74
    sget v1, Lq;->fL:I

    goto :goto_3a

    :cond_77
    sget-object v0, Lq;->fC:[I

    aget v0, v0, v3

    add-int/2addr v0, v2

    add-int/lit8 v3, v3, 0x1

    move v2, v0

    goto :goto_3c

    :cond_80
    const/4 v0, 0x4

    if-ne p0, v0, :cond_91

    const-string v0, "Bạn không có đủ tiền!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto :goto_15

    :cond_91
    const/4 v0, 0x5

    if-ne p0, v0, :cond_a3

    const-string v0, "Bạn đã bị trọng thương! Mất một số điểm kinh nghiệm!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15

    :cond_a3
    const/4 v0, 0x6

    if-ne p0, v0, :cond_b5

    const-string v0, "Level up!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15

    :cond_b5
    const/4 v0, 0x7

    if-ne p0, v0, :cond_c7

    const-string v0, "Buy OK!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, ""

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, "OK"

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15

    :cond_c7
    const/16 v0, 0x8

    if-ne p0, v0, :cond_da

    const-string v0, "Bạn vừa hấp thụ lam ngọc và được tăng một cấp"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15

    :cond_da
    const/16 v0, 0x9

    if-ne p0, v0, :cond_ed

    const-string v0, "Bạn vừa có được Hỏa long kiếm và hấp thụ sức mạnh rồng lửa từ phong ấn"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "OK"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15

    :cond_ed
    const/16 v0, 0xa

    if-ne p0, v0, :cond_100

    const-string v0, "Dữ liệu của phần chơi cũ sẽ bị mất. Bạn có chắc muốn chơi mới?"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "Có"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, "Không"

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15

    :cond_100
    const/16 v0, 0xb

    if-ne p0, v0, :cond_15

    const-string v0, "Game sẽ được lưu ở lần chuyển màn cuối cùng. Bạn có chắc muốn thoát?"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    const-string v0, "Có"

    sput-object v0, Lq;->gf:Ljava/lang/String;

    const-string v0, "Không"

    sput-object v0, Lq;->gg:Ljava/lang/String;

    goto/16 :goto_15
.end method

.method private static h(Ljavax/microedition/lcdui/Graphics;)V
    .registers 15

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v9, 0x3

    const/16 v11, 0x14

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p0, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-static {p0}, Lq;->c(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p0}, Lq;->b(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->E:I

    sget v1, Lq;->F:I

    invoke-virtual {p0, v2, v2, v0, v1}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, -0x13

    const/16 v3, 0x81

    const/16 v4, 0x78

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0xd

    sget v1, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v2, v0, v1, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "Sử dụng"

    sget v1, Lq;->F:I

    add-int/lit8 v1, v1, -0xd

    invoke-static {p0, v0, v9, v1, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Quay lại"

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, -0x3

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xd

    invoke-static {p0, v0, v1, v3, v13}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const v0, 0xbb6611

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, -0x12

    const/16 v3, 0x7e

    const/16 v4, 0x75

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v0, 0x642200

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3d

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, -0x10

    const/16 v3, 0x7b

    const/16 v4, 0x73

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "Sử dụng Item"

    sget v1, Lq;->ad:I

    sget v3, Lq;->fn:I

    add-int/lit8 v3, v3, -0x8

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    move v10, v2

    :goto_89
    if-lt v10, v9, :cond_114

    sget-object v0, Lq;->fr:[I

    sget v1, Lq;->fq:I

    aget v0, v0, v1

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->fo:I

    add-int/lit8 v0, v0, -0xa

    sget v1, Lq;->fp:I

    mul-int/lit8 v1, v1, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x14

    invoke-virtual {p0, v0, v1, v11, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v0, Lq;->fs:[Ljava/lang/String;

    sget v1, Lq;->fp:I

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    sget v3, Lq;->fn:I

    add-int/lit8 v3, v3, 0x32

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Số lượng: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v1, Lq;->br:[I

    sget v3, Lq;->fp:I

    aget v1, v1, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v1, Lq;->ad:I

    sget v3, Lq;->fn:I

    add-int/lit8 v3, v3, 0x41

    invoke-static {p0, v0, v1, v3, v12}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v2

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, -0x13

    invoke-virtual {p0, v0, v1, v2, v11}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v13

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v12

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x24

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v9

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x28

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    return-void

    :cond_114
    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->fo:I

    add-int/lit8 v0, v0, -0xa

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x14

    const/16 v3, 0x13

    invoke-virtual {p0, v0, v1, v3, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->fo:I

    add-int/lit8 v0, v0, 0x32

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x14

    const/16 v3, 0x13

    invoke-virtual {p0, v0, v1, v3, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x4a1900

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->fo:I

    add-int/lit8 v0, v0, -0xa

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x14

    invoke-virtual {p0, v0, v1, v11, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lq;->fo:I

    add-int/lit8 v0, v0, 0x32

    mul-int/lit8 v1, v10, 0x14

    add-int/2addr v0, v1

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x14

    invoke-virtual {p0, v0, v1, v11, v11}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    aget-object v1, v0, v2

    mul-int/lit8 v3, v10, 0xf

    const/16 v4, 0xd

    const/16 v5, 0xf

    sget v0, Lq;->fo:I

    mul-int/lit8 v6, v10, 0x14

    add-int v7, v0, v6

    sget v0, Lq;->fn:I

    add-int/lit8 v8, v0, 0x1e

    move-object v0, p0

    move v6, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    aget-object v1, v0, v13

    mul-int/lit8 v3, v10, 0xf

    const/16 v4, 0xd

    const/16 v5, 0xf

    sget v0, Lq;->fo:I

    add-int/lit8 v0, v0, 0x3c

    mul-int/lit8 v6, v10, 0x14

    add-int v7, v0, v6

    sget v0, Lq;->fn:I

    add-int/lit8 v8, v0, 0x1e

    move-object v0, p0

    move v6, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_89
.end method

.method public static i()V
    .registers 4

    :try_start_0
    sget-object v0, Lq;->dS:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    const-string v0, "/u/co.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->dS:Ljavax/microedition/lcdui/Image;

    :cond_c
    const/4 v0, 0x2

    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    const-string v2, "/u/wpt1.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget v0, Lg;->as:I

    if-nez v0, :cond_2a

    sget-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/u/wpt0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    :goto_29
    return-void

    :cond_2a
    sget-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/wpt"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v3, Lg;->as:I

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_4c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_4c} :catch_4d

    goto :goto_29

    :catch_4d
    move-exception v0

    goto :goto_29
.end method

.method private static i(I)V
    .registers 4

    const/4 v2, 0x2

    const/4 v1, -0x1

    const/16 v0, 0xc

    if-ne p0, v0, :cond_12

    sget-boolean v0, Lq;->n:Z

    if-eqz v0, :cond_12

    sget v0, Lq;->aQ:I

    if-eq v0, v1, :cond_12

    sput v1, Lq;->aQ:I

    sput v2, Lg;->ax:I

    :cond_12
    sget-boolean v0, Lg;->l:Z

    if-nez v0, :cond_1a

    sget v0, Lq;->aL:I

    sput v0, Lq;->aK:I

    :cond_1a
    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_22

    sget v0, Lt;->j:I

    sput v0, Lt;->i:I

    :cond_22
    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_2a

    sget v0, Lt;->l:I

    sput v0, Lt;->k:I

    :cond_2a
    sget-boolean v0, Lm;->g:Z

    if-nez v0, :cond_32

    sget v0, Lm;->f:I

    sput v0, Lm;->e:I

    :cond_32
    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_3a

    const/16 v0, 0x1f40

    sput v0, Le;->f:I

    :cond_3a
    sput v2, Lq;->K:I

    sput p0, Lq;->as:I

    const/4 v0, 0x1

    sput v0, LMidlet;->d:I

    invoke-static {}, Lq;->R()V

    new-instance v0, Ljava/lang/Thread;

    sget-object v1, LMidlet;->b:LMidlet;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static i(Ljavax/microedition/lcdui/Graphics;)V
    .registers 9

    const/16 v4, 0x81

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {p0, v0, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x66

    invoke-virtual {p0, v0, v2, v4, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x78

    invoke-virtual {p0, v0, v2, v4, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0xd

    sget v2, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v1, v0, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "Chọn"

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    invoke-static {p0, v0, v7, v2, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Quay lại"

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, -0x3

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xd

    invoke-static {p0, v0, v2, v3, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const v0, 0xbb6611

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, -0x12

    const/16 v3, 0x7e

    const/16 v4, 0x75

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v0, 0x642200

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3d

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, -0x10

    const/16 v3, 0x7b

    const/16 v4, 0x73

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    move v0, v1

    :goto_7b
    const/4 v2, 0x5

    if-lt v0, v2, :cond_e0

    sget-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    sget v2, Lq;->G:I

    add-int/lit8 v2, v2, -0x37

    sget v3, Lq;->fz:I

    rem-int/lit8 v3, v3, 0x2

    add-int/2addr v2, v3

    sget v3, Lq;->fx:I

    sget v4, Lq;->fy:I

    mul-int/lit8 v4, v4, 0x12

    add-int/2addr v3, v4

    sget v4, Lq;->fz:I

    rem-int/lit8 v4, v4, 0x2

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v2, v3, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x14

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x24

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v7

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->fx:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x28

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    return-void

    :cond_e0
    sget-object v2, Lq;->fA:[Ljava/lang/String;

    aget-object v2, v2, v0

    sget v3, Lq;->G:I

    add-int/lit8 v3, v3, -0x1e

    sget v4, Lq;->fx:I

    mul-int/lit8 v5, v0, 0x12

    add-int/2addr v4, v5

    invoke-static {p0, v2, v3, v4, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_7b
.end method

.method public static j()V
    .registers 5

    const/4 v4, 0x3

    const/4 v0, 0x5

    sput v0, Lq;->dn:I

    sget-object v0, Lq;->dR:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_10

    const/4 v0, 0x3

    :try_start_9
    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dR:[Ljavax/microedition/lcdui/Image;
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_d} :catch_61

    const/4 v0, 0x0

    :goto_e
    if-lt v0, v4, :cond_41

    :cond_10
    :goto_10
    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->do:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dp:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dq:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dr:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->ds:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dt:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dv:[I

    sget v0, Lq;->dn:I

    new-array v0, v0, [I

    sput-object v0, Lq;->du:[I

    return-void

    :cond_41
    :try_start_41
    sget-object v1, Lq;->dR:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/i/dm"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_41 .. :try_end_5e} :catch_61

    add-int/lit8 v0, v0, 0x1

    goto :goto_e

    :catch_61
    move-exception v0

    goto :goto_10
.end method

.method private static j(I)V
    .registers 2

    const/4 v0, 0x0

    sput v0, Lq;->aO:I

    sput p0, Lq;->aM:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->aN:Z

    return-void
.end method

.method private static j(Ljavax/microedition/lcdui/Graphics;)V
    .registers 10

    const/16 v8, 0x18

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {p0, v0, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ab:I

    sget v2, Lq;->ac:I

    invoke-virtual {p0, v1, v1, v0, v2}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0xd

    sget v2, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v1, v0, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lq;->fY:Ljava/lang/String;

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    invoke-static {p0, v0, v5, v2, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Quay lại"

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, -0x3

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xd

    invoke-static {p0, v0, v2, v3, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget v0, Lq;->ab:I

    sget v2, Lq;->ac:I

    invoke-virtual {p0, v1, v1, v0, v2}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    sget v0, Lq;->fT:I

    neg-int v0, v0

    sget v2, Lq;->fU:I

    neg-int v2, v2

    invoke-virtual {p0, v0, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    sget-object v0, Lq;->fH:Ljavax/microedition/lcdui/Image;

    invoke-virtual {p0, v0, v1, v1, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    move v0, v1

    :goto_54
    sget-object v2, Lq;->bt:[Z

    array-length v2, v2

    if-lt v0, v2, :cond_f2

    sget-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    sget v2, Lq;->fJ:I

    sget v3, Lq;->fK:I

    invoke-virtual {p0, v0, v2, v3, v8}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget v0, Lq;->fL:I

    const/4 v2, -0x1

    if-eq v0, v2, :cond_f1

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {p0, v0, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    const v0, 0x642200

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->G:I

    add-int/lit8 v0, v0, -0x3c

    sget v2, Lq;->ac:I

    add-int/lit8 v2, v2, -0x23

    const/16 v3, 0x78

    const/16 v4, 0x21

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0xbb6611

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->G:I

    add-int/lit8 v0, v0, -0x3b

    sget v2, Lq;->ac:I

    add-int/lit8 v2, v2, -0x22

    const/16 v3, 0x75

    const/16 v4, 0x1e

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v0, Lq;->fB:[Ljava/lang/String;

    sget v2, Lq;->fL:I

    aget-object v0, v0, v2

    sget v2, Lq;->G:I

    sget v3, Lq;->ac:I

    add-int/lit8 v3, v3, -0x19

    invoke-static {p0, v0, v2, v3, v7}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, -0x3c

    sget v2, Lq;->ac:I

    add-int/lit8 v2, v2, -0x23

    const/16 v3, 0x14

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, 0x3c

    sget v2, Lq;->ac:I

    add-int/lit8 v2, v2, -0x23

    invoke-virtual {p0, v0, v1, v2, v8}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v7

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, -0x3c

    sget v2, Lq;->ac:I

    add-int/lit8 v2, v2, -0x2

    const/16 v3, 0x24

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v5

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, 0x3c

    sget v2, Lq;->ac:I

    add-int/lit8 v2, v2, -0x2

    const/16 v3, 0x28

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_f1
    return-void

    :cond_f2
    sget v2, Lq;->fX:I

    if-ne v0, v2, :cond_107

    sget-object v2, Lg;->N:[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v1

    sget-object v3, Lq;->fD:[I

    aget v3, v3, v0

    add-int/lit8 v3, v3, 0xa

    sget-object v4, Lq;->fE:[I

    aget v4, v4, v0

    invoke-virtual {p0, v2, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_107
    sget-object v2, Lq;->bt:[Z

    aget-boolean v2, v2, v0

    if-eqz v2, :cond_125

    sget v2, Lq;->fL:I

    if-ne v0, v2, :cond_118

    sget v2, Lq;->fM:I

    rem-int/lit8 v2, v2, 0xa

    const/4 v3, 0x5

    if-le v2, v3, :cond_125

    :cond_118
    sget-object v2, Lq;->fI:Ljavax/microedition/lcdui/Image;

    sget-object v3, Lq;->fD:[I

    aget v3, v3, v0

    sget-object v4, Lq;->fE:[I

    aget v4, v4, v0

    invoke-virtual {p0, v2, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_125
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_54
.end method

.method public static final k()V
    .registers 8

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x2

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_8

    :goto_7
    return-void

    :cond_8
    sget-object v0, Lq;->dT:[[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_1d

    filled-new-array {v6, v7}, [I

    move-result-object v0

    const-class v2, Ljavax/microedition/lcdui/Image;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dT:[[Ljavax/microedition/lcdui/Image;

    move v2, v1

    :goto_1b
    if-lt v2, v6, :cond_32

    :cond_1d
    new-array v0, v6, [I

    sput-object v0, Lq;->cS:[I

    new-array v0, v6, [I

    sput-object v0, Lq;->cT:[I

    new-array v0, v6, [I

    sput-object v0, Lq;->cU:[I

    sget-object v2, Lq;->cU:[I

    const/4 v3, 0x1

    const/4 v4, -0x1

    aput v4, v2, v3

    aput v4, v0, v1

    goto :goto_7

    :cond_32
    move v0, v1

    :goto_33
    if-lt v0, v7, :cond_39

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_1b

    :cond_39
    :try_start_39
    sget-object v3, Lq;->dT:[[Ljavax/microedition/lcdui/Image;

    aget-object v3, v3, v2

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "/e/d"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ".png"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v4

    aput-object v4, v3, v0
    :try_end_5c
    .catch Ljava/io/IOException; {:try_start_39 .. :try_end_5c} :catch_5f

    :goto_5c
    add-int/lit8 v0, v0, 0x1

    goto :goto_33

    :catch_5f
    move-exception v3

    goto :goto_5c
.end method

.method private static k(I)V
    .registers 7

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    sparse-switch p0, :sswitch_data_7c

    :goto_8
    return-void

    :sswitch_9
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v1

    goto :goto_8

    :sswitch_12
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0x8

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0x8

    aput-boolean v2, v0, v1

    goto :goto_8

    :sswitch_1f
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v3

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v3

    goto :goto_8

    :sswitch_28
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v5

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v5

    goto :goto_8

    :sswitch_31
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v4

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v4

    goto :goto_8

    :sswitch_3a
    sget-object v0, Lq;->C:[Z

    add-int/lit8 v1, p0, -0x30

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    add-int/lit8 v1, p0, -0x30

    aput-boolean v2, v0, v1

    goto :goto_8

    :sswitch_47
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xa

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xa

    aput-boolean v2, v0, v1

    goto :goto_8

    :sswitch_54
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xb

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xb

    aput-boolean v2, v0, v1

    goto :goto_8

    :sswitch_61
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xc

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aput-boolean v2, v0, v1

    goto :goto_8

    :sswitch_6e
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xd

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aput-boolean v2, v0, v1

    goto :goto_8

    nop

    :sswitch_data_7c
    .sparse-switch
        -0x16 -> :sswitch_6e
        -0x15 -> :sswitch_61
        -0x7 -> :sswitch_6e
        -0x6 -> :sswitch_61
        -0x5 -> :sswitch_31
        -0x4 -> :sswitch_28
        -0x3 -> :sswitch_1f
        -0x2 -> :sswitch_12
        -0x1 -> :sswitch_9
        0xa -> :sswitch_31
        0x23 -> :sswitch_54
        0x2a -> :sswitch_47
        0x30 -> :sswitch_3a
        0x31 -> :sswitch_3a
        0x32 -> :sswitch_3a
        0x33 -> :sswitch_3a
        0x34 -> :sswitch_3a
        0x35 -> :sswitch_3a
        0x36 -> :sswitch_3a
        0x37 -> :sswitch_3a
        0x38 -> :sswitch_3a
        0x39 -> :sswitch_3a
    .end sparse-switch
.end method

.method private static k(Ljavax/microedition/lcdui/Graphics;)V
    .registers 9

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->E:I

    sget v3, Lq;->F:I

    invoke-virtual {p0, v2, v2, v0, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-boolean v0, Lq;->ga:Z

    if-eqz v0, :cond_13

    :goto_12
    return-void

    :cond_13
    sget v0, Lq;->gb:I

    if-ne v0, v1, :cond_4b

    sget-object v0, Lq;->fZ:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0x1e

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :goto_25
    sget v0, Lq;->gb:I

    if-nez v0, :cond_88

    const-string v0, "Bật âm thanh?"

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, 0xf

    invoke-static {p0, v0, v3, v4, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Bật"

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xe

    invoke-static {p0, v0, v7, v3, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Tắt"

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, -0x4

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xe

    invoke-static {p0, v0, v2, v3, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto :goto_12

    :cond_4b
    move v3, v2

    :goto_4c
    const/16 v0, 0xa

    if-lt v3, v0, :cond_6b

    const-string v0, "*"

    sget v3, Lq;->G:I

    add-int/lit8 v3, v3, -0x3c

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0xa

    invoke-static {p0, v0, v3, v4, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "/"

    sget v3, Lq;->G:I

    add-int/lit8 v3, v3, 0x3c

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0xa

    invoke-static {p0, v0, v3, v4, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto :goto_25

    :cond_6b
    sget-object v4, Lq;->fZ:[Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->bu:I

    if-ge v3, v0, :cond_86

    move v0, v1

    :goto_72
    aget-object v0, v4, v0

    sget v4, Lq;->G:I

    add-int/lit8 v4, v4, -0x3c

    mul-int/lit8 v5, v3, 0xc

    add-int/2addr v4, v5

    sget v5, Lq;->H:I

    add-int/lit8 v5, v5, -0x1e

    invoke-virtual {p0, v0, v4, v5, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto :goto_4c

    :cond_86
    move v0, v2

    goto :goto_72

    :cond_88
    const-string v0, "Chất lượng hình ảnh?"

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, 0xf

    invoke-static {p0, v0, v3, v4, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Cao"

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xe

    invoke-static {p0, v0, v7, v3, v2}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Thấp"

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, -0x4

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xe

    invoke-static {p0, v0, v2, v3, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto/16 :goto_12
.end method

.method public static final l()V
    .registers 6

    const/4 v5, 0x2

    const/4 v0, 0x0

    sget-object v1, Lq;->dU:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_d

    new-array v1, v5, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lq;->dU:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_b
    if-lt v1, v5, :cond_3e

    :cond_d
    const/16 v1, 0xa

    sput v1, Lq;->dh:I

    new-array v1, v1, [I

    sput-object v1, Lq;->di:[I

    sget v1, Lq;->dh:I

    new-array v1, v1, [I

    sput-object v1, Lq;->dj:[I

    sget v1, Lq;->dh:I

    new-array v1, v1, [I

    sput-object v1, Lq;->ah:[I

    sget v1, Lq;->dh:I

    new-array v1, v1, [I

    sput-object v1, Lq;->dk:[I

    sget v1, Lq;->dh:I

    new-array v1, v1, [I

    sput-object v1, Lq;->ai:[I

    sget v1, Lq;->dh:I

    new-array v1, v1, [Z

    sput-object v1, Lq;->dm:[Z

    sget v1, Lq;->dh:I

    new-array v1, v1, [I

    sput-object v1, Lq;->dl:[I

    :goto_39
    sget v1, Lq;->dh:I

    if-lt v0, v1, :cond_5e

    return-void

    :cond_3e
    :try_start_3e
    sget-object v2, Lq;->dU:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/c/pt"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v1
    :try_end_5b
    .catch Ljava/io/IOException; {:try_start_3e .. :try_end_5b} :catch_66

    :goto_5b
    add-int/lit8 v1, v1, 0x1

    goto :goto_b

    :cond_5e
    sget-object v1, Lq;->ah:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_39

    :catch_66
    move-exception v2

    goto :goto_5b
.end method

.method private static l(I)V
    .registers 7

    const/16 v5, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    sparse-switch p0, :sswitch_data_58

    :goto_9
    return-void

    :sswitch_a
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v1

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v1

    goto :goto_9

    :sswitch_13
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v5

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v5

    goto :goto_9

    :sswitch_1c
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v3

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v3

    goto :goto_9

    :sswitch_25
    sget-object v0, Lq;->C:[Z

    aput-boolean v2, v0, v4

    sget-object v0, Lq;->D:[Z

    aput-boolean v2, v0, v4

    goto :goto_9

    :sswitch_2e
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x5

    aput-boolean v2, v0, v1

    goto :goto_9

    :sswitch_34
    sget-object v0, Lq;->C:[Z

    add-int/lit8 v1, p0, -0x30

    aput-boolean v2, v0, v1

    goto :goto_9

    :sswitch_3b
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xa

    aput-boolean v2, v0, v1

    goto :goto_9

    :sswitch_42
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xb

    aput-boolean v2, v0, v1

    goto :goto_9

    :sswitch_49
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xc

    aput-boolean v2, v0, v1

    goto :goto_9

    :sswitch_50
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0xd

    aput-boolean v2, v0, v1

    goto :goto_9

    nop

    :sswitch_data_58
    .sparse-switch
        -0x16 -> :sswitch_50
        -0x15 -> :sswitch_49
        -0x7 -> :sswitch_50
        -0x6 -> :sswitch_49
        -0x5 -> :sswitch_2e
        -0x4 -> :sswitch_25
        -0x3 -> :sswitch_1c
        -0x2 -> :sswitch_13
        -0x1 -> :sswitch_a
        0xa -> :sswitch_2e
        0x23 -> :sswitch_42
        0x2a -> :sswitch_3b
        0x30 -> :sswitch_34
        0x31 -> :sswitch_34
        0x32 -> :sswitch_34
        0x33 -> :sswitch_34
        0x34 -> :sswitch_34
        0x35 -> :sswitch_34
        0x36 -> :sswitch_34
        0x37 -> :sswitch_34
        0x38 -> :sswitch_34
        0x39 -> :sswitch_34
    .end sparse-switch
.end method

.method private static l(Ljavax/microedition/lcdui/Graphics;)V
    .registers 10

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {p0, v0, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x81

    const/16 v4, 0x78

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0xd

    sget v2, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v1, v0, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->gc:I

    const/16 v2, 0xa

    if-ne v0, v2, :cond_44

    sget v0, Lq;->bW:I

    add-int/lit8 v0, v0, 0x5

    sget v2, Lq;->ab:I

    sget v3, Lq;->F:I

    sget v4, Lq;->bW:I

    sub-int/2addr v3, v4

    add-int/lit8 v3, v3, -0x5

    invoke-virtual {p0, v1, v0, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :cond_44
    sget-object v0, Lq;->gf:Ljava/lang/String;

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    invoke-static {p0, v0, v8, v2, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->gg:Ljava/lang/String;

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, -0x3

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, -0xd

    invoke-static {p0, v0, v2, v3, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const v0, 0xbb6611

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x12

    const/16 v3, 0x7e

    const/16 v4, 0x75

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v0, 0x642200

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3d

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x10

    const/16 v3, 0x7b

    const/16 v4, 0x73

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    move v0, v1

    :goto_85
    sget-object v2, Lq;->gh:[Ljava/lang/String;

    array-length v2, v2

    if-lt v0, v2, :cond_cf

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x14

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v6

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v7

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x24

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v8

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x28

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    return-void

    :cond_cf
    sget-object v2, Lq;->gh:[Ljava/lang/String;

    aget-object v2, v2, v0

    sget v3, Lq;->G:I

    sget v4, Lq;->bv:I

    mul-int/lit8 v5, v0, 0x12

    add-int/2addr v4, v5

    invoke-static {p0, v2, v3, v4, v7}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_85
.end method

.method public static final m()V
    .registers 4

    const/4 v3, 0x5

    new-array v0, v3, [I

    sput-object v0, Lq;->dx:[I

    new-array v0, v3, [I

    sput-object v0, Lq;->dy:[I

    new-array v0, v3, [I

    sput-object v0, Lq;->dz:[I

    new-array v0, v3, [I

    sput-object v0, Lq;->dA:[I

    new-array v0, v3, [I

    sput-object v0, Lq;->dB:[I

    new-array v0, v3, [I

    sput-object v0, Lq;->dC:[I

    new-array v0, v3, [Ljava/lang/String;

    sput-object v0, Lq;->dw:[Ljava/lang/String;

    const/4 v0, 0x0

    :goto_1e
    if-lt v0, v3, :cond_21

    return-void

    :cond_21
    sget-object v1, Lq;->dB:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_1e
.end method

.method private static m(Ljavax/microedition/lcdui/Graphics;)V
    .registers 10

    const v8, 0xbb6611

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/16 v5, 0x7e

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {p0, v0, v2}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x81

    const/16 v4, 0x66

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->F:I

    add-int/lit8 v0, v0, -0xd

    sget v2, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p0, v1, v0, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "OK"

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    invoke-static {p0, v0, v7, v2, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    invoke-virtual {p0, v8}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x12

    const/16 v3, 0x63

    invoke-virtual {p0, v0, v2, v5, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v0, 0x642200

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3d

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x10

    const/16 v3, 0x7b

    const/16 v4, 0x61

    invoke-virtual {p0, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    invoke-virtual {p0, v8}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x12

    const/16 v3, 0x14

    invoke-virtual {p0, v0, v2, v5, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, -0x12

    const/16 v3, 0x4d

    invoke-virtual {p0, v0, v2, v5, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v2, "Bạn vừa đạt cấp "

    invoke-direct {v0, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v2, Lg;->aW:I

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v2, Lq;->G:I

    sget v3, Lq;->bv:I

    add-int/lit8 v3, v3, -0xe

    invoke-static {p0, v0, v2, v3, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    move v0, v1

    :goto_9a
    if-lt v0, v7, :cond_c5

    sget-object v0, Lq;->eb:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v0, v1

    sget v2, Lq;->G:I

    add-int/lit8 v2, v2, -0x3a

    sget v3, Lq;->fz:I

    rem-int/lit8 v3, v3, 0x2

    add-int/2addr v2, v3

    sget v3, Lq;->bv:I

    add-int/lit8 v3, v3, 0x8

    sget v4, Lq;->gi:I

    mul-int/lit8 v4, v4, 0x12

    add-int/2addr v3, v4

    invoke-virtual {p0, v0, v2, v3, v1}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->bx:[Ljava/lang/String;

    sget v1, Lq;->gi:I

    aget-object v0, v0, v1

    sget v1, Lq;->G:I

    sget v2, Lq;->bv:I

    add-int/lit8 v2, v2, 0x40

    invoke-static {p0, v0, v1, v2, v6}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    return-void

    :cond_c5
    sget v2, Lq;->gi:I

    if-ne v0, v2, :cond_d0

    sget v2, Lq;->fz:I

    rem-int/lit8 v2, v2, 0xa

    const/4 v3, 0x7

    if-ge v2, v3, :cond_e2

    :cond_d0
    sget-object v2, Lq;->bw:[Ljava/lang/String;

    aget-object v2, v2, v0

    sget v3, Lq;->G:I

    add-int/lit8 v3, v3, -0x28

    sget v4, Lq;->bv:I

    add-int/lit8 v4, v4, 0x8

    mul-int/lit8 v5, v0, 0x10

    add-int/2addr v4, v5

    invoke-static {p0, v2, v3, v4, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :cond_e2
    add-int/lit8 v0, v0, 0x1

    goto :goto_9a
.end method

.method private static m(I)Z
    .registers 5

    const/4 v1, 0x0

    const/4 v0, 0x2

    :goto_2
    sget-object v2, Lq;->bf:[I

    array-length v2, v2

    if-lt v0, v2, :cond_9

    move v0, v1

    :goto_8
    return v0

    :cond_9
    sget-object v2, Lq;->bf:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-ne v2, v3, :cond_12

    move v0, v1

    goto :goto_8

    :cond_12
    sget-object v2, Lq;->bf:[I

    aget v2, v2, v0

    if-ne v2, p0, :cond_1a

    const/4 v0, 0x1

    goto :goto_8

    :cond_1a
    add-int/lit8 v0, v0, 0x1

    goto :goto_2
.end method

.method public static n()V
    .registers 5

    const/4 v4, 0x2

    sget-object v0, Lq;->dV:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dV:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    :goto_a
    if-lt v0, v4, :cond_d

    :cond_c
    return-void

    :cond_d
    :try_start_d
    sget-object v1, Lq;->dV:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/e/l"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_2a
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_2a} :catch_2d

    :goto_2a
    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :catch_2d
    move-exception v1

    goto :goto_2a
.end method

.method public static o()V
    .registers 5

    const/4 v4, 0x4

    sget-object v0, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    :goto_a
    if-lt v0, v4, :cond_d

    :cond_c
    return-void

    :cond_d
    :try_start_d
    sget-object v1, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/e/e"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_2a
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_2a} :catch_2d

    :goto_2a
    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :catch_2d
    move-exception v1

    goto :goto_2a
.end method

.method public static p()V
    .registers 3

    const/4 v0, 0x5

    sput v0, Lq;->cY:I

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_20

    const/4 v0, 0x2

    :try_start_8
    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/i/pt0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    const-string v2, "/i/pt1.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_20} :catch_51

    :cond_20
    :goto_20
    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->da:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->db:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dc:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dd:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->de:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->df:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->dg:[I

    sget v0, Lq;->cY:I

    new-array v0, v0, [I

    sput-object v0, Lq;->cZ:[I

    return-void

    :catch_51
    move-exception v0

    goto :goto_20
.end method

.method public static final q()V
    .registers 7

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x2

    sget-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_e

    new-array v0, v6, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    move v0, v1

    :goto_c
    if-lt v0, v6, :cond_2d

    :cond_e
    new-array v0, v5, [I

    sput-object v0, Lq;->cJ:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cK:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cL:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cM:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cN:[I

    sget-object v0, Lq;->cL:[I

    sget-object v2, Lq;->cL:[I

    const/4 v3, 0x1

    const/4 v4, -0x1

    aput v4, v2, v3

    aput v4, v0, v1

    return-void

    :cond_2d
    :try_start_2d
    sget-object v2, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/e/sp"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v0
    :try_end_4a
    .catch Ljava/io/IOException; {:try_start_2d .. :try_end_4a} :catch_4d

    :goto_4a
    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :catch_4d
    move-exception v2

    goto :goto_4a
.end method

.method public static final r()V
    .registers 7

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x2

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_8

    :goto_7
    return-void

    :cond_8
    new-array v0, v6, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->ec:[Ljavax/microedition/lcdui/Image;

    move v0, v1

    :goto_d
    if-lt v0, v6, :cond_2a

    new-array v0, v5, [I

    sput-object v0, Lq;->cO:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cP:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cQ:[I

    new-array v0, v5, [I

    sput-object v0, Lq;->cR:[I

    sget-object v0, Lq;->cQ:[I

    sget-object v2, Lq;->cQ:[I

    const/4 v3, 0x1

    const/4 v4, -0x1

    aput v4, v2, v3

    aput v4, v0, v1

    goto :goto_7

    :cond_2a
    :try_start_2a
    sget-object v2, Lq;->ec:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/e/w"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v0
    :try_end_47
    .catch Ljava/io/IOException; {:try_start_2a .. :try_end_47} :catch_4a

    :goto_47
    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    :catch_4a
    move-exception v2

    goto :goto_47
.end method

.method public static s()V
    .registers 1

    sget-boolean v0, Lg;->bb:Z

    if-eqz v0, :cond_7

    const/4 v0, 0x0

    sput v0, Lq;->w:I

    :cond_7
    return-void
.end method

.method public static t()V
    .registers 7

    const/4 v2, 0x0

    const/4 v1, 0x1

    new-instance v0, Lq;

    invoke-direct {v0}, Lq;-><init>()V

    sput-object v0, LMidlet;->a:Lq;

    invoke-static {}, Lq;->P()V

    sget-object v3, LMidlet;->a:Lq;

    sget v0, LMidlet;->g:I

    if-nez v0, :cond_4c

    move v0, v1

    :goto_13
    invoke-static {v0}, LMidlet;->a(I)V

    invoke-static {}, Lq;->u()V

    sget-object v0, Lc;->i:[I

    const/4 v4, 0x6

    aget v0, v0, v4

    add-int/lit8 v0, v0, 0x14

    const v4, 0x10ec1d

    add-int/lit8 v0, v0, -0x6

    rem-int v0, v4, v0

    sget v4, Lq;->K:I

    sget-object v5, Lg;->E:[[[I

    const/16 v6, 0x28

    aget-object v5, v5, v6

    aget-object v2, v5, v2

    aget v2, v2, v1

    add-int/lit8 v2, v2, 0xb

    add-int/2addr v2, v0

    if-ne v4, v2, :cond_4e

    add-int/lit8 v0, v0, 0x2

    :goto_3a
    rem-int/lit8 v2, v0, 0x2

    if-nez v2, :cond_3f

    const/4 v0, -0x1

    :cond_3f
    sput v0, Lq;->K:I

    sput-boolean v1, LMidlet;->c:Z

    new-instance v0, Ljava/lang/Thread;

    invoke-direct {v0, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :cond_4c
    move v0, v2

    goto :goto_13

    :cond_4e
    const/16 v0, 0xd

    goto :goto_3a
.end method

.method public static u()V
    .registers 1

    :try_start_0
    const-string v0, "/u/lg.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->fc:Ljavax/microedition/lcdui/Image;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9

    :goto_8
    return-void

    :catch_9
    move-exception v0

    goto :goto_8
.end method

.method public static v()V
    .registers 5

    const/4 v0, 0x0

    const/4 v4, 0x4

    sget v1, Lq;->ae:I

    add-int/lit8 v1, v1, -0x28

    sput v1, Lq;->bm:I

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x32

    sput v1, Lq;->fg:I

    const/4 v1, 0x0

    sput-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    new-array v1, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    :try_start_15
    sget-object v1, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x0

    const-string v3, "/u/t.png"

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v1, v2

    sget-object v1, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x1

    const-string v3, "/u/wpt2.png"

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v1, v2

    sget-object v1, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x2

    const-string v3, "/u/wpt3.png"

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v1, v2

    sget-object v1, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x3

    const-string v3, "/u/wpt4.png"

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v1, v2
    :try_end_41
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_41} :catch_76

    :goto_41
    sget-object v1, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_4c

    new-array v1, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_4a
    if-lt v1, v4, :cond_50

    :cond_4c
    invoke-static {}, Ljava/lang/System;->gc()V

    return-void

    :cond_50
    :try_start_50
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/bd"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_6d
    .catch Ljava/io/IOException; {:try_start_50 .. :try_end_6d} :catch_71

    :goto_6d
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_4a

    :catch_71
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_6d

    :catch_76
    move-exception v1

    goto :goto_41
.end method

.method public static w()V
    .registers 5

    const/4 v4, 0x4

    const/4 v0, 0x0

    sput v0, Lq;->ge:I

    sget-object v1, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_f

    new-array v1, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    move v1, v0

    :goto_d
    if-lt v1, v4, :cond_10

    :cond_f
    return-void

    :cond_10
    :try_start_10
    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/u/bd"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_2d
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_2d} :catch_31

    :goto_2d
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_d

    :catch_31
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2d
.end method

.method public static x()V
    .registers 1

    sget v0, Lq;->H:I

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->bv:I

    const/16 v0, 0xe

    sput v0, Lq;->K:I

    return-void
.end method

.method private static y()V
    .registers 6

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v4, -0x1

    sget v0, Lq;->eQ:I

    packed-switch v0, :pswitch_data_b4

    :cond_a
    :goto_a
    :pswitch_a  #0x7, 0xb
    sget v0, Lc;->j:I

    if-ltz v0, :cond_1b

    sget v0, Lc;->j:I

    sget v1, Lc;->k:I

    sget v2, Lc;->l:I

    sget v3, Lc;->m:I

    invoke-static {v0, v1, v2, v3}, Lq;->b(IIII)V

    sput v4, Lc;->j:I

    :cond_1b
    return-void

    :pswitch_1c  #0x3
    sput v1, Lg;->bc:I

    sput v1, Lg;->bh:I

    const-string v0, "Giết 10 nhím"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_a

    :pswitch_26  #0x4
    sput-boolean v2, Lg;->f:Z

    sput v4, Lg;->bc:I

    sput v1, Lg;->bh:I

    const-string v0, "đã phục hồi khinh công"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_a

    :pswitch_32  #0x5
    sput v2, Lg;->bc:I

    sput v1, Lg;->bh:I

    const-string v0, "Tìm Sakura ở thác"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_a

    :pswitch_3c  #0x6
    sput v3, Lg;->bc:I

    sput v1, Lg;->bh:I

    const-string v0, "Tìm Toniku thôn Sanzuya"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_a

    :pswitch_46  #0x8
    sput-boolean v2, Lg;->i:Z

    sput v4, Lg;->bc:I

    sput v1, Lg;->bh:I

    const-string v0, "Lên đường!"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_a

    :pswitch_52  #0x9
    sput v4, Lg;->bh:I

    const/16 v0, 0x9

    sput v0, Lg;->bc:I

    const-string v0, "Giết mực khổng lồ"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_a

    :pswitch_5e  #0xa
    sput v4, Lq;->eQ:I

    const/16 v0, 0x450

    sput v0, Lg;->at:I

    const/16 v0, 0xf0

    sput v0, Lg;->au:I

    const/16 v0, 0x480

    sput v0, Lg;->bo:I

    const/16 v0, 0xf0

    sput v0, Lg;->bp:I

    sput v5, Lg;->bn:I

    sput v4, Lg;->bA:I

    sput v2, Lg;->aF:I

    sput v2, Lg;->bs:I

    sput v1, Lg;->bL:I

    invoke-static {v5}, Lg;->d(I)V

    const/16 v0, 0x19

    invoke-static {v0}, Lq;->g(I)V

    goto :goto_a

    :pswitch_83  #0xc
    sput v4, Lq;->eQ:I

    sput v3, Lq;->av:I

    sput-boolean v2, Lg;->A:Z

    const-string v0, "đã có sáo thần"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_a

    :pswitch_90  #0xd
    sput v4, Lq;->eQ:I

    sput v2, Lg;->a:I

    const-string v0, "Mua thuốc mang về cho Sakura"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_a

    :pswitch_9b  #0xe
    const/16 v0, 0xe

    sput v0, Lg;->bc:I

    sput v4, Lq;->eQ:I

    goto/16 :goto_a

    :pswitch_a3  #0xf
    sput v4, Lq;->eQ:I

    sget-boolean v0, Lg;->o:Z

    if-eqz v0, :cond_a

    const/4 v0, 0x3

    sput v0, Lg;->a:I

    const-string v0, "Tìm thẻ học sinh"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_a

    nop

    :pswitch_data_b4
    .packed-switch 0x3
        :pswitch_1c  #00000003
        :pswitch_26  #00000004
        :pswitch_32  #00000005
        :pswitch_3c  #00000006
        :pswitch_a  #00000007
        :pswitch_46  #00000008
        :pswitch_52  #00000009
        :pswitch_5e  #0000000a
        :pswitch_a  #0000000b
        :pswitch_83  #0000000c
        :pswitch_90  #0000000d
        :pswitch_9b  #0000000e
        :pswitch_a3  #0000000f
    .end packed-switch
.end method

.method private static z()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->aq:Ljavax/microedition/lcdui/Image;

    return-void
.end method


# virtual methods
.method public final commandAction(Ljavax/microedition/lcdui/Command;Ljavax/microedition/lcdui/Displayable;)V
    .registers 6

    invoke-virtual {p1}, Ljavax/microedition/lcdui/Command;->getLabel()Ljava/lang/String;

    move-result-object v0

    const-string v1, "OK"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-static {}, Lb;->e()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " >> "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    check-cast p2, Ljavax/microedition/lcdui/TextBox;

    invoke-virtual {p2}, Ljavax/microedition/lcdui/TextBox;->getString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "sms://+84914710711"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lb;->a(Ljava/lang/String;Ljava/lang/String;I)V

    :cond_33
    sget-object v0, LMidlet;->b:LMidlet;

    invoke-static {v0}, Ljavax/microedition/lcdui/Display;->getDisplay(Ljavax/microedition/midlet/MIDlet;)Ljavax/microedition/lcdui/Display;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljavax/microedition/lcdui/Display;->setCurrent(Ljavax/microedition/lcdui/Displayable;)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Canvas;->setFullScreenMode(Z)V

    return-void
.end method

.method protected final keyPressed(I)V
    .registers 10

    const/16 v7, 0x39

    const/4 v6, 0x1

    const/4 v1, -0x5

    const/4 v0, 0x0

    sget-boolean v2, Lq;->m:Z

    if-eqz v2, :cond_a

    :cond_9
    :goto_9
    return-void

    :cond_a
    const/16 v2, 0x23

    if-ne p1, v2, :cond_38

    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "1984"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_32

    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "30538"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_73

    const v0, 0x7a120

    sput v0, Lg;->aO:I

    sput v0, Lg;->aN:I

    sput v0, Lg;->aM:I

    sput v0, Lg;->aL:I

    const-string v0, "Unlimit HP MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    :cond_32
    :goto_32
    sput-boolean v6, Lq;->J:Z

    const-string v0, ""

    sput-object v0, Lq;->cs:Ljava/lang/String;

    :cond_38
    const/16 v0, 0x30

    if-lt p1, v0, :cond_60

    if-gt p1, v7, :cond_60

    sget-object v0, Lq;->cs:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    int-to-char v0, p1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lq;->cs:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v2, 0xa

    if-le v0, v2, :cond_60

    const-string v0, ""

    sput-object v0, Lq;->cs:Ljava/lang/String;

    :cond_60
    sget-boolean v0, Lq;->bR:Z

    if-eqz v0, :cond_67

    sparse-switch p1, :sswitch_data_162

    :cond_67
    :goto_67
    sget-boolean v0, Lq;->aA:Z

    if-eqz v0, :cond_6f

    if-eq p1, v1, :cond_6f

    if-ne p1, v7, :cond_9

    :cond_6f
    invoke-static {p1}, Lq;->k(I)V

    goto :goto_9

    :cond_73
    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "38305"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_87

    const/16 v0, 0x2710

    sput v0, Lg;->aJ:I

    const-string v0, "Unlimit Damage"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_32

    :cond_87
    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "1982"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_98

    const v0, 0x186a0

    invoke-static {v0}, Lg;->c(I)V

    goto :goto_32

    :cond_98
    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "1983"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b0

    sget v0, Lq;->aj:I

    const v2, 0xc350

    add-int/2addr v0, v2

    sput v0, Lq;->aj:I

    const-string v0, "Money+=50000"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto :goto_32

    :cond_b0
    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "12456"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_e9

    new-instance v2, Ljavax/microedition/lcdui/TextBox;

    const-string v3, "Type anything:"

    const-string v4, ""

    const/16 v5, 0x32

    invoke-direct {v2, v3, v4, v5, v0}, Ljavax/microedition/lcdui/TextBox;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    new-instance v3, Ljavax/microedition/lcdui/Command;

    const-string v4, "OK"

    const/4 v5, 0x4

    invoke-direct {v3, v4, v5, v0}, Ljavax/microedition/lcdui/Command;-><init>(Ljava/lang/String;II)V

    invoke-virtual {v2, v3}, Ljavax/microedition/lcdui/Displayable;->addCommand(Ljavax/microedition/lcdui/Command;)V

    new-instance v3, Ljavax/microedition/lcdui/Command;

    const-string v4, "Back"

    const/4 v5, 0x2

    invoke-direct {v3, v4, v5, v0}, Ljavax/microedition/lcdui/Command;-><init>(Ljava/lang/String;II)V

    invoke-virtual {v2, v3}, Ljavax/microedition/lcdui/Displayable;->addCommand(Ljavax/microedition/lcdui/Command;)V

    invoke-virtual {v2, p0}, Ljavax/microedition/lcdui/Displayable;->setCommandListener(Ljavax/microedition/lcdui/CommandListener;)V

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-static {v0}, Ljavax/microedition/lcdui/Display;->getDisplay(Ljavax/microedition/midlet/MIDlet;)Ljavax/microedition/lcdui/Display;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljavax/microedition/lcdui/Display;->setCurrent(Ljavax/microedition/lcdui/Displayable;)V

    goto/16 :goto_32

    :cond_e9
    sget-object v2, Lq;->cs:Ljava/lang/String;

    const-string v3, "1981"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_106

    :goto_f3
    sget-object v2, Lq;->bt:[Z

    array-length v2, v2

    if-lt v0, v2, :cond_ff

    const-string v0, "Unlock all map!"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_32

    :cond_ff
    sget-object v2, Lq;->bt:[Z

    aput-boolean v6, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_f3

    :cond_106
    sget-object v0, Lq;->cs:Ljava/lang/String;

    const-string v2, "8463"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32

    sget v0, Lq;->ez:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-wide v4, Lq;->eA:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x3e8

    div-long/2addr v2, v4

    long-to-int v2, v2

    add-int/2addr v0, v2

    new-instance v2, Ljava/lang/StringBuffer;

    div-int/lit16 v3, v0, 0xe10

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    rem-int/lit16 v3, v0, 0xe10

    div-int/lit8 v3, v3, 0x3c

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    rem-int/lit8 v0, v0, 0x3c

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_32

    :sswitch_14c
    const/4 p1, -0x6

    goto/16 :goto_67

    :sswitch_14f
    const/4 p1, -0x7

    goto/16 :goto_67

    :sswitch_152
    const/4 p1, -0x8

    goto/16 :goto_67

    :sswitch_155
    const/4 p1, -0x3

    goto/16 :goto_67

    :sswitch_158
    const/4 p1, -0x4

    goto/16 :goto_67

    :sswitch_15b
    const/4 p1, -0x2

    goto/16 :goto_67

    :sswitch_15e
    move p1, v1

    goto/16 :goto_67

    nop

    :sswitch_data_162
    .sparse-switch
        -0x17 -> :sswitch_152
        -0x16 -> :sswitch_14f
        -0x15 -> :sswitch_14c
        -0x14 -> :sswitch_15e
        -0x6 -> :sswitch_15b
        -0x5 -> :sswitch_158
        -0x2 -> :sswitch_155
        0x15 -> :sswitch_14c
        0x16 -> :sswitch_14f
    .end sparse-switch
.end method

.method protected final keyReleased(I)V
    .registers 4

    const/4 v0, -0x5

    sget-boolean v1, Lq;->bR:Z

    if-eqz v1, :cond_8

    sparse-switch p1, :sswitch_data_26

    :cond_8
    :goto_8
    sget-boolean v1, Lq;->aA:Z

    if-eqz v1, :cond_21

    if-eq p1, v0, :cond_21

    const/16 v0, 0x39

    if-eq p1, v0, :cond_21

    :goto_12
    return-void

    :sswitch_13
    const/4 p1, -0x6

    goto :goto_8

    :sswitch_15
    const/4 p1, -0x7

    goto :goto_8

    :sswitch_17
    const/4 p1, -0x8

    goto :goto_8

    :sswitch_19
    const/4 p1, -0x3

    goto :goto_8

    :sswitch_1b
    const/4 p1, -0x4

    goto :goto_8

    :sswitch_1d
    const/4 p1, -0x2

    goto :goto_8

    :sswitch_1f
    move p1, v0

    goto :goto_8

    :cond_21
    invoke-static {p1}, Lq;->l(I)V

    goto :goto_12

    nop

    :sswitch_data_26
    .sparse-switch
        -0x17 -> :sswitch_17
        -0x16 -> :sswitch_15
        -0x15 -> :sswitch_13
        -0x14 -> :sswitch_1f
        -0x6 -> :sswitch_1d
        -0x5 -> :sswitch_1b
        -0x2 -> :sswitch_19
        0x15 -> :sswitch_13
        0x16 -> :sswitch_15
    .end sparse-switch
.end method

.method protected final paint(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    :try_start_0
    sget v0, Lq;->K:I

    packed-switch v0, :pswitch_data_902

    :cond_5
    :goto_5
    return-void

    :pswitch_6  #0x1
    const/4 v0, -0x1

    const/4 v1, -0x1

    sget v2, Lq;->ab:I

    add-int/lit8 v2, v2, 0x2

    sget v3, Lq;->ac:I

    add-int/lit8 v3, v3, 0x2

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-static {p1}, Lq;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->ay:I

    neg-int v0, v0

    sget v1, Lq;->az:I

    neg-int v1, v1

    invoke-virtual {p1, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    sget v0, Lq;->as:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_28

    invoke-static {p1}, Lj;->b(Ljavax/microedition/lcdui/Graphics;)V

    :cond_28
    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_1a7

    invoke-static {p1}, Lj;->c(Ljavax/microedition/lcdui/Graphics;)V

    :goto_2f
    invoke-static {p1}, Lj;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget-object v0, Lo;->a:Lo;

    invoke-virtual {v0, p1}, Lo;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Lc;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->as:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_43

    invoke-static {p1}, Lj;->b(Ljavax/microedition/lcdui/Graphics;)V

    :cond_43
    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_4d

    sget-boolean v0, Lg;->w:Z

    if-nez v0, :cond_52

    :cond_4d
    const/4 v0, 0x0

    :goto_4e
    sget v1, Lq;->aW:I

    if-lt v0, v1, :cond_1ac

    :cond_52
    const/4 v0, 0x0

    move v10, v0

    :goto_54
    sget v0, Lq;->aP:I

    if-lt v10, v0, :cond_1eb

    invoke-static {p1}, Lt;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Le;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Lp;->a(Ljavax/microedition/lcdui/Graphics;)V

    const/4 v0, 0x0

    move v10, v0

    :goto_63
    sget v0, Lq;->dn:I

    if-lt v10, v0, :cond_26a

    const/4 v0, 0x0

    move v10, v0

    :goto_69
    sget v0, Lq;->cY:I

    if-lt v10, v0, :cond_2c3

    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_75

    sget-boolean v0, Lg;->l:Z

    if-eqz v0, :cond_31c

    :cond_75
    :goto_75
    invoke-static {p1}, La;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Ln;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Lg;->c(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->dF:I

    if-eqz v0, :cond_96

    sget v0, Lq;->dF:I

    rem-int/lit8 v0, v0, 0x3

    const/4 v1, 0x2

    if-ge v0, v1, :cond_96

    sget-object v1, Lq;->dV:[Ljavax/microedition/lcdui/Image;

    aget-object v0, v1, v0

    sget v1, Lq;->dD:I

    sget v2, Lq;->dE:I

    const/16 v3, 0x11

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_96
    sget v0, Lq;->am:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_ae

    sget v0, Lq;->dH:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_48d

    sget-object v0, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->dG:I

    aget-object v0, v0, v1

    sget v1, Lq;->ak:I

    sget v2, Lq;->al:I

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_ae
    :goto_ae
    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-eq v0, v1, :cond_b7

    invoke-static {p1}, Lg;->a(Ljavax/microedition/lcdui/Graphics;)V

    :cond_b7
    invoke-static {p1}, Lg;->d(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Li;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Lg;->b(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_c9

    invoke-static {p1}, Lg;->a(Ljavax/microedition/lcdui/Graphics;)V

    :cond_c9
    invoke-static {p1}, Lm;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->av:I

    if-eqz v0, :cond_d4

    sget-object v0, Lq;->dN:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_4b5

    :cond_d4
    :goto_d4
    const/4 v0, 0x0

    move v10, v0

    :goto_d6
    const/4 v0, 0x2

    if-lt v10, v0, :cond_4e5

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_e1

    const/4 v0, 0x0

    :goto_de
    const/4 v1, 0x2

    if-lt v0, v1, :cond_53d

    :cond_e1
    const/4 v0, 0x0

    move v1, v0

    :goto_e3
    sget v0, Lq;->cv:I

    if-lt v1, v0, :cond_55e

    const/4 v0, 0x0

    :goto_e8
    sget v1, Lq;->dh:I

    if-lt v0, v1, :cond_589

    sget-boolean v0, Ld;->a:Z

    if-eqz v0, :cond_f5

    sget v0, Ld;->c:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_5a8

    :cond_f5
    :goto_f5
    const/4 v0, 0x0

    :goto_f6
    sget v1, Lq;->cC:I

    if-lt v0, v1, :cond_5c3

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_102

    const/4 v0, 0x0

    :goto_ff
    const/4 v1, 0x2

    if-lt v0, v1, :cond_5db

    :cond_102
    invoke-static {p1}, Lj;->e(Ljavax/microedition/lcdui/Graphics;)V

    const/4 v0, 0x0

    move v6, v0

    :goto_107
    const/4 v0, 0x5

    if-lt v6, v0, :cond_5fa

    sget v0, Lq;->aE:I

    sget v1, Lq;->as:I

    if-ne v0, v1, :cond_11e

    sget-object v0, Lq;->dK:[Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->eu:I

    aget-object v0, v0, v1

    sget v1, Lq;->ev:I

    sget v2, Lq;->ew:I

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_11e
    invoke-static {p1}, Lq;->b(Ljavax/microedition/lcdui/Graphics;)V

    sget-boolean v0, Ls;->a:Z

    if-eqz v0, :cond_129

    sget v0, Ls;->c:I

    if-nez v0, :cond_61b

    :cond_129
    :goto_129
    sget-object v0, Lo;->b:Lo;

    invoke-virtual {v0, p1}, Lo;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget-boolean v0, Lq;->J:Z

    if-eqz v0, :cond_135

    invoke-static {p1}, Lq;->c(Ljavax/microedition/lcdui/Graphics;)V

    :cond_135
    sget v0, Lq;->cr:I

    const/4 v1, 0x1

    if-le v0, v1, :cond_13d

    invoke-static {p1}, Lq;->d(Ljavax/microedition/lcdui/Graphics;)V

    :cond_13d
    sget-boolean v0, Lq;->cV:Z

    if-eqz v0, :cond_187

    invoke-virtual {p1}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p1}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p1, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    const/4 v0, -0x1

    const/4 v1, -0x1

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, 0x2

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, 0x2

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget v2, Lq;->E:I

    const/16 v3, 0x15

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x9ccc3b

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    const/16 v1, 0x13

    sget v2, Lq;->E:I

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v1, 0x2

    if-le v0, v1, :cond_187

    sget-object v0, Lq;->cX:Ljava/lang/String;

    sget v1, Lq;->ad:I

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :cond_187
    sget-boolean v0, Lq;->bD:Z

    if-eqz v0, :cond_198

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget v2, Lq;->E:I

    sget v3, Lq;->F:I

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :cond_198
    sget-boolean v0, Lq;->bd:Z

    if-eqz v0, :cond_5

    invoke-static {p1}, Lq;->e(Ljavax/microedition/lcdui/Graphics;)V
    :try_end_19f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_19f} :catch_1a1

    goto/16 :goto_5

    :catch_1a1
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto/16 :goto_5

    :cond_1a7
    :try_start_1a7
    invoke-static {p1}, Lj;->d(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_2f

    :cond_1ac
    sget v1, Lq;->ay:I

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0xc

    if-gt v1, v2, :cond_1e7

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xc

    if-lt v1, v2, :cond_1e7

    sget v1, Lq;->az:I

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    if-gt v1, v2, :cond_1e7

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x18

    if-lt v1, v2, :cond_1e7

    sget-object v1, Lq;->dP:Ljavax/microedition/lcdui/Image;

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    sget-object v3, Lq;->aZ:[I

    aget v3, v3, v0

    const/16 v4, 0x21

    invoke-virtual {p1, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_1e7
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_4e

    :cond_1eb
    sget v0, Lq;->ay:I

    sget-object v1, Lq;->aR:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, 0xc

    if-gt v0, v1, :cond_233

    sget v0, Lq;->ay:I

    sget v1, Lq;->ab:I

    add-int/2addr v0, v1

    sget-object v1, Lq;->aR:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0xc

    if-lt v0, v1, :cond_233

    sget v0, Lq;->az:I

    sget-object v1, Lq;->aS:[I

    aget v1, v1, v10

    if-gt v0, v1, :cond_233

    sget v0, Lq;->az:I

    sget v1, Lq;->ac:I

    add-int/2addr v0, v1

    sget-object v1, Lq;->aS:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0x18

    if-lt v0, v1, :cond_233

    sget-object v0, Lq;->aT:[I

    aget v0, v0, v10

    const/4 v1, 0x1

    if-ne v0, v1, :cond_238

    sget-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->aU:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lq;->aR:[I

    aget v1, v1, v10

    sget-object v2, Lq;->aS:[I

    aget v2, v2, v10

    const/16 v3, 0x21

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_233
    :goto_233
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_54

    :cond_238
    sget-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->aU:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    sget-object v4, Lq;->aU:[I

    aget v4, v4, v10

    aget-object v0, v0, v4

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lq;->dM:[Ljavax/microedition/lcdui/Image;

    sget-object v5, Lq;->aU:[I

    aget v5, v5, v10

    aget-object v0, v0, v5

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget-object v0, Lq;->aR:[I

    aget v7, v0, v10

    sget-object v0, Lq;->aS:[I

    aget v8, v0, v10

    const/16 v9, 0x21

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_233

    :cond_26a
    sget-object v0, Lq;->dq:[I

    aget v0, v0, v10

    if-eqz v0, :cond_2be

    sget-object v0, Lq;->do:[I

    aget v0, v0, v10

    sget v1, Lq;->ay:I

    add-int/lit8 v1, v1, -0xa

    if-lt v0, v1, :cond_2be

    sget-object v0, Lq;->do:[I

    aget v0, v0, v10

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, 0xa

    if-gt v0, v1, :cond_2be

    sget-object v0, Lq;->dp:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    if-lt v0, v1, :cond_2be

    sget-object v0, Lq;->dp:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x14

    if-gt v0, v1, :cond_2be

    sget-object v0, Lq;->dR:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->dv:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    const/4 v2, 0x0

    sget-object v0, Lq;->dt:[I

    aget v0, v0, v10

    mul-int/lit8 v3, v0, 0xf

    const/16 v4, 0x8

    const/16 v5, 0xf

    const/4 v6, 0x0

    sget-object v0, Lq;->do:[I

    aget v7, v0, v10

    sget-object v0, Lq;->dp:[I

    aget v8, v0, v10

    const/16 v9, 0x21

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_2be
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_63

    :cond_2c3
    sget-object v0, Lq;->dc:[I

    aget v0, v0, v10

    if-eqz v0, :cond_317

    sget-object v0, Lq;->da:[I

    aget v0, v0, v10

    sget v1, Lq;->ay:I

    add-int/lit8 v1, v1, -0xa

    if-lt v0, v1, :cond_317

    sget-object v0, Lq;->da:[I

    aget v0, v0, v10

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, 0xa

    if-gt v0, v1, :cond_317

    sget-object v0, Lq;->db:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    if-lt v0, v1, :cond_317

    sget-object v0, Lq;->db:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x14

    if-gt v0, v1, :cond_317

    sget-object v0, Lq;->dY:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->cZ:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    const/4 v2, 0x0

    sget-object v0, Lq;->df:[I

    aget v0, v0, v10

    mul-int/lit8 v3, v0, 0xf

    const/16 v4, 0xd

    const/16 v5, 0xf

    const/4 v6, 0x0

    sget-object v0, Lq;->da:[I

    aget v7, v0, v10

    sget-object v0, Lq;->db:[I

    aget v8, v0, v10

    const/16 v9, 0x21

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_317
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_69

    :cond_31c
    sget v0, Lq;->eD:I

    const/16 v1, 0x16

    if-eq v0, v1, :cond_75

    sget v0, Lq;->ay:I

    sget v1, Lq;->ab:I

    add-int/2addr v0, v1

    sget v1, Lq;->aH:I

    sget v2, Lq;->eG:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    if-lt v0, v1, :cond_75

    sget v0, Lq;->ay:I

    sget v1, Lq;->aH:I

    sget v2, Lq;->eG:I

    shr-int/lit8 v2, v2, 0x1

    add-int/2addr v1, v2

    if-gt v0, v1, :cond_75

    sget v0, Lq;->az:I

    sget v1, Lq;->aI:I

    if-gt v0, v1, :cond_75

    sget v0, Lq;->az:I

    sget v1, Lq;->ac:I

    add-int/2addr v0, v1

    sget v1, Lq;->aI:I

    sget v2, Lq;->aJ:I

    sub-int/2addr v1, v2

    if-lt v0, v1, :cond_75

    const/4 v0, 0x0

    sget v1, Lq;->eF:I

    if-nez v1, :cond_376

    const/4 v10, -0x2

    sget v0, Lq;->eD:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_360

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v1, 0x5

    if-le v0, v1, :cond_360

    const/4 v10, -0x1

    :cond_360
    sget v0, Lq;->eE:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_40c

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    sget v1, Lq;->aH:I

    sget v2, Lq;->aI:I

    add-int/lit8 v2, v2, 0x1

    const/16 v3, 0x21

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    move v0, v10

    :cond_376
    :goto_376
    sget v1, Lq;->eE:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_435

    sget-object v1, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    sget v2, Lq;->eF:I

    aget-object v1, v1, v2

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    add-int/2addr v0, v3

    add-int/lit8 v0, v0, 0x1

    const/16 v3, 0x21

    invoke-virtual {p1, v1, v2, v0, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :goto_38d
    sget v0, Lq;->eD:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_3aa

    sget v0, Lq;->eE:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_461

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    sget v1, Lq;->aH:I

    add-int/lit8 v1, v1, 0xa

    sget v2, Lq;->aI:I

    add-int/lit8 v2, v2, -0x19

    add-int/lit8 v2, v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_3aa
    :goto_3aa
    sget v0, Lq;->eJ:I

    if-eqz v0, :cond_75

    const v0, 0x330011

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->aH:I

    sget v1, Lq;->eG:I

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    sget v1, Lq;->aI:I

    sget v2, Lq;->aJ:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, -0x7

    sget v2, Lq;->eG:I

    add-int/lit8 v2, v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lq;->aK:I

    sget v1, Lq;->eG:I

    mul-int/2addr v0, v1

    sget v1, Lq;->aL:I

    div-int/2addr v0, v1

    const/high16 v1, 0xee0000

    invoke-virtual {p1, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->aH:I

    sget v2, Lq;->eG:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    sget v2, Lq;->aI:I

    sget v3, Lq;->aJ:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v1, v2, v0, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0x440022

    invoke-virtual {p1, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->aH:I

    sget v2, Lq;->eG:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    add-int/2addr v1, v0

    sget v2, Lq;->aI:I

    sget v3, Lq;->aJ:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x6

    sget v3, Lq;->eG:I

    sub-int v0, v3, v0

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v1, v2, v0, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    goto/16 :goto_75

    :cond_40c
    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x4

    aget-object v1, v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v4, 0x4

    aget-object v0, v0, v4

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v5, 0x4

    aget-object v0, v0, v5

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget v7, Lq;->aH:I

    sget v0, Lq;->aI:I

    add-int/lit8 v8, v0, 0x1

    const/16 v9, 0x21

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    move v0, v10

    goto/16 :goto_376

    :cond_435
    sget-object v1, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    sget v2, Lq;->eF:I

    aget-object v1, v1, v2

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v4, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    sget v5, Lq;->eF:I

    aget-object v4, v4, v5

    invoke-virtual {v4}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v5, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    sget v6, Lq;->eF:I

    aget-object v5, v5, v6

    invoke-virtual {v5}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget v7, Lq;->aH:I

    sget v8, Lq;->aI:I

    add-int/2addr v0, v8

    add-int/lit8 v8, v0, 0x1

    const/16 v9, 0x21

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_38d

    :cond_461
    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x3

    aget-object v1, v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v4, 0x3

    aget-object v0, v0, v4

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lq;->dX:[Ljavax/microedition/lcdui/Image;

    const/4 v5, 0x3

    aget-object v0, v0, v5

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget v0, Lq;->aH:I

    add-int/lit8 v7, v0, -0xa

    sget v0, Lq;->aI:I

    add-int/lit8 v0, v0, -0x19

    add-int/lit8 v8, v0, 0x1

    const/16 v9, 0x18

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_3aa

    :cond_48d
    sget-object v0, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->dG:I

    aget-object v1, v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    sget v4, Lq;->dG:I

    aget-object v0, v0, v4

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lq;->dW:[Ljavax/microedition/lcdui/Image;

    sget v5, Lq;->dG:I

    aget-object v0, v0, v5

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget v7, Lq;->ak:I

    sget v8, Lq;->al:I

    const/4 v9, 0x3

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_ae

    :cond_4b5
    sget v0, Lq;->bi:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_4d8

    sget-object v1, Lq;->dN:Ljavax/microedition/lcdui/Image;

    sget v2, Lq;->ed:I

    sget v3, Lq;->ee:I

    sget v0, Lq;->at:I

    sget-object v4, Lc;->f:[I

    const/4 v5, 0x0

    aget v4, v4, v5

    add-int/lit8 v4, v4, 0xf

    rem-int/2addr v0, v4

    const/4 v4, 0x4

    if-le v0, v4, :cond_4d6

    const/4 v0, 0x0

    :goto_4ce
    add-int/2addr v0, v3

    const/16 v3, 0x21

    invoke-virtual {p1, v1, v2, v0, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_d4

    :cond_4d6
    const/4 v0, 0x1

    goto :goto_4ce

    :cond_4d8
    sget-object v0, Lq;->dN:Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->ed:I

    sget v2, Lq;->ee:I

    const/16 v3, 0x21

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_d4

    :cond_4e5
    sget-object v0, Lq;->cL:[I

    aget v0, v0, v10

    const/4 v1, -0x1

    if-eq v0, v1, :cond_507

    sget-object v0, Lq;->cN:[I

    aget v0, v0, v10

    const/4 v1, 0x1

    if-ne v0, v1, :cond_50c

    sget-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->cM:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lq;->cJ:[I

    aget v1, v1, v10

    sget-object v2, Lq;->cK:[I

    aget v2, v2, v10

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_507
    :goto_507
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_d6

    :cond_50c
    sget-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->cM:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    sget-object v4, Lq;->cM:[I

    aget v4, v4, v10

    aget-object v0, v0, v4

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lq;->dZ:[Ljavax/microedition/lcdui/Image;

    sget-object v5, Lq;->cM:[I

    aget v5, v5, v10

    aget-object v0, v0, v5

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget-object v0, Lq;->cJ:[I

    aget v7, v0, v10

    sget-object v0, Lq;->cK:[I

    aget v8, v0, v10

    const/4 v9, 0x3

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_507

    :cond_53d
    sget-object v1, Lq;->cU:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_55a

    sget-object v1, Lq;->dT:[[Ljavax/microedition/lcdui/Image;

    aget-object v1, v1, v0

    sget-object v2, Lq;->cU:[I

    aget v2, v2, v0

    aget-object v1, v1, v2

    sget-object v2, Lq;->cS:[I

    aget v2, v2, v0

    sget-object v3, Lq;->cT:[I

    aget v3, v3, v0

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_55a
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_de

    :cond_55e
    sget-object v0, Lq;->cy:[I

    aget v0, v0, v1

    const/4 v2, -0x1

    if-eq v0, v2, :cond_582

    sget-object v0, Lq;->dJ:[[Ljavax/microedition/lcdui/Image;

    sget-object v2, Lq;->cB:[I

    aget v2, v2, v1

    aget-object v2, v0, v2

    sget-object v0, Lq;->cz:[I

    aget v0, v0, v1

    if-lez v0, :cond_587

    const/4 v0, 0x0

    :goto_574
    aget-object v0, v2, v0

    sget-object v2, Lq;->cw:[I

    aget v2, v2, v1

    sget-object v3, Lq;->cx:[I

    aget v3, v3, v1

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_582
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto/16 :goto_e3

    :cond_587
    const/4 v0, 0x1

    goto :goto_574

    :cond_589
    sget-object v1, Lq;->ah:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_5a4

    sget-object v1, Lq;->dU:[Ljavax/microedition/lcdui/Image;

    sget-object v2, Lq;->dk:[I

    aget v2, v2, v0

    aget-object v1, v1, v2

    sget-object v2, Lq;->di:[I

    aget v2, v2, v0

    sget-object v3, Lq;->dj:[I

    aget v3, v3, v0

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_5a4
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_e8

    :cond_5a8
    sget-object v1, Ld;->b:Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x0

    sget v0, Ld;->c:I

    if-nez v0, :cond_5c1

    const/16 v3, 0x18

    :goto_5b1
    const/16 v4, 0x18

    const/16 v5, 0x18

    const/4 v6, 0x0

    sget v7, Ld;->d:I

    sget v8, Ld;->e:I

    const/4 v9, 0x0

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_f5

    :cond_5c1
    const/4 v3, 0x0

    goto :goto_5b1

    :cond_5c3
    sget-object v1, Lq;->cF:[I

    aget v1, v1, v0

    if-eqz v1, :cond_5d7

    sget-object v1, Lq;->dL:Ljavax/microedition/lcdui/Image;

    sget-object v2, Lq;->cD:[I

    aget v2, v2, v0

    sget-object v3, Lq;->cE:[I

    aget v3, v3, v0

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_5d7
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_f6

    :cond_5db
    sget-object v1, Lq;->cQ:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_5f6

    sget-object v1, Lq;->ec:[Ljavax/microedition/lcdui/Image;

    sget-object v2, Lq;->cR:[I

    aget v2, v2, v0

    aget-object v1, v1, v2

    sget-object v2, Lq;->cO:[I

    aget v2, v2, v0

    sget-object v3, Lq;->cP:[I

    aget v3, v3, v0

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_5f6
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_ff

    :cond_5fa
    sget-object v0, Lq;->dB:[I

    aget v0, v0, v6

    const/4 v1, -0x1

    if-eq v0, v1, :cond_616

    sget-object v0, Lq;->dw:[Ljava/lang/String;

    aget-object v1, v0, v6

    sget-object v0, Lq;->dC:[I

    aget v2, v0, v6

    sget-object v0, Lq;->dx:[I

    aget v3, v0, v6

    sget-object v0, Lq;->dy:[I

    aget v4, v0, v6

    const/4 v5, 0x0

    move-object v0, p1

    invoke-static/range {v0 .. v5}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V

    :cond_616
    add-int/lit8 v0, v6, 0x1

    move v6, v0

    goto/16 :goto_107

    :cond_61b
    sget-object v1, Ls;->b:Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x0

    sget v0, Ls;->f:I

    shr-int/lit8 v0, v0, 0x2

    mul-int/lit8 v3, v0, 0x32

    const/16 v4, 0x32

    const/16 v5, 0x32

    const/4 v6, 0x0

    sget v7, Ls;->d:I

    sget v8, Ls;->e:I

    const/4 v9, 0x3

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_129

    :pswitch_634  #0x2
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget v2, Lq;->E:I

    const/16 v3, 0x15

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Loading... "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lq;->bl:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "%"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget v1, Lq;->E:I

    shr-int/lit8 v1, v1, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto/16 :goto_5

    :pswitch_663  #0x3
    const/4 v0, -0x1

    const/4 v1, -0x1

    sget v2, Lq;->E:I

    add-int/lit8 v2, v2, 0x2

    sget v3, Lq;->F:I

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    invoke-static {p1}, Lq;->a(Ljavax/microedition/lcdui/Graphics;)V

    sget v0, Lq;->ay:I

    neg-int v0, v0

    sget v1, Lq;->az:I

    neg-int v1, v1

    invoke-virtual {p1, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_736

    invoke-static {p1}, Lj;->c(Ljavax/microedition/lcdui/Graphics;)V

    :goto_683
    invoke-static {p1}, Lj;->a(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Lj;->e(Ljavax/microedition/lcdui/Graphics;)V

    invoke-virtual {p1}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p1}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p1, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget v2, Lq;->ab:I

    sget v3, Lq;->bV:I

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/4 v0, 0x0

    sget v1, Lq;->bW:I

    sget v2, Lq;->ab:I

    sget v3, Lq;->F:I

    sget v4, Lq;->bW:I

    sub-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->bM:I

    const/16 v1, 0x28

    if-ne v0, v1, :cond_6d4

    const v0, 0x9ccc3b

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    sget v1, Lq;->bV:I

    add-int/lit8 v1, v1, -0x1

    sget v2, Lq;->E:I

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/4 v0, 0x0

    sget v1, Lq;->bW:I

    add-int/lit8 v1, v1, 0x1

    sget v2, Lq;->E:I

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :cond_6d4
    sget-object v0, Lq;->ea:Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, -0x4

    sget v2, Lq;->bZ:I

    sub-int/2addr v1, v2

    sget v2, Lq;->H:I

    add-int/lit8 v2, v2, -0xa

    sget v3, Lq;->ca:I

    add-int/2addr v2, v3

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget v0, Lq;->bM:I

    const/16 v1, 0x14

    if-le v0, v1, :cond_704

    sget-object v0, Lq;->dO:[Ljavax/microedition/lcdui/Image;

    sget v1, Lq;->bN:I

    aget-object v0, v0, v1

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, 0x1e

    sget v2, Lq;->bZ:I

    sub-int/2addr v1, v2

    sget v2, Lq;->H:I

    sget v3, Lq;->ca:I

    add-int/2addr v2, v3

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_704
    const-string v0, "*"

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, -0x37

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    sget v2, Lq;->bY:I

    const/4 v3, 0x0

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "/"

    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, 0x37

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x3

    add-int/2addr v1, v2

    sget v2, Lq;->bY:I

    const/4 v3, 0x1

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->bL:[Ljava/lang/String;

    sget v1, Lq;->bS:I

    aget-object v0, v0, v1

    sget v1, Lq;->G:I

    sget v2, Lq;->bY:I

    const/4 v3, 0x3

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    goto/16 :goto_5

    :cond_736
    invoke-static {p1}, Lj;->d(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_683

    :pswitch_73b  #0x4
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget v2, Lq;->E:I

    sget v3, Lq;->F:I

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lq;->fc:Ljavax/microedition/lcdui/Image;

    if-eqz v0, :cond_5

    sget v0, Lq;->fe:I

    if-ltz v0, :cond_5

    sget-object v1, Lq;->fc:Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x0

    sget v0, Lq;->fe:I

    mul-int/lit8 v3, v0, 0x33

    const/16 v4, 0x47

    const/16 v5, 0x33

    const/4 v6, 0x0

    sget v0, Lq;->E:I

    shr-int/lit8 v7, v0, 0x1

    sget v0, Lq;->F:I

    shr-int/lit8 v8, v0, 0x1

    const/4 v9, 0x3

    move-object v0, p1

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_5

    :pswitch_76b  #0x5
    invoke-static {p1}, Lq;->i(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_770  #0x6
    invoke-static {p1}, Lq;->j(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_775  #0x7
    invoke-static {p1}, Lq;->l(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_77a  #0xe
    invoke-static {p1}, Lq;->m(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_77f  #0x8
    invoke-static {p1}, Lq;->h(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_784  #0x9
    invoke-static {p1}, Lq;->g(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_789  #0xa
    invoke-static {p1}, Lq;->k(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_78e  #0xb
    invoke-static {p1}, Lq;->f(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_793  #0xc
    invoke-static {p1}, Lq;->f(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_798  #0xd
    invoke-static {p1}, Lb;->a(Ljavax/microedition/lcdui/Graphics;)V

    goto/16 :goto_5

    :pswitch_79d  #0xf
    invoke-virtual {p1}, Ljavax/microedition/lcdui/Graphics;->getTranslateX()I

    move-result v0

    neg-int v0, v0

    invoke-virtual {p1}, Ljavax/microedition/lcdui/Graphics;->getTranslateY()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {p1, v0, v1}, Ljavax/microedition/lcdui/Graphics;->translate(II)V

    invoke-static {p1}, Lq;->c(Ljavax/microedition/lcdui/Graphics;)V

    invoke-static {p1}, Lq;->b(Ljavax/microedition/lcdui/Graphics;)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget v2, Lq;->E:I

    sget v3, Lq;->F:I

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->setClip(IIII)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x40

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, -0x13

    const/16 v2, 0x81

    const/16 v3, 0x78

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/4 v0, 0x0

    sget v1, Lq;->F:I

    add-int/lit8 v1, v1, -0xd

    sget v2, Lq;->E:I

    const/16 v3, 0xd

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "Chọn"

    const/4 v1, 0x3

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    const/4 v3, 0x0

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "Quay lại"

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, -0x3

    sget v2, Lq;->F:I

    add-int/lit8 v2, v2, -0xd

    const/4 v3, 0x1

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const v0, 0xbb6611

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3f

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, -0x12

    const/16 v2, 0x7e

    const/16 v3, 0x75

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v0, 0x642200

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0x3d

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, -0x10

    const/16 v2, 0x7b

    const/16 v3, 0x73

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const-string v0, "Chọn vũ khí"

    sget v1, Lq;->ad:I

    sget v2, Lq;->fn:I

    const/4 v3, 0x2

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0xa

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x19

    const/16 v2, 0x13

    const/16 v3, 0x14

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0xa

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x19

    const/16 v2, 0x13

    const/16 v3, 0x14

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v0, 0x4a1900

    invoke-virtual {p1, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0xa

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x19

    const/16 v2, 0x14

    const/16 v3, 0x14

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lq;->ad:I

    add-int/lit8 v0, v0, -0xa

    sget v1, Lq;->fn:I

    add-int/lit8 v1, v1, 0x19

    const/16 v2, 0x14

    const/16 v3, 0x14

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v0, Lq;->fu:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lq;->bs:[I

    sget v2, Lq;->fp:I

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x8

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x1c

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->fp:I

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x3c

    const/4 v3, 0x2

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "*"

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x1c

    sget v2, Lq;->fv:I

    rem-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x1c

    const/4 v3, 0x0

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    const-string v0, "/"

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x1e

    sget v2, Lq;->fv:I

    rem-int/lit8 v2, v2, 0x3

    add-int/2addr v1, v2

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x1c

    const/4 v3, 0x1

    invoke-static {p1, v0, v1, v2, v3}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x14

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, -0x13

    const/16 v3, 0x18

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, -0x40

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x24

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    sget v1, Lq;->ad:I

    add-int/lit8 v1, v1, 0x41

    sget v2, Lq;->fn:I

    add-int/lit8 v2, v2, 0x65

    const/16 v3, 0x28

    invoke-virtual {p1, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V
    :try_end_8ff
    .catch Ljava/lang/Exception; {:try_start_1a7 .. :try_end_8ff} :catch_1a1

    goto/16 :goto_5

    nop

    :pswitch_data_902
    .packed-switch 0x1
        :pswitch_6  #00000001
        :pswitch_634  #00000002
        :pswitch_663  #00000003
        :pswitch_73b  #00000004
        :pswitch_76b  #00000005
        :pswitch_770  #00000006
        :pswitch_775  #00000007
        :pswitch_77f  #00000008
        :pswitch_784  #00000009
        :pswitch_789  #0000000a
        :pswitch_78e  #0000000b
        :pswitch_793  #0000000c
        :pswitch_798  #0000000d
        :pswitch_77a  #0000000e
        :pswitch_79d  #0000000f
    .end packed-switch
.end method

.method protected final pointerDragged(II)V
    .registers 3

    sput p1, Lq;->A:I

    sput p2, Lq;->B:I

    return-void
.end method

.method protected final pointerPressed(II)V
    .registers 3

    sput p1, Lq;->A:I

    sput p2, Lq;->B:I

    return-void
.end method

.method protected final pointerReleased(II)V
    .registers 4

    const/4 v0, 0x1

    sput-boolean v0, Lq;->z:Z

    sput p1, Lq;->A:I

    sput p2, Lq;->B:I

    return-void
.end method

.method public final run()V
    .registers 15

    const/4 v11, 0x4

    const/4 v9, 0x2

    const/4 v8, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x1

    sget-boolean v0, Lq;->y:Z

    if-nez v0, :cond_13

    sput-boolean v6, Lq;->y:Z

    const/16 v0, 0xd

    sput v0, Lq;->K:I

    const/16 v0, 0x8

    sput v0, Lb;->g:I

    :cond_13
    :try_start_13
    sget-boolean v0, Lq;->y:Z
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_15} :catch_3f

    if-nez v0, :cond_20

    :goto_17
    invoke-static {}, Lq;->a()V

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    return-void

    :cond_20
    :try_start_20
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    sget v0, Lq;->K:I

    packed-switch v0, :pswitch_data_21d8

    :cond_29
    :goto_29
    invoke-virtual {p0}, Ljavax/microedition/lcdui/Canvas;->repaint()V

    invoke-virtual {p0}, Ljavax/microedition/lcdui/Canvas;->serviceRepaints()V

    :goto_2f
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sub-long/2addr v0, v12

    sget v2, Lq;->bz:I

    int-to-long v2, v2

    cmp-long v0, v0, v2

    if-gez v0, :cond_13

    invoke-static {}, Ljava/lang/Thread;->yield()V
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_3e} :catch_3f

    goto :goto_2f

    :catch_3f
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_17

    :pswitch_44  #0x1
    :try_start_44
    sget v0, Lq;->at:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->at:I

    const/16 v1, 0x2710

    if-ne v0, v1, :cond_51

    const/4 v0, 0x0

    sput v0, Lq;->at:I

    :cond_51
    sget v0, Lg;->aN:I

    if-gtz v0, :cond_64

    sget-boolean v0, Lq;->by:Z

    if-nez v0, :cond_64

    const/4 v0, 0x0

    sput v0, Lg;->aN:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->by:Z

    const-string v0, "đã hết MP"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    :cond_64
    sget-boolean v0, Lq;->by:Z

    if-eqz v0, :cond_6f

    sget v0, Lg;->aN:I

    if-lez v0, :cond_6f

    const/4 v0, 0x0

    sput-boolean v0, Lq;->by:Z

    :cond_6f
    sget-boolean v0, Lq;->m:Z

    if-eqz v0, :cond_9e

    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_9e

    sget v0, Lg;->R:I

    sget v1, Lg;->at:I

    sget v2, Lg;->aF:I

    mul-int/lit8 v2, v2, 0x12

    sub-int/2addr v1, v2

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/4 v1, 0x5

    if-gt v0, v1, :cond_1cd

    const/16 v0, 0x12

    sput v0, Lg;->V:I

    sget v0, Lg;->at:I

    sget v1, Lg;->aF:I

    mul-int/lit8 v1, v1, 0xf

    sub-int/2addr v0, v1

    sput v0, Lg;->R:I

    sget v0, Lg;->au:I

    sput v0, Lg;->S:I

    const/4 v0, 0x0

    sput-boolean v0, Lq;->m:Z

    :cond_9e
    :goto_9e
    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_ce

    sget v0, Lg;->D:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_ce

    sget-boolean v0, Lg;->x:Z

    if-nez v0, :cond_ce

    sget-boolean v0, Lg;->w:Z

    if-eqz v0, :cond_ce

    sget v0, Lg;->at:I

    const/16 v1, 0x9f0

    if-lt v0, v1, :cond_ce

    const/4 v0, 0x1

    sput-boolean v0, Lg;->x:Z

    const/4 v0, 0x1

    sput-boolean v0, Lg;->t:Z

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    sget v0, Lg;->aW:I

    const/16 v1, 0x14

    if-lt v0, v1, :cond_1ec

    const/16 v0, 0x25

    invoke-static {v0}, Lq;->g(I)V

    :cond_ce
    :goto_ce
    sget v0, Lq;->aM:I

    const/16 v1, 0x22

    if-ne v0, v1, :cond_e9

    sget v0, Lg;->aW:I

    const/16 v1, 0x14

    if-lt v0, v1, :cond_e9

    sget v0, Lg;->a:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_e9

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    const/4 v0, 0x4

    sput v0, Lg;->a:I

    :cond_e9
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_103

    sget-boolean v0, Lg;->r:Z

    if-nez v0, :cond_103

    sget-boolean v0, Lg;->p:Z

    if-nez v0, :cond_103

    sget-boolean v0, Lq;->j:Z

    if-nez v0, :cond_103

    const/16 v0, 0x13

    invoke-static {v0}, Lq;->j(I)V

    const/4 v0, 0x1

    sput-boolean v0, Lq;->j:Z

    :cond_103
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_11f

    sget-boolean v0, Lg;->s:Z

    if-eqz v0, :cond_11f

    sget v0, Lg;->aW:I

    const/16 v1, 0xd

    if-ge v0, v1, :cond_11f

    sget-boolean v0, Lq;->bA:Z

    if-nez v0, :cond_11f

    const/16 v0, 0x21

    invoke-static {v0}, Lq;->j(I)V

    const/4 v0, 0x1

    sput-boolean v0, Lq;->bA:Z

    :cond_11f
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_144

    sget-boolean v0, Lg;->s:Z

    if-eqz v0, :cond_144

    sget-boolean v0, Lg;->bm:Z

    if-eqz v0, :cond_144

    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_144

    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_144

    sget v0, Lg;->at:I

    const/16 v1, 0xa08

    if-lt v0, v1, :cond_144

    sget-boolean v0, Lq;->aA:Z

    if-nez v0, :cond_144

    const/16 v0, 0x33

    invoke-static {v0}, Lq;->g(I)V

    :cond_144
    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_179

    sget-boolean v0, Lg;->r:Z

    if-eqz v0, :cond_179

    sget-boolean v0, Lg;->s:Z

    if-nez v0, :cond_179

    sget v0, Lg;->at:I

    sget-object v1, Lc;->d:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x32

    if-ge v0, v1, :cond_179

    sget v0, Lg;->au:I

    sget-object v1, Lc;->e:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    if-ne v0, v1, :cond_179

    const/16 v0, 0x1e

    invoke-static {v0}, Lq;->g(I)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    const/4 v0, 0x1

    sput-boolean v0, Lg;->s:Z

    :cond_179
    sget v0, Lq;->as:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_18f

    sget v0, Lg;->bc:I

    if-ne v0, v11, :cond_18f

    sget-boolean v0, Lq;->k:Z

    if-nez v0, :cond_18f

    const/4 v0, 0x1

    sput-boolean v0, Lq;->k:Z

    const/16 v0, 0x15

    invoke-static {v0}, Lq;->j(I)V

    :cond_18f
    sget v0, Lq;->as:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_1aa

    sget v0, Lg;->at:I

    const/16 v1, 0x978

    if-lt v0, v1, :cond_1aa

    sget-boolean v0, Lq;->l:Z

    if-nez v0, :cond_1aa

    const/4 v0, 0x1

    sput-boolean v0, Lq;->l:Z

    const/16 v0, 0x21

    invoke-static {v0}, Lq;->g(I)V

    const/4 v0, 0x1

    sput-boolean v0, Lg;->O:Z

    :cond_1aa
    sget v0, Lg;->at:I

    if-gez v0, :cond_1f3

    sget v0, Lj;->g:I

    if-eq v0, v8, :cond_299

    invoke-static {}, Lq;->A()V

    sget v0, Lj;->l:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget v0, Lj;->m:I

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lj;->g:I

    invoke-static {v0}, Lq;->i(I)V

    goto/16 :goto_29

    :cond_1cd
    sget v0, Lg;->R:I

    sget v1, Lg;->at:I

    sget v2, Lg;->aF:I

    mul-int/lit8 v2, v2, 0xf

    sub-int/2addr v1, v2

    if-ge v0, v1, :cond_1ea

    move v0, v6

    :goto_1d9
    sput v0, Lg;->ad:I

    sget v0, Lg;->ad:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lg;->T:I

    const/16 v0, 0x108

    sput v0, Lg;->S:I

    const/4 v0, 0x2

    sput v0, Lg;->V:I

    goto/16 :goto_9e

    :cond_1ea
    move v0, v8

    goto :goto_1d9

    :cond_1ec
    const/16 v0, 0x31

    invoke-static {v0}, Lq;->g(I)V

    goto/16 :goto_ce

    :cond_1f3
    sget v0, Lg;->at:I

    sget v1, Lj;->c:I

    add-int/lit8 v1, v1, -0x18

    if-lt v0, v1, :cond_238

    sget v0, Lj;->h:I

    if-eq v0, v8, :cond_299

    invoke-static {}, Lq;->A()V

    sget v0, Lj;->i:I

    if-eq v0, v8, :cond_222

    sget v0, Lg;->au:I

    sget v1, Lj;->v:I

    if-le v0, v1, :cond_222

    sget v0, Lj;->p:I

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget v0, Lj;->q:I

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lj;->i:I

    invoke-static {v0}, Lq;->i(I)V

    goto/16 :goto_29

    :cond_222
    sget v0, Lj;->n:I

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget v0, Lj;->o:I

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lj;->h:I

    invoke-static {v0}, Lq;->i(I)V

    goto/16 :goto_29

    :cond_238
    sget v0, Lg;->au:I

    sget v1, Lg;->aw:I

    add-int/2addr v0, v1

    sget v1, Lj;->d:I

    if-lt v0, v1, :cond_266

    sget v0, Lg;->ax:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_266

    sget v0, Lj;->k:I

    if-eq v0, v8, :cond_299

    invoke-static {}, Lq;->A()V

    sget v0, Lj;->t:I

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget v0, Lj;->u:I

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lj;->k:I

    invoke-static {v0}, Lq;->i(I)V

    const/4 v0, 0x4

    sput v0, Lg;->ax:I

    goto/16 :goto_29

    :cond_266
    sget v0, Lg;->au:I

    if-gez v0, :cond_299

    sget v0, Lq;->as:I

    if-ne v0, v11, :cond_494

    sget v0, Lg;->at:I

    const/16 v1, 0xa80

    if-lt v0, v1, :cond_296

    invoke-static {}, Lq;->A()V

    sget v0, Lj;->r:I

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget v0, Lj;->s:I

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lj;->j:I

    invoke-static {v0}, Lq;->i(I)V

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, -0x3

    sput v0, Lg;->aw:I

    const/4 v0, 0x0

    sput v0, Lg;->av:I

    goto/16 :goto_29

    :cond_296
    const/4 v0, 0x4

    sput v0, Lg;->ax:I

    :cond_299
    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_2d3

    sget v0, Lq;->fX:I

    const/16 v1, 0xc

    if-ge v0, v1, :cond_2d3

    sget-object v0, Lq;->eZ:[I

    sget v1, Lq;->fX:I

    aget v0, v0, v1

    if-eq v0, v8, :cond_2d3

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x32

    if-nez v0, :cond_2d3

    sget-object v0, Lo;->b:Lo;

    new-instance v1, Lr;

    sget v2, Lq;->ay:I

    sget-object v3, Lq;->eY:Ljava/util/Random;

    invoke-virtual {v3}, Ljava/util/Random;->nextInt()I

    move-result v3

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    sget v4, Lq;->ab:I

    rem-int/2addr v3, v4

    add-int/2addr v2, v3

    sget v3, Lq;->az:I

    sget-object v4, Lq;->eZ:[I

    sget v5, Lq;->fX:I

    aget v4, v4, v5

    invoke-direct {v1, v2, v3, v4}, Lr;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :cond_2d3
    invoke-static {}, Lq;->P()V

    invoke-static {}, Lq;->M()V

    invoke-static {}, Lq;->K()Z

    move-result v0

    if-nez v0, :cond_29

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_2ea

    sget-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;

    if-eqz v0, :cond_2ea

    move v0, v7

    :goto_2e8
    if-lt v0, v9, :cond_4ba

    :cond_2ea
    sget-boolean v0, Lq;->bd:Z

    if-eqz v0, :cond_4ed

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_307

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->F()V

    sget v0, Lq;->eP:I

    sget v1, Lq;->eO:I

    if-ne v0, v1, :cond_307

    const/4 v0, 0x0

    sput-boolean v0, Lq;->bd:Z

    invoke-static {}, Lq;->y()V

    :cond_307
    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    :cond_30a
    :goto_30a
    invoke-static {}, Lq;->J()V

    move v0, v7

    :goto_30e
    sget v1, Lq;->aW:I

    if-lt v0, v1, :cond_be2

    :cond_312
    :goto_312
    move v0, v7

    :goto_313
    sget v1, Lq;->aP:I

    if-lt v0, v1, :cond_e35

    move v0, v7

    :goto_318
    const/4 v1, 0x5

    if-lt v0, v1, :cond_ea7

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_322

    move v0, v7

    :goto_320
    if-lt v0, v9, :cond_ee3

    :cond_322
    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_329

    move v0, v7

    :goto_327
    if-lt v0, v9, :cond_f17

    :cond_329
    move v0, v7

    :goto_32a
    if-lt v0, v9, :cond_f50

    move v10, v7

    :goto_32d
    sget v0, Lq;->dh:I

    if-lt v10, v0, :cond_f90

    :goto_331
    sget-boolean v0, Ld;->a:Z

    if-eqz v0, :cond_351

    sget v0, Ld;->c:I

    if-ne v0, v6, :cond_351

    sget v0, Ld;->d:I

    sget v1, Ld;->f:I

    add-int/2addr v0, v1

    sput v0, Ld;->d:I

    sget v0, Ld;->f:I

    if-gez v0, :cond_351

    sget v0, Ld;->d:I

    sget v1, Ld;->g:I

    if-ge v0, v1, :cond_351

    sget v0, Ld;->g:I

    sput v0, Ld;->d:I

    const/4 v0, 0x0

    sput v0, Ld;->c:I

    :cond_351
    sget-boolean v0, Ls;->a:Z

    if-eqz v0, :cond_385

    sget v0, Ls;->c:I

    if-ne v0, v6, :cond_385

    sget v0, Ls;->f:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Ls;->f:I

    const/16 v1, 0x8

    if-le v0, v1, :cond_367

    const/16 v0, 0x8

    sput v0, Ls;->f:I

    :cond_367
    sget v0, Ls;->d:I

    sget v1, Lq;->ay:I

    sget v2, Lq;->ad:I

    add-int/2addr v1, v2

    sget v2, Ls;->d:I

    sub-int/2addr v1, v2

    shr-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Ls;->d:I

    sget v0, Ls;->e:I

    sget v1, Lq;->az:I

    sget v2, Lq;->ae:I

    add-int/2addr v1, v2

    sget v2, Ls;->e:I

    sub-int/2addr v1, v2

    shr-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Ls;->e:I

    :cond_385
    invoke-static {}, Lq;->H()V

    sget v0, Lq;->as:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_1251

    sget v0, Lq;->bi:I

    if-ne v0, v9, :cond_1248

    sget-boolean v0, Lg;->r:Z

    if-nez v0, :cond_1248

    sget v0, Lq;->dF:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->dF:I

    :cond_39c
    :goto_39c
    sget v0, Lq;->am:I

    if-eq v0, v8, :cond_3ee

    sget v0, Lq;->an:I

    if-ne v0, v6, :cond_1264

    sget v0, Lq;->dI:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->dI:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_3c9

    sget v0, Lq;->dG:I

    if-ne v0, v6, :cond_3b5

    const/4 v0, -0x1

    sput v0, Lq;->am:I

    :cond_3b5
    sget v0, Lq;->dG:I

    if-ge v0, v6, :cond_3bf

    sget v0, Lq;->dG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->dG:I

    :cond_3bf
    sget v0, Lq;->dG:I

    if-ne v0, v6, :cond_3c9

    sget v0, Lq;->al:I

    add-int/lit8 v0, v0, 0x8

    sput v0, Lq;->al:I

    :cond_3c9
    sget v0, Lg;->at:I

    sget v1, Lq;->ak:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_3ee

    sget v0, Lg;->au:I

    sget v1, Lq;->al:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x11

    if-ge v0, v1, :cond_3ee

    sget v0, Le;->e:I

    sget v1, Lq;->dH:I

    neg-int v1, v1

    invoke-static {v0, v1}, Lg;->a(II)V

    const/4 v0, -0x1

    sput v0, Lq;->am:I

    :cond_3ee
    :goto_3ee
    invoke-static {}, Lq;->I()V

    sget v0, Lq;->aE:I

    if-ltz v0, :cond_43d

    sget v0, Lq;->es:I

    sget v1, Lq;->ay:I

    add-int/lit8 v1, v1, 0xa

    if-le v0, v1, :cond_12b7

    sget v0, Lq;->es:I

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, -0xa

    if-ge v0, v1, :cond_12b7

    sget v0, Lq;->et:I

    sget v1, Lq;->az:I

    add-int/lit8 v1, v1, 0xa

    if-le v0, v1, :cond_12b7

    sget v0, Lq;->et:I

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, -0xa

    if-ge v0, v1, :cond_12b7

    const/4 v0, 0x2

    sput v0, Lq;->eu:I

    sget v0, Lq;->es:I

    sput v0, Lq;->ev:I

    sget v0, Lq;->et:I

    sget v1, Lq;->ey:I

    add-int/2addr v0, v1

    sput v0, Lq;->ew:I

    :cond_429
    :goto_429
    sget v0, Lq;->ey:I

    sget v1, Lq;->ex:I

    add-int/2addr v0, v1

    sput v0, Lq;->ey:I

    const/4 v1, 0x5

    if-eq v0, v1, :cond_438

    sget v0, Lq;->ey:I

    const/4 v1, -0x5

    if-ne v0, v1, :cond_43d

    :cond_438
    sget v0, Lq;->ex:I

    neg-int v0, v0

    sput v0, Lq;->ex:I

    :cond_43d
    invoke-static {}, Lg;->b()V

    invoke-static {}, Lg;->a()V

    invoke-static {}, Lg;->i()V

    invoke-static {}, Lg;->c()V

    invoke-static {}, La;->b()V

    invoke-static {}, Ln;->b()V

    invoke-static {}, Lt;->b()V

    invoke-static {}, Lm;->b()V

    invoke-static {}, Le;->a()V

    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_460

    sget-boolean v0, Lg;->l:Z

    if-eqz v0, :cond_1342

    :cond_460
    :goto_460
    invoke-static {}, Lq;->L()V

    invoke-static {}, Lq;->O()V

    sget v0, Lq;->as:I

    const/16 v1, 0x11

    if-ne v0, v1, :cond_14e5

    sget v0, Lq;->bi:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_14e5

    const/4 v0, 0x0

    sput v0, Lq;->av:I

    :cond_474
    :goto_474
    invoke-static {}, Li;->a()V

    sget-object v0, Lo;->b:Lo;

    invoke-virtual {v0}, Lo;->b()V

    sget-object v0, Lo;->a:Lo;

    invoke-virtual {v0}, Lo;->b()V

    sget-boolean v0, Lq;->cV:Z

    if-eqz v0, :cond_29

    sget v0, Lq;->cW:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->cW:I

    const/16 v1, 0x96

    if-lt v0, v1, :cond_29

    const/4 v0, 0x0

    sput-boolean v0, Lq;->cV:Z

    goto/16 :goto_29

    :cond_494
    sget v0, Lj;->j:I

    if-eq v0, v8, :cond_299

    invoke-static {}, Lq;->A()V

    sget v0, Lj;->r:I

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget v0, Lj;->s:I

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lj;->j:I

    invoke-static {v0}, Lq;->i(I)V

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, -0x3

    sput v0, Lg;->aw:I

    const/4 v0, 0x0

    sput v0, Lg;->av:I

    goto/16 :goto_29

    :cond_4ba
    sget v1, Lq;->at:I

    add-int/lit8 v2, v0, 0x2

    shl-int/lit8 v2, v2, 0x3

    rem-int/2addr v1, v2

    if-nez v1, :cond_4e9

    sget-object v1, Lq;->L:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->L:[I

    aget v1, v1, v0

    sget v2, Lq;->ab:I

    sget-object v3, Lq;->aq:Ljavax/microedition/lcdui/Image;

    invoke-virtual {v3}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v3

    shr-int/lit8 v3, v3, 0x1

    add-int/2addr v2, v3

    if-le v1, v2, :cond_4e9

    sget-object v1, Lq;->L:[I

    sget-object v2, Lq;->aq:Ljavax/microedition/lcdui/Image;

    invoke-virtual {v2}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v2

    shr-int/lit8 v2, v2, 0x1

    neg-int v2, v2

    aput v2, v1, v0

    :cond_4e9
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_2e8

    :cond_4ed
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_52e

    sget v0, Lg;->ax:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_502

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    goto/16 :goto_30a

    :cond_502
    invoke-static {}, Lq;->U()V

    const/4 v0, 0x5

    sput v0, Lq;->K:I

    invoke-static {}, Lq;->b()V

    invoke-static {}, Lq;->c()V

    :cond_50e
    :goto_50e
    sget v0, Lg;->ax:I

    if-ne v0, v6, :cond_85d

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_667

    invoke-static {}, Lq;->c()V

    sget-object v0, Lq;->V:Ljava/lang/String;

    const-string v1, "Giao tiếp"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_614

    sget v0, Lg;->bi:I

    invoke-static {v0}, Lc;->a(I)V

    goto/16 :goto_30a

    :cond_52e
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x0

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_549

    const/4 v0, 0x1

    sput-boolean v0, Lq;->fa:Z

    invoke-static {}, Lq;->T()V

    const/16 v0, 0xf

    sput v0, Lq;->K:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x0

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto :goto_50e

    :cond_549
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_55a

    const/4 v0, 0x2

    sput v0, Lg;->aR:I

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto :goto_50e

    :cond_55a
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_56b

    const/4 v0, -0x2

    sput v0, Lg;->aR:I

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto :goto_50e

    :cond_56b
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0x9

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_57c

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0x9

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto/16 :goto_30a

    :cond_57c
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x7

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_58a

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x7

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto :goto_50e

    :cond_58a
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xa

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_5cf

    sget v0, Lg;->ax:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_5cf

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xa

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    sget v0, Lg;->aL:I

    sget v1, Lg;->aM:I

    if-ge v0, v1, :cond_50e

    move v0, v7

    :goto_5a5
    const/4 v1, 0x3

    if-ge v0, v1, :cond_50e

    sget-object v1, Lq;->br:[I

    aget v1, v1, v0

    if-lez v1, :cond_5cc

    sget-object v1, Lq;->br:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    sget v1, Lg;->aL:I

    sget-object v2, Lq;->ft:[I

    aget v0, v2, v0

    add-int/2addr v0, v1

    sput v0, Lg;->aL:I

    sget v1, Lg;->aM:I

    if-le v0, v1, :cond_5c7

    sget v0, Lg;->aM:I

    sput v0, Lg;->aL:I

    :cond_5c7
    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_50e

    :cond_5cc
    add-int/lit8 v0, v0, 0x1

    goto :goto_5a5

    :cond_5cf
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xb

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_50e

    sget v0, Lg;->ax:I

    const/4 v1, 0x6

    if-eq v0, v1, :cond_50e

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xb

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    sget v0, Lg;->aN:I

    sget v1, Lg;->aO:I

    if-ge v0, v1, :cond_50e

    const/4 v0, 0x3

    :goto_5ea
    const/4 v1, 0x6

    if-ge v0, v1, :cond_50e

    sget-object v1, Lq;->br:[I

    aget v1, v1, v0

    if-lez v1, :cond_611

    sget-object v1, Lq;->br:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    sget v1, Lg;->aN:I

    sget-object v2, Lq;->ft:[I

    aget v0, v2, v0

    add-int/2addr v0, v1

    sput v0, Lg;->aN:I

    sget v1, Lg;->aO:I

    if-le v0, v1, :cond_60c

    sget v0, Lg;->aO:I

    sput v0, Lg;->aN:I

    :cond_60c
    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_50e

    :cond_611
    add-int/lit8 v0, v0, 0x1

    goto :goto_5ea

    :cond_614
    sget-object v0, Lq;->V:Ljava/lang/String;

    const-string v1, "Trò chuyện"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_644

    invoke-static {}, Lq;->c()V

    sget-object v0, Lg;->M:[I

    sget v1, Lg;->bj:I

    sget v2, Lg;->aF:I

    neg-int v2, v2

    aput v2, v0, v1

    sget-object v0, Lg;->G:[[Ljava/lang/String;

    sget v1, Lg;->bj:I

    aget-object v0, v0, v1

    const/4 v1, 0x0

    sget-object v2, Lg;->K:[I

    sget v3, Lg;->bj:I

    aget v2, v2, v3

    sget-object v3, Lg;->L:[I

    sget v4, Lg;->bj:I

    aget v3, v3, v4

    add-int/lit8 v3, v3, -0x2c

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_30a

    :cond_644
    sget-object v0, Lq;->V:Ljava/lang/String;

    const-string v1, "Nói chuyện"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_30a

    sget-boolean v0, Lg;->bg:Z

    if-eqz v0, :cond_30a

    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_30a

    sget-object v0, Lq;->bO:[[Ljava/lang/String;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x0

    sget v2, Lg;->R:I

    sget v3, Lg;->S:I

    add-int/lit8 v3, v3, -0x2c

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_30a

    :cond_667
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_78c

    move v0, v7

    :goto_66f
    sget v1, Lq;->aP:I

    if-lt v0, v1, :cond_6be

    move v0, v7

    :goto_674
    sget v1, Lp;->a:I

    if-lt v0, v1, :cond_751

    sget-boolean v0, Lg;->f:Z

    if-eqz v0, :cond_789

    const/16 v0, -0xa

    :goto_67e
    sput v0, Lg;->aw:I

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, -0x1

    sput v0, Lg;->bi:I

    const/4 v0, -0x1

    sput v0, Lg;->bj:I

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    :cond_696
    :goto_696
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    const/4 v0, 0x5

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aV:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, 0x0

    sput v0, Lg;->aw:I

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    const/4 v0, -0x1

    sput v0, Lg;->bi:I

    const/4 v0, -0x1

    sput v0, Lg;->bj:I

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_30a

    :cond_6be
    sget v1, Lg;->au:I

    sget-object v2, Lq;->aS:[I

    aget v2, v2, v0

    if-ne v1, v2, :cond_74d

    sget v1, Lg;->at:I

    sget-object v2, Lq;->aR:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    const/16 v2, 0x1e

    if-ge v1, v2, :cond_74d

    sget-object v1, Lq;->aR:[I

    aget v1, v1, v0

    sput v1, Lg;->at:I

    const/16 v1, 0x12

    sput v1, Lg;->ax:I

    sget v1, Lq;->as:I

    const/16 v2, 0xd

    if-ne v1, v2, :cond_70e

    sget v1, Lg;->R:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    mul-int/lit8 v3, v3, 0x12

    sub-int/2addr v2, v3

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    const/4 v2, 0x5

    if-gt v1, v2, :cond_720

    const/16 v1, 0x12

    sput v1, Lg;->V:I

    sget v1, Lg;->R:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    mul-int/lit8 v3, v3, 0xf

    sub-int/2addr v2, v3

    if-eq v1, v2, :cond_70e

    sget v1, Lg;->at:I

    sget v2, Lg;->aF:I

    mul-int/lit8 v2, v2, 0xf

    sub-int/2addr v1, v2

    sput v1, Lg;->R:I

    :cond_70e
    :goto_70e
    invoke-static {}, Lq;->b()V

    sput v0, Lq;->aQ:I

    sget-object v1, Lq;->aT:[I

    sget v2, Lg;->aF:I

    aput v2, v1, v0

    sget-object v1, Lq;->aU:[I

    const/4 v2, 0x0

    aput v2, v1, v0

    goto/16 :goto_30a

    :cond_720
    const/4 v1, 0x1

    sput-boolean v1, Lq;->m:Z

    const/4 v1, 0x2

    sput v1, Lg;->V:I

    const/16 v1, 0x108

    sput v1, Lg;->au:I

    sget v1, Lg;->R:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    mul-int/lit8 v3, v3, 0xf

    sub-int/2addr v2, v3

    if-ge v1, v2, :cond_738

    const/4 v1, 0x1

    sput v1, Lg;->ad:I

    :cond_738
    sget v1, Lg;->R:I

    sget v2, Lg;->at:I

    sget v3, Lg;->aF:I

    mul-int/lit8 v3, v3, 0xf

    sub-int/2addr v2, v3

    if-lt v1, v2, :cond_746

    const/4 v1, -0x1

    sput v1, Lg;->ad:I

    :cond_746
    sget v1, Lg;->ad:I

    mul-int/lit8 v1, v1, 0x5

    sput v1, Lg;->av:I

    goto :goto_70e

    :cond_74d
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_66f

    :cond_751
    sget-object v1, Lp;->f:[I

    aget v1, v1, v0

    if-nez v1, :cond_785

    sget v1, Lg;->au:I

    sget-object v2, Lp;->c:[I

    aget v2, v2, v0

    if-ne v1, v2, :cond_785

    sget v1, Lg;->at:I

    sget-object v2, Lp;->b:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    const/16 v2, 0x1e

    if-ge v1, v2, :cond_785

    invoke-static {}, Lq;->b()V

    sput v0, Lp;->g:I

    sget-object v1, Lp;->d:[I

    sget v2, Lg;->aF:I

    aput v2, v1, v0

    sget-object v1, Lp;->f:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lp;->e:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    goto/16 :goto_30a

    :cond_785
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_674

    :cond_789
    const/4 v0, -0x8

    goto/16 :goto_67e

    :cond_78c
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_7b2

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_7a9

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    :goto_79a
    const/4 v0, -0x1

    sput v0, Lg;->bi:I

    const/4 v0, -0x1

    sput v0, Lg;->bj:I

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_696

    :cond_7a9
    const/4 v0, 0x2

    sput v0, Lg;->ax:I

    sget v0, Lq;->aC:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto :goto_79a

    :cond_7b2
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_7d7

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_7cf

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    :goto_7c0
    const/4 v0, -0x1

    sput v0, Lg;->bj:I

    const/4 v0, -0x1

    sput v0, Lg;->bi:I

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_696

    :cond_7cf
    const/4 v0, 0x2

    sput v0, Lg;->ax:I

    sget v0, Lq;->aC:I

    sput v0, Lg;->av:I

    goto :goto_7c0

    :cond_7d7
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0x8

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_80b

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, 0x0

    sput v0, Lg;->aH:I

    const/16 v0, 0x8

    sput v0, Lg;->ax:I

    sget v0, Lp;->g:I

    if-eq v0, v8, :cond_696

    sget-object v0, Lp;->f:[I

    sget v1, Lp;->g:I

    const/4 v2, 0x0

    aput v2, v0, v1

    sget-object v0, Lp;->c:[I

    sget v1, Lp;->g:I

    sget v2, Lg;->au:I

    aput v2, v0, v1

    sget-object v0, Lp;->e:[I

    sget v1, Lp;->g:I

    const/4 v2, 0x0

    aput v2, v0, v1

    const/4 v0, 0x5

    sput v0, Lq;->aC:I

    const/4 v0, -0x1

    sput v0, Lp;->g:I

    goto/16 :goto_696

    :cond_80b
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x1

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_834

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    const/4 v0, -0x4

    sput v0, Lg;->av:I

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, -0x1

    sput v0, Lg;->bi:I

    const/4 v0, -0x1

    sput v0, Lg;->bj:I

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_696

    :cond_834
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x3

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_696

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    const/4 v0, 0x4

    sput v0, Lg;->av:I

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, -0x1

    sput v0, Lg;->bi:I

    const/4 v0, -0x1

    sput v0, Lg;->bj:I

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_696

    :cond_85d
    sget v0, Lg;->ax:I

    if-ne v0, v9, :cond_8c5

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_896

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    sget-boolean v0, Lg;->f:Z

    if-eqz v0, :cond_894

    const/16 v0, -0xa

    :goto_871
    sput v0, Lg;->aw:I

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    :cond_879
    :goto_879
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    const/4 v0, 0x5

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aV:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, 0x0

    sput v0, Lg;->aw:I

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto/16 :goto_30a

    :cond_894
    const/4 v0, -0x8

    goto :goto_871

    :cond_896
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_8ae

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_8a5

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    goto :goto_879

    :cond_8a5
    sget v0, Lq;->aC:I

    neg-int v0, v0

    sget v1, Lg;->aR:I

    add-int/2addr v0, v1

    sput v0, Lg;->av:I

    goto :goto_879

    :cond_8ae
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_879

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_8bd

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    goto :goto_879

    :cond_8bd
    sget v0, Lq;->aC:I

    sget v1, Lg;->aR:I

    add-int/2addr v0, v1

    sput v0, Lg;->av:I

    goto :goto_879

    :cond_8c5
    sget v0, Lg;->ax:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_911

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_8de

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    goto/16 :goto_30a

    :cond_8de
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_8f8

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_8ee

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    goto/16 :goto_30a

    :cond_8ee
    sget v0, Lg;->aP:I

    neg-int v0, v0

    sget v1, Lg;->aR:I

    add-int/2addr v0, v1

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_8f8
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_908

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    goto/16 :goto_30a

    :cond_908
    sget v0, Lg;->aP:I

    sget v1, Lg;->aR:I

    add-int/2addr v0, v1

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_911
    sget v0, Lg;->ax:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_9a2

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_942

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_93c

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    :cond_924
    :goto_924
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_956

    const/4 v0, 0x5

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aV:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto/16 :goto_30a

    :cond_93c
    sget v0, Lq;->aC:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto :goto_924

    :cond_942
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_924

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_951

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    goto :goto_924

    :cond_951
    sget v0, Lq;->aC:I

    sput v0, Lg;->av:I

    goto :goto_924

    :cond_956
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    sget-boolean v0, Lg;->f:Z

    if-eqz v0, :cond_30a

    sget v0, Lg;->aN:I

    if-lez v0, :cond_30a

    sget v0, Lg;->aw:I

    const/4 v1, -0x4

    if-le v0, v1, :cond_30a

    sget v0, Lg;->aG:I

    if-nez v0, :cond_30a

    sget v0, Lg;->aG:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aG:I

    const/4 v0, -0x7

    sput v0, Lg;->aw:I

    sget v0, Lg;->aN:I

    add-int/lit8 v0, v0, -0x5

    sput v0, Lg;->aN:I

    if-gez v0, :cond_982

    const/4 v0, 0x0

    sput v0, Lg;->aN:I

    :cond_982
    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    const/4 v0, -0x1

    sget v1, Lg;->at:I

    add-int/lit8 v1, v1, 0x8

    sget v2, Lg;->au:I

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    const/4 v0, 0x1

    sget v1, Lg;->at:I

    add-int/lit8 v1, v1, -0x8

    sget v2, Lg;->au:I

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    invoke-static {v0, v1}, Lq;->c(II)Z

    goto/16 :goto_30a

    :cond_9a2
    sget v0, Lg;->ax:I

    if-ne v0, v11, :cond_a05

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_9bd

    sget v0, Lp;->g:I

    if-eq v0, v8, :cond_9bd

    invoke-static {}, Lq;->c()V

    sget v0, Lg;->au:I

    add-int/lit8 v0, v0, -0x3

    sput v0, Lg;->au:I

    const/4 v0, 0x7

    sput v0, Lg;->ay:I

    :cond_9bd
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_9f1

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_9eb

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    :cond_9cb
    :goto_9cb
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    sget v0, Lg;->aw:I

    if-gt v0, v11, :cond_9da

    sget v0, Lp;->g:I

    if-eq v0, v8, :cond_30a

    :cond_9da
    const/4 v0, 0x5

    sput v0, Lg;->ax:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/4 v0, 0x0

    sput v0, Lg;->aV:I

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto/16 :goto_30a

    :cond_9eb
    sget v0, Lq;->aC:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto :goto_9cb

    :cond_9f1
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_9cb

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_a00

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    goto :goto_9cb

    :cond_a00
    sget v0, Lq;->aC:I

    sput v0, Lg;->av:I

    goto :goto_9cb

    :cond_a05
    sget v0, Lg;->ax:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_a48

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_a32

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_a2a

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    :cond_a18
    :goto_a18
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    const/4 v0, 0x1

    sput-boolean v0, Lg;->aZ:Z

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto/16 :goto_30a

    :cond_a2a
    sget v0, Lq;->aC:I

    neg-int v0, v0

    add-int/lit8 v0, v0, 0x2

    sput v0, Lg;->av:I

    goto :goto_a18

    :cond_a32
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_a18

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_a41

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    goto :goto_a18

    :cond_a41
    sget v0, Lq;->aC:I

    add-int/lit8 v0, v0, -0x2

    sput v0, Lg;->av:I

    goto :goto_a18

    :cond_a48
    sget v0, Lg;->ax:I

    const/16 v1, 0x12

    if-ne v0, v1, :cond_aeb

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_a70

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    const/16 v0, 0x15

    sput v0, Lg;->ax:I

    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_a67

    const/16 v0, 0x15

    sput v0, Lg;->V:I

    :cond_a67
    const/16 v0, 0xa

    sput v0, Lg;->aG:I

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    goto/16 :goto_30a

    :cond_a70
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_aa3

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_a87

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, -0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_a87
    const/4 v0, 0x1

    sput v0, Lg;->aG:I

    const/16 v0, 0x13

    sput v0, Lg;->ax:I

    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_a98

    const/16 v0, 0x13

    sput v0, Lg;->V:I

    :cond_a98
    const/16 v0, 0xa

    sput v0, Lg;->aG:I

    sget v0, Lq;->aD:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_aa3
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_ad2

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_aba

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, 0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_aba
    const/16 v0, 0x13

    sput v0, Lg;->ax:I

    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_ac8

    const/16 v0, 0x13

    sput v0, Lg;->V:I

    :cond_ac8
    const/16 v0, 0xa

    sput v0, Lg;->aG:I

    sget v0, Lq;->aD:I

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_ad2
    sget-object v0, Lq;->C:[Z

    const/16 v1, 0x8

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    const/4 v0, 0x1

    sput v0, Lg;->ax:I

    sget v0, Lq;->as:I

    const/16 v1, 0xd

    if-ne v0, v1, :cond_ae6

    const/4 v0, 0x1

    sput v0, Lg;->V:I

    :cond_ae6
    const/4 v0, -0x1

    sput v0, Lq;->aQ:I

    goto/16 :goto_30a

    :cond_aeb
    sget v0, Lg;->ax:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_b44

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_b09

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    const/16 v0, 0x15

    sput v0, Lg;->ax:I

    const/4 v0, -0x1

    sput v0, Lq;->aX:I

    const/16 v0, 0xa

    sput v0, Lg;->aG:I

    goto/16 :goto_30a

    :cond_b09
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_b27

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_b20

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, -0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_b20
    sget v0, Lq;->aD:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_b27
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_b3e

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, 0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_b3e
    sget v0, Lq;->aD:I

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_b44
    sget v0, Lg;->ax:I

    const/16 v1, 0x15

    if-ne v0, v1, :cond_b85

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_b68

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_b61

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, -0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_b61
    sget v0, Lq;->aD:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_b68
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_b7f

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, 0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_b7f
    sget v0, Lq;->aD:I

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_b85
    sget v0, Lg;->ax:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_bc6

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_ba9

    sget v0, Lg;->aF:I

    if-ne v0, v6, :cond_ba2

    const/4 v0, -0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, -0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_ba2
    sget v0, Lq;->aD:I

    neg-int v0, v0

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_ba9
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    sget v0, Lg;->aF:I

    if-ne v0, v8, :cond_bc0

    const/4 v0, 0x1

    sput v0, Lg;->aF:I

    sget-object v0, Lq;->aT:[I

    sget v1, Lq;->aQ:I

    const/4 v2, 0x1

    aput v2, v0, v1

    goto/16 :goto_30a

    :cond_bc0
    sget v0, Lq;->aD:I

    sput v0, Lg;->av:I

    goto/16 :goto_30a

    :cond_bc6
    sget v0, Lg;->ax:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_30a

    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_30a

    const/16 v0, -0xa

    sput v0, Lg;->aw:I

    const/4 v0, 0x3

    sput v0, Lg;->ax:I

    const/4 v0, -0x1

    sput v0, Lg;->aq:I

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    goto/16 :goto_30a

    :cond_be2
    sget-object v1, Lq;->ba:[I

    aget v1, v1, v0

    sparse-switch v1, :sswitch_data_21fa

    :cond_be9
    :goto_be9
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_30e

    :sswitch_bed
    sget v1, Lq;->as:I

    const/4 v2, 0x3

    if-ne v1, v2, :cond_bf6

    sget-boolean v1, Lg;->n:Z

    if-nez v1, :cond_312

    :cond_bf6
    sget-object v1, Lq;->aY:[I

    aget v2, v1, v0

    sget-object v3, Lq;->bb:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->bb:[I

    aget v1, v1, v0

    if-lez v1, :cond_c76

    sget-object v1, Lq;->bb:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    :goto_c0f
    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, -0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-nez v1, :cond_c3f

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, 0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-nez v1, :cond_c3f

    sget-object v1, Lq;->ba:[I

    const/4 v2, 0x4

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    :cond_c3f
    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, 0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x2

    const/4 v3, 0x4

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-nez v1, :cond_c66

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, -0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x2

    const/16 v3, 0x8

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_be9

    :cond_c66
    sget-object v1, Lq;->aY:[I

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    invoke-static {v2}, Lj;->e(I)I

    move-result v2

    add-int/lit8 v2, v2, 0xc

    aput v2, v1, v0

    goto/16 :goto_be9

    :cond_c76
    sget-object v1, Lq;->bb:[I

    aget v1, v1, v0

    if-gez v1, :cond_c85

    sget-object v1, Lq;->bb:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    goto :goto_c0f

    :cond_c85
    sget-object v1, Lq;->ba:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    goto :goto_c0f

    :sswitch_c8b
    sget-object v1, Lq;->aZ:[I

    aget v2, v1, v0

    sget-object v3, Lq;->bc:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    aget v1, v1, v0

    const/16 v2, 0x14

    if-ge v1, v2, :cond_ca6

    sget-object v1, Lq;->bc:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    :cond_ca6
    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, 0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    const/4 v3, 0x2

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-nez v1, :cond_cc8

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, -0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    const/4 v3, 0x2

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_ce0

    :cond_cc8
    sget-object v1, Lq;->aZ:[I

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    const/4 v2, 0x0

    aput v2, v1, v0

    sget-object v1, Lq;->ba:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    goto/16 :goto_be9

    :cond_ce0
    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    sget v3, Lj;->f:I

    sub-int/2addr v2, v3

    const/16 v3, 0x40

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_be9

    sget-object v1, Lq;->aZ:[I

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xd

    invoke-static {v1, v2}, Lq;->c(II)Z

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, 0x1

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xa

    invoke-static {v1, v2}, Lq;->c(II)Z

    sget-object v1, Lq;->bc:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->eL:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    sget-object v1, Lq;->eM:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->ba:[I

    const/16 v2, 0xb

    aput v2, v1, v0

    goto/16 :goto_be9

    :sswitch_d34
    sget v1, Lq;->as:I

    const/16 v2, 0xe

    if-ne v1, v2, :cond_d9e

    sget-boolean v1, Lg;->w:Z

    if-nez v1, :cond_d9e

    sget-boolean v1, Lg;->v:Z

    if-eqz v1, :cond_d9e

    sget v1, Lg;->D:I

    if-ne v1, v6, :cond_d78

    sget v1, Lg;->au:I

    sget v2, Lg;->aA:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x7

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    const/16 v2, 0x19

    if-ge v1, v2, :cond_d78

    sget v1, Lg;->at:I

    sget-object v2, Lq;->aY:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    const/16 v2, 0xa

    if-ge v1, v2, :cond_d78

    const/4 v1, 0x2

    sput v1, Lg;->D:I

    sget-object v1, Lq;->bc:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    const-string v1, "Giải được câu đố thứ 2"

    invoke-static {v1}, Lq;->a(Ljava/lang/String;)V

    :cond_d78
    sget v1, Lg;->D:I

    if-ne v1, v9, :cond_be9

    sget-object v1, Lq;->aZ:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x3

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    aget v1, v1, v0

    const/16 v2, 0x28

    if-le v1, v2, :cond_312

    sget-object v1, Lq;->bc:[I

    const/4 v2, 0x0

    aput v2, v1, v0

    const/4 v0, 0x0

    sput v0, Lq;->aW:I

    goto/16 :goto_312

    :cond_d9e
    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x2

    if-nez v1, :cond_be9

    sget-object v1, Lq;->aZ:[I

    aget v2, v1, v0

    sget-object v3, Lq;->eL:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    aget v2, v1, v0

    sget-object v3, Lq;->eL:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->bc:[I

    aget v1, v1, v0

    if-lt v1, v6, :cond_dc5

    sget-object v1, Lq;->eL:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    :cond_dc5
    sget-object v1, Lq;->bc:[I

    aget v1, v1, v0

    if-gt v1, v8, :cond_dd0

    sget-object v1, Lq;->eL:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    :cond_dd0
    sget-object v1, Lq;->aY:[I

    aget v2, v1, v0

    sget-object v3, Lq;->eM:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget v1, Lq;->aX:I

    if-ne v0, v1, :cond_df2

    sget-object v1, Lq;->aZ:[I

    sget v2, Lq;->aX:I

    aget v1, v1, v2

    add-int/lit8 v1, v1, -0x18

    sput v1, Lg;->au:I

    sget v1, Lg;->at:I

    sget-object v2, Lq;->eM:[I

    aget v2, v2, v0

    add-int/2addr v1, v2

    sput v1, Lg;->at:I

    :cond_df2
    sget v1, Lq;->as:I

    const/16 v2, 0xe

    if-ne v1, v2, :cond_e07

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    const/16 v2, 0x948

    if-le v1, v2, :cond_e07

    sget-object v1, Lq;->eM:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    goto/16 :goto_be9

    :cond_e07
    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, 0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    const/4 v3, 0x4

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-nez v1, :cond_e2a

    sget-object v1, Lq;->aY:[I

    aget v1, v1, v0

    add-int/lit8 v1, v1, -0xc

    sget-object v2, Lq;->aZ:[I

    aget v2, v2, v0

    const/16 v3, 0x8

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_be9

    :cond_e2a
    sget-object v1, Lq;->eM:[I

    sget-object v2, Lq;->eM:[I

    aget v2, v2, v0

    neg-int v2, v2

    aput v2, v1, v0

    goto/16 :goto_be9

    :cond_e35
    sget v1, Lq;->aQ:I

    if-ne v0, v1, :cond_e42

    sget v1, Lg;->aG:I

    if-le v1, v6, :cond_e94

    sget-object v1, Lq;->aU:[I

    const/4 v2, 0x2

    aput v2, v1, v0

    :cond_e42
    :goto_e42
    sget-object v1, Lq;->aV:[I

    aget v1, v1, v0

    if-ne v1, v6, :cond_e90

    sget-object v1, Lq;->aS:[I

    aget v2, v1, v0

    sget-object v3, Lq;->eK:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->eK:[I

    aget v1, v1, v0

    const/16 v2, 0x14

    if-ge v1, v2, :cond_e63

    sget-object v1, Lq;->eK:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    :cond_e63
    sget-object v1, Lq;->aS:[I

    aget v1, v1, v0

    sget v2, Lj;->d:I

    if-ge v1, v2, :cond_e7a

    sget-object v1, Lq;->aR:[I

    aget v1, v1, v0

    sget-object v2, Lq;->aS:[I

    aget v2, v2, v0

    const/4 v3, 0x2

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_e90

    :cond_e7a
    sget-object v1, Lq;->eK:[I

    const/4 v2, 0x0

    aput v2, v1, v0

    sget-object v1, Lq;->aV:[I

    const/4 v2, 0x0

    aput v2, v1, v0

    sget-object v1, Lq;->aS:[I

    sget-object v2, Lq;->aS:[I

    aget v2, v2, v0

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    aput v2, v1, v0

    :cond_e90
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_313

    :cond_e94
    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x8

    const/4 v2, 0x3

    if-le v1, v2, :cond_ea1

    sget-object v1, Lq;->aU:[I

    const/4 v2, 0x1

    aput v2, v1, v0

    goto :goto_e42

    :cond_ea1
    sget-object v1, Lq;->aU:[I

    const/4 v2, 0x0

    aput v2, v1, v0

    goto :goto_e42

    :cond_ea7
    sget-object v1, Lq;->dB:[I

    aget v1, v1, v0

    if-eq v1, v8, :cond_edf

    sget-object v1, Lq;->dB:[I

    aget v2, v1, v0

    sget-object v3, Lq;->dA:[I

    aget v3, v3, v0

    invoke-static {v3}, Lq;->a(I)I

    move-result v3

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->dB:[I

    aget v1, v1, v0

    const/16 v2, 0x1e

    if-le v1, v2, :cond_ec9

    sget-object v1, Lq;->dB:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    :cond_ec9
    sget-object v1, Lq;->dx:[I

    aget v2, v1, v0

    sget-object v3, Lq;->dz:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->dy:[I

    aget v2, v1, v0

    sget-object v3, Lq;->dA:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    aput v2, v1, v0

    :cond_edf
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_318

    :cond_ee3
    sget-object v1, Lq;->cQ:[I

    aget v1, v1, v0

    if-eq v1, v8, :cond_f0a

    sget-object v1, Lq;->cP:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x2

    if-nez v1, :cond_f0a

    sget-object v1, Lq;->cQ:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->cQ:[I

    aget v1, v1, v0

    if-le v1, v9, :cond_f0e

    sget-object v1, Lq;->cQ:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    :cond_f0a
    :goto_f0a
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_320

    :cond_f0e
    sget-object v1, Lq;->cR:[I

    sget-object v2, Lq;->cQ:[I

    aget v2, v2, v0

    aput v2, v1, v0

    goto :goto_f0a

    :cond_f17
    sget-object v1, Lq;->cU:[I

    aget v1, v1, v0

    if-eq v1, v8, :cond_f43

    sget-object v1, Lq;->cU:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->cU:[I

    aget v1, v1, v0

    const/4 v2, 0x5

    if-lt v1, v2, :cond_f31

    sget-object v1, Lq;->cU:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    :cond_f31
    if-nez v0, :cond_f47

    sget-object v1, Lq;->cS:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    :goto_f3b
    sget-object v1, Lq;->cT:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    :cond_f43
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_327

    :cond_f47
    sget-object v1, Lq;->cS:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    goto :goto_f3b

    :cond_f50
    sget-object v1, Lq;->cL:[I

    aget v1, v1, v0

    if-eq v1, v8, :cond_f7f

    sget-object v1, Lq;->cL:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lq;->cJ:[I

    aget v2, v1, v0

    sget-object v3, Lq;->cN:[I

    aget v3, v3, v0

    shl-int/lit8 v3, v3, 0x2

    add-int/2addr v2, v3

    aput v2, v1, v0

    sget-object v1, Lq;->cK:[I

    aget v2, v1, v0

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, v0

    sget-object v1, Lq;->cL:[I

    aget v1, v1, v0

    const/4 v2, 0x6

    if-lt v1, v2, :cond_f83

    sget-object v1, Lq;->cL:[I

    const/4 v2, -0x1

    aput v2, v1, v0

    :cond_f7f
    :goto_f7f
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_32a

    :cond_f83
    sget-object v1, Lq;->cM:[I

    sget-object v2, Lq;->cL:[I

    aget v2, v2, v0

    shr-int/lit8 v2, v2, 0x1

    rem-int/lit8 v2, v2, 0x3

    aput v2, v1, v0

    goto :goto_f7f

    :cond_f90
    sget-object v0, Lq;->ah:[I

    aget v0, v0, v10

    if-ne v0, v6, :cond_1220

    sget-object v0, Lq;->di:[I

    aget v1, v0, v10

    sget-object v2, Lq;->ai:[I

    aget v2, v2, v10

    add-int/2addr v1, v2

    aput v1, v0, v10

    sget-object v0, Lq;->dj:[I

    aget v1, v0, v10

    sget-object v2, Lq;->dl:[I

    aget v2, v2, v10

    add-int/2addr v1, v2

    aput v1, v0, v10

    sget-object v0, Lq;->di:[I

    aget v0, v0, v10

    sget v1, Lq;->ay:I

    if-lt v0, v1, :cond_fd2

    sget-object v0, Lq;->di:[I

    aget v0, v0, v10

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    if-gt v0, v1, :cond_fd2

    sget-object v0, Lq;->dj:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    if-lt v0, v1, :cond_fd2

    sget-object v0, Lq;->dj:[I

    aget v0, v0, v10

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    if-le v0, v1, :cond_fdc

    :cond_fd2
    sget-object v0, Lq;->ah:[I

    const/4 v1, -0x1

    aput v1, v0, v10

    :cond_fd7
    :goto_fd7
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto/16 :goto_32d

    :cond_fdc
    sget-object v0, Lq;->ai:[I

    aget v0, v0, v10

    if-lez v0, :cond_1066

    sget-object v0, Lq;->di:[I

    aget v0, v0, v10

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    invoke-static {v0, v1}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-ne v0, v11, :cond_1066

    sget-object v0, Lq;->ah:[I

    const/4 v1, 0x2

    aput v1, v0, v10

    sget-object v0, Lq;->di:[I

    sget-object v1, Lq;->di:[I

    aget v1, v1, v10

    invoke-static {v1}, Lj;->e(I)I

    move-result v1

    aput v1, v0, v10

    :cond_1003
    :goto_1003
    sget-object v0, Lq;->dk:[I

    aget v1, v0, v10

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, v10

    sget-object v0, Lq;->dk:[I

    aget v0, v0, v10

    if-le v0, v6, :cond_1016

    sget-object v0, Lq;->dk:[I

    const/4 v1, 0x0

    aput v1, v0, v10

    :cond_1016
    sget-object v0, Lq;->ai:[I

    aget v0, v0, v10

    if-eqz v0, :cond_fd7

    move v3, v7

    :goto_101d
    sget v0, La;->c:I

    if-lt v3, v0, :cond_1094

    :cond_1021
    :goto_1021
    move v3, v7

    :goto_1022
    sget v0, Ln;->c:I

    if-lt v3, v0, :cond_1129

    :cond_1026
    :goto_1026
    sget-object v0, Lq;->dm:[Z

    aget-boolean v0, v0, v10

    if-nez v0, :cond_11bb

    sget v0, Lg;->at:I

    sget-object v1, Lq;->di:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lg;->aB:I

    if-ge v0, v1, :cond_11bb

    sget v0, Lg;->au:I

    sget v1, Lg;->aC:I

    sub-int/2addr v0, v1

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lg;->aC:I

    if-ge v0, v1, :cond_11bb

    sget v0, Lg;->ax:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_11ac

    sget v0, Lg;->ar:I

    if-nez v0, :cond_11ac

    sget-object v0, Lq;->ai:[I

    sget-object v1, Lq;->ai:[I

    aget v1, v1, v10

    neg-int v1, v1

    aput v1, v0, v10

    sget-object v0, Lq;->dl:[I

    const/4 v1, -0x3

    aput v1, v0, v10

    goto/16 :goto_331

    :cond_1066
    sget-object v0, Lq;->ai:[I

    aget v0, v0, v10

    if-gez v0, :cond_1003

    sget-object v0, Lq;->di:[I

    aget v0, v0, v10

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    invoke-static {v0, v1}, Lj;->b(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    const/16 v1, 0x8

    if-ne v0, v1, :cond_1003

    sget-object v0, Lq;->ah:[I

    const/4 v1, 0x2

    aput v1, v0, v10

    sget-object v0, Lq;->di:[I

    sget-object v1, Lq;->di:[I

    aget v1, v1, v10

    invoke-static {v1}, Lj;->e(I)I

    move-result v1

    sget v2, Lj;->f:I

    add-int/2addr v1, v2

    aput v1, v0, v10

    goto/16 :goto_1003

    :cond_1094
    sget-object v0, La;->i:[I

    aget v0, v0, v3

    const/4 v1, 0x5

    if-eq v0, v1, :cond_1124

    sget-object v0, La;->i:[I

    aget v0, v0, v3

    if-eq v0, v6, :cond_1124

    sget-object v0, La;->i:[I

    aget v0, v0, v3

    const/16 v1, 0xa

    if-eq v0, v1, :cond_1124

    sget-object v0, La;->e:[I

    aget v0, v0, v3

    sget-object v1, Lq;->di:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget-object v1, La;->h:[I

    aget v1, v1, v3

    if-ge v0, v1, :cond_1124

    sget-object v0, La;->f:[I

    aget v0, v0, v3

    sget-object v1, La;->g:[I

    aget v1, v1, v3

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget-object v1, La;->g:[I

    aget v1, v1, v3

    if-ge v0, v1, :cond_1124

    sget-object v0, Lq;->dm:[Z

    aget-boolean v0, v0, v10

    if-eqz v0, :cond_1121

    sget v0, Lg;->aK:I

    shl-int/lit8 v0, v0, 0x1

    :goto_10e0
    invoke-static {v3, v10, v0}, La;->b(III)Z

    move-result v1

    if-nez v1, :cond_1021

    sget-object v1, La;->e:[I

    aget v1, v1, v3

    sget-object v2, La;->f:[I

    aget v2, v2, v3

    sget-object v4, La;->g:[I

    aget v4, v4, v3

    shr-int/lit8 v4, v4, 0x1

    sub-int/2addr v2, v4

    sget-object v4, La;->k:[I

    aget v4, v4, v3

    invoke-static {v1, v2, v4}, Lq;->c(III)Z

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, La;->e:[I

    aget v2, v2, v3

    sget-object v4, La;->f:[I

    aget v4, v4, v3

    sget-object v5, La;->g:[I

    aget v3, v5, v3

    sub-int v3, v4, v3

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    goto/16 :goto_1021

    :cond_1121
    sget v0, Lg;->aK:I

    goto :goto_10e0

    :cond_1124
    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto/16 :goto_101d

    :cond_1129
    sget-object v0, Ln;->i:[I

    aget v0, v0, v3

    const/4 v1, 0x5

    if-eq v0, v1, :cond_11a7

    sget-object v0, Ln;->i:[I

    aget v0, v0, v3

    if-eq v0, v6, :cond_11a7

    sget-object v0, Ln;->i:[I

    aget v0, v0, v3

    const/16 v1, 0xa

    if-eq v0, v1, :cond_11a7

    sget-object v0, Ln;->e:[I

    aget v0, v0, v3

    sget-object v1, Lq;->di:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-ge v0, v1, :cond_11a7

    sget-object v0, Ln;->f:[I

    aget v0, v0, v3

    add-int/lit8 v0, v0, -0xc

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x19

    if-ge v0, v1, :cond_11a7

    sget-object v0, Lq;->dm:[Z

    aget-boolean v0, v0, v10

    if-eqz v0, :cond_11a4

    sget v0, Lg;->aK:I

    shl-int/lit8 v0, v0, 0x1

    :goto_116c
    invoke-static {v3, v0, v10}, Ln;->a(III)Z

    move-result v1

    if-nez v1, :cond_1026

    sget-object v1, Ln;->e:[I

    aget v1, v1, v3

    sget-object v2, Ln;->f:[I

    aget v2, v2, v3

    add-int/lit8 v2, v2, -0xc

    sget-object v4, Ln;->j:[I

    aget v4, v4, v3

    invoke-static {v1, v2, v4}, Lq;->c(III)Z

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "-"

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget-object v2, Ln;->e:[I

    aget v2, v2, v3

    sget-object v4, Ln;->f:[I

    aget v3, v4, v3

    add-int/lit8 v3, v3, -0x19

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    goto/16 :goto_1026

    :cond_11a4
    sget v0, Lg;->aK:I

    goto :goto_116c

    :cond_11a7
    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto/16 :goto_1022

    :cond_11ac
    sget v0, Lg;->aK:I

    sget v1, Lg;->aF:I

    neg-int v1, v1

    invoke-static {v0, v1}, Lg;->a(II)V

    sget-object v0, Lq;->ah:[I

    const/4 v1, -0x1

    aput v1, v0, v10

    goto/16 :goto_331

    :cond_11bb
    sget-boolean v0, Lq;->aG:Z

    if-eqz v0, :cond_fd7

    sget v0, Lq;->aH:I

    sget-object v1, Lq;->di:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lq;->eG:I

    shr-int/lit8 v1, v1, 0x1

    if-ge v0, v1, :cond_fd7

    sget v0, Lq;->aI:I

    sget v1, Lq;->aJ:I

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lq;->aJ:I

    shr-int/lit8 v1, v1, 0x1

    if-ge v0, v1, :cond_fd7

    sget v0, Lg;->aK:I

    sget v1, Lq;->eE:I

    neg-int v1, v1

    invoke-static {v0, v1}, Lq;->d(II)Z

    sget-object v0, Lq;->di:[I

    aget v0, v0, v10

    sget-object v1, Lq;->dj:[I

    aget v1, v1, v10

    sget v2, Lq;->eE:I

    invoke-static {v0, v1, v2}, Lq;->c(III)Z

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "-"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v1, Lg;->aK:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    sget v2, Lq;->aH:I

    sget v3, Lq;->aI:I

    sget v4, Lq;->aJ:I

    sub-int/2addr v3, v4

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-static/range {v0 .. v5}, Lq;->a(Ljava/lang/String;IIIII)V

    sget-object v0, Lq;->ah:[I

    const/4 v1, -0x1

    aput v1, v0, v10

    goto/16 :goto_fd7

    :cond_1220
    sget-object v0, Lq;->ah:[I

    aget v0, v0, v10

    if-le v0, v6, :cond_fd7

    sget-object v0, Lq;->ah:[I

    aget v1, v0, v10

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, v10

    sget-object v0, Lq;->ah:[I

    aget v0, v0, v10

    const/16 v1, 0xa

    if-lt v0, v1, :cond_fd7

    sget-object v0, Lq;->ah:[I

    const/4 v1, 0x1

    aput v1, v0, v10

    sget-object v0, Lq;->dl:[I

    const/16 v1, 0xc

    aput v1, v0, v10

    sget-object v0, Lq;->ai:[I

    const/4 v1, 0x0

    aput v1, v0, v10

    goto/16 :goto_fd7

    :cond_1248
    sget-boolean v0, Lg;->r:Z

    if-eqz v0, :cond_39c

    const/4 v0, 0x0

    sput v0, Lq;->dF:I

    goto/16 :goto_39c

    :cond_1251
    sget v0, Lq;->dF:I

    if-lez v0, :cond_39c

    sget v0, Lq;->dF:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->dF:I

    const/16 v1, 0x1e

    if-le v0, v1, :cond_39c

    const/4 v0, 0x0

    sput v0, Lq;->dF:I

    goto/16 :goto_39c

    :cond_1264
    sget v0, Lq;->an:I

    if-ne v0, v9, :cond_3ee

    sget v0, Lq;->dI:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->dI:I

    sget v0, Lq;->ak:I

    sget v1, Lq;->dH:I

    sget v2, Lq;->dI:I

    mul-int/2addr v1, v2

    add-int/2addr v0, v1

    sput v0, Lq;->ak:I

    sget v0, Lg;->at:I

    sget v1, Lq;->ak:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_129d

    sget v0, Lg;->au:I

    sget v1, Lq;->al:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-ge v0, v1, :cond_129d

    sget v0, Le;->e:I

    sget v1, Lq;->dH:I

    neg-int v1, v1

    invoke-static {v0, v1}, Lg;->a(II)V

    const/4 v0, -0x1

    sput v0, Lq;->am:I

    :cond_129d
    sget v0, Lq;->dI:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_12aa

    sget v0, Lq;->dG:I

    if-ne v0, v9, :cond_12b5

    const/4 v0, 0x3

    :goto_12a8
    sput v0, Lq;->dG:I

    :cond_12aa
    sget v0, Lq;->dI:I

    const/16 v1, 0xf

    if-lt v0, v1, :cond_3ee

    const/4 v0, -0x1

    sput v0, Lq;->am:I

    goto/16 :goto_3ee

    :cond_12b5
    move v0, v9

    goto :goto_12a8

    :cond_12b7
    sget v0, Lg;->at:I

    sget v1, Lq;->es:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lg;->au:I

    sget v2, Lq;->et:I

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    if-le v0, v1, :cond_1315

    sget v0, Lg;->at:I

    sget v1, Lq;->es:I

    if-le v0, v1, :cond_1305

    const/4 v0, 0x1

    sput v0, Lq;->eu:I

    sget v0, Lq;->ay:I

    add-int/lit8 v0, v0, 0x14

    sget v1, Lq;->ey:I

    add-int/2addr v0, v1

    sput v0, Lq;->ev:I

    :goto_12dd
    sget v0, Lq;->et:I

    add-int/lit8 v0, v0, 0x18

    sput v0, Lq;->ew:I

    sget v1, Lq;->az:I

    add-int/lit8 v1, v1, 0xa

    if-ge v0, v1, :cond_12ef

    sget v0, Lq;->az:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lq;->ew:I

    :cond_12ef
    sget v0, Lq;->ew:I

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    add-int/lit8 v1, v1, -0xa

    if-le v0, v1, :cond_429

    sget v0, Lq;->az:I

    sget v1, Lq;->ac:I

    add-int/2addr v0, v1

    add-int/lit8 v0, v0, -0xa

    sput v0, Lq;->ew:I

    goto/16 :goto_429

    :cond_1305
    const/4 v0, 0x0

    sput v0, Lq;->eu:I

    sget v0, Lq;->ay:I

    sget v1, Lq;->ab:I

    add-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x14

    sget v1, Lq;->ey:I

    add-int/2addr v0, v1

    sput v0, Lq;->ev:I

    goto :goto_12dd

    :cond_1315
    sget v0, Lg;->au:I

    sget v1, Lq;->et:I

    if-le v0, v1, :cond_132d

    const/4 v0, 0x3

    sput v0, Lq;->eu:I

    sget v0, Lg;->at:I

    sput v0, Lq;->ev:I

    sget v0, Lq;->az:I

    add-int/lit8 v0, v0, 0x14

    sget v1, Lq;->ey:I

    add-int/2addr v0, v1

    sput v0, Lq;->ew:I

    goto/16 :goto_429

    :cond_132d
    const/4 v0, 0x2

    sput v0, Lq;->eu:I

    sget v0, Lg;->at:I

    sput v0, Lq;->ev:I

    sget v0, Lq;->az:I

    sget v1, Lq;->ac:I

    add-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x14

    sget v1, Lq;->ey:I

    add-int/2addr v0, v1

    sput v0, Lq;->ew:I

    goto/16 :goto_429

    :cond_1342
    sget v0, Lq;->eJ:I

    if-lez v0, :cond_134c

    sget v0, Lq;->eJ:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->eJ:I

    :cond_134c
    sget v0, Lq;->eD:I

    packed-switch v0, :pswitch_data_2208

    :pswitch_1351  #0x3, 0x4
    goto/16 :goto_460

    :pswitch_1353  #0x1
    sget v0, Lq;->eH:I

    if-lez v0, :cond_137a

    sget v0, Lq;->eH:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->eH:I

    :cond_135d
    :goto_135d
    const/4 v0, 0x0

    sput v0, Lq;->eF:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v1, 0x6

    if-ne v0, v1, :cond_460

    sget v0, Lq;->eE:I

    neg-int v0, v0

    sget v1, Lq;->aH:I

    sget v2, Lq;->eE:I

    mul-int/lit8 v2, v2, 0x1c

    add-int/2addr v1, v2

    sget v2, Lq;->aI:I

    add-int/lit8 v2, v2, -0x5

    invoke-static {v0, v1, v2}, Lq;->b(III)Z

    goto/16 :goto_460

    :cond_137a
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x50

    add-int/lit8 v0, v0, -0x28

    if-lez v0, :cond_13ad

    add-int/lit8 v0, v0, 0x14

    :goto_1384
    sget v1, Lq;->aH:I

    add-int/2addr v1, v0

    sput v1, Lq;->eI:I

    if-lez v0, :cond_13b0

    move v0, v6

    :goto_138c
    sput v0, Lq;->eE:I

    shl-int/lit8 v0, v0, 0x2

    sput v0, Lq;->eC:I

    sget v0, Lq;->aK:I

    sget v1, Lq;->aL:I

    shr-int/lit8 v1, v1, 0x1

    if-ge v0, v1, :cond_13a0

    sget v0, Lq;->eE:I

    shl-int/lit8 v0, v0, 0x3

    sput v0, Lq;->eC:I

    :cond_13a0
    const/4 v0, 0x2

    sput v0, Lq;->eD:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_135d

    invoke-static {}, Lq;->G()V

    goto :goto_135d

    :cond_13ad
    add-int/lit8 v0, v0, -0x14

    goto :goto_1384

    :cond_13b0
    move v0, v8

    goto :goto_138c

    :pswitch_13b2  #0x2
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_13bb

    invoke-static {}, Lq;->G()V

    :cond_13bb
    sget v0, Lq;->aH:I

    sget v1, Lq;->eE:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lq;->aI:I

    add-int/lit8 v1, v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_13d5

    const/4 v0, 0x1

    sput v0, Lq;->eD:I

    const/4 v0, 0x0

    sput v0, Lq;->eH:I

    goto/16 :goto_460

    :cond_13d5
    sget v0, Lq;->aH:I

    sget v1, Lq;->eI:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x8

    if-ge v0, v1, :cond_13e9

    const/4 v0, 0x1

    sput v0, Lq;->eD:I

    const/16 v0, 0x14

    sput v0, Lq;->eH:I

    :cond_13e9
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_13fb

    sget v0, Lq;->aH:I

    sget v1, Lq;->eC:I

    add-int/2addr v0, v1

    sput v0, Lq;->aH:I

    const/4 v0, 0x0

    sput v0, Lq;->eF:I

    goto/16 :goto_460

    :cond_13fb
    const/4 v0, 0x1

    sput v0, Lq;->eF:I

    goto/16 :goto_460

    :pswitch_1400  #0x5
    sget v0, Lq;->aH:I

    sget v1, Lq;->eE:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lq;->aI:I

    add-int/lit8 v1, v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0, v1, v2}, Lj;->a(III)Z

    move-result v0

    if-nez v0, :cond_141a

    const/4 v0, 0x1

    sput v0, Lq;->eD:I

    const/4 v0, 0x0

    sput v0, Lq;->eH:I

    goto/16 :goto_460

    :cond_141a
    sget v0, Lq;->aH:I

    sget v1, Lq;->eI:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v11, :cond_142c

    const/4 v0, 0x1

    sput v0, Lq;->eD:I

    const/16 v0, 0x23

    sput v0, Lq;->eH:I

    :cond_142c
    sget v0, Lg;->au:I

    sget v1, Lq;->aI:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x12

    if-ge v0, v1, :cond_1465

    sget v0, Lq;->aH:I

    sget v1, Lq;->eE:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0xa

    if-ge v0, v1, :cond_1465

    sget v0, Lq;->eB:I

    sget v1, Lq;->eE:I

    invoke-static {v0, v1}, Lg;->a(II)V

    const/4 v0, 0x1

    sput v0, Lq;->eD:I

    const/16 v0, 0x2d

    sput v0, Lq;->eH:I

    sget v0, Lq;->aK:I

    sget v1, Lq;->aL:I

    shr-int/lit8 v1, v1, 0x1

    if-ge v0, v1, :cond_1465

    const/16 v0, 0x12

    sput v0, Lq;->eH:I

    :cond_1465
    sget v0, Lq;->aH:I

    sget v1, Lq;->eC:I

    add-int/2addr v0, v1

    sput v0, Lq;->aH:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x3

    sput v0, Lq;->eF:I

    goto/16 :goto_460

    :pswitch_1474  #0x7
    sget v0, Lq;->aH:I

    sget v1, Lq;->eE:I

    sub-int/2addr v0, v1

    sput v0, Lq;->aH:I

    const/4 v0, 0x2

    sput v0, Lq;->eF:I

    sget v0, Lq;->eH:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eH:I

    if-ne v0, v11, :cond_460

    const/4 v0, 0x1

    sput v0, Lq;->eD:I

    sget v0, Lq;->eI:I

    sput v0, Lq;->eH:I

    if-lez v0, :cond_460

    sget v0, Lq;->aK:I

    sget v1, Lq;->aL:I

    shr-int/lit8 v1, v1, 0x1

    if-ge v0, v1, :cond_460

    const/4 v0, 0x5

    sput v0, Lq;->eH:I

    goto/16 :goto_460

    :pswitch_149c  #0x6
    const/4 v0, 0x1

    sput-boolean v0, Lg;->l:Z

    sget v0, Lq;->aI:I

    sget v1, Lq;->eH:I

    add-int/2addr v0, v1

    sput v0, Lq;->aI:I

    sget v0, Lq;->eH:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eH:I

    sget v0, Lq;->aH:I

    sget v1, Lq;->eC:I

    add-int/2addr v0, v1

    sput v0, Lq;->aH:I

    sget v0, Lq;->eC:I

    if-le v0, v6, :cond_14bd

    sget v0, Lq;->eC:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->eC:I

    :cond_14bd
    sget v0, Lq;->eC:I

    if-ge v0, v8, :cond_14c7

    sget v0, Lq;->eC:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->eC:I

    :cond_14c7
    sget v0, Lq;->aI:I

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    sget v2, Lq;->aJ:I

    add-int/2addr v1, v2

    if-gt v0, v1, :cond_14dc

    sget v0, Lq;->aI:I

    sget v1, Lj;->d:I

    sget v2, Lq;->aJ:I

    add-int/2addr v1, v2

    if-lt v0, v1, :cond_460

    :cond_14dc
    const/4 v0, 0x0

    sput v0, Lq;->eH:I

    const/16 v0, 0x16

    sput v0, Lq;->eD:I

    goto/16 :goto_460

    :cond_14e5
    sget v0, Lq;->bi:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_14f6

    sget-boolean v0, Lg;->u:Z

    if-eqz v0, :cond_474

    sget-boolean v0, Lg;->s:Z

    if-eqz v0, :cond_474

    sget-boolean v0, Lg;->t:Z

    if-eqz v0, :cond_474

    :cond_14f6
    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_1509

    sget v0, Lg;->D:I

    if-eqz v0, :cond_1509

    sget v0, Lq;->bi:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1509

    sget v0, Lq;->av:I

    if-eq v0, v6, :cond_474

    :cond_1509
    sget v0, Lq;->as:I

    const/16 v1, 0x10

    if-ne v0, v1, :cond_1513

    sget-boolean v0, Lg;->A:Z

    if-eqz v0, :cond_474

    :cond_1513
    sget v0, Lq;->av:I

    if-eqz v0, :cond_474

    sget-object v0, Lq;->dN:Ljavax/microedition/lcdui/Image;

    if-eqz v0, :cond_474

    sget v0, Lq;->av:I

    if-ne v0, v6, :cond_1596

    sget v0, Lq;->bi:I

    if-ne v0, v11, :cond_1526

    const/4 v0, 0x2

    sput v0, Lq;->av:I

    :cond_1526
    sget v0, Lg;->au:I

    sget v1, Lg;->aA:I

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    sget v1, Lq;->ee:I

    add-int/lit8 v1, v1, -0x7

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0xa

    if-ge v0, v1, :cond_474

    sget v0, Lg;->at:I

    sget v1, Lq;->ed:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0xa

    if-ge v0, v1, :cond_474

    const/4 v0, 0x2

    sput v0, Lq;->av:I

    const/4 v0, 0x1

    sput-boolean v0, Lg;->bf:Z

    sget v0, Lq;->bi:I

    packed-switch v0, :pswitch_data_221a

    :pswitch_1552  #0x4
    goto/16 :goto_474

    :pswitch_1554  #0x0
    const-string v0, "Lấy được bí kíp"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_474

    :pswitch_155b  #0x1
    const-string v0, "Lấy được gươm của Sakura"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_474

    :pswitch_1562  #0x2
    const-string v0, "Tìm được mắt kiếng"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    const/4 v0, 0x1

    sput-boolean v0, Lg;->r:Z

    goto/16 :goto_474

    :pswitch_156c  #0x3
    const-string v0, "Giải được câu đố thứ 1"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    const/4 v0, 0x1

    sput v0, Lg;->D:I

    goto/16 :goto_474

    :pswitch_1576  #0x5
    const/4 v0, 0x1

    sput-boolean v0, Lg;->z:Z

    const-string v0, "Lấy được tượng Kỳ lân"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    goto/16 :goto_474

    :pswitch_1580  #0x6
    const-string v0, "đã có sáo thần"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    const/4 v0, 0x1

    sput-boolean v0, Lg;->A:Z

    goto/16 :goto_474

    :pswitch_158a  #0x7
    const/4 v0, 0x1

    sput-boolean v0, Lg;->B:Z

    const/4 v0, 0x0

    sput v0, Lg;->aG:I

    const/16 v0, 0x17

    sput v0, Lg;->ax:I

    goto/16 :goto_474

    :cond_1596
    sget v0, Lq;->av:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->av:I

    sget v0, Lq;->ee:I

    add-int/lit8 v0, v0, -0x3

    sput v0, Lq;->ee:I

    sget v0, Lq;->bi:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_15aa

    const/4 v0, 0x0

    sput v0, Lq;->av:I

    :cond_15aa
    sget v0, Lq;->av:I

    const/16 v1, 0x28

    if-le v0, v1, :cond_474

    const/4 v0, 0x0

    sput v0, Lq;->av:I

    goto/16 :goto_474

    :pswitch_15b5  #0x2
    sget v0, Lq;->bl:I

    sget v1, Lq;->bk:I

    if-ge v0, v1, :cond_29

    sget v0, Lq;->bl:I

    add-int/lit8 v0, v0, 0x5

    sput v0, Lq;->bl:I

    goto/16 :goto_29

    :pswitch_15c3  #0x3
    sget v0, Lq;->bZ:I

    if-lez v0, :cond_15cd

    sget v0, Lq;->bZ:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->bZ:I

    :cond_15cd
    sget v0, Lq;->ca:I

    if-lez v0, :cond_15d7

    sget v0, Lq;->ca:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->ca:I

    :cond_15d7
    sget v0, Lq;->at:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->at:I

    const/16 v1, 0x2710

    if-ne v0, v1, :cond_15e4

    const/4 v0, 0x0

    sput v0, Lq;->at:I

    :cond_15e4
    sget v0, Lq;->bV:I

    sget v1, Lq;->bT:I

    if-gt v0, v1, :cond_15f0

    sget v0, Lq;->bW:I

    sget v1, Lq;->bU:I

    if-ge v0, v1, :cond_16cb

    :cond_15f0
    invoke-static {}, Lq;->b()V

    invoke-static {}, Lq;->c()V

    :cond_15f6
    :goto_15f6
    sget v0, Lq;->ay:I

    if-nez v0, :cond_1608

    const/16 v0, 0x3c0

    sput v0, Lq;->ay:I

    const/16 v0, 0x30

    sput v0, Lq;->az:I

    const/4 v0, 0x1

    sput v0, Lq;->ef:I

    const/4 v0, 0x1

    sput v0, Lq;->eg:I

    :cond_1608
    sget v0, Lq;->ay:I

    sget v1, Lq;->ef:I

    add-int/2addr v0, v1

    sput v0, Lq;->ay:I

    sget v1, Lq;->ej:I

    if-le v0, v1, :cond_161c

    sget v0, Lq;->ej:I

    sput v0, Lq;->ay:I

    sget v0, Lq;->ef:I

    neg-int v0, v0

    sput v0, Lq;->ef:I

    :cond_161c
    sget v0, Lq;->ay:I

    const/16 v1, 0x18

    if-ge v0, v1, :cond_162b

    const/16 v0, 0x18

    sput v0, Lq;->ay:I

    sget v0, Lq;->ef:I

    neg-int v0, v0

    sput v0, Lq;->ef:I

    :cond_162b
    sget v0, Lq;->az:I

    if-gez v0, :cond_1637

    const/4 v0, 0x0

    sput v0, Lq;->az:I

    sget v0, Lq;->eg:I

    neg-int v0, v0

    sput v0, Lq;->eg:I

    :cond_1637
    sget v0, Lq;->az:I

    sget v1, Lq;->ek:I

    if-le v0, v1, :cond_1646

    sget v0, Lq;->ek:I

    sput v0, Lq;->az:I

    sget v0, Lq;->eg:I

    neg-int v0, v0

    sput v0, Lq;->eg:I

    :cond_1646
    sget v0, Lq;->ay:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->W:I

    if-gez v0, :cond_1654

    const/4 v0, 0x0

    sput v0, Lq;->W:I

    :cond_1654
    sget v0, Lq;->az:I

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    sput v0, Lq;->X:I

    sget v0, Lq;->W:I

    sget v1, Lq;->ct:I

    add-int/2addr v0, v1

    sput v0, Lq;->Y:I

    sget v0, Lq;->X:I

    sget v1, Lq;->cu:I

    add-int/2addr v0, v1

    sput v0, Lq;->Z:I

    sget v0, Lq;->X:I

    if-gez v0, :cond_1670

    const/4 v0, 0x0

    sput v0, Lq;->X:I

    :cond_1670
    sget v0, Lq;->Z:I

    sget v1, Lj;->b:I

    add-int/lit8 v1, v1, -0x1

    if-le v0, v1, :cond_167e

    sget v0, Lj;->b:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->Z:I

    :cond_167e
    sget v0, Lq;->bM:I

    const/16 v1, 0x18

    if-ne v0, v1, :cond_168a

    const/4 v0, 0x3

    sput v0, Lq;->ca:I

    const/4 v0, 0x2

    sput v0, Lq;->bZ:I

    :cond_168a
    sget v0, Lq;->bM:I

    const/16 v1, 0x28

    if-ne v0, v1, :cond_16b4

    sget v0, Lq;->bV:I

    sget v1, Lq;->bT:I

    if-le v0, v1, :cond_169c

    sget v0, Lq;->bV:I

    add-int/lit8 v0, v0, -0x4

    sput v0, Lq;->bV:I

    :cond_169c
    sget v0, Lq;->bW:I

    sget v1, Lq;->bU:I

    if-ge v0, v1, :cond_16a8

    sget v0, Lq;->bW:I

    add-int/lit8 v0, v0, 0x4

    sput v0, Lq;->bW:I

    :cond_16a8
    sget v0, Lq;->bY:I

    sget v1, Lq;->bX:I

    if-le v0, v1, :cond_16b4

    sget v0, Lq;->bY:I

    add-int/lit8 v0, v0, -0x2

    sput v0, Lq;->bY:I

    :cond_16b4
    sget v0, Lq;->bM:I

    const/16 v1, 0x28

    if-ge v0, v1, :cond_16c0

    sget v0, Lq;->bM:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bM:I

    :cond_16c0
    sget v0, Lq;->bM:I

    const/16 v1, 0x18

    if-ge v0, v1, :cond_179c

    const/4 v0, 0x0

    sput v0, Lq;->bN:I

    goto/16 :goto_29

    :cond_16cb
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_16e7

    sget v0, Lq;->bS:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->bS:I

    if-gez v0, :cond_16e1

    sget-object v0, Lq;->bL:[Ljava/lang/String;

    array-length v0, v0

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->bS:I

    :cond_16e1
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    :cond_16e7
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1702

    sget v0, Lq;->bS:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bS:I

    sget-object v1, Lq;->bL:[Ljava/lang/String;

    array-length v1, v1

    if-ne v0, v1, :cond_16fc

    const/4 v0, 0x0

    sput v0, Lq;->bS:I

    :cond_16fc
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    :cond_1702
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_15f6

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bS:I

    if-nez v0, :cond_173b

    invoke-static {}, LMidlet;->a()Z

    move-result v0

    if-eqz v0, :cond_172a

    sget-boolean v0, Lq;->a:Z

    if-nez v0, :cond_172a

    const/16 v0, 0xa

    invoke-static {v0}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    :cond_1722
    :goto_1722
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    const/4 v2, 0x0

    aput-boolean v2, v0, v1

    goto/16 :goto_15f6

    :cond_172a
    invoke-static {}, Lq;->B()V

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sput-wide v0, Lq;->eA:J

    const/4 v0, 0x0

    invoke-static {v0}, Lq;->i(I)V

    goto :goto_1722

    :cond_173b
    sget v0, Lq;->bS:I

    if-ne v0, v6, :cond_175b

    invoke-static {}, LMidlet;->a()Z

    move-result v0

    if-eqz v0, :cond_15f6

    const/4 v0, 0x0

    invoke-static {v0}, Lq;->a(Z)V

    invoke-static {}, Lq;->B()V

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->e:Z

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sput-wide v0, Lq;->eA:J

    sget v0, Lq;->as:I

    invoke-static {v0}, Lq;->i(I)V

    goto :goto_1722

    :cond_175b
    sget v0, Lq;->bS:I

    if-ne v0, v9, :cond_177b

    invoke-static {}, Lq;->B()V

    const/4 v0, 0x2

    sput v0, Lq;->K:I

    invoke-static {}, Lq;->R()V

    const/16 v0, 0xb

    sput v0, LMidlet;->d:I

    const/16 v0, 0x63

    sput v0, Lq;->as:I

    new-instance v0, Ljava/lang/Thread;

    sget-object v1, LMidlet;->b:LMidlet;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto :goto_1722

    :cond_177b
    sget v0, Lq;->bS:I
    :try_end_177d
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_177d} :catch_3f

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1792

    :try_start_1780
    sget-object v0, LMidlet;->b:LMidlet;

    const-string v1, "http://vechai321.xtgem.com"

    invoke-virtual {v0, v1}, Ljavax/microedition/midlet/MIDlet;->platformRequest(Ljava/lang/String;)Z

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V
    :try_end_178c
    .catch Ljavax/microedition/io/ConnectionNotFoundException; {:try_start_1780 .. :try_end_178c} :catch_178d
    .catch Ljava/lang/Exception; {:try_start_1780 .. :try_end_178c} :catch_3f

    goto :goto_1722

    :catch_178d
    move-exception v0

    :try_start_178e
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1722

    :cond_1792
    sget v0, Lq;->bS:I

    if-ne v0, v11, :cond_1722

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    goto :goto_1722

    :cond_179c
    const/4 v0, 0x1

    sput v0, Lq;->bN:I

    goto/16 :goto_29

    :pswitch_17a1  #0x4
    sget v0, Lq;->fd:I

    if-ge v0, v11, :cond_17a9

    sget v0, Lq;->fd:I

    sput v0, Lq;->fe:I

    :cond_17a9
    sget v0, Lq;->fd:I

    const/16 v1, 0x33

    if-le v0, v1, :cond_17d1

    const/4 v0, 0x0

    sput-object v0, Lq;->fc:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lq;->Y()V

    const/16 v0, 0xa

    sput v0, Lq;->K:I

    :cond_17b9
    :goto_17b9
    sget-object v0, Lq;->x:Lq;

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Displayable;->getWidth()I

    move-result v0

    sput v0, Lq;->E:I

    sget-object v0, Lq;->x:Lq;

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Displayable;->getHeight()I

    move-result v0

    sput v0, Lq;->F:I

    sget v0, Lq;->fd:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fd:I

    goto/16 :goto_29

    :cond_17d1
    sget v0, Lq;->fd:I

    const/16 v1, 0x2e

    if-le v0, v1, :cond_17b9

    sget v0, Lq;->fd:I

    add-int/lit8 v0, v0, -0x2e

    rsub-int/lit8 v0, v0, 0x4

    sput v0, Lq;->fe:I

    goto :goto_17b9

    :pswitch_17e0  #0x5
    sget v0, Lq;->fz:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fz:I

    const/16 v1, 0x2710

    if-le v0, v1, :cond_17ed

    const/4 v0, 0x0

    sput v0, Lq;->fz:I

    :cond_17ed
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1809

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lj;->c()V

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    move v0, v6

    :goto_1802
    if-eqz v0, :cond_29

    invoke-static {}, Lq;->c()V

    goto/16 :goto_29

    :cond_1809
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_1818

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1998

    :cond_1818
    sget v0, Lq;->fy:I

    if-nez v0, :cond_1823

    invoke-static {}, Lq;->S()V

    const/16 v0, 0x8

    sput v0, Lq;->K:I

    :cond_1823
    sget v0, Lq;->fy:I

    if-ne v0, v6, :cond_182e

    invoke-static {}, Lq;->T()V

    const/16 v0, 0xf

    sput v0, Lq;->K:I

    :cond_182e
    sget v0, Lq;->fy:I

    if-ne v0, v9, :cond_1841

    sget v0, Lq;->fX:I

    const/16 v1, 0x67

    if-ne v0, v1, :cond_188d

    const/4 v0, 0x2

    sput v0, Lq;->fX:I

    :cond_183b
    :goto_183b
    invoke-static {}, Lq;->V()V

    const/4 v0, 0x6

    sput v0, Lq;->K:I

    :cond_1841
    sget v0, Lq;->fy:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1867

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lj;->c()V

    invoke-static {}, Lq;->w()V

    const/4 v0, 0x5

    invoke-static {v0}, Lq;->h(I)V

    sget v0, Lq;->as:I

    const/16 v1, 0x69

    if-ne v0, v1, :cond_18ad

    const-string v0, "Giết nhím nâu bảo vệ mùa màng"

    :goto_185b
    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->ae:I

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    :cond_1867
    sget v0, Lq;->fy:I

    if-ne v0, v11, :cond_21d5

    sget v0, Lg;->ax:I

    if-eq v0, v6, :cond_1984

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lj;->c()V

    invoke-static {}, Lq;->w()V

    const/4 v0, 0x5

    invoke-static {v0}, Lq;->h(I)V

    const-string v0, "Bạn chỉ có thể lưu và thoát khi nhân vật đang đứng yên."

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->ae:I

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    move v0, v6

    goto/16 :goto_1802

    :cond_188d
    sget v0, Lq;->fX:I

    const/16 v1, 0x65

    if-ne v0, v1, :cond_1897

    const/4 v0, 0x5

    sput v0, Lq;->fX:I

    goto :goto_183b

    :cond_1897
    sget v0, Lq;->fX:I

    const/16 v1, 0x64

    if-ne v0, v1, :cond_18a2

    const/16 v0, 0xa

    sput v0, Lq;->fX:I

    goto :goto_183b

    :cond_18a2
    sget v0, Lq;->fX:I

    const/16 v1, 0x66

    if-ne v0, v1, :cond_183b

    const/16 v0, 0xe

    sput v0, Lq;->fX:I

    goto :goto_183b

    :cond_18ad
    sget-boolean v0, Lq;->e:Z

    if-eqz v0, :cond_18b4

    const-string v0, "Rủ bạn bè cùng đến trường Haruna điều tra"

    goto :goto_185b

    :cond_18b4
    sget v0, Lg;->bc:I

    if-nez v0, :cond_18bb

    const-string v0, "Giết 10 nhím nâu ở khu luyện tập rồi quay về gặp cô Ayumi"

    goto :goto_185b

    :cond_18bb
    sget v0, Lg;->bc:I

    if-ne v0, v6, :cond_18c9

    sget-boolean v0, Lg;->h:Z

    if-eqz v0, :cond_18c6

    const-string v0, "Xuống dưới chân thác nước tìm thanh gươm và mang về cho Sakura"

    goto :goto_185b

    :cond_18c6
    const-string v0, "Tìm Sakura ở thác nước, cùng quay về gặp thầy hiệu trưởng"

    goto :goto_185b

    :cond_18c9
    sget v0, Lg;->bc:I

    if-ne v0, v9, :cond_18d9

    sget v0, Lq;->as:I

    const/16 v1, 0x6c

    if-ne v0, v1, :cond_18d6

    const-string v0, "Chạy đua và thắng Toniku bằng mọi giá (gợi ý: trên cành cây)"

    goto :goto_185b

    :cond_18d6
    const-string v0, "Tìm Toniku ở thôn Sanzuya và cùng về gặp thầy hiệu trưởng"

    goto :goto_185b

    :cond_18d9
    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_18e5

    sget-boolean v0, Lq;->g:Z

    if-nez v0, :cond_18e5

    const-string v0, "Gặp cô Ayumi để phục hồi võ công."

    goto/16 :goto_185b

    :cond_18e5
    sget-boolean v0, Lg;->i:Z

    if-eqz v0, :cond_18f1

    sget-boolean v0, Lq;->h:Z

    if-nez v0, :cond_18f1

    const-string v0, "Lên đường đến trường Haruna!"

    goto/16 :goto_185b

    :cond_18f1
    sget-boolean v0, Lq;->g:Z

    if-eqz v0, :cond_18f9

    const-string v0, "Gặp thầy hiệu trưởng"

    goto/16 :goto_185b

    :cond_18f9
    sget v0, Lg;->bc:I

    if-ne v0, v11, :cond_1901

    const-string v0, "Giết 20 rùa biển làm lương khô"

    goto/16 :goto_185b

    :cond_1901
    sget v0, Lg;->bc:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_190a

    const-string v0, "Giết 20 ốc ma đen đem về cho già làng để làm diều lượn"

    goto/16 :goto_185b

    :cond_190a
    sget v0, Lg;->a:I

    if-nez v0, :cond_1912

    const-string v0, "Giết mực khổng lồ trên đỉnh Ichidai rồi về gặp già làng"

    goto/16 :goto_185b

    :cond_1912
    sget v0, Lg;->a:I

    if-ne v0, v6, :cond_191a

    const-string v0, "đến cánh đồng Fuki mua thuốc trị thương mang về cho Sakura"

    goto/16 :goto_185b

    :cond_191a
    sget v0, Lg;->a:I

    if-ne v0, v9, :cond_1922

    const-string v0, "Tiếp tục lên đường đến trường Haruna"

    goto/16 :goto_185b

    :cond_1922
    sget v0, Lg;->a:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_192b

    const-string v0, "Tìm thẻ học sinh (Gợi ý: Cô gái)"

    goto/16 :goto_185b

    :cond_192b
    sget v0, Lg;->a:I

    if-ne v0, v11, :cond_1933

    const-string v0, "Lên đường đến miếu Chakumi"

    goto/16 :goto_185b

    :cond_1933
    sget v0, Lg;->a:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_193c

    const-string v0, "Giải câu đố: Ba anh vác gậy đuổi nhau, mười hai cô gái làm ngơ đứng nhìn"

    goto/16 :goto_185b

    :cond_193c
    sget v0, Lg;->a:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_1945

    const-string v0, "Giải câu đố: Cái gì lạ lắm, tên trùng một âm, nước đục chui lầm, thì tiêu đời cá"

    goto/16 :goto_185b

    :cond_1945
    sget v0, Lg;->a:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_194e

    const-string v0, "Giải câu đố thứ ba: Cái gì vừa là áo vừa là nhà?"

    goto/16 :goto_185b

    :cond_194e
    sget v0, Lg;->a:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_1958

    const-string v0, "Tập luyện để đạt được cấp độ 10 rồi quay về gặp già làng"

    goto/16 :goto_185b

    :cond_1958
    sget v0, Lg;->a:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_1962

    const-string v0, "đến miếu Chakumi tiêu diệt tên Sanosuke"

    goto/16 :goto_185b

    :cond_1962
    sget v0, Lg;->a:I

    const/16 v1, 0xa

    if-ne v0, v1, :cond_196c

    const-string v0, "Tập luyện để đạt được cấp độ 13"

    goto/16 :goto_185b

    :cond_196c
    sget v0, Lg;->a:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_1976

    const-string v0, "Tập luyện để đạt được cấp độ 20"

    goto/16 :goto_185b

    :cond_1976
    sget v0, Lg;->a:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_1980

    const-string v0, "Qua dãy lớp học (bên phải) gặp Toniku"

    goto/16 :goto_185b

    :cond_1980
    const-string v0, "Không có nhiệm vụ"

    goto/16 :goto_185b

    :cond_1984
    invoke-static {}, Lq;->w()V

    const/16 v0, 0xb

    invoke-static {v0}, Lq;->h(I)V

    sget v0, Lq;->ae:I

    add-int/lit8 v0, v0, -0x28

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    move v0, v6

    goto/16 :goto_1802

    :cond_1998
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0x8

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_19ae

    sget v0, Lq;->fy:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fy:I

    if-le v0, v11, :cond_21d5

    const/4 v0, 0x0

    sput v0, Lq;->fy:I

    move v0, v6

    goto/16 :goto_1802

    :cond_19ae
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_19c3

    sget v0, Lq;->fy:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fy:I

    if-gez v0, :cond_21d5

    const/4 v0, 0x4

    sput v0, Lq;->fy:I

    move v0, v6

    goto/16 :goto_1802

    :cond_19c3
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_19cd

    move v0, v6

    goto/16 :goto_1802

    :cond_19cd
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_21d2

    move v0, v6

    goto/16 :goto_1802

    :pswitch_19d7  #0x6
    sget v0, Lq;->fM:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fM:I

    const/16 v1, 0x2710

    if-le v0, v1, :cond_19e4

    const/4 v0, 0x0

    sput v0, Lq;->fM:I

    :cond_19e4
    sget v0, Lq;->fT:I

    sget v1, Lq;->fN:I

    if-ne v0, v1, :cond_19f0

    sget v0, Lq;->fU:I

    sget v1, Lq;->fO:I

    if-eq v0, v1, :cond_1a56

    :cond_19f0
    sget v0, Lq;->fN:I

    sget v1, Lq;->fT:I

    sub-int/2addr v0, v1

    shl-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fP:I

    sget v0, Lq;->fO:I

    sget v1, Lq;->fU:I

    sub-int/2addr v0, v1

    shl-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fQ:I

    sget v0, Lq;->fR:I

    sget v1, Lq;->fP:I

    add-int/2addr v0, v1

    sput v0, Lq;->fR:I

    sget v0, Lq;->fT:I

    sget v1, Lq;->fR:I

    shr-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sput v0, Lq;->fT:I

    sget v0, Lq;->fR:I

    and-int/lit8 v0, v0, 0xf

    sput v0, Lq;->fR:I

    sget v0, Lq;->fS:I

    sget v1, Lq;->fQ:I

    add-int/2addr v0, v1

    sput v0, Lq;->fS:I

    sget v0, Lq;->fU:I

    sget v1, Lq;->fS:I

    shr-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sput v0, Lq;->fU:I

    sget v0, Lq;->fS:I

    and-int/lit8 v0, v0, 0xf

    sput v0, Lq;->fS:I

    sget v0, Lq;->fT:I

    const/16 v1, -0x28

    if-ge v0, v1, :cond_1a38

    const/16 v0, -0x28

    sput v0, Lq;->fT:I

    :cond_1a38
    sget v0, Lq;->fT:I

    sget v1, Lq;->fV:I

    if-le v0, v1, :cond_1a42

    sget v0, Lq;->fV:I

    sput v0, Lq;->fT:I

    :cond_1a42
    sget v0, Lq;->fU:I

    const/16 v1, -0x28

    if-ge v0, v1, :cond_1a4c

    const/16 v0, -0x28

    sput v0, Lq;->fU:I

    :cond_1a4c
    sget v0, Lq;->fU:I

    sget v1, Lq;->fW:I

    if-le v0, v1, :cond_1a56

    sget v0, Lq;->fW:I

    sput v0, Lq;->fU:I

    :cond_1a56
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_1a65

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1a7b

    :cond_1a65
    invoke-static {}, Lq;->c()V

    sget v0, Lq;->fL:I

    if-eq v0, v8, :cond_1a7b

    sget-object v0, Lq;->bt:[Z

    sget v1, Lq;->fL:I

    aget-boolean v0, v0, v1

    if-nez v0, :cond_1a9e

    const/4 v0, 0x1

    invoke-static {v0}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    :cond_1a7b
    :goto_1a7b
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1ab4

    invoke-static {}, Lq;->W()V

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lj;->c()V

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    const/4 v2, 0x1

    aput-boolean v2, v0, v1

    goto/16 :goto_29

    :cond_1a9e
    sget v0, Lq;->fX:I

    sget v1, Lq;->fL:I

    if-ne v0, v1, :cond_1aac

    const/4 v0, 0x3

    invoke-static {v0}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto :goto_1a7b

    :cond_1aac
    const/4 v0, 0x2

    invoke-static {v0}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto :goto_1a7b

    :cond_1ab4
    sget-object v0, Lq;->C:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_21cf

    sget v0, Lq;->fK:I

    add-int/lit8 v0, v0, -0x4

    sput v0, Lq;->fK:I

    const/16 v1, -0x14

    if-ge v0, v1, :cond_1ac9

    const/16 v0, -0x14

    sput v0, Lq;->fK:I

    :cond_1ac9
    move v0, v6

    :goto_1aca
    sget-object v1, Lq;->C:[Z

    const/16 v2, 0x8

    aget-boolean v1, v1, v2

    if-eqz v1, :cond_1ae1

    sget v0, Lq;->fK:I

    add-int/lit8 v0, v0, 0x4

    sput v0, Lq;->fK:I

    const/16 v1, 0x117

    if-le v0, v1, :cond_1ae0

    const/16 v0, 0x117

    sput v0, Lq;->fK:I

    :cond_1ae0
    move v0, v6

    :cond_1ae1
    sget-object v1, Lq;->C:[Z

    const/4 v2, 0x4

    aget-boolean v1, v1, v2

    if-eqz v1, :cond_1af7

    sget v0, Lq;->fJ:I

    add-int/lit8 v0, v0, -0x4

    sput v0, Lq;->fJ:I

    const/16 v1, -0x14

    if-ge v0, v1, :cond_1af6

    const/16 v0, -0x14

    sput v0, Lq;->fJ:I

    :cond_1af6
    move v0, v6

    :cond_1af7
    sget-object v1, Lq;->C:[Z

    const/4 v2, 0x6

    aget-boolean v1, v1, v2

    if-eqz v1, :cond_1b0d

    sget v0, Lq;->fJ:I

    add-int/lit8 v0, v0, 0x4

    sput v0, Lq;->fJ:I

    const/16 v1, 0x117

    if-le v0, v1, :cond_1b0c

    const/16 v0, 0x117

    sput v0, Lq;->fJ:I

    :cond_1b0c
    move v0, v6

    :cond_1b0d
    if-eqz v0, :cond_29

    sget v0, Lq;->fJ:I

    sget v1, Lq;->ad:I

    sub-int/2addr v0, v1

    sput v0, Lq;->fN:I

    sget v0, Lq;->fK:I

    sget v1, Lq;->ae:I

    sub-int/2addr v0, v1

    sput v0, Lq;->fO:I

    invoke-static {}, Lq;->X()V

    goto/16 :goto_29

    :pswitch_1b22  #0x7
    sget v0, Lq;->ge:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->ge:I

    const/16 v1, 0xa

    if-ge v0, v1, :cond_1b2f

    invoke-static {}, Lq;->c()V

    :cond_1b2f
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1b3f

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->gc:I

    packed-switch v0, :pswitch_data_222e

    :cond_1b3f
    :goto_1b3f
    :pswitch_1b3f  #0x7
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1b4f

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->gc:I

    packed-switch v0, :pswitch_data_2248

    :cond_1b4f
    :goto_1b4f
    :pswitch_1b4f  #0x1, 0x3, 0x4, 0x5, 0x6, 0x8, 0x9
    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_29

    :pswitch_1b54  #0x1, 0x3, 0x4
    const/4 v0, 0x6

    sput v0, Lq;->K:I

    goto :goto_1b3f

    :pswitch_1b58  #0x5, 0x6, 0x8, 0x9, 0xa, 0xb
    sget v0, Lq;->gc:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_1b62

    const/4 v0, 0x0

    sput-boolean v0, Lq;->y:Z

    goto :goto_1b3f

    :cond_1b62
    sget v0, Lq;->gc:I

    const/16 v1, 0xa

    if-ne v0, v1, :cond_1b7c

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lq;->B()V

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sput-wide v0, Lq;->eA:J

    const/4 v0, 0x0

    invoke-static {v0}, Lq;->i(I)V

    goto :goto_1b3f

    :cond_1b7c
    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    goto :goto_1b3f

    :pswitch_1b83  #0x2
    sget v0, Lq;->gd:I

    sget v1, Lq;->aj:I

    if-lt v0, v1, :cond_1b8e

    const/4 v0, 0x4

    invoke-static {v0}, Lq;->h(I)V

    goto :goto_1b3f

    :cond_1b8e
    sget v0, Lq;->aj:I

    sget v1, Lq;->gd:I

    sub-int/2addr v0, v1

    sput v0, Lq;->aj:I

    invoke-static {}, Lq;->W()V

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Lj;->c()V

    invoke-static {}, Lq;->A()V

    sget-object v0, Lq;->fF:[I

    sget v1, Lq;->fL:I

    aget v0, v0, v1

    mul-int/lit8 v0, v0, 0x18

    sput v0, Lg;->at:I

    sput v0, Lg;->aS:I

    sget-object v0, Lq;->fG:[I

    sget v1, Lq;->fL:I

    aget v0, v0, v1

    mul-int/lit8 v0, v0, 0x18

    sput v0, Lg;->au:I

    sput v0, Lg;->aT:I

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->f:Z

    sget v0, Lq;->fL:I

    invoke-static {v0}, Lq;->i(I)V

    goto/16 :goto_1b3f

    :pswitch_1bc3  #0x2
    const/4 v0, 0x6

    sput v0, Lq;->K:I

    goto :goto_1b4f

    :pswitch_1bc7  #0xa
    const/4 v0, 0x1

    sput v0, Lq;->bS:I

    const/4 v0, 0x3

    sput v0, Lq;->K:I

    goto :goto_1b4f

    :pswitch_1bce  #0x7
    const/16 v0, 0x9

    sput v0, Lq;->K:I

    goto/16 :goto_1b4f

    :pswitch_1bd4  #0xb
    sget v0, Lq;->as:I

    invoke-static {v0}, Lj;->c(I)V

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    goto/16 :goto_1b4f

    :pswitch_1bde  #0xe
    sget v0, Lq;->fz:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fz:I

    const/16 v1, 0x2710

    if-le v0, v1, :cond_1beb

    const/4 v0, 0x0

    sput v0, Lq;->fz:I

    :cond_1beb
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1c24

    const/4 v0, 0x0

    sput v0, Lg;->aX:I

    sget v0, Lg;->aW:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aW:I

    sget v0, Lg;->a:I

    const/16 v1, 0xa

    if-ne v0, v1, :cond_1c11

    sget v0, Lg;->aW:I

    const/16 v1, 0xd

    if-lt v0, v1, :cond_1c11

    const/4 v0, 0x4

    sput v0, Lg;->a:I

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    :cond_1c11
    sget v0, Lq;->gi:I

    packed-switch v0, :pswitch_data_2262

    :goto_1c16
    sget v0, Lg;->aM:I

    sput v0, Lg;->aL:I

    sget v0, Lg;->aO:I

    sput v0, Lg;->aN:I

    invoke-static {}, Lq;->c()V

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    :cond_1c24
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1c34

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->gi:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->gi:I

    :cond_1c34
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0x8

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1c45

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->gi:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->gi:I

    :cond_1c45
    sget v0, Lq;->gi:I

    if-gez v0, :cond_1c4c

    const/4 v0, 0x2

    sput v0, Lq;->gi:I

    :cond_1c4c
    sget v0, Lq;->gi:I

    if-le v0, v9, :cond_1c53

    const/4 v0, 0x0

    sput v0, Lq;->gi:I

    :cond_1c53
    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_29

    :pswitch_1c58  #0x0
    sget v0, Lg;->aM:I

    sget-object v1, Lg;->d:[I

    sget v2, Lg;->aW:I

    add-int/lit8 v2, v2, -0x2

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aM:I

    goto :goto_1c16

    :pswitch_1c66  #0x1
    sget v0, Lg;->aJ:I

    sget-object v1, Lg;->b:[I

    sget v2, Lg;->aW:I

    add-int/lit8 v2, v2, -0x2

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aJ:I

    sget v0, Lg;->aK:I

    add-int/lit8 v0, v0, 0x2

    sput v0, Lg;->aK:I

    goto :goto_1c16

    :pswitch_1c7a  #0x2
    sget v0, Lg;->aO:I

    sget-object v1, Lg;->e:[I

    sget v2, Lg;->aW:I

    add-int/lit8 v2, v2, -0x2

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aO:I

    goto :goto_1c16

    :pswitch_1c88  #0x8
    sget v0, Lq;->fq:I

    if-lez v0, :cond_1c92

    sget v0, Lq;->fq:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fq:I

    :cond_1c92
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_1ca1

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1cdc

    :cond_1ca1
    sget-object v0, Lq;->br:[I

    sget v1, Lq;->fp:I

    aget v0, v0, v1

    if-lez v0, :cond_1cd9

    sget-object v0, Lq;->br:[I

    sget v1, Lq;->fp:I

    aget v2, v0, v1

    add-int/lit8 v2, v2, -0x1

    aput v2, v0, v1

    sget-object v0, Lq;->fr:[I

    array-length v0, v0

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fq:I

    sget v0, Lq;->fp:I

    if-gt v0, v9, :cond_1cf1

    sget v0, Lg;->aL:I

    sget v1, Lg;->aM:I

    if-ge v0, v1, :cond_1ccf

    sget v0, Lg;->aL:I

    sget-object v1, Lq;->ft:[I

    sget v2, Lq;->fp:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aL:I

    :cond_1ccf
    sget v0, Lg;->aL:I

    sget v1, Lg;->aM:I

    if-le v0, v1, :cond_1cd9

    sget v0, Lg;->aM:I

    sput v0, Lg;->aL:I

    :cond_1cd9
    :goto_1cd9
    invoke-static {}, Lq;->c()V

    :cond_1cdc
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1d18

    sget v0, Lg;->ax:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_1d0d

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    goto/16 :goto_29

    :cond_1cf1
    sget v0, Lg;->aN:I

    sget v1, Lg;->aO:I

    if-ge v0, v1, :cond_1d02

    sget v0, Lg;->aN:I

    sget-object v1, Lq;->ft:[I

    sget v2, Lq;->fp:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aN:I

    :cond_1d02
    sget v0, Lg;->aN:I

    sget v1, Lg;->aO:I

    if-le v0, v1, :cond_1cd9

    sget v0, Lg;->aO:I

    sput v0, Lg;->aN:I

    goto :goto_1cd9

    :cond_1d0d
    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    const/4 v0, 0x5

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1d18
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1d2d

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->fp:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fp:I

    if-gez v0, :cond_1d2d

    const/4 v0, 0x5

    sput v0, Lq;->fp:I

    :cond_1d2d
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_29

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->fp:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fp:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_29

    const/4 v0, 0x0

    sput v0, Lq;->fp:I

    goto/16 :goto_29

    :pswitch_1d45  #0x9
    sget v0, Lq;->fh:I

    if-lez v0, :cond_1d4f

    sget v0, Lq;->fh:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fh:I

    :cond_1d4f
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_1d5e

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1daa

    :cond_1d5e
    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bo:I

    if-nez v0, :cond_1e65

    sget v0, Lq;->bp:I

    if-nez v0, :cond_1e1d

    sget v0, Lq;->bn:I

    const/4 v1, 0x3

    if-ge v0, v1, :cond_1dcc

    sget-object v0, Lq;->br:[I

    const/4 v1, 0x0

    aget v0, v0, v1

    sget-object v1, Lq;->br:[I

    const/4 v2, 0x1

    aget v1, v1, v2

    add-int/2addr v0, v1

    sget-object v1, Lq;->br:[I

    const/4 v2, 0x2

    aget v1, v1, v2

    add-int/2addr v0, v1

    const/16 v1, 0x63

    if-gt v0, v1, :cond_29

    :goto_1d83
    sget v0, Lq;->aj:I

    sget-object v1, Lq;->fl:[[I

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    if-lt v0, v1, :cond_1de2

    sget-object v0, Lq;->br:[I

    sget v1, Lq;->bn:I

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    sget v0, Lq;->aj:I

    sget-object v1, Lq;->fl:[[I

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    sub-int/2addr v0, v1

    sput v0, Lq;->aj:I

    :cond_1daa
    :goto_1daa
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2030

    const/4 v0, 0x0

    sput-object v0, Lq;->fw:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->fm:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-static {}, Lj;->c()V

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    goto/16 :goto_29

    :cond_1dcc
    sget-object v0, Lq;->br:[I

    const/4 v1, 0x3

    aget v0, v0, v1

    sget-object v1, Lq;->br:[I

    const/4 v2, 0x4

    aget v1, v1, v2

    add-int/2addr v0, v1

    sget-object v1, Lq;->br:[I

    const/4 v2, 0x5

    aget v1, v1, v2

    add-int/2addr v0, v1

    const/16 v1, 0x63

    if-gt v0, v1, :cond_29

    goto :goto_1d83

    :cond_1de2
    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Không có đủ tiền: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v1, Lq;->fl:[[I

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$. Bạn chỉ có: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget v1, Lq;->aj:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$. Hãy đi tìm thêm."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1e1d
    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lb;->e:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " BUY "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "110"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget-object v1, Lb;->c:[[Ljava/lang/String;

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lb;->d:[[Ljava/lang/String;

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    add-int/lit8 v2, v2, 0x1

    invoke-static {v0, v1, v2}, Lb;->a(Ljava/lang/String;Ljava/lang/String;I)V

    goto/16 :goto_1daa

    :cond_1e65
    sget v0, Lq;->bn:I

    if-eqz v0, :cond_1eb8

    sget v0, Lg;->aW:I

    sget-object v1, Lq;->ff:[I

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    if-ge v0, v1, :cond_1e9e

    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Bạn phải đạt cấp độ "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v1, Lq;->ff:[I

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, " mới có thể mua vũ khí này!"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1e9e
    sget v0, Lq;->bn:I

    invoke-static {v0}, Lq;->m(I)Z

    move-result v0

    if-eqz v0, :cond_1eb8

    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    const-string v0, "Không cần thiết phải mua vũ khí này vì vũ khí này đã mua rồi!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1eb8
    sget v0, Lq;->bn:I

    if-nez v0, :cond_1edc

    sget v0, Lq;->as:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_1eca

    sget-boolean v0, Lg;->n:Z

    if-nez v0, :cond_1eca

    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_1edc

    :cond_1eca
    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    const-string v0, "Không cần thiết phải mua thuốc trị thương vì bạn chưa cần dùng tới!"

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1edc
    sget v0, Lq;->bp:I

    if-nez v0, :cond_1fe8

    sget v0, Lq;->aj:I

    sget-object v1, Lq;->fl:[[I

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    if-lt v0, v1, :cond_1fad

    sget v0, Lq;->aj:I

    sget-object v1, Lq;->fl:[[I

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    sub-int/2addr v0, v1

    sput v0, Lq;->aj:I

    sget v0, Lq;->bn:I

    if-eqz v0, :cond_1f98

    sget v0, Lq;->bn:I

    sput v0, Lg;->as:I

    invoke-static {}, Lg;->e()V

    invoke-static {}, Lq;->i()V

    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Xin chúc mừng. Bạn đã có vũ khí mới: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v1, Lq;->bq:[[Ljava/lang/String;

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "!"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lg;->aJ:I

    sget-object v1, Lq;->fj:[I

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aJ:I

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    sget-object v0, Lq;->bf:[I

    sget v1, Lq;->bh:I

    sget v2, Lg;->as:I

    aput v2, v0, v1

    sget v0, Lg;->as:I

    packed-switch v0, :pswitch_data_226c

    :goto_1f50
    sget v0, Lq;->bh:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bh:I

    goto/16 :goto_29

    :pswitch_1f58  #0x1
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm sét"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x2

    aput v2, v0, v1

    goto :goto_1f50

    :pswitch_1f68  #0x2
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm lửa"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x3

    aput v2, v0, v1

    goto :goto_1f50

    :pswitch_1f78  #0x3
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm băng"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x4

    aput v2, v0, v1

    goto :goto_1f50

    :pswitch_1f88  #0x4
    sget-object v0, Lq;->bg:[Ljava/lang/String;

    sget v1, Lq;->bh:I

    const-string v2, "Gươm hỏa long"

    aput-object v2, v0, v1

    sget-object v0, Lq;->bs:[I

    sget v1, Lq;->bh:I

    const/4 v2, 0x5

    aput v2, v0, v1

    goto :goto_1f50

    :cond_1f98
    const/4 v0, 0x1

    sput-boolean v0, Lg;->n:Z

    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    const-string v0, "Xin chúc mừng. Bạn đã mua được thuốc trị thương."

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1fad
    const/4 v0, 0x7

    invoke-static {v0}, Lq;->h(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Không có đủ tiền: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v1, Lq;->fl:[[I

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$. Bạn chỉ có: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget v1, Lq;->aj:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "$. Hãy đi tìm thêm."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    goto/16 :goto_29

    :cond_1fe8
    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lb;->e:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " PAY "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "110"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget-object v1, Lb;->c:[[Ljava/lang/String;

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lb;->d:[[Ljava/lang/String;

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    add-int/lit8 v2, v2, 0x6

    invoke-static {v0, v1, v2}, Lb;->a(Ljava/lang/String;Ljava/lang/String;I)V

    goto/16 :goto_1daa

    :cond_2030
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x2

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2047

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bo:I

    if-ne v0, v6, :cond_2047

    const/4 v0, 0x0

    sput v0, Lq;->bo:I

    sget v0, Lq;->bn:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bn:I

    :cond_2047
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0x8

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_206c

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bo:I

    if-nez v0, :cond_206c

    const/4 v0, 0x1

    sput v0, Lq;->bo:I

    sget v0, Lq;->bn:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->bn:I

    if-gez v0, :cond_2064

    const/4 v0, 0x0

    sput v0, Lq;->bn:I

    :cond_2064
    sget v0, Lq;->bn:I

    const/4 v1, 0x3

    if-le v0, v1, :cond_206c

    const/4 v0, 0x3

    sput v0, Lq;->bn:I

    :cond_206c
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2085

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bn:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->bn:I

    if-gez v0, :cond_2085

    sget v0, Lq;->bo:I

    if-nez v0, :cond_20ae

    const/4 v0, 0x5

    sput v0, Lq;->bn:I

    :cond_2085
    :goto_2085
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_29

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bn:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bn:I

    sget v0, Lq;->bo:I

    if-nez v0, :cond_20a1

    sget v0, Lq;->bn:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_20a1

    const/4 v0, 0x0

    sput v0, Lq;->bn:I

    :cond_20a1
    sget v0, Lq;->bo:I

    if-ne v0, v6, :cond_29

    sget v0, Lq;->bn:I

    if-ne v0, v11, :cond_29

    const/4 v0, 0x0

    sput v0, Lq;->bn:I

    goto/16 :goto_29

    :cond_20ae
    const/4 v0, 0x3

    sput v0, Lq;->bn:I

    goto :goto_2085

    :pswitch_20b2  #0xa
    sget-boolean v0, Lq;->ga:Z

    if-eqz v0, :cond_20bf

    const/4 v0, 0x0

    sput-object v0, Lq;->fZ:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-static {}, Lq;->E()V

    :cond_20bf
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_20e4

    sget v0, Lq;->gb:I

    if-nez v0, :cond_20e0

    const/4 v0, 0x0

    sput-boolean v0, LMidlet;->h:Z

    :goto_20ce
    move v0, v6

    :goto_20cf
    if-eqz v0, :cond_29

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    sget v0, Lq;->gb:I

    if-nez v0, :cond_212a

    const/4 v0, 0x1

    sput v0, Lq;->gb:I

    goto/16 :goto_29

    :cond_20e0
    const/4 v0, 0x0

    sput-boolean v0, Lq;->b:Z

    goto :goto_20ce

    :cond_20e4
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_20f9

    sget v0, Lq;->gb:I

    if-nez v0, :cond_20f5

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->h:Z

    :goto_20f3
    move v0, v6

    goto :goto_20cf

    :cond_20f5
    const/4 v0, 0x1

    sput-boolean v0, Lq;->b:Z

    goto :goto_20f3

    :cond_20f9
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2110

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bu:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->bu:I

    if-gez v0, :cond_2128

    const/4 v0, 0x0

    sput v0, Lq;->bu:I

    move v0, v7

    goto :goto_20cf

    :cond_2110
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2128

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->bu:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->bu:I

    const/16 v1, 0xa

    if-le v0, v1, :cond_2128

    const/16 v0, 0xa

    sput v0, Lq;->bu:I

    :cond_2128
    move v0, v7

    goto :goto_20cf

    :cond_212a
    const/4 v0, 0x1

    sput-boolean v0, Lq;->ga:Z

    goto/16 :goto_29

    :pswitch_212f  #0xb
    invoke-static {}, Lq;->N()V

    goto/16 :goto_29

    :pswitch_2134  #0xc
    invoke-static {}, Lq;->N()V

    goto/16 :goto_29

    :pswitch_2139  #0xd
    invoke-static {}, Lb;->b()V

    goto/16 :goto_29

    :pswitch_213e  #0xf
    sget v0, Lq;->fq:I

    if-lez v0, :cond_2148

    sget v0, Lq;->fq:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fq:I

    :cond_2148
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_2157

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2167

    :cond_2157
    sget v0, Lq;->fp:I

    if-ne v0, v6, :cond_2181

    const/4 v0, 0x1

    sput v0, Lg;->ar:I

    :goto_215e
    invoke-static {}, Lq;->i()V

    invoke-static {}, Lg;->e()V

    invoke-static {}, Lq;->c()V

    :cond_2167
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_2191

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lq;->b()V

    sget-boolean v0, Lq;->fa:Z

    if-eqz v0, :cond_218d

    const/4 v0, 0x1

    sput v0, Lq;->K:I

    :goto_217c
    const/4 v0, 0x0

    sput-boolean v0, Lq;->fa:Z

    goto/16 :goto_29

    :cond_2181
    sget-object v0, Lq;->bf:[I

    sget v1, Lq;->fp:I

    aget v0, v0, v1

    sput v0, Lg;->as:I

    const/4 v0, 0x0

    sput v0, Lg;->ar:I

    goto :goto_215e

    :cond_218d
    const/4 v0, 0x5

    sput v0, Lq;->K:I

    goto :goto_217c

    :cond_2191
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x4

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_21a9

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->fp:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fp:I

    if-gez v0, :cond_21a9

    sget v0, Lq;->bh:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lq;->fp:I

    :cond_21a9
    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x6

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_21c0

    invoke-static {}, Lq;->c()V

    sget v0, Lq;->fp:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fp:I

    sget v1, Lq;->bh:I

    if-ne v0, v1, :cond_21c0

    const/4 v0, 0x0

    sput v0, Lq;->fp:I

    :cond_21c0
    sget v0, Lq;->fv:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->fv:I

    const/16 v1, 0x64

    if-lt v0, v1, :cond_29

    const/4 v0, 0x0

    sput v0, Lq;->fv:I
    :try_end_21cd
    .catch Ljava/lang/Exception; {:try_start_178e .. :try_end_21cd} :catch_3f

    goto/16 :goto_29

    :cond_21cf
    move v0, v7

    goto/16 :goto_1aca

    :cond_21d2
    move v0, v7

    goto/16 :goto_1802

    :cond_21d5
    move v0, v6

    goto/16 :goto_1802

    :pswitch_data_21d8
    .packed-switch 0x1
        :pswitch_44  #00000001
        :pswitch_15b5  #00000002
        :pswitch_15c3  #00000003
        :pswitch_17a1  #00000004
        :pswitch_17e0  #00000005
        :pswitch_19d7  #00000006
        :pswitch_1b22  #00000007
        :pswitch_1c88  #00000008
        :pswitch_1d45  #00000009
        :pswitch_20b2  #0000000a
        :pswitch_212f  #0000000b
        :pswitch_2134  #0000000c
        :pswitch_2139  #0000000d
        :pswitch_1bde  #0000000e
        :pswitch_213e  #0000000f
    .end packed-switch

    :sswitch_data_21fa
    .sparse-switch
        0x2 -> :sswitch_bed
        0x4 -> :sswitch_c8b
        0xb -> :sswitch_d34
    .end sparse-switch

    :pswitch_data_2208
    .packed-switch 0x1
        :pswitch_1353  #00000001
        :pswitch_13b2  #00000002
        :pswitch_1351  #00000003
        :pswitch_1351  #00000004
        :pswitch_1400  #00000005
        :pswitch_149c  #00000006
        :pswitch_1474  #00000007
    .end packed-switch

    :pswitch_data_221a
    .packed-switch 0x0
        :pswitch_1554  #00000000
        :pswitch_155b  #00000001
        :pswitch_1562  #00000002
        :pswitch_156c  #00000003
        :pswitch_1552  #00000004
        :pswitch_1576  #00000005
        :pswitch_1580  #00000006
        :pswitch_158a  #00000007
    .end packed-switch

    :pswitch_data_222e
    .packed-switch 0x1
        :pswitch_1b54  #00000001
        :pswitch_1b83  #00000002
        :pswitch_1b54  #00000003
        :pswitch_1b54  #00000004
        :pswitch_1b58  #00000005
        :pswitch_1b58  #00000006
        :pswitch_1b3f  #00000007
        :pswitch_1b58  #00000008
        :pswitch_1b58  #00000009
        :pswitch_1b58  #0000000a
        :pswitch_1b58  #0000000b
    .end packed-switch

    :pswitch_data_2248
    .packed-switch 0x1
        :pswitch_1b4f  #00000001
        :pswitch_1bc3  #00000002
        :pswitch_1b4f  #00000003
        :pswitch_1b4f  #00000004
        :pswitch_1b4f  #00000005
        :pswitch_1b4f  #00000006
        :pswitch_1bce  #00000007
        :pswitch_1b4f  #00000008
        :pswitch_1b4f  #00000009
        :pswitch_1bc7  #0000000a
        :pswitch_1bd4  #0000000b
    .end packed-switch

    :pswitch_data_2262
    .packed-switch 0x0
        :pswitch_1c58  #00000000
        :pswitch_1c66  #00000001
        :pswitch_1c7a  #00000002
    .end packed-switch

    :pswitch_data_226c
    .packed-switch 0x1
        :pswitch_1f58  #00000001
        :pswitch_1f68  #00000002
        :pswitch_1f78  #00000003
        :pswitch_1f88  #00000004
    .end packed-switch
.end method
