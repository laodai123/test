.class public final Lp;
.super Ljava/lang/Object;


# static fields
.field public static a:I

.field public static b:[I

.field public static c:[I

.field public static d:[I

.field public static e:[I

.field public static f:[I

.field public static g:I

.field private static h:[Ljavax/microedition/lcdui/Image;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, -0x1

    sput v0, Lp;->g:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a()V
    .registers 5

    const/4 v4, 0x3

    sget-object v0, Lp;->h:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lp;->h:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    :goto_a
    if-lt v0, v4, :cond_2b

    :cond_c
    :goto_c
    sget v0, Lp;->a:I

    new-array v0, v0, [I

    sput-object v0, Lp;->b:[I

    sget v0, Lp;->a:I

    new-array v0, v0, [I

    sput-object v0, Lp;->c:[I

    sget v0, Lp;->a:I

    new-array v0, v0, [I

    sput-object v0, Lp;->d:[I

    sget v0, Lp;->a:I

    new-array v0, v0, [I

    sput-object v0, Lp;->e:[I

    sget v0, Lp;->a:I

    new-array v0, v0, [I

    sput-object v0, Lp;->f:[I

    return-void

    :cond_2b
    :try_start_2b
    sget-object v1, Lp;->h:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/i/k"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_48} :catch_4b

    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :catch_4b
    move-exception v0

    goto :goto_c
.end method

.method public static final a(I)V
    .registers 6

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-boolean v0, Lg;->m:Z

    if-nez v0, :cond_7

    :cond_6
    :goto_6
    return-void

    :cond_7
    sput v1, Lp;->a:I

    sget v0, Lp;->g:I

    const/4 v3, -0x1

    if-ne v0, v3, :cond_33

    move v0, v1

    :goto_f
    const/4 v3, 0x6

    if-ne p0, v3, :cond_35

    add-int/lit8 v3, v0, 0x1

    sput v3, Lp;->a:I

    invoke-static {}, Lp;->a()V

    const/16 v3, 0x21

    const/4 v4, 0x4

    invoke-static {v1, v3, v4}, Lp;->a(III)V

    if-ne v0, v2, :cond_6

    sget v0, Lg;->at:I

    sget v1, Lg;->au:I

    invoke-static {v2, v0, v1}, Lp;->a(III)V

    sput v2, Lp;->g:I

    sget-object v0, Lp;->d:[I

    sget v1, Lp;->g:I

    sget v2, Lg;->aF:I

    aput v2, v0, v1

    goto :goto_6

    :cond_33
    move v0, v2

    goto :goto_f

    :cond_35
    if-ne v0, v2, :cond_6

    sput v2, Lp;->a:I

    invoke-static {}, Lp;->a()V

    sget v0, Lg;->at:I

    sget v2, Lg;->au:I

    invoke-static {v1, v0, v2}, Lp;->a(III)V

    sput v1, Lp;->g:I

    sget-object v0, Lp;->d:[I

    sget v1, Lp;->g:I

    sget v2, Lg;->aF:I

    aput v2, v0, v1

    goto :goto_6
.end method

.method private static a(III)V
    .registers 5

    sget-object v0, Lp;->b:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p1

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Lp;->c:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p2

    aput v1, v0, p0

    sget-object v0, Lp;->e:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    sget-object v0, Lp;->d:[I

    const/4 v1, 0x1

    aput v1, v0, p0

    return-void
.end method

.method public static final a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 12

    const/16 v9, 0x21

    const/4 v2, 0x0

    move v10, v2

    :goto_4
    sget v0, Lp;->a:I

    if-lt v10, v0, :cond_9

    return-void

    :cond_9
    sget v0, Lq;->ay:I

    sget-object v1, Lp;->b:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, 0xc

    if-gt v0, v1, :cond_4f

    sget v0, Lq;->ay:I

    sget v1, Lq;->ab:I

    add-int/2addr v0, v1

    sget-object v1, Lp;->b:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0xc

    if-lt v0, v1, :cond_4f

    sget v0, Lq;->az:I

    sget-object v1, Lp;->c:[I

    aget v1, v1, v10

    if-gt v0, v1, :cond_4f

    sget v0, Lq;->az:I

    sget v1, Lq;->ac:I

    add-int/2addr v0, v1

    sget-object v1, Lp;->c:[I

    aget v1, v1, v10

    add-int/lit8 v1, v1, -0x18

    if-lt v0, v1, :cond_4f

    sget-object v0, Lp;->d:[I

    aget v0, v0, v10

    const/4 v1, 0x1

    if-ne v0, v1, :cond_53

    sget-object v0, Lp;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lp;->e:[I

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget-object v1, Lp;->b:[I

    aget v1, v1, v10

    sget-object v3, Lp;->c:[I

    aget v3, v3, v10

    invoke-virtual {p0, v0, v1, v3, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_4f
    :goto_4f
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto :goto_4

    :cond_53
    sget-object v0, Lp;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lp;->e:[I

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Lp;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lp;->e:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lp;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lp;->e:[I

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    const/4 v6, 0x2

    sget-object v0, Lp;->b:[I

    aget v7, v0, v10

    sget-object v0, Lp;->c:[I

    aget v8, v0, v10

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_4f
.end method
