.class public final Lr;
.super Lh;


# instance fields
.field private h:I

.field private i:I


# direct methods
.method public constructor <init>(III)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lh;-><init>(III)V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 6

    const/4 v4, 0x0

    const/4 v3, 0x1

    iget v0, p0, Lh;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lh;->f:I

    iget v0, p0, Lh;->f:I

    sget-object v1, Lh;->a:[[I

    iget v2, p0, Lh;->d:I

    aget-object v1, v1, v2

    array-length v1, v1

    if-lt v0, v1, :cond_15

    iput v4, p0, Lh;->f:I

    :cond_15
    iget v0, p0, Lh;->b:I

    sget v1, Lq;->ay:I

    if-ge v0, v1, :cond_43

    iput-boolean v3, p0, Lh;->g:Z

    :cond_1d
    :goto_1d
    iget v0, p0, Lh;->b:I

    iget v1, p0, Lr;->h:I

    add-int/2addr v0, v1

    iput v0, p0, Lh;->b:I

    iget v0, p0, Lr;->i:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lr;->i:I

    iget v0, p0, Lr;->i:I

    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x28

    add-int/lit8 v1, v1, 0xa

    if-le v0, v1, :cond_3c

    iput v4, p0, Lr;->i:I

    iget v0, p0, Lr;->h:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lr;->h:I

    :cond_3c
    iget v0, p0, Lh;->c:I

    add-int/lit8 v0, v0, 0x2

    iput v0, p0, Lh;->c:I

    return-void

    :cond_43
    iget v0, p0, Lh;->b:I

    sget v1, Lq;->ay:I

    sget v2, Lq;->ab:I

    add-int/2addr v1, v2

    if-le v0, v1, :cond_4f

    iput-boolean v3, p0, Lh;->g:Z

    goto :goto_1d

    :cond_4f
    iget v0, p0, Lh;->c:I

    sget v1, Lq;->az:I

    sget v2, Lq;->ac:I

    add-int/2addr v1, v2

    if-le v0, v1, :cond_1d

    iput-boolean v3, p0, Lh;->g:Z

    goto :goto_1d
.end method
