.class public final Lk;
.super Ljava/lang/Object;


# instance fields
.field a:I

.field b:I

.field c:I

.field d:I

.field e:I

.field f:I


# direct methods
.method public constructor <init>(III)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x10

    iput v0, p0, Lk;->d:I

    const/16 v0, 0x13

    iput v0, p0, Lk;->e:I

    iput p1, p0, Lk;->a:I

    iput p2, p0, Lk;->b:I

    const/4 v0, 0x0

    iput v0, p0, Lk;->c:I

    iput p3, p0, Lk;->f:I

    iget v0, p0, Lk;->f:I

    if-nez v0, :cond_3a

    sget-object v0, Lt;->o:Ljava/util/Vector;

    new-instance v1, Lk;

    iget v2, p0, Lk;->a:I

    iget v3, p0, Lk;->b:I

    add-int/lit8 v3, v3, -0x1

    const/4 v4, -0x1

    invoke-direct {v1, v2, v3, v4}, Lk;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    sget-object v0, Lt;->o:Ljava/util/Vector;

    new-instance v1, Lk;

    iget v2, p0, Lk;->a:I

    iget v3, p0, Lk;->b:I

    add-int/lit8 v3, v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1, v2, v3, v4}, Lk;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :cond_3a
    return-void
.end method
