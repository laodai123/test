.class public final La;
.super Ljava/lang/Object;


# static fields
.field private static A:[I

.field private static B:[I

.field private static C:[I

.field private static D:[I

.field private static E:[I

.field private static F:[I

.field private static G:[I

.field private static H:[I

.field private static I:[I

.field private static J:[I

.field private static K:[Z

.field private static L:[[I

.field private static M:[[I

.field private static N:[[Z

.field private static O:[I

.field public static final a:[I

.field public static b:Z

.field public static c:I

.field public static d:[I

.field public static e:[I

.field public static f:[I

.field public static g:[I

.field public static h:[I

.field public static i:[I

.field public static j:[I

.field public static k:[I

.field public static l:[I

.field public static m:[I

.field private static n:[Ljava/lang/String;

.field private static o:[I

.field private static p:[I

.field private static q:[I

.field private static r:[[[Ljavax/microedition/lcdui/Image;

.field private static s:I

.field private static t:[I

.field private static u:[I

.field private static v:[I

.field private static w:[I

.field private static x:[I

.field private static y:[I

.field private static z:[I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    const/16 v7, 0xa

    const/4 v6, 0x5

    const/16 v5, 0x1e

    const/16 v4, 0x14

    const/16 v3, 0xc8

    const/16 v0, 0x1d

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "Nhím nâu"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "Thỏ trắng"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "Cóc vàng"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "Bọ cánh cứng"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "Lật đật"

    aput-object v2, v0, v1

    const-string v1, "ốc ma đen"

    aput-object v1, v0, v6

    const/4 v1, 0x6

    const-string v2, "Bò cạp"

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const-string v2, "Bọ xít"

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const-string v2, "Khỉ lông nâu"

    aput-object v2, v0, v1

    const/16 v1, 0x9

    const-string v2, "Bù nhìn"

    aput-object v2, v0, v1

    const-string v1, "Cào cào"

    aput-object v1, v0, v7

    const/16 v1, 0xb

    const-string v2, "Ninja gió"

    aput-object v2, v0, v1

    const/16 v1, 0xc

    const-string v2, "Ốc bưu vàng"

    aput-object v2, v0, v1

    const/16 v1, 0xd

    const-string v2, "Dơi"

    aput-object v2, v0, v1

    const/16 v1, 0xe

    const-string v2, "Ma xương"

    aput-object v2, v0, v1

    const/16 v1, 0xf

    const-string v2, "Rùa"

    aput-object v2, v0, v1

    const/16 v1, 0x10

    const-string v2, "Cua"

    aput-object v2, v0, v1

    const/16 v1, 0x11

    const-string v2, "Ốc mượn hồn"

    aput-object v2, v0, v1

    const/16 v1, 0x12

    const-string v2, "Ma dù"

    aput-object v2, v0, v1

    const/16 v1, 0x13

    const-string v2, "Mực nhảy"

    aput-object v2, v0, v1

    const-string v1, "Cá nhám xanh"

    aput-object v1, v0, v4

    const/16 v1, 0x15

    const-string v2, "Rắn cạp nong"

    aput-object v2, v0, v1

    const/16 v1, 0x16

    const-string v2, "Heo rừng"

    aput-object v2, v0, v1

    const/16 v1, 0x17

    const-string v2, "Hồn ma"

    aput-object v2, v0, v1

    const/16 v1, 0x18

    const-string v2, "Hồn ma"

    aput-object v2, v0, v1

    const/16 v1, 0x19

    const-string v2, "Quỷ đầu lâu"

    aput-object v2, v0, v1

    const/16 v1, 0x1a

    const-string v2, "Rùa già"

    aput-object v2, v0, v1

    const/16 v1, 0x1b

    const-string v2, "Bọ núi"

    aput-object v2, v0, v1

    const/16 v1, 0x1c

    const-string v2, "Ốc tiền sử"

    aput-object v2, v0, v1

    sput-object v0, La;->n:[Ljava/lang/String;

    const/16 v0, 0x20

    new-array v0, v0, [I

    fill-array-data v0, :array_162

    sput-object v0, La;->o:[I

    const/16 v0, 0x22

    new-array v0, v0, [I

    const/4 v1, 0x0

    const/16 v2, 0xf

    aput v2, v0, v1

    const/4 v1, 0x2

    aput v5, v0, v1

    const/4 v1, 0x3

    aput v4, v0, v1

    const/4 v1, 0x4

    const/16 v2, 0x32

    aput v2, v0, v1

    const/16 v1, 0x19

    aput v1, v0, v6

    const/4 v1, 0x6

    aput v6, v0, v1

    const/4 v1, 0x7

    aput v7, v0, v1

    const/16 v1, 0x8

    aput v4, v0, v1

    const/16 v1, 0x9

    const/16 v2, 0x28

    aput v2, v0, v1

    aput v5, v0, v7

    const/16 v1, 0xb

    const/16 v2, 0x28

    aput v2, v0, v1

    const/16 v1, 0xc

    const/16 v2, 0x82

    aput v2, v0, v1

    const/16 v1, 0xd

    aput v5, v0, v1

    const/16 v1, 0xe

    const/16 v2, 0x28

    aput v2, v0, v1

    const/16 v1, 0xf

    const/16 v2, 0x64

    aput v2, v0, v1

    const/16 v1, 0x10

    const/16 v2, 0x3c

    aput v2, v0, v1

    const/16 v1, 0x11

    const/16 v2, 0xa0

    aput v2, v0, v1

    const/16 v1, 0x12

    const/16 v2, 0x78

    aput v2, v0, v1

    const/16 v1, 0x13

    aput v3, v0, v1

    aput v3, v0, v4

    const/16 v1, 0x15

    aput v3, v0, v1

    const/16 v1, 0x16

    aput v3, v0, v1

    const/16 v1, 0x17

    aput v3, v0, v1

    const/16 v1, 0x18

    aput v3, v0, v1

    const/16 v1, 0x19

    aput v3, v0, v1

    const/16 v1, 0x1a

    aput v3, v0, v1

    const/16 v1, 0x1b

    aput v3, v0, v1

    const/16 v1, 0x1c

    aput v3, v0, v1

    const/16 v1, 0x1d

    aput v3, v0, v1

    aput v3, v0, v5

    const/16 v1, 0x1f

    aput v3, v0, v1

    const/16 v1, 0x20

    aput v3, v0, v1

    const/16 v1, 0x21

    aput v3, v0, v1

    sput-object v0, La;->a:[I

    const/16 v0, 0x22

    new-array v0, v0, [I

    fill-array-data v0, :array_1a6

    sput-object v0, La;->p:[I

    const/16 v0, 0x22

    new-array v0, v0, [I

    fill-array-data v0, :array_1ee

    sput-object v0, La;->q:[I

    const/4 v0, 0x0

    sput-object v0, La;->O:[I

    return-void

    nop

    :array_162
    .array-data 4
        0x64
        0x64
        0xc8
        0xc8
        0x190
        0x96
        0x3c
        0x1f4
        0xfa
        0x190
        0x258
        0x1f4
        0x258
        0x320
        0x384
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x1388
        0x7d0
        0x7d0
        0x7d0
        0x7d0
        0x7d0
    .end array-data

    :array_1a6
    .array-data 4
        0x23
        0x5
        0x28
        0x28
        0x2d
        0x32
        0x1e
        0x82
        0x3c
        0x41
        0x46
        0x4b
        0x78
        0x55
        0x64
        0x78
        0x8c
        0xa0
        0x78
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
    .end array-data

    :array_1ee
    .array-data 4
        0x14
        0x1
        0x1e
        0x19
        0x28
        0x28
        0xf
        0x32
        0x3c
        0x46
        0x50
        0x64
        0x78
        0x82
        0xa0
        0xaa
        0xd2
        0xbe
        0xdc
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
        0xc8
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, La;->r:[[[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method public static final a(I)V
    .registers 12

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v1, 0x0

    sput v1, La;->c:I

    sparse-switch p0, :sswitch_data_d4c

    :cond_a
    :goto_a
    sget v0, La;->c:I

    if-lez v0, :cond_26

    sget-object v0, La;->O:[I

    array-length v0, v0

    const/4 v2, 0x4

    filled-new-array {v0, v8, v2}, [I

    move-result-object v0

    const-class v2, Ljavax/microedition/lcdui/Image;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[[Ljavax/microedition/lcdui/Image;

    sput-object v0, La;->r:[[[Ljavax/microedition/lcdui/Image;

    move v0, v1

    :goto_21
    sget-object v2, La;->O:[I

    array-length v2, v2

    if-lt v0, v2, :cond_cd4

    :cond_26
    return-void

    :sswitch_27
    new-array v0, v7, [I

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_db2

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_dc6

    aput-object v2, v0, v1

    invoke-static {}, La;->d()V

    const/16 v0, 0x8

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0x8

    invoke-static {v1, v0}, La;->m(II)V

    goto :goto_a

    :sswitch_52
    new-array v0, v8, [I

    aput v7, v0, v7

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xe

    new-array v2, v2, [I

    fill-array-data v2, :array_dda

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xe

    new-array v2, v2, [I

    fill-array-data v2, :array_dfa

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_e1a

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_e22

    aput-object v2, v0, v7

    invoke-static {}, La;->d()V

    const/16 v0, 0xd

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0x9

    invoke-static {v1, v0}, La;->m(II)V

    const/4 v0, 0x4

    invoke-static {v7, v0}, La;->h(II)V

    goto/16 :goto_a

    :sswitch_96
    new-array v0, v9, [I

    aput v7, v0, v7

    aput v8, v0, v8

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_e2a

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_e34

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_e3e

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_e54

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_e6a

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_e7e

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x10

    invoke-static {v0}, La;->e(I)V

    invoke-static {v1, v8}, La;->m(II)V

    const/16 v0, 0x8

    invoke-static {v7, v0}, La;->h(II)V

    invoke-static {v8, v9}, La;->b(II)V

    goto/16 :goto_a

    :sswitch_f4
    new-array v0, v7, [I

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xe

    new-array v2, v2, [I

    fill-array-data v2, :array_e92

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xe

    new-array v2, v2, [I

    fill-array-data v2, :array_eb2

    aput-object v2, v0, v1

    invoke-static {}, La;->d()V

    invoke-static {v9}, La;->e(I)V

    invoke-static {v1, v9}, La;->m(II)V

    goto/16 :goto_a

    :sswitch_11c
    new-array v0, v9, [I

    fill-array-data v0, :array_ed2

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_edc

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_ee6

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_ef0

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_ef8

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_f00

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_f12

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x10

    invoke-static {v0}, La;->e(I)V

    invoke-static {v1, v9}, La;->h(II)V

    invoke-static {v7, v8}, La;->b(II)V

    invoke-static {v8, v10}, La;->j(II)V

    goto/16 :goto_a

    :sswitch_16f
    new-array v0, v9, [I

    aput v9, v0, v7

    const/4 v2, 0x4

    aput v2, v0, v8

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_f24

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v9, [I

    fill-array-data v2, :array_f2e

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_f38

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_f46

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_f54

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_f6c

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x11

    invoke-static {v0}, La;->e(I)V

    invoke-static {v1, v9}, La;->m(II)V

    const/4 v0, 0x5

    invoke-static {v7, v0}, La;->j(II)V

    move v0, v1

    :goto_1c7
    sget v2, La;->c:I

    if-lt v0, v2, :cond_233

    :cond_1cb
    sget v2, La;->c:I

    if-eq v0, v2, :cond_a

    move v2, v0

    :goto_1d0
    add-int/lit8 v3, v0, 0x9

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v8, v3, v2

    sget-object v3, La;->d:[I

    const/4 v4, 0x4

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x20

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x16

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    aput v7, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x3

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    aput v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1d0

    :cond_233
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_1cb

    add-int/lit8 v0, v0, 0x1

    goto :goto_1c7

    :sswitch_23d
    new-array v0, v9, [I

    fill-array-data v0, :array_f84

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xe

    new-array v2, v2, [I

    fill-array-data v2, :array_f8e

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xe

    new-array v2, v2, [I

    fill-array-data v2, :array_fae

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_fce

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_fdc

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_fea

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_1002

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x19

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0xc

    invoke-static {v1, v0}, La;->q(II)V

    move v0, v1

    :goto_295
    sget v2, La;->c:I

    if-lt v0, v2, :cond_2a9

    :cond_299
    sget v2, La;->c:I

    if-eq v0, v2, :cond_2a2

    move v2, v0

    :goto_29e
    add-int/lit8 v3, v0, 0x5

    if-lt v2, v3, :cond_2b3

    :cond_2a2
    const/16 v0, 0x8

    invoke-static {v8, v0}, La;->o(II)V

    goto/16 :goto_a

    :cond_2a9
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_299

    add-int/lit8 v0, v0, 0x1

    goto :goto_295

    :cond_2b3
    sget-object v3, La;->J:[I

    aput v7, v3, v2

    sget-object v3, La;->d:[I

    aput v10, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    add-int/lit8 v4, v2, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    aput v8, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_29e

    :sswitch_31c
    new-array v0, v8, [I

    fill-array-data v0, :array_101a

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_1022

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_1034

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_1046

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1054

    aput-object v2, v0, v7

    invoke-static {}, La;->d()V

    invoke-static {v9}, La;->e(I)V

    invoke-static {v1, v7}, La;->o(II)V

    invoke-static {v7, v8}, La;->q(II)V

    goto/16 :goto_a

    :sswitch_35a
    new-array v0, v8, [I

    fill-array-data v0, :array_1064

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_106c

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_107e

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1090

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_10a0

    aput-object v2, v0, v7

    invoke-static {}, La;->d()V

    const/16 v0, 0xc

    invoke-static {v0}, La;->e(I)V

    invoke-static {v1, v10}, La;->o(II)V

    const/4 v0, 0x5

    invoke-static {v7, v0}, La;->j(II)V

    goto/16 :goto_a

    :sswitch_39b
    new-array v0, v8, [I

    fill-array-data v0, :array_10b0

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_10b8

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_10dc

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1100

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_1110

    aput-object v2, v0, v7

    invoke-static {}, La;->d()V

    const/16 v0, 0x11

    invoke-static {v0}, La;->e(I)V

    move v0, v1

    :goto_3d8
    sget v2, La;->c:I

    if-lt v0, v2, :cond_3eb

    :cond_3dc
    sget v2, La;->c:I

    if-eq v0, v2, :cond_3e5

    move v2, v0

    :goto_3e1
    add-int/lit8 v3, v0, 0xd

    if-lt v2, v3, :cond_3f5

    :cond_3e5
    const/4 v0, 0x4

    invoke-static {v7, v0}, La;->d(II)V

    goto/16 :goto_a

    :cond_3eb
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_3dc

    add-int/lit8 v0, v0, 0x1

    goto :goto_3d8

    :cond_3f5
    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x8

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->f:[I

    aget v4, v3, v2

    add-int/lit8 v4, v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    aput v7, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    mul-int/lit8 v4, v2, 0x5

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x3c

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_3e1

    :sswitch_45f
    new-array v0, v9, [I

    fill-array-data v0, :array_1120

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_112a

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_1148

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_1166

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_117e

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_1196

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_11ae

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x1c

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0xc

    invoke-static {v1, v0}, La;->d(II)V

    const/16 v0, 0x8

    invoke-static {v7, v0}, La;->c(II)V

    const/16 v0, 0x8

    invoke-static {v8, v0}, La;->i(II)V

    goto/16 :goto_a

    :sswitch_4c4
    new-array v0, v9, [I

    fill-array-data v0, :array_11c6

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_11d0

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_11d8

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_11e0

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_11e8

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_11f0

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_11f8

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/4 v0, 0x6

    invoke-static {v0}, La;->e(I)V

    invoke-static {v1, v8}, La;->d(II)V

    invoke-static {v7, v8}, La;->c(II)V

    invoke-static {v8, v8}, La;->i(II)V

    goto/16 :goto_a

    :sswitch_516
    new-array v0, v7, [I

    const/16 v2, 0xc

    aput v2, v0, v1

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_1200

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_1216

    aput-object v2, v0, v1

    invoke-static {}, La;->d()V

    const/16 v0, 0x8

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0x8

    invoke-static {v1, v0}, La;->p(II)V

    goto/16 :goto_a

    :sswitch_546
    new-array v0, v7, [I

    const/16 v2, 0xc

    aput v2, v0, v1

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_122c

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_123e

    aput-object v2, v0, v1

    invoke-static {}, La;->d()V

    const/4 v0, 0x5

    invoke-static {v0}, La;->e(I)V

    const/4 v0, 0x5

    invoke-static {v1, v0}, La;->p(II)V

    goto/16 :goto_a

    :sswitch_570
    new-array v0, v8, [I

    fill-array-data v0, :array_1250

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1258

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1272

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/16 v2, 0x16

    new-array v2, v2, [I

    fill-array-data v2, :array_128c

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/16 v2, 0x16

    new-array v2, v2, [I

    fill-array-data v2, :array_12bc

    aput-object v2, v0, v7

    invoke-static {}, La;->d()V

    const/16 v0, 0x1e

    invoke-static {v0}, La;->e(I)V

    move v0, v1

    :goto_5af
    sget v2, La;->c:I

    if-lt v0, v2, :cond_62c

    :cond_5b3
    sget v2, La;->c:I

    if-eq v0, v2, :cond_5bc

    move v2, v0

    :goto_5b8
    add-int/lit8 v3, v0, 0xa

    if-lt v2, v3, :cond_637

    :cond_5bc
    move v0, v1

    :goto_5bd
    sget v2, La;->c:I

    if-lt v0, v2, :cond_6a4

    :cond_5c1
    sget v2, La;->c:I

    if-eq v0, v2, :cond_a

    move v2, v0

    :goto_5c6
    add-int/lit8 v3, v0, 0x14

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v7, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0xe

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x24

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x20

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    aput v7, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x3

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x1f4

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_5c6

    :cond_62c
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_5b3

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_5af

    :cond_637
    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0xd

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x78

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0x32

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x1

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    const/4 v4, -0x3

    aput v4, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_5b8

    :cond_6a4
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_5c1

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_5bd

    :sswitch_6af
    new-array v0, v9, [I

    fill-array-data v0, :array_12ec

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_12f6

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_1314

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_1332

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v8, [I

    fill-array-data v2, :array_133a

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_1342

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_1356

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x14

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0xc

    invoke-static {v1, v0}, La;->l(II)V

    invoke-static {v7, v8}, La;->f(II)V

    const/4 v0, 0x6

    invoke-static {v8, v0}, La;->d(II)V

    goto/16 :goto_a

    :sswitch_70d
    new-array v0, v8, [I

    fill-array-data v0, :array_136a

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_1372

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    fill-array-data v2, :array_138a

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_13a2

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_13b4

    aput-object v2, v0, v7

    invoke-static {}, La;->d()V

    const/16 v0, 0xc

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0x8

    invoke-static {v1, v0}, La;->f(II)V

    const/4 v0, 0x4

    invoke-static {v7, v0}, La;->e(II)V

    goto/16 :goto_a

    :sswitch_752
    new-array v0, v9, [I

    fill-array-data v0, :array_13c6

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_13d0

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_13e2

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_13f4

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_1406

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_1418

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_142a

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x12

    invoke-static {v0}, La;->e(I)V

    move v0, v1

    :goto_79b
    sget v2, La;->c:I

    if-lt v0, v2, :cond_7b2

    :cond_79f
    sget v2, La;->c:I

    if-eq v0, v2, :cond_7a8

    move v2, v0

    :goto_7a4
    add-int/lit8 v3, v0, 0x6

    if-lt v2, v3, :cond_7bc

    :cond_7a8
    const/4 v0, 0x6

    invoke-static {v7, v0}, La;->e(II)V

    const/4 v0, 0x6

    invoke-static {v8, v0}, La;->n(II)V

    goto/16 :goto_a

    :cond_7b2
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_79f

    add-int/lit8 v0, v0, 0x1

    goto :goto_79b

    :cond_7bc
    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x12

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x24

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x20

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x12

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    aput v7, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    const/16 v4, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_7a4

    :sswitch_81e
    new-array v0, v7, [I

    const/16 v2, 0x14

    aput v2, v0, v1

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_143c

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_144c

    aput-object v2, v0, v1

    invoke-static {}, La;->d()V

    invoke-static {v8}, La;->e(I)V

    invoke-static {v1, v8}, La;->a(II)V

    goto/16 :goto_a

    :sswitch_848
    new-array v0, v9, [I

    fill-array-data v0, :array_145c

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1466

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1480

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_149a

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v10, [I

    fill-array-data v2, :array_14ac

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_14be

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_14d4

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x17

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0x9

    invoke-static {v1, v0}, La;->l(II)V

    const/4 v0, 0x6

    invoke-static {v7, v0}, La;->n(II)V

    const/16 v0, 0x8

    invoke-static {v8, v0}, La;->a(II)V

    goto/16 :goto_a

    :sswitch_8a8
    new-array v0, v9, [I

    fill-array-data v0, :array_14ea

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_14f4

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x9

    new-array v2, v2, [I

    fill-array-data v2, :array_150a

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1520

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_153a

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1554

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_156e

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x19

    invoke-static {v0}, La;->e(I)V

    invoke-static {v1, v10}, La;->l(II)V

    const/16 v0, 0x9

    invoke-static {v7, v0}, La;->n(II)V

    const/16 v0, 0x9

    invoke-static {v8, v0}, La;->a(II)V

    goto/16 :goto_a

    :sswitch_90b
    new-array v0, v9, [I

    fill-array-data v0, :array_1588

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x16

    new-array v2, v2, [I

    fill-array-data v2, :array_1592

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x16

    new-array v2, v2, [I

    fill-array-data v2, :array_15c2

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/16 v2, 0x16

    new-array v2, v2, [I

    fill-array-data v2, :array_15f2

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/16 v2, 0x16

    new-array v2, v2, [I

    fill-array-data v2, :array_1622

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_1652

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_166c

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x32

    invoke-static {v0}, La;->e(I)V

    move v0, v1

    :goto_960
    sget v2, La;->c:I

    if-lt v0, v2, :cond_9f4

    :cond_964
    sget v2, La;->c:I

    if-eq v0, v2, :cond_96d

    move v2, v0

    :goto_969
    add-int/lit8 v3, v0, 0x14

    if-lt v2, v3, :cond_9ff

    :cond_96d
    move v0, v1

    :goto_96e
    sget v2, La;->c:I

    if-lt v0, v2, :cond_a71

    :cond_972
    sget v2, La;->c:I

    if-eq v0, v2, :cond_97b

    move v2, v0

    :goto_977
    add-int/lit8 v3, v0, 0x14

    if-lt v2, v3, :cond_a7c

    :cond_97b
    move v0, v1

    :goto_97c
    sget v2, La;->c:I

    if-lt v0, v2, :cond_ae8

    :cond_980
    sget v2, La;->c:I

    if-eq v0, v2, :cond_a

    move v2, v0

    :goto_985
    add-int/lit8 v3, v0, 0xa

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v8, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x19

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x96

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0x50

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    add-int/lit8 v4, v2, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    aput v8, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_985

    :cond_9f4
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_964

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_960

    :cond_9ff
    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x17

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x28

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x16

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    add-int/lit8 v4, v2, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->A:[I

    add-int/lit8 v4, v2, 0x14

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    aput v8, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_969

    :cond_a71
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_972

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_96e

    :cond_a7c
    sget-object v3, La;->J:[I

    aput v7, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x1e

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    add-int/lit8 v4, v2, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    aput v8, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_977

    :cond_ae8
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_980

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_97c

    :sswitch_af3
    new-array v0, v9, [I

    fill-array-data v0, :array_1686

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_1690

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_16a4

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    new-array v2, v7, [I

    const/16 v3, 0x5b

    aput v3, v2, v1

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    new-array v2, v7, [I

    const/16 v3, 0x8

    aput v3, v2, v1

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_16b8

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xb

    new-array v2, v2, [I

    fill-array-data v2, :array_16d2

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x11

    invoke-static {v0}, La;->e(I)V

    const/4 v0, 0x6

    invoke-static {v1, v0}, La;->l(II)V

    invoke-static {v7, v7}, La;->g(II)V

    move v0, v1

    :goto_b4d
    sget v2, La;->c:I

    if-lt v0, v2, :cond_bc5

    :cond_b51
    sget v2, La;->c:I

    if-eq v0, v2, :cond_a

    move v2, v0

    :goto_b56
    add-int/lit8 v3, v0, 0xa

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v8, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x1a

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    add-int/lit8 v4, v2, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    aput v8, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_b56

    :cond_bc5
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_b51

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_b4d

    :sswitch_bd0
    new-array v0, v9, [I

    fill-array-data v0, :array_16ec

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_16f6

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_171a

    aput-object v2, v0, v1

    sget-object v0, La;->L:[[I

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_173e

    aput-object v2, v0, v7

    sget-object v0, La;->M:[[I

    const/16 v2, 0xd

    new-array v2, v2, [I

    fill-array-data v2, :array_175c

    aput-object v2, v0, v7

    sget-object v0, La;->L:[[I

    const/16 v2, 0xc

    new-array v2, v2, [I

    fill-array-data v2, :array_177a

    aput-object v2, v0, v8

    sget-object v0, La;->M:[[I

    const/16 v2, 0xc

    new-array v2, v2, [I

    fill-array-data v2, :array_1796

    aput-object v2, v0, v8

    invoke-static {}, La;->d()V

    const/16 v0, 0x1c

    invoke-static {v0}, La;->e(I)V

    const/16 v0, 0xa

    invoke-static {v1, v0}, La;->g(II)V

    const/16 v0, 0x8

    invoke-static {v7, v0}, La;->k(II)V

    move v0, v1

    :goto_c2f
    sget v2, La;->c:I

    if-lt v0, v2, :cond_ca7

    :cond_c33
    sget v2, La;->c:I

    if-eq v0, v2, :cond_a

    move v2, v0

    :goto_c38
    add-int/lit8 v3, v0, 0xa

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v8, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x1c

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x18

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, -0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    add-int/lit8 v4, v2, 0x3c

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->w:[I

    aput v8, v3, v2

    sget-object v3, La;->x:[I

    aput v9, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_c38

    :cond_ca7
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_c33

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_c2f

    :sswitch_cb2
    new-array v0, v7, [I

    const/16 v2, 0x1b

    aput v2, v0, v1

    sput-object v0, La;->O:[I

    invoke-static {}, La;->c()V

    sget-object v0, La;->L:[[I

    new-array v2, v1, [I

    aput-object v2, v0, v1

    sget-object v0, La;->M:[[I

    new-array v2, v1, [I

    aput-object v2, v0, v1

    invoke-static {}, La;->d()V

    invoke-static {v1}, La;->e(I)V

    invoke-static {v1, v1}, La;->k(II)V

    goto/16 :goto_a

    :cond_cd4
    move v3, v1

    :goto_cd5
    if-lt v3, v8, :cond_cdb

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_21

    :cond_cdb
    move v2, v1

    :goto_cdc
    const/4 v4, 0x4

    if-lt v2, v4, :cond_cfd

    sget-object v2, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v0

    aget-object v2, v2, v3

    aget-object v2, v2, v8

    if-nez v2, :cond_cf9

    sget-object v2, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v2, v2, v0

    aget-object v2, v2, v3

    sget-object v4, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    aget-object v4, v4, v7

    aput-object v4, v2, v8

    :cond_cf9
    add-int/lit8 v2, v3, 0x1

    move v3, v2

    goto :goto_cd5

    :cond_cfd
    :try_start_cfd
    sget-object v4, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "/mob/m"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v6, La;->O:[I

    aget v6, v6, v0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v5

    const-string v6, ".png"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v5

    aput-object v5, v4, v2
    :try_end_d2a
    .catch Ljava/lang/Exception; {:try_start_cfd .. :try_end_d2a} :catch_d49

    :goto_d2a
    sget-object v4, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    aget-object v4, v4, v2

    if-nez v4, :cond_d46

    if-ne v3, v7, :cond_d46

    sget-object v4, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v0

    aget-object v4, v4, v7

    sget-object v5, La;->r:[[[Ljavax/microedition/lcdui/Image;

    aget-object v5, v5, v0

    aget-object v5, v5, v1

    aget-object v5, v5, v2

    aput-object v5, v4, v2

    :cond_d46
    add-int/lit8 v2, v2, 0x1

    goto :goto_cdc

    :catch_d49
    move-exception v4

    goto :goto_d2a

    nop

    :sswitch_data_d4c
    .sparse-switch
        0x1 -> :sswitch_52
        0x2 -> :sswitch_96
        0x3 -> :sswitch_11c
        0x4 -> :sswitch_16f
        0x5 -> :sswitch_23d
        0x6 -> :sswitch_35a
        0x7 -> :sswitch_39b
        0x8 -> :sswitch_45f
        0x9 -> :sswitch_516
        0xa -> :sswitch_546
        0xb -> :sswitch_570
        0xc -> :sswitch_6af
        0xd -> :sswitch_70d
        0xe -> :sswitch_752
        0xf -> :sswitch_848
        0x10 -> :sswitch_8a8
        0x11 -> :sswitch_90b
        0x12 -> :sswitch_af3
        0x13 -> :sswitch_bd0
        0x14 -> :sswitch_cb2
        0x65 -> :sswitch_31c
        0x66 -> :sswitch_81e
        0x67 -> :sswitch_f4
        0x69 -> :sswitch_27
        0x6a -> :sswitch_4c4
    .end sparse-switch

    :array_db2
    .array-data 4
        0x7
        0xb
        0x11
        0xc
        0x1d
        0x1f
        0x20
        0x21
    .end array-data

    :array_dc6
    .array-data 4
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
    .end array-data

    :array_dda
    .array-data 4
        0x2c
        0x28
        0x2a
        0x27
        0x29
        0x27
        0x22
        0x30
        0x1f
        0x15
        0x8
        0x1a
        0x19
        0x18
    .end array-data

    :array_dfa
    .array-data 4
        0xa
        0xb
        0x9
        0x9
        0x7
        0x5
        0x9
        0x9
        0x7
        0xa
        0x9
        0x6
        0x8
        0xa
    .end array-data

    :array_e1a
    .array-data 4
        0x8
        0x3
    .end array-data

    :array_e22
    .array-data 4
        0x9
        0x9
    .end array-data

    :array_e2a
    .array-data 4
        0xe
        0xf
        0xe
    .end array-data

    :array_e34
    .array-data 4
        0x5
        0xd
        0x21
    .end array-data

    :array_e3e
    .array-data 4
        0xc
        0x6
        0x1
        0x6
        0x7
        0x9
        0x7
        0xe
        0x7
    .end array-data

    :array_e54
    .array-data 4
        0x5
        0x5
        0x5
        0x7
        0x9
        0x9
        0xb
        0xd
        0x12
    .end array-data

    :array_e6a
    .array-data 4
        0x7
        0x4
        0x7
        0xd
        0x9
        0xc
        0x4
        0x9
    .end array-data

    :array_e7e
    .array-data 4
        0x17
        0x1a
        0x1d
        0x1c
        0x20
        0x21
        0x23
        0x24
    .end array-data

    :array_e92
    .array-data 4
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0x9
        0xa
        0xb
        0xc
    .end array-data

    :array_eb2
    .array-data 4
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0x7
        0x7
        0x7
        0x7
    .end array-data

    :array_ed2
    .array-data 4
        0x1
        0x2
        0x3
    .end array-data

    :array_edc
    .array-data 4
        0x44
        0x40
        0x1b
    .end array-data

    :array_ee6
    .array-data 4
        0x13
        0x13
        0x5
    .end array-data

    :array_ef0
    .array-data 4
        0x37
        0x30
    .end array-data

    :array_ef8
    .array-data 4
        0x14
        0x18
    .end array-data

    :array_f00
    .array-data 4
        0x2c
        0x21
        0x17
        0x2
        0x17
        0xc
        0x1b
    .end array-data

    :array_f12
    .array-data 4
        0xd
        0xa
        0x2
        0x1
        0xb
        0x11
        0x15
    .end array-data

    :array_f24
    .array-data 4
        0x1
        0x61
        0x45
    .end array-data

    :array_f2e
    .array-data 4
        0x7
        0x8
        0xb
    .end array-data

    :array_f38
    .array-data 4
        0x6e
        0x6f
        0x6d
        0x6e
        0x6d
    .end array-data

    :array_f46
    .array-data 4
        0x6
        0x6
        0x6
        0x6
        0x6
    .end array-data

    :array_f54
    .array-data 4
        0x68
        0x58
        0x4a
        0x40
        0x22
        0x12
        0x9
        0x3f
        0x41
        0x46
    .end array-data

    :array_f6c
    .array-data 4
        0xa
        0xc
        0xb
        0xc
        0x9
        0x9
        0x9
        0xc
        0xc
        0xb
    .end array-data

    :array_f84
    .array-data 4
        0x5
        0x7
        0x6
    .end array-data

    :array_f8e
    .array-data 4
        0x14
        0xc
        0xe
        0x9
        0x7
        0x8
        0x7
        0x9
        0x8
        0x8
        0xd
        0xa
        0x7
        0x1b
    .end array-data

    :array_fae
    .array-data 4
        0x4d
        0x4c
        0x48
        0x45
        0x41
        0x41
        0x3c
        0x3c
        0x38
        0x30
        0x2c
        0x27
        0x1e
        0x18
    .end array-data

    :array_fce
    .array-data 4
        0x6
        0x7
        0x6
        0x4
        0x4
    .end array-data

    :array_fdc
    .array-data 4
        0x36
        0x32
        0x2c
        0x21
        0x12
    .end array-data

    :array_fea
    .array-data 4
        0x12
        0xf
        0x17
        0xc
        0xe
        0x4
        0x7
        0xd
        0x14
        0x19
    .end array-data

    :array_1002
    .array-data 4
        0x36
        0x23
        0x1d
        0x16
        0x16
        0x16
        0x9
        0x8
        0x7
        0x4
    .end array-data

    :array_101a
    .array-data 4
        0x6
        0x5
    .end array-data

    :array_1022
    .array-data 4
        0x4
        0x6
        0x8
        0xa
        0xc
        0xe
        0x10
    .end array-data

    :array_1034
    .array-data 4
        0xb
        0xb
        0xb
        0xb
        0xb
        0xb
        0xb
    .end array-data

    :array_1046
    .array-data 4
        0x5
        0x7
        0x9
        0xd
        0xf
    .end array-data

    :array_1054
    .array-data 4
        0xb
        0xb
        0xb
        0xb
        0xb
        0xb
    .end array-data

    :array_1064
    .array-data 4
        0x6
        0x3
    .end array-data

    :array_106c
    .array-data 4
        0x8
        0xa
        0xe
        0xf
        0x14
        0x13
        0x21
    .end array-data

    :array_107e
    .array-data 4
        0xd
        0xd
        0xc
        0xa
        0xb
        0x8
        0x4
    .end array-data

    :array_1090
    .array-data 4
        0x30
        0x32
        0x3b
        0x3d
        0x43
        0x45
    .end array-data

    :array_10a0
    .array-data 4
        0x8
        0x9
        0xb
        0xd
        0xe
        0xf
    .end array-data

    :array_10b0
    .array-data 4
        0x8
        0xa
    .end array-data

    :array_10b8
    .array-data 4
        0x6
        0x7
        0xc
        0xe
        0x1e
        0x21
        0x1f
        0x25
        0x26
        0x24
        0x28
        0x2a
        0x2c
        0x49
        0x4b
        0x4d
    .end array-data

    :array_10dc
    .array-data 4
        0xa
        0xa
        0x9
        0x8
        0xa
        0xa
        0x9
        0x9
        0x9
        0x6
        0x8
        0x8
        0x7
        0xa
        0xa
        0xa
    .end array-data

    :array_1100
    .array-data 4
        0x59
        0x5a
        0x5b
        0x61
        0x3b
        0x3e
    .end array-data

    :array_1110
    .array-data 4
        0x9
        0x9
        0x9
        0xb
        0x4
        0x5
    .end array-data

    :array_1120
    .array-data 4
        0xa
        0x9
        0xb
    .end array-data

    :array_112a
    .array-data 4
        0x4
        0x5
        0x1b
        0x1c
        0x34
        0x36
        0x3a
        0x49
        0x4a
        0x78
        0x79
        0x7a
        0x90
    .end array-data

    :array_1148
    .array-data 4
        0xa
        0xa
        0x9
        0x9
        0xa
        0xb
        0xa
        0x9
        0x8
        0x9
        0x8
        0x9
        0xa
    .end array-data

    :array_1166
    .array-data 4
        0xe
        0x12
        0x23
        0x28
        0x30
        0x40
        0x48
        0x62
        0x70
        0x81
    .end array-data

    :array_117e
    .array-data 4
        0xa
        0xa
        0xb
        0xb
        0xb
        0xa
        0x9
        0x9
        0xa
        0x8
    .end array-data

    :array_1196
    .array-data 4
        0xe
        0x12
        0x23
        0x28
        0x30
        0x40
        0x48
        0x62
        0x70
        0x81
    .end array-data

    :array_11ae
    .array-data 4
        0xa
        0xa
        0xb
        0xb
        0xb
        0xa
        0x9
        0x9
        0xa
        0x8
    .end array-data

    :array_11c6
    .array-data 4
        0xa
        0x9
        0xb
    .end array-data

    :array_11d0
    .array-data 4
        0xb
        0xd
    .end array-data

    :array_11d8
    .array-data 4
        0xa
        0x8
    .end array-data

    :array_11e0
    .array-data 4
        0x15
        0x1b
    .end array-data

    :array_11e8
    .array-data 4
        0xa
        0x9
    .end array-data

    :array_11f0
    .array-data 4
        0x15
        0x1b
    .end array-data

    :array_11f8
    .array-data 4
        0xa
        0x9
    .end array-data

    :array_1200
    .array-data 4
        0x8
        0xa
        0x5
        0x8
        0xa
        0xc
        0x18
        0x71
        0x74
    .end array-data

    :array_1216
    .array-data 4
        0x13
        0x13
        0x10
        0xe
        0x6
        0x6
        0x11
        0x10
        0x10
    .end array-data

    :array_122c
    .array-data 4
        0x2
        0x3
        0x7
        0x8
        0x9
        0xa
        0x25
    .end array-data

    :array_123e
    .array-data 4
        0xc
        0xc
        0xb
        0xb
        0xa
        0xa
        0x8
    .end array-data

    :array_1250
    .array-data 4
        0xd
        0xe
    .end array-data

    :array_1258
    .array-data 4
        0x9
        0x1d
        0x15
        0x1a
        0x9
        0x10
        0x1d
        0xe
        0x2d
        0x2d
        0x38
    .end array-data

    :array_1272
    .array-data 4
        0x1d
        0x1b
        0x18
        0x11
        0x12
        0x7
        0x8
        0x1
        0x12
        0x24
        0x2
    .end array-data

    :array_128c
    .array-data 4
        0x10
        0xd
        0x9
        0x19
        0x1e
        0x24
        0x13
        0x23
        0x22
        0x19
        0x8
        0xa
        0x10
        0xf
        0x28
        0x29
        0x2c
        0x2d
        0x2e
        0x2e
        0x36
        0x3a
    .end array-data

    :array_12bc
    .array-data 4
        0x23
        0x1f
        0x1b
        0x1b
        0x1e
        0x26
        0x1b
        0x17
        0xe
        0x14
        0x15
        0xe
        0xa
        0x3
        0x5
        0x5
        0x10
        0x15
        0x15
        0x27
        0x10
        0xc
    .end array-data

    :array_12ec
    .array-data 4
        0xf
        0x10
        0xa
    .end array-data

    :array_12f6
    .array-data 4
        0xc
        0x15
        0x1a
        0x32
        0x36
        0x3b
        0x40
        0x45
        0x4a
        0x52
        0x54
        0x52
        0x5b
    .end array-data

    :array_1314
    .array-data 4
        0x9
        0xc
        0xc
        0x6
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xd
        0xd
        0xb
    .end array-data

    :array_1332
    .array-data 4
        0x6b
        0x6e
    .end array-data

    :array_133a
    .array-data 4
        0xb
        0xb
    .end array-data

    :array_1342
    .array-data 4
        0x8
        0xa
        0x17
        0x18
        0x21
        0x23
        0x60
        0x64
    .end array-data

    :array_1356
    .array-data 4
        0x8
        0x6
        0x7
        0x7
        0x6
        0x5
        0x5
        0x8
    .end array-data

    :array_136a
    .array-data 4
        0x10
        0x11
    .end array-data

    :array_1372
    .array-data 4
        0xe
        0xf
        0x18
        0x1c
        0x32
        0x35
        0x45
        0x46
        0x49
        0x4b
    .end array-data

    :array_138a
    .array-data 4
        0xb
        0xb
        0xb
        0xb
        0xb
        0xb
        0xb
        0xb
        0x6
        0x6
    .end array-data

    :array_13a2
    .array-data 4
        0x28
        0x54
        0x56
        0x59
        0x5d
        0x53
        0x54
    .end array-data

    :array_13b4
    .array-data 4
        0x9
        0xb
        0xb
        0xb
        0xb
        0x4
        0x4
    .end array-data

    :array_13c6
    .array-data 4
        0x12
        0x11
        0x13
    .end array-data

    :array_13d0
    .array-data 4
        0x1a
        0x3d
        0x41
        0x40
        0x4a
        0x58
        0x66
    .end array-data

    :array_13e2
    .array-data 4
        0xd
        0x9
        0x9
        0xf
        0xc
        0xe
        0x10
    .end array-data

    :array_13f4
    .array-data 4
        0x7
        0x8
        0xa
        0x2f
        0x32
        0x34
        0x4a
    .end array-data

    :array_1406
    .array-data 4
        0x10
        0x10
        0x10
        0xc
        0xc
        0xc
        0x10
    .end array-data

    :array_1418
    .array-data 4
        0xd
        0x31
        0x37
        0x47
        0x4d
        0x53
        0x62
    .end array-data

    :array_142a
    .array-data 4
        0x13
        0x13
        0x13
        0x13
        0x13
        0x13
        0x13
    .end array-data

    :array_143c
    .array-data 4
        0x7
        0x9
        0xb
        0xd
        0xf
        0x11
    .end array-data

    :array_144c
    .array-data 4
        0xc
        0xc
        0xc
        0xc
        0xc
        0xc
    .end array-data

    :array_145c
    .array-data 4
        0xf
        0x13
        0x14
    .end array-data

    :array_1466
    .array-data 4
        0x7
        0x9
        0xf
        0x17
        0x1a
        0x24
        0x32
        0x84
        0x87
        0x8d
        0x8f
    .end array-data

    :array_1480
    .array-data 4
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0x8
        0x8
    .end array-data

    :array_149a
    .array-data 4
        0x11
        0x28
        0x2a
        0x38
        0x3e
        0x51
        0x53
    .end array-data

    :array_14ac
    .array-data 4
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
    .end array-data

    :array_14be
    .array-data 4
        0x18
        0x58
        0x5a
        0x5e
        0x62
        0x66
        0x68
        0x78
        0x7d
    .end array-data

    :array_14d4
    .array-data 4
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
    .end array-data

    :array_14ea
    .array-data 4
        0x15
        0x13
        0x14
    .end array-data

    :array_14f4
    .array-data 4
        0x4
        0x8
        0x9
        0xc
        0xe
        0xf
        0x10
        0x15
        0x13
    .end array-data

    :array_150a
    .array-data 4
        0xa
        0xc
        0xc
        0xa
        0xb
        0x9
        0x8
        0x7
        0x2
    .end array-data

    :array_1520
    .array-data 4
        0x1b
        0x1d
        0x21
        0x28
        0x2e
        0x34
        0x42
        0x4b
        0x53
        0x55
        0x5a
    .end array-data

    :array_153a
    .array-data 4
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
    .end array-data

    :array_1554
    .array-data 4
        0x1c
        0x1e
        0x20
        0x29
        0x2f
        0x35
        0x44
        0x4c
        0x52
        0x56
        0x5b
    .end array-data

    :array_156e
    .array-data 4
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
        0xd
    .end array-data

    :array_1588
    .array-data 4
        0x17
        0x18
        0x19
    .end array-data

    :array_1592
    .array-data 4
        0xd
        0x25
        0x3d
        0x46
        0x36
        0x1e
        0x7
        0x3d
        0x15
        0xf
        0x25
        0x35
        0x43
        0x7
        0x4
        0x14
        0x24
        0x36
        0x44
        0x1d
        0x2d
        0x3d
    .end array-data

    :array_15c2
    .array-data 4
        0x1c
        0x1c
        0x1c
        0x17
        0x17
        0x17
        0x17
        0x12
        0x12
        0x12
        0xd
        0xd
        0xd
        0xd
        0x8
        0x8
        0x8
        0x8
        0x8
        0x4
        0x4
        0x4
    .end array-data

    :array_15f2
    .array-data 4
        0xd
        0x25
        0x3d
        0x46
        0x36
        0x1e
        0x7
        0x3d
        0x15
        0xf
        0x25
        0x35
        0x43
        0x7
        0x4
        0x14
        0x24
        0x36
        0x44
        0x1d
        0x2d
        0x3d
    .end array-data

    :array_1622
    .array-data 4
        0x1c
        0x1c
        0x1c
        0x17
        0x17
        0x17
        0x17
        0x12
        0x12
        0x12
        0xd
        0xd
        0xd
        0xd
        0x8
        0x8
        0x8
        0x8
        0x8
        0x4
        0x4
        0x4
    .end array-data

    :array_1652
    .array-data 4
        0x30
        0x41
        0x17
        0x24
        0x43
        0xd
        0x39
        0x18
        0x6
        0x32
        0x44
    .end array-data

    :array_166c
    .array-data 4
        0x19
        0x15
        0x19
        0x13
        0xf
        0xb
        0x6
        0x5
        0x2
        0x1
        0x1
    .end array-data

    :array_1686
    .array-data 4
        0xf
        0x16
        0x1a
    .end array-data

    :array_1690
    .array-data 4
        0x8
        0xb
        0x1b
        0x14
        0x22
        0x26
        0x47
        0x4c
    .end array-data

    :array_16a4
    .array-data 4
        0xd
        0xd
        0xd
        0xa
        0xd
        0xd
        0xc
        0xc
    .end array-data

    :array_16b8
    .array-data 4
        0x10
        0x2d
        0x32
        0x2f
        0x2d
        0x38
        0x39
        0x3a
        0x42
        0x54
        0x56
    .end array-data

    :array_16d2
    .array-data 4
        0xb
        0xb
        0xb
        0x8
        0x9
        0x9
        0x8
        0x5
        0xb
        0x8
        0x8
    .end array-data

    :array_16ec
    .array-data 4
        0x16
        0x1b
        0x1c
    .end array-data

    :array_16f6
    .array-data 4
        0x5
        0x6
        0x7
        0xe
        0x11
        0x11
        0x1a
        0x1f
        0x13
        0x16
        0x17
        0x15
        0x1a
        0x1b
        0x1f
        0x22
    .end array-data

    :array_171a
    .array-data 4
        0x1b
        0x1b
        0x1b
        0x1a
        0x18
        0x13
        0x18
        0x16
        0xe
        0xe
        0x9
        0x8
        0x4
        0x5
        0x7
        0x7
    .end array-data

    :array_173e
    .array-data 4
        0x14
        0x15
        0x10
        0xf
        0x17
        0x15
        0x1d
        0x17
        0x2d
        0x2e
        0x2f
        0x3e
        0x3f
    .end array-data

    :array_175c
    .array-data 4
        0x16
        0x15
        0x10
        0x11
        0xc
        0xb
        0x9
        0x3
        0x5
        0x5
        0x5
        0x15
        0x14
    .end array-data

    :array_177a
    .array-data 4
        0x26
        0x29
        0x2c
        0x30
        0x30
        0x2c
        0x2e
        0x32
        0x3a
        0x3b
        0x3f
        0x43
    .end array-data

    :array_1796
    .array-data 4
        0x7
        0x7
        0x7
        0x8
        0xf
        0x12
        0x13
        0x16
        0x17
        0x17
        0x15
        0x14
    .end array-data
.end method

.method private static a(II)V
    .registers 9

    const/16 v6, 0x14

    const/4 v0, 0x0

    :goto_3
    sget v1, La;->c:I

    if-lt v0, v1, :cond_c

    :cond_7
    sget v1, La;->c:I

    if-ne v0, v1, :cond_16

    :cond_b
    return-void

    :cond_c
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_16
    move v1, v0

    :goto_17
    add-int v2, v0, p1

    if-ge v1, v2, :cond_b

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    aput v6, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x28

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0x1e

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x10

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    aput v6, v2, v1

    sget-object v2, La;->f:[I

    aget v3, v2, v1

    add-int/lit8 v3, v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    mul-int/lit8 v3, v1, 0x5

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x3c

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_17
.end method

.method public static final a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 8

    const/4 v6, 0x3

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, La;->c:I

    if-lt v0, v2, :cond_8

    return-void

    :cond_8
    sget-object v2, La;->i:[I

    aget v2, v2, v0

    const/4 v3, 0x5

    if-eq v2, v3, :cond_e8

    sget-object v2, La;->i:[I

    aget v2, v2, v0

    const/16 v3, 0x8

    if-eq v2, v3, :cond_e8

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v3, Lq;->ay:I

    add-int/lit8 v3, v3, -0xa

    if-lt v2, v3, :cond_e8

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v3, Lq;->ay:I

    sget v4, Lq;->ab:I

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0xa

    if-gt v2, v3, :cond_e8

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v3, Lq;->az:I

    if-lt v2, v3, :cond_e8

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v3, Lq;->az:I

    sget v4, Lq;->ac:I

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x14

    if-gt v2, v3, :cond_e8

    sget-object v2, La;->r:[[[Ljavax/microedition/lcdui/Image;

    sget-object v3, La;->J:[I

    aget v3, v3, v0

    aget-object v3, v2, v3

    sget-object v2, La;->k:[I

    aget v2, v2, v0

    if-ltz v2, :cond_ec

    move v2, v1

    :goto_52
    aget-object v2, v3, v2

    sget-object v3, La;->B:[I

    aget v3, v3, v0

    aget-object v2, v2, v3

    sget-object v3, La;->e:[I

    aget v3, v3, v0

    sget-object v4, La;->f:[I

    aget v4, v4, v0

    const/16 v5, 0x21

    invoke-virtual {p0, v2, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v2, La;->t:[I

    aget v2, v2, v0

    if-eqz v2, :cond_e8

    const/16 v2, 0x3311

    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v3, La;->h:[I

    aget v3, v3, v0

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x1

    sget-object v3, La;->f:[I

    aget v3, v3, v0

    sget-object v4, La;->g:[I

    aget v4, v4, v0

    sub-int/2addr v3, v4

    add-int/lit8 v3, v3, -0x7

    sget-object v4, La;->h:[I

    aget v4, v4, v0

    add-int/lit8 v4, v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0, v2, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget-object v2, La;->l:[I

    aget v2, v2, v0

    sget-object v3, La;->h:[I

    aget v3, v3, v0

    mul-int/2addr v2, v3

    sget-object v3, La;->C:[I

    aget v3, v3, v0

    div-int/2addr v2, v3

    const v3, 0xee00

    invoke-virtual {p0, v3}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v3, La;->e:[I

    aget v3, v3, v0

    sget-object v4, La;->h:[I

    aget v4, v4, v0

    shr-int/lit8 v4, v4, 0x1

    sub-int/2addr v3, v4

    sget-object v4, La;->f:[I

    aget v4, v4, v0

    sget-object v5, La;->g:[I

    aget v5, v5, v0

    sub-int/2addr v4, v5

    add-int/lit8 v4, v4, -0x6

    invoke-virtual {p0, v3, v4, v2, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const/16 v3, 0x4422

    invoke-virtual {p0, v3}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v3, La;->e:[I

    aget v3, v3, v0

    sget-object v4, La;->h:[I

    aget v4, v4, v0

    shr-int/lit8 v4, v4, 0x1

    sub-int/2addr v3, v4

    add-int/2addr v3, v2

    sget-object v4, La;->f:[I

    aget v4, v4, v0

    sget-object v5, La;->g:[I

    aget v5, v5, v0

    sub-int/2addr v4, v5

    add-int/lit8 v4, v4, -0x6

    sget-object v5, La;->h:[I

    aget v5, v5, v0

    sub-int v2, v5, v2

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {p0, v3, v4, v2, v6}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :cond_e8
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_3

    :cond_ec
    const/4 v2, 0x1

    goto/16 :goto_52
.end method

.method public static final a(III)Z
    .registers 8

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    const/4 v3, 0x2

    if-eq v2, v3, :cond_17

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    if-eq v2, v4, :cond_17

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    const/4 v3, 0x4

    if-ne v2, v3, :cond_52

    :cond_17
    sget-object v2, La;->l:[I

    aget v3, v2, p0

    sub-int/2addr v3, p1

    aput v3, v2, p0

    sget-object v2, La;->l:[I

    aget v2, v2, p0

    if-gtz v2, :cond_41

    sget-object v2, La;->l:[I

    aput v1, v2, p0

    sget-object v2, La;->j:[I

    const/4 v3, -0x5

    aput v3, v2, p0

    sget-object v2, La;->y:[I

    shl-int/lit8 v3, p2, 0x3

    neg-int v3, v3

    aput v3, v2, p0

    sget-object v2, La;->z:[I

    aput v1, v2, p0

    sget-object v2, La;->t:[I

    aput v1, v2, p0

    sget-object v1, La;->i:[I

    aput v0, v1, p0

    :goto_40
    return v0

    :cond_41
    sget-object v0, La;->j:[I

    aput v1, v0, p0

    sget-object v0, La;->k:[I

    aput p2, v0, p0

    sget-object v0, La;->i:[I

    const/4 v2, 0x6

    aput v2, v0, p0

    sget-object v0, La;->B:[I

    aput v4, v0, p0

    :cond_52
    move v0, v1

    goto :goto_40
.end method

.method public static final a(IIII)Z
    .registers 11

    const/4 v6, 0x2

    const/16 v5, 0x9

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    if-eq v2, v6, :cond_1f

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    if-eq v2, v4, :cond_1f

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    const/4 v3, 0x4

    if-eq v2, v3, :cond_1f

    sget-object v2, La;->i:[I

    aget v2, v2, p0

    if-ne v2, v5, :cond_e9

    :cond_1f
    sget-object v2, La;->l:[I

    aget v3, v2, p0

    sub-int/2addr v3, p1

    aput v3, v2, p0

    sget-object v2, La;->l:[I

    aget v2, v2, p0

    if-gtz v2, :cond_d7

    sget-object v2, La;->l:[I

    aput v1, v2, p0

    sget-object v2, La;->j:[I

    const/4 v3, -0x5

    aput v3, v2, p0

    sget-object v2, La;->y:[I

    shl-int/lit8 v3, p2, 0x3

    neg-int v3, v3

    aput v3, v2, p0

    sget-object v2, La;->z:[I

    aput v1, v2, p0

    sget-object v2, La;->t:[I

    aput v1, v2, p0

    sget-object v1, La;->i:[I

    aput v0, v1, p0

    sget v1, Lq;->as:I

    const/16 v2, 0xc

    if-ne v1, v2, :cond_b0

    sget v1, Lg;->bc:I

    const/4 v2, 0x4

    if-ne v1, v2, :cond_b0

    if-nez p3, :cond_58

    invoke-static {p0}, La;->d(I)V

    :cond_58
    if-ne p3, v0, :cond_af

    sget v1, Lg;->bc:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_af

    sget v1, Lg;->bc:I

    if-ge v1, v5, :cond_af

    sget-object v1, Lc;->g:[I

    sget v2, Lg;->bc:I

    aget v1, v1, v2

    sget-object v2, La;->d:[I

    aget v2, v2, p0

    if-ne v1, v2, :cond_af

    sget v1, Lg;->bh:I

    if-lez v1, :cond_79

    sget v1, Lg;->bh:I

    add-int/lit8 v1, v1, -0x1

    sput v1, Lg;->bh:I

    :cond_79
    new-instance v1, Ljava/lang/StringBuffer;

    sget-object v2, La;->n:[Ljava/lang/String;

    sget-object v3, Lc;->g:[I

    sget v4, Lg;->bc:I

    aget v3, v3, v4

    aget-object v2, v2, v3

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    sget v2, Lg;->bh:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    const-string v2, "#"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    sget-object v2, Lc;->h:[I

    sget v3, Lg;->bc:I

    aget v2, v2, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lq;->a(Ljava/lang/String;)V

    :cond_af
    :goto_af
    return v0

    :cond_b0
    invoke-static {p0}, La;->d(I)V

    if-nez p3, :cond_af

    sget v1, Lq;->as:I

    const/16 v2, 0xe

    if-ne v1, v2, :cond_af

    sget-boolean v1, Lg;->w:Z

    if-eqz v1, :cond_af

    sget v1, Lg;->D:I

    if-ne v1, v6, :cond_af

    sget-boolean v1, Lg;->x:Z

    if-nez v1, :cond_af

    sget-object v1, La;->d:[I

    aget v1, v1, p0

    const/16 v2, 0x11

    if-ne v1, v2, :cond_af

    sput v4, Lg;->D:I

    const-string v1, "Giải được câu đố thứ 3"

    invoke-static {v1}, Lq;->a(Ljava/lang/String;)V

    goto :goto_af

    :cond_d7
    sget-object v0, La;->i:[I

    aget v0, v0, p0

    if-ne v0, v5, :cond_eb

    sget-object v0, La;->j:[I

    aget v2, v0, p0

    add-int/lit8 v2, v2, -0x7

    aput v2, v0, p0

    sget-object v0, La;->k:[I

    aput p2, v0, p0

    :cond_e9
    :goto_e9
    move v0, v1

    goto :goto_af

    :cond_eb
    sget-object v0, La;->j:[I

    aput v1, v0, p0

    sget-object v0, La;->k:[I

    aput p2, v0, p0

    sget-object v0, La;->i:[I

    const/4 v2, 0x6

    aput v2, v0, p0

    sget-object v0, La;->B:[I

    aput v4, v0, p0

    goto :goto_e9
.end method

.method public static final b()V
    .registers 10

    const/4 v4, -0x1

    const/4 v9, 0x3

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x64

    if-nez v0, :cond_10

    move v0, v1

    :goto_c
    sget v2, La;->c:I

    if-lt v0, v2, :cond_16

    :cond_10
    move v0, v1

    :goto_11
    sget v2, La;->c:I

    if-lt v0, v2, :cond_51

    return-void

    :cond_16
    sget-object v2, La;->i:[I

    aget v2, v2, v0

    const/4 v6, 0x5

    if-eq v2, v6, :cond_44

    sget v2, Lg;->at:I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    sget v6, Lg;->au:I

    sget-object v7, La;->f:[I

    aget v7, v7, v0

    sub-int/2addr v6, v7

    invoke-static {v6}, Lq;->a(I)I

    move-result v6

    add-int/2addr v2, v6

    sget v6, Lq;->ac:I

    sget v7, Lq;->ab:I

    add-int/2addr v6, v7

    if-le v2, v6, :cond_44

    sget-object v2, La;->i:[I

    const/16 v6, 0xa

    aput v6, v2, v0

    :cond_41
    :goto_41
    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :cond_44
    sget-object v2, La;->i:[I

    aget v2, v2, v0

    const/16 v6, 0xa

    if-ne v2, v6, :cond_41

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto :goto_41

    :cond_51
    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_79

    sget-object v2, La;->l:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_79

    sget v2, Lg;->as:I

    if-ne v2, v5, :cond_79

    sget-object v2, La;->l:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_6f

    sget-object v2, La;->l:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x3

    aput v6, v2, v0

    :cond_6f
    sget-object v2, La;->l:[I

    aget v2, v2, v0

    if-ge v2, v3, :cond_79

    sget-object v2, La;->l:[I

    aput v3, v2, v0

    :cond_79
    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_89

    sget v2, Lg;->as:I

    if-ne v2, v5, :cond_89

    sget-object v2, La;->t:[I

    const/16 v6, 0x64

    aput v6, v2, v0

    :cond_89
    sget-object v2, La;->E:[I

    aget v2, v2, v0

    const/16 v6, 0x1e

    if-gt v2, v6, :cond_99

    sget-object v2, La;->E:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    :cond_99
    sget-object v2, La;->t:[I

    aget v2, v2, v0

    if-lez v2, :cond_a7

    sget-object v2, La;->t:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    :cond_a7
    sget-object v2, La;->i:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_1250

    :cond_ae
    :goto_ae
    :pswitch_ae  #0x7, 0x8
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_11

    :pswitch_b2  #0x5
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    sget v6, La;->s:I

    if-lt v2, v6, :cond_ae

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget v2, Lq;->at:I

    sget-object v6, La;->L:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    array-length v6, v6

    rem-int/2addr v2, v6

    sget-object v6, La;->N:[[Z

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    aget-boolean v6, v6, v2

    if-eqz v6, :cond_e5

    sget-object v2, La;->j:[I

    sget v6, La;->s:I

    aput v6, v2, v0

    goto :goto_ae

    :cond_e5
    sget-object v6, La;->e:[I

    sget-object v7, La;->L:[[I

    sget-object v8, La;->J:[I

    aget v8, v8, v0

    aget-object v7, v7, v8

    aget v7, v7, v2

    aput v7, v6, v0

    sget-object v6, La;->f:[I

    sget-object v7, La;->M:[[I

    sget-object v8, La;->J:[I

    aget v8, v8, v0

    aget-object v7, v7, v8

    aget v7, v7, v2

    aput v7, v6, v0

    sget-object v6, La;->N:[[Z

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    aput-boolean v3, v6, v2

    sget-object v6, La;->H:[I

    aput v2, v6, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->l:[I

    sget-object v6, La;->C:[I

    aget v6, v6, v0

    aput v6, v2, v0

    sget-object v2, La;->d:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_1266

    goto :goto_ae

    :pswitch_123  #0x0, 0x1, 0x8, 0x9, 0xc, 0xf, 0x17, 0x1a
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x14

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x14

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_139  #0x2, 0x15
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x18

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x18

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_14f  #0x3, 0xa, 0x1b
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_161  #0x4, 0x12
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x14

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x14

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    const/4 v6, -0x3

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_17c  #0x5, 0x6, 0x16, 0x1c
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x14

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x14

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_192  #0x7
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_1a4  #0xb, 0x18
    sget-object v2, La;->i:[I

    const/4 v6, 0x5

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_1ab  #0xd, 0x19
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0xc

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0xc

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_1c1  #0xe, 0x13, 0x14
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x1e

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x1e

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_1d7  #0x10
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x28

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x28

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_1ed  #0x11
    sget-object v2, La;->u:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x3c

    aput v6, v2, v0

    sget-object v2, La;->v:[I

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0x3c

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_203  #0x2
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_12a4

    goto/16 :goto_ae

    :pswitch_20c  #0x0
    invoke-static {v0}, La;->j(I)V

    goto/16 :goto_ae

    :pswitch_211  #0x1
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v3, v2, v0

    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_248

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_238
    :goto_238
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    if-le v2, v9, :cond_ae

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    goto/16 :goto_ae

    :cond_248
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_238

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_238

    :pswitch_257  #0x2
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->z:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->z:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_2e3

    sget-object v2, La;->z:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    :cond_270
    :goto_270
    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->y:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aget v2, v2, v0

    if-le v2, v9, :cond_2b2

    sget-object v2, La;->y:[I

    const/4 v6, -0x3

    aput v6, v2, v0

    sget-object v2, La;->z:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x2

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    :cond_2b2
    sget-object v2, La;->y:[I

    aget v2, v2, v0

    const/4 v6, -0x2

    if-ne v2, v6, :cond_302

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_2f3

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_2c7
    :goto_2c7
    sget-object v2, La;->z:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    mul-int/lit8 v6, v6, 0x6

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :goto_2d5
    invoke-static {v0}, La;->b(I)V

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x9

    if-nez v2, :cond_ae

    invoke-static {v0}, La;->c(I)V

    goto/16 :goto_ae

    :cond_2e3
    sget-object v2, La;->z:[I

    aget v2, v2, v0

    if-ge v2, v4, :cond_270

    sget-object v2, La;->z:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    goto/16 :goto_270

    :cond_2f3
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_2c7

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_2c7

    :cond_302
    sget-object v2, La;->B:[I

    aput v3, v2, v0

    goto :goto_2d5

    :pswitch_307  #0x3, 0x1b
    invoke-static {v0}, La;->n(I)V

    goto/16 :goto_ae

    :pswitch_30c  #0x4, 0x12
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->z:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->z:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_394

    sget-object v2, La;->z:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    :cond_325
    :goto_325
    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->y:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aget v2, v2, v0

    if-le v2, v9, :cond_363

    sget-object v2, La;->y:[I

    const/4 v6, -0x3

    aput v6, v2, v0

    sget-object v2, La;->z:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x2

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    :cond_363
    sget-object v2, La;->y:[I

    aget v2, v2, v0

    const/4 v6, -0x2

    if-ne v2, v6, :cond_3b2

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_3a3

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_378
    :goto_378
    sget-object v2, La;->z:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    mul-int/lit8 v6, v6, 0x6

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :goto_386
    invoke-static {v0}, La;->b(I)V

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x9

    if-nez v2, :cond_ae

    invoke-static {v0}, La;->c(I)V

    goto/16 :goto_ae

    :cond_394
    sget-object v2, La;->z:[I

    aget v2, v2, v0

    if-ge v2, v4, :cond_325

    sget-object v2, La;->z:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    goto :goto_325

    :cond_3a3
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_378

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_378

    :cond_3b2
    sget-object v2, La;->B:[I

    aput v3, v2, v0

    goto :goto_386

    :pswitch_3b7  #0x5, 0x1c
    invoke-static {v0}, La;->j(I)V

    goto/16 :goto_ae

    :pswitch_3bc  #0x6
    invoke-static {v0}, La;->r(I)V

    goto/16 :goto_ae

    :pswitch_3c1  #0x7
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->w:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->x:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    if-gez v2, :cond_3e1

    sget-object v2, La;->e:[I

    aput v1, v2, v0

    :cond_3e1
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lj;->c:I

    add-int/lit8 v6, v6, -0xa

    if-le v2, v6, :cond_3f3

    sget-object v2, La;->e:[I

    sget v6, Lj;->c:I

    add-int/lit8 v6, v6, -0xa

    aput v6, v2, v0

    :cond_3f3
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    if-gez v2, :cond_3fd

    sget-object v2, La;->f:[I

    aput v1, v2, v0

    :cond_3fd
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lj;->d:I

    add-int/lit8 v6, v6, -0x14

    if-le v2, v6, :cond_40f

    sget-object v2, La;->f:[I

    sget v6, Lj;->d:I

    add-int/lit8 v6, v6, -0x14

    aput v6, v2, v0

    :cond_40f
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x1f

    if-nez v2, :cond_455

    sget-object v2, La;->w:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x3

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    shr-int/lit8 v6, v6, 0x1

    rem-int/lit8 v6, v6, 0x3

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, 0xa

    const/16 v7, 0x2000

    invoke-static {v2, v6, v7}, Lj;->a(III)Z

    move-result v2

    if-eqz v2, :cond_455

    sget v2, Lq;->at:I

    rem-int/2addr v2, v0

    if-nez v2, :cond_455

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v2, La;->k:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    neg-int v6, v6

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto/16 :goto_ae

    :cond_455
    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_464

    sget-object v2, La;->B:[I

    aput v9, v2, v0

    :goto_45f
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_464
    sget-object v2, La;->B:[I

    aput v3, v2, v0

    goto :goto_45f

    :pswitch_469  #0x8
    sget v2, Lq;->at:I

    add-int/2addr v2, v0

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_48f

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_482

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_482
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x1

    add-int/2addr v6, v7

    aput v6, v2, v0

    :cond_48f
    sget v2, Lq;->at:I

    add-int/lit8 v6, v0, 0x1

    shl-int/lit8 v6, v6, 0x3

    rem-int/2addr v2, v6

    if-nez v2, :cond_49c

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    :cond_49c
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_4af

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_4aa
    :goto_4aa
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_4af
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_4aa

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_4aa

    :pswitch_4be  #0xa
    invoke-static {v0}, La;->n(I)V

    goto/16 :goto_ae

    :pswitch_4c3  #0x9
    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v6, La;->k:[I

    sget v2, Lg;->at:I

    sget-object v7, La;->e:[I

    aget v7, v7, v0

    if-le v2, v7, :cond_4d6

    move v2, v3

    :goto_4d2
    aput v2, v6, v0

    goto/16 :goto_ae

    :cond_4d6
    move v2, v4

    goto :goto_4d2

    :pswitch_4d8  #0xb
    invoke-static {v0}, La;->k(I)V

    goto/16 :goto_ae

    :pswitch_4dd  #0xd
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->w:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, 0x64

    if-le v2, v6, :cond_55f

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    sget v7, Lq;->at:I

    rem-int/lit8 v7, v7, 0x4

    add-int/lit8 v7, v7, 0x1

    mul-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    :cond_515
    :goto_515
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, 0x14

    if-le v2, v6, :cond_58d

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x1

    neg-int v6, v6

    aput v6, v2, v0

    :goto_52d
    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->x:[I

    aget v7, v7, v0

    shr-int/lit8 v7, v7, 0x1

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_55a

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_5aa

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0xc

    aput v6, v2, v0

    :cond_55a
    :goto_55a
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_55f
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, -0x64

    if-ge v2, v6, :cond_515

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    sget v7, Lq;->at:I

    rem-int/lit8 v7, v7, 0x4

    add-int/lit8 v7, v7, 0x1

    mul-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    goto :goto_515

    :cond_58d
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, -0x14

    if-ge v2, v6, :cond_5a5

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    goto :goto_52d

    :cond_5a5
    sget-object v2, La;->x:[I

    aput v1, v2, v0

    goto :goto_52d

    :cond_5aa
    sget-object v2, La;->f:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0xc

    aput v6, v2, v0

    goto :goto_55a

    :pswitch_5b3  #0x19
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->w:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, 0x64

    if-le v2, v6, :cond_62d

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    sget v7, Lq;->at:I

    rem-int/lit8 v7, v7, 0x4

    add-int/lit8 v7, v7, 0x1

    mul-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    :cond_5eb
    :goto_5eb
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, 0x14

    if-le v2, v6, :cond_65b

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x1

    neg-int v6, v6

    aput v6, v2, v0

    :goto_603
    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->x:[I

    aget v7, v7, v0

    shr-int/lit8 v7, v7, 0x1

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_628

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_628

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_628
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_62d
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, -0x64

    if-ge v2, v6, :cond_5eb

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    sget v7, Lq;->at:I

    rem-int/lit8 v7, v7, 0x4

    add-int/lit8 v7, v7, 0x1

    mul-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    goto :goto_5eb

    :cond_65b
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    sub-int/2addr v2, v6

    const/16 v6, -0x14

    if-ge v2, v6, :cond_673

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    goto :goto_603

    :cond_673
    sget-object v2, La;->x:[I

    aput v1, v2, v0

    goto :goto_603

    :pswitch_678  #0xe
    invoke-static {v0}, La;->k(I)V

    goto/16 :goto_ae

    :pswitch_67d  #0xf, 0x1a
    invoke-static {v0}, La;->r(I)V

    goto/16 :goto_ae

    :pswitch_682  #0x10, 0x16, 0x18
    sget v2, Lq;->at:I

    shl-int/lit8 v6, v0, 0x5

    add-int/2addr v2, v6

    rem-int/lit8 v2, v2, 0x64

    const/16 v6, 0x1e

    if-le v2, v6, :cond_6ac

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_69f

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_69f
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    :cond_6ac
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_6c8

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_6ba
    :goto_6ba
    invoke-static {v0}, La;->b(I)V

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x9

    if-nez v2, :cond_ae

    invoke-static {v0}, La;->c(I)V

    goto/16 :goto_ae

    :cond_6c8
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_6ba

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_6ba

    :pswitch_6d7  #0x13
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_6ef

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_6ef

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_6ef
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x1

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_70f

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_70a
    :goto_70a
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_70f
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_70a

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_70a

    :pswitch_71e  #0x11
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_743

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_736

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_736
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x1

    add-int/2addr v6, v7

    aput v6, v2, v0

    :cond_743
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_75f

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_751
    :goto_751
    invoke-static {v0}, La;->b(I)V

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x9

    if-nez v2, :cond_ae

    invoke-static {v0}, La;->c(I)V

    goto/16 :goto_ae

    :cond_75f
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_751

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_751

    :pswitch_76e  #0xc
    invoke-static {v0}, La;->j(I)V

    goto/16 :goto_ae

    :pswitch_773  #0x14
    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_785

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_785
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x2

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_7a5

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_7a0
    :goto_7a0
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_7a5
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_7a0

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_7a0

    :pswitch_7b4  #0x17
    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x4

    if-nez v2, :cond_7d4

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_7d4

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    sget-object v2, La;->j:[I

    aput v3, v2, v0

    :cond_7d4
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->j:[I

    aget v7, v7, v0

    sget-object v8, La;->k:[I

    aget v8, v8, v0

    mul-int/2addr v7, v8

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_800

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_7f2
    :goto_7f2
    invoke-static {v0}, La;->b(I)V

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x9

    if-nez v2, :cond_ae

    invoke-static {v0}, La;->c(I)V

    goto/16 :goto_ae

    :cond_800
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_7f2

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_7f2

    :pswitch_80f  #0x15
    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_821

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_821
    rem-int/lit8 v2, v0, 0x2

    if-nez v2, :cond_843

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    :goto_830
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->v:[I

    aget v6, v6, v0

    if-le v2, v6, :cond_851

    sget-object v2, La;->k:[I

    aput v4, v2, v0

    :cond_83e
    :goto_83e
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :cond_843
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x1

    add-int/2addr v6, v7

    aput v6, v2, v0

    goto :goto_830

    :cond_851
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->u:[I

    aget v6, v6, v0

    if-ge v2, v6, :cond_83e

    sget-object v2, La;->k:[I

    aput v3, v2, v0

    goto :goto_83e

    :pswitch_860  #0x6
    sget-object v2, La;->t:[I

    const/16 v6, 0x64

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v5, v2, v0

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_87c

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_87c

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    :cond_87c
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_12e2

    goto/16 :goto_ae

    :pswitch_885  #0x0
    sget-object v2, La;->E:[I

    aget v2, v2, v0

    const/16 v6, 0x1e

    if-ge v2, v6, :cond_8b2

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x1

    sub-int/2addr v6, v7

    aput v6, v2, v0

    :goto_89a
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_8be

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x2

    aput v6, v2, v0

    goto/16 :goto_ae

    :cond_8b2
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    sub-int/2addr v6, v7

    aput v6, v2, v0

    goto :goto_89a

    :cond_8be
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v6, 0x5

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x2

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto/16 :goto_ae

    :pswitch_8d3  #0x1
    invoke-static {v0}, La;->o(I)V

    goto/16 :goto_ae

    :pswitch_8d8  #0x2
    invoke-static {v0}, La;->f(I)V

    goto/16 :goto_ae

    :pswitch_8dd  #0x3, 0x1b
    invoke-static {v0}, La;->m(I)V

    goto/16 :goto_ae

    :pswitch_8e2  #0x4, 0x12
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    sub-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v5, v2, v0

    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v6, 0x7

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->y:[I

    const/4 v6, -0x4

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    mul-int/lit8 v6, v6, 0x3

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_927  #0x5, 0x1c
    invoke-static {v0}, La;->q(I)V

    goto/16 :goto_ae

    :pswitch_92c  #0x6
    invoke-static {v0}, La;->q(I)V

    goto/16 :goto_ae

    :pswitch_931  #0x7
    invoke-static {v0}, La;->m(I)V

    goto/16 :goto_ae

    :pswitch_936  #0x8
    invoke-static {v0}, La;->q(I)V

    goto/16 :goto_ae

    :pswitch_93b  #0x9
    sget-object v2, La;->k:[I

    sget v6, Lg;->aF:I

    neg-int v6, v6

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    rem-int/lit8 v2, v2, 0x4

    if-le v2, v3, :cond_9e4

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :goto_94e
    sget-object v2, La;->i:[I

    aput v3, v2, v0

    sget-object v2, La;->j:[I

    const/4 v6, -0x8

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    sget v6, Lg;->aF:I

    shl-int/lit8 v6, v6, 0x3

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->e:[I

    aget v7, v7, v0

    aput v7, v2, v6

    sget-object v2, La;->f:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->f:[I

    aget v7, v7, v0

    aput v7, v2, v6

    sget-object v2, La;->H:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aput v7, v2, v6

    sget-object v2, La;->u:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->e:[I

    sget-object v8, La;->A:[I

    aget v8, v8, v0

    aget v7, v7, v8

    add-int/lit8 v7, v7, -0x14

    aput v7, v2, v6

    sget-object v2, La;->v:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->e:[I

    sget-object v8, La;->A:[I

    aget v8, v8, v0

    aget v7, v7, v8

    add-int/lit8 v7, v7, 0x14

    aput v7, v2, v6

    sget-object v2, La;->l:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->C:[I

    sget-object v8, La;->A:[I

    aget v8, v8, v0

    aget v7, v7, v8

    aput v7, v2, v6

    sget-object v2, La;->k:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget v7, Lg;->aF:I

    neg-int v7, v7

    aput v7, v2, v6

    sget-object v2, La;->i:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    aput v5, v2, v6

    sget-object v2, La;->j:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    aput v1, v2, v6

    sget-object v2, La;->k:[I

    aput v1, v2, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->x:[I

    aput v1, v6, v0

    aput v1, v2, v0

    sget-object v2, La;->E:[I

    aput v1, v2, v0

    goto/16 :goto_ae

    :cond_9e4
    sget-object v2, La;->B:[I

    aput v5, v2, v0

    goto/16 :goto_94e

    :pswitch_9ea  #0xa
    invoke-static {v0}, La;->m(I)V

    goto/16 :goto_ae

    :pswitch_9ef  #0xb, 0x16
    invoke-static {v0}, La;->g(I)V

    goto/16 :goto_ae

    :pswitch_9f4  #0xd, 0x19
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->w:[I

    aget v7, v7, v0

    shr-int/lit8 v7, v7, 0x3

    sub-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->x:[I

    aget v7, v7, v0

    shr-int/lit8 v7, v7, 0x3

    sub-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->w:[I

    aget v2, v2, v0

    if-nez v2, :cond_a20

    sget-object v2, La;->w:[I

    aput v5, v2, v0

    :cond_a20
    sget-object v2, La;->x:[I

    aget v2, v2, v0

    if-nez v2, :cond_a2a

    sget-object v2, La;->x:[I

    aput v5, v2, v0

    :cond_a2a
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v6, 0x5

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v6, La;->k:[I

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v7, La;->u:[I

    aget v7, v7, v0

    if-le v2, v7, :cond_a58

    move v2, v4

    :goto_a46
    aput v2, v6, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x3

    aput v6, v2, v0

    sget-object v2, La;->E:[I

    aput v1, v2, v0

    goto/16 :goto_ae

    :cond_a58
    move v2, v3

    goto :goto_a46

    :pswitch_a5a  #0xe
    invoke-static {v0}, La;->g(I)V

    goto/16 :goto_ae

    :pswitch_a5f  #0xf, 0x18, 0x1a
    invoke-static {v0}, La;->q(I)V

    goto/16 :goto_ae

    :pswitch_a64  #0x17
    invoke-static {v0}, La;->g(I)V

    sget-object v2, La;->l:[I

    aget v2, v2, v0

    sget-object v6, La;->C:[I

    aget v6, v6, v0

    shr-int/lit8 v6, v6, 0x1

    if-ge v2, v6, :cond_ae

    sget-object v2, La;->i:[I

    aput v3, v2, v0

    sget-object v2, La;->j:[I

    const/4 v6, -0x8

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    sget v6, Lg;->aF:I

    shl-int/lit8 v6, v6, 0x3

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_a86  #0x10, 0x15
    invoke-static {v0}, La;->o(I)V

    goto/16 :goto_ae

    :pswitch_a8b  #0x13
    sget-object v2, La;->i:[I

    const/4 v6, 0x4

    aput v6, v2, v0

    goto/16 :goto_ae

    :pswitch_a92  #0x11
    invoke-static {v0}, La;->q(I)V

    goto/16 :goto_ae

    :pswitch_a97  #0xc
    invoke-static {v0}, La;->o(I)V

    goto/16 :goto_ae

    :pswitch_a9c  #0x14
    invoke-static {v0}, La;->f(I)V

    goto/16 :goto_ae

    :pswitch_aa1  #0x4
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/16 v6, 0x13

    if-eq v2, v6, :cond_ab7

    sget-boolean v2, Lq;->aA:Z

    if-nez v2, :cond_ab1

    sget-boolean v2, Lq;->bd:Z

    if-eqz v2, :cond_ab7

    :cond_ab1
    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto/16 :goto_ae

    :cond_ab7
    sget-boolean v2, Lg;->ba:Z

    if-eqz v2, :cond_acb

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->y:[I

    aput v1, v2, v0

    :cond_acb
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    packed-switch v2, :pswitch_data_1320

    goto/16 :goto_ae

    :pswitch_ad4  #0x0
    invoke-static {v0}, La;->h(I)V

    goto/16 :goto_ae

    :pswitch_ad9  #0x1
    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v2, La;->y:[I

    const/4 v6, -0x4

    aput v6, v2, v0

    sget-object v7, La;->j:[I

    move v2, v1

    move v6, v0

    :goto_af8
    aput v2, v7, v6

    goto/16 :goto_ae

    :pswitch_afc  #0x2
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    if-ne v2, v9, :cond_b1f

    sget-object v2, La;->K:[Z

    aget-boolean v2, v2, v0

    if-eqz v2, :cond_b61

    sget-object v2, La;->K:[Z

    aput-boolean v1, v2, v0

    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    invoke-static {v2, v6}, Lg;->b(II)V

    :cond_b1f
    :goto_b1f
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    shr-int/lit8 v2, v2, 0x2

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_b6d

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :goto_b38
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xc

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v2, La;->y:[I

    const/4 v6, -0x4

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto/16 :goto_ae

    :cond_b61
    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    invoke-static {v2, v6}, Lg;->a(II)V

    goto :goto_b1f

    :cond_b6d
    sget-object v2, La;->B:[I

    aput v3, v2, v0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    sub-int/2addr v6, v7

    aput v6, v2, v0

    goto :goto_b38

    :pswitch_b7d  #0x3, 0x1b
    invoke-static {v0}, La;->l(I)V

    goto/16 :goto_ae

    :pswitch_b82  #0x4, 0x12
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    if-ne v2, v9, :cond_ba5

    sget-object v2, La;->K:[Z

    aget-boolean v2, v2, v0

    if-eqz v2, :cond_be7

    sget-object v2, La;->K:[Z

    aput-boolean v1, v2, v0

    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    invoke-static {v2, v6}, Lg;->b(II)V

    :cond_ba5
    :goto_ba5
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    shr-int/lit8 v2, v2, 0x2

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_bf3

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    :goto_bba
    sget-object v2, La;->B:[I

    aput v9, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xc

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v2, La;->y:[I

    const/4 v6, -0x4

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto/16 :goto_ae

    :cond_be7
    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    invoke-static {v2, v6}, Lg;->a(II)V

    goto :goto_ba5

    :cond_bf3
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    sub-int/2addr v6, v7

    aput v6, v2, v0

    goto :goto_bba

    :pswitch_bff  #0x5, 0x15, 0x16, 0x17, 0x18, 0x1c
    invoke-static {v0}, La;->p(I)V

    goto/16 :goto_ae

    :pswitch_c04  #0x6
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v9, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    if-ne v2, v9, :cond_c36

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x3

    add-int/2addr v2, v6

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0xc

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x3

    sget-object v8, La;->D:[I

    aget v8, v8, v0

    invoke-static {v2, v6, v7, v8, v5}, Lq;->b(IIIII)V

    goto/16 :goto_ae

    :cond_c36
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v6, 0x6

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto/16 :goto_ae

    :pswitch_c47  #0x7
    invoke-static {v0}, La;->l(I)V

    goto/16 :goto_ae

    :pswitch_c4c  #0x8
    invoke-static {v0}, La;->h(I)V

    goto/16 :goto_ae

    :pswitch_c51  #0xa
    invoke-static {v0}, La;->l(I)V

    goto/16 :goto_ae

    :pswitch_c56  #0x9
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v6, 0x6

    if-ne v2, v6, :cond_ae

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    shl-int/lit8 v6, v6, 0x4

    add-int/2addr v2, v6

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    add-int/lit8 v6, v6, -0x10

    sget-object v7, La;->k:[I

    aget v7, v7, v0

    shl-int/lit8 v7, v7, 0x3

    invoke-static {v2, v6, v7, v1, v1}, Lq;->a(IIIIZ)V

    goto/16 :goto_ae

    :pswitch_c89  #0xb, 0x1a
    invoke-static {v0}, La;->i(I)V

    goto/16 :goto_ae

    :pswitch_c8e  #0xd, 0x19
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-ge v2, v6, :cond_d34

    sget-object v2, La;->w:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x6

    add-int/lit8 v6, v6, 0x4

    aput v6, v2, v0

    :cond_ca0
    :goto_ca0
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    if-ge v2, v6, :cond_d49

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x2

    aput v6, v2, v0

    :cond_cb2
    :goto_cb2
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->w:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->x:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_ce0

    sget-object v2, La;->B:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_ce0

    sget-object v2, La;->B:[I

    aput v1, v2, v0

    :cond_ce0
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/4 v6, 0x5

    if-ge v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/4 v6, 0x5

    if-ge v2, v6, :cond_ae

    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget v6, Lg;->aF:I

    neg-int v6, v6

    invoke-static {v2, v6}, Lg;->a(II)V

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v6, La;->k:[I

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v7, La;->u:[I

    aget v7, v7, v0

    if-le v2, v7, :cond_d5e

    move v2, v4

    :goto_d1b
    aput v2, v6, v0

    sget-object v2, La;->w:[I

    sget-object v6, La;->k:[I

    aget v6, v6, v0

    sget v7, Lq;->at:I

    rem-int/lit8 v7, v7, 0x4

    add-int/lit8 v7, v7, 0x1

    mul-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->E:[I

    const/16 v6, 0xa

    aput v6, v2, v0

    goto/16 :goto_ae

    :cond_d34
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-le v2, v6, :cond_ca0

    sget-object v2, La;->w:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x6

    add-int/lit8 v6, v6, 0x4

    neg-int v6, v6

    aput v6, v2, v0

    goto/16 :goto_ca0

    :cond_d49
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    if-le v2, v6, :cond_cb2

    sget-object v2, La;->x:[I

    sget v6, Lq;->at:I

    rem-int/lit8 v6, v6, 0x4

    add-int/lit8 v6, v6, 0x2

    neg-int v6, v6

    aput v6, v2, v0

    goto/16 :goto_cb2

    :cond_d5e
    move v2, v3

    goto :goto_d1b

    :pswitch_d60  #0xe
    invoke-static {v0}, La;->i(I)V

    goto/16 :goto_ae

    :pswitch_d65  #0xf
    invoke-static {v0}, La;->h(I)V

    goto/16 :goto_ae

    :pswitch_d6a  #0x10
    invoke-static {v0}, La;->h(I)V

    goto/16 :goto_ae

    :pswitch_d6f  #0x11
    invoke-static {v0}, La;->p(I)V

    goto/16 :goto_ae

    :pswitch_d74  #0x13
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v9, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xf

    if-gt v2, v6, :cond_dd8

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x7

    aput v6, v2, v0

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-ge v2, v6, :cond_e69

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    :cond_da0
    :goto_da0
    sget-boolean v2, Lq;->aA:Z

    if-nez v2, :cond_dd8

    sget-boolean v2, Lq;->bd:Z

    if-nez v2, :cond_dd8

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v6, 0x10

    if-ge v2, v6, :cond_dd8

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    add-int/lit8 v6, v6, -0x10

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v6, 0x14

    if-ge v2, v6, :cond_dd8

    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget v6, Lg;->aF:I

    neg-int v6, v6

    invoke-static {v2, v6}, Lg;->a(II)V

    sget-object v2, La;->j:[I

    const/16 v6, 0xf

    aput v6, v2, v0

    :cond_dd8
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xf

    if-ne v2, v6, :cond_de4

    sget-object v2, La;->y:[I

    aput v3, v2, v0

    :cond_de4
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xf

    if-le v2, v6, :cond_ae

    sget-object v2, La;->B:[I

    aput v5, v2, v0

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->y:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-boolean v2, Lq;->aA:Z

    if-nez v2, :cond_e35

    sget-boolean v2, Lq;->bd:Z

    if-nez v2, :cond_e35

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v6, 0x10

    if-ge v2, v6, :cond_e35

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    add-int/lit8 v6, v6, -0x10

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v6, 0x14

    if-ge v2, v6, :cond_e35

    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget v6, Lg;->aF:I

    neg-int v6, v6

    invoke-static {v2, v6}, Lg;->a(II)V

    :cond_e35
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    if-le v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aput v1, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto/16 :goto_ae

    :cond_e69
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-le v2, v6, :cond_da0

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    goto/16 :goto_da0

    :pswitch_e7b  #0xc
    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget v6, Lg;->aF:I

    neg-int v6, v6

    invoke-static {v2, v6}, Lg;->a(II)V

    sget-object v2, La;->i:[I

    aput v9, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v7, La;->B:[I

    move v2, v5

    move v6, v0

    goto/16 :goto_af8

    :pswitch_e93  #0x14
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xa

    if-gt v2, v6, :cond_ef3

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    if-le v2, v6, :cond_eb3

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x4

    aput v6, v2, v0

    :cond_eb3
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-ge v2, v6, :cond_f5a

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x2

    aput v6, v2, v0

    :cond_ec3
    :goto_ec3
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v6, 0x10

    if-ge v2, v6, :cond_ef3

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lg;->au:I

    add-int/lit8 v6, v6, -0x10

    sub-int/2addr v2, v6

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v6, 0x14

    if-ge v2, v6, :cond_ef3

    sget-object v2, La;->D:[I

    aget v2, v2, v0

    sget v6, Lg;->aF:I

    neg-int v6, v6

    invoke-static {v2, v6}, Lg;->a(II)V

    sget-object v2, La;->j:[I

    const/16 v6, 0xa

    aput v6, v2, v0

    :cond_ef3
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xa

    if-ne v2, v6, :cond_eff

    sget-object v2, La;->y:[I

    aput v3, v2, v0

    :cond_eff
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0xa

    if-le v2, v6, :cond_f4c

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->y:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    if-le v2, v6, :cond_f4c

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    aput v1, v2, v0

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    :cond_f4c
    sget-object v7, La;->B:[I

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_f6c

    move v2, v1

    move v6, v0

    goto/16 :goto_af8

    :cond_f5a
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lg;->at:I

    if-le v2, v6, :cond_ec3

    sget-object v2, La;->e:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x2

    aput v6, v2, v0

    goto/16 :goto_ec3

    :cond_f6c
    move v2, v3

    move v6, v0

    goto/16 :goto_af8

    :pswitch_f70  #0x3
    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/16 v6, 0x23

    if-lt v2, v6, :cond_f96

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    sget-object v2, La;->i:[I

    aput v5, v2, v0

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_f96

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_f96

    sget-object v2, La;->m:[I

    aput v4, v2, v0

    :cond_f96
    sget-object v2, La;->B:[I

    aput v1, v2, v0

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_fa4

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-eq v2, v3, :cond_ae

    :cond_fa4
    invoke-static {v0}, La;->b(I)V

    goto/16 :goto_ae

    :pswitch_fa9  #0x1
    sget-object v2, La;->m:[I

    aput v4, v2, v0

    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->j:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    if-nez v2, :cond_fd4

    sget-object v2, La;->y:[I

    aget v2, v2, v0

    if-le v2, v3, :cond_101c

    sget-object v2, La;->y:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, -0x1

    aput v6, v2, v0

    :cond_fd4
    :goto_fd4
    sget-object v2, La;->e:[I

    aget v6, v2, v0

    sget-object v7, La;->y:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v5, v2, v0

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lq;->Z:I

    mul-int/lit8 v6, v6, 0x18

    if-gt v2, v6, :cond_1001

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lq;->W:I

    mul-int/lit8 v6, v6, 0x18

    if-lt v2, v6, :cond_1001

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget v6, Lq;->Y:I

    mul-int/lit8 v6, v6, 0x18

    if-le v2, v6, :cond_102b

    :cond_1001
    sget-object v2, La;->j:[I

    const/16 v6, -0x12c

    aput v6, v2, v0

    sget-object v2, La;->i:[I

    const/4 v6, 0x5

    aput v6, v2, v0

    sget-object v2, La;->N:[[Z

    sget-object v6, La;->J:[I

    aget v6, v6, v0

    aget-object v2, v2, v6

    sget-object v6, La;->H:[I

    aget v6, v6, v0

    aput-boolean v1, v2, v6

    goto/16 :goto_ae

    :cond_101c
    sget-object v2, La;->y:[I

    aget v2, v2, v0

    if-ge v2, v4, :cond_fd4

    sget-object v2, La;->y:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    goto :goto_fd4

    :cond_102b
    sget-object v2, La;->z:[I

    aget v2, v2, v0

    if-eqz v2, :cond_103e

    sget-object v2, La;->z:[I

    aget v2, v2, v0

    if-ge v2, v9, :cond_1127

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v6, 0x7

    if-le v2, v6, :cond_1127

    :cond_103e
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    invoke-static {v2, v6}, Lj;->b(II)I

    move-result v2

    and-int/lit8 v2, v2, 0x2

    if-ne v2, v5, :cond_1127

    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/16 v6, 0x19

    if-ne v2, v6, :cond_107f

    if-le v0, v9, :cond_107f

    sget-boolean v2, Lg;->A:Z

    if-nez v2, :cond_107f

    sget v2, Lq;->bi:I

    const/4 v6, 0x5

    if-eq v2, v6, :cond_107f

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    invoke-static {v2}, Lj;->d(I)I

    move-result v2

    const/4 v6, 0x5

    sput v6, Lq;->bi:I

    invoke-static {}, Lq;->f()V

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    invoke-static {v6, v2}, Lq;->a(II)V

    sget-object v6, La;->e:[I

    aget v6, v6, v0

    add-int/lit8 v2, v2, -0x1c

    invoke-static {v6, v2}, Lq;->b(II)V

    :cond_107f
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/16 v6, 0x17

    if-ne v2, v6, :cond_1113

    sget-object v2, La;->i:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    aget v2, v2, v6

    const/4 v6, 0x5

    if-ne v2, v6, :cond_1113

    sget-object v2, La;->e:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->e:[I

    aget v7, v7, v0

    sget-object v8, La;->k:[I

    aget v8, v8, v0

    shl-int/lit8 v8, v8, 0x3

    sub-int/2addr v7, v8

    aput v7, v2, v6

    sget-object v2, La;->f:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->f:[I

    aget v7, v7, v0

    invoke-static {v7}, Lj;->d(I)I

    move-result v7

    aput v7, v2, v6

    sget-object v2, La;->H:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aput v7, v2, v6

    sget-object v2, La;->u:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->e:[I

    sget-object v8, La;->A:[I

    aget v8, v8, v0

    aget v7, v7, v8

    add-int/lit8 v7, v7, -0x14

    aput v7, v2, v6

    sget-object v2, La;->v:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->e:[I

    sget-object v8, La;->A:[I

    aget v8, v8, v0

    aget v7, v7, v8

    add-int/lit8 v7, v7, 0x14

    aput v7, v2, v6

    sget-object v2, La;->l:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget-object v7, La;->C:[I

    sget-object v8, La;->A:[I

    aget v8, v8, v0

    aget v7, v7, v8

    aput v7, v2, v6

    sget-object v2, La;->k:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    sget v7, Lg;->aF:I

    neg-int v7, v7

    aput v7, v2, v6

    sget-object v2, La;->i:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    const/16 v7, 0x9

    aput v7, v2, v6

    sget-object v2, La;->j:[I

    sget-object v6, La;->A:[I

    aget v6, v6, v0

    const/4 v7, -0x5

    aput v7, v2, v6

    :cond_1113
    sget-object v6, La;->j:[I

    sget-object v2, La;->j:[I

    aget v2, v2, v0

    const/4 v7, 0x4

    if-le v2, v7, :cond_1155

    const/4 v2, -0x4

    :goto_111d
    aput v2, v6, v0

    sget-object v2, La;->z:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    :cond_1127
    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    const/16 v7, 0x40

    invoke-static {v2, v6, v7}, Lj;->a(III)Z

    move-result v2

    if-eqz v2, :cond_ae

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget v6, Lj;->f:I

    rem-int/2addr v2, v6

    const/16 v6, 0x8

    if-le v2, v6, :cond_ae

    sget-object v2, La;->e:[I

    aget v2, v2, v0

    sget-object v6, La;->f:[I

    aget v6, v6, v0

    invoke-static {v6}, Lj;->d(I)I

    move-result v6

    add-int/lit8 v6, v6, 0x8

    invoke-static {v2, v6}, Lq;->c(II)Z

    goto/16 :goto_ae

    :cond_1155
    sget-object v2, La;->j:[I

    aget v2, v2, v0

    neg-int v2, v2

    goto :goto_111d

    :pswitch_115b  #0x9
    sget-object v2, La;->f:[I

    aget v6, v2, v0

    sget-object v7, La;->j:[I

    aget v7, v7, v0

    add-int/2addr v6, v7

    aput v6, v2, v0

    sget-object v2, La;->j:[I

    aget v6, v2, v0

    add-int/lit8 v6, v6, 0x1

    aput v6, v2, v0

    sget-object v2, La;->B:[I

    aput v5, v2, v0

    sget-object v2, La;->d:[I

    aget v2, v2, v0

    sparse-switch v2, :sswitch_data_135e

    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    if-le v2, v6, :cond_ae

    sget-object v2, La;->f:[I

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    aput v6, v2, v0

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_11ad

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_11ad

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    :cond_11ad
    :goto_11ad
    sget-object v2, La;->i:[I

    aput v9, v2, v0

    goto/16 :goto_ae

    :sswitch_11b3
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    if-le v2, v6, :cond_ae

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_11d6

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_11d6

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto :goto_11ad

    :cond_11d6
    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto/16 :goto_ae

    :sswitch_11dc
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    if-le v2, v6, :cond_ae

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_11ff

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_11ff

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto :goto_11ad

    :cond_11ff
    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto/16 :goto_ae

    :sswitch_1205
    sget-object v2, La;->l:[I

    aget v2, v2, v0

    sget-object v6, La;->C:[I

    aget v6, v6, v0

    shr-int/lit8 v6, v6, 0x1

    if-ge v2, v6, :cond_1226

    sget-object v2, La;->i:[I

    aput v3, v2, v0

    sget-object v2, La;->t:[I

    aput v3, v2, v0

    sget-object v2, La;->j:[I

    const/4 v6, -0x8

    aput v6, v2, v0

    sget-object v2, La;->y:[I

    sget v6, Lg;->aF:I

    shl-int/lit8 v6, v6, 0x3

    aput v6, v2, v0

    :cond_1226
    sget-object v2, La;->f:[I

    aget v2, v2, v0

    sget-object v6, La;->M:[[I

    sget-object v7, La;->J:[I

    aget v7, v7, v0

    aget-object v6, v6, v7

    sget-object v7, La;->H:[I

    aget v7, v7, v0

    aget v6, v6, v7

    if-le v2, v6, :cond_ae

    sget v2, Lg;->as:I

    if-ne v2, v9, :cond_124a

    sget-object v2, La;->m:[I

    aget v2, v2, v0

    if-ne v2, v3, :cond_124a

    sget-object v2, La;->j:[I

    aput v1, v2, v0

    goto/16 :goto_11ad

    :cond_124a
    sget-object v2, La;->i:[I

    aput v5, v2, v0

    goto/16 :goto_ae

    :pswitch_data_1250
    .packed-switch 0x1
        :pswitch_fa9  #00000001
        :pswitch_203  #00000002
        :pswitch_f70  #00000003
        :pswitch_aa1  #00000004
        :pswitch_b2  #00000005
        :pswitch_860  #00000006
        :pswitch_ae  #00000007
        :pswitch_ae  #00000008
        :pswitch_115b  #00000009
    .end packed-switch

    :pswitch_data_1266
    .packed-switch 0x0
        :pswitch_123  #00000000
        :pswitch_123  #00000001
        :pswitch_139  #00000002
        :pswitch_14f  #00000003
        :pswitch_161  #00000004
        :pswitch_17c  #00000005
        :pswitch_17c  #00000006
        :pswitch_192  #00000007
        :pswitch_123  #00000008
        :pswitch_123  #00000009
        :pswitch_14f  #0000000a
        :pswitch_1a4  #0000000b
        :pswitch_123  #0000000c
        :pswitch_1ab  #0000000d
        :pswitch_1c1  #0000000e
        :pswitch_123  #0000000f
        :pswitch_1d7  #00000010
        :pswitch_1ed  #00000011
        :pswitch_161  #00000012
        :pswitch_1c1  #00000013
        :pswitch_1c1  #00000014
        :pswitch_139  #00000015
        :pswitch_17c  #00000016
        :pswitch_123  #00000017
        :pswitch_1a4  #00000018
        :pswitch_1ab  #00000019
        :pswitch_123  #0000001a
        :pswitch_14f  #0000001b
        :pswitch_17c  #0000001c
    .end packed-switch

    :pswitch_data_12a4
    .packed-switch 0x0
        :pswitch_20c  #00000000
        :pswitch_211  #00000001
        :pswitch_257  #00000002
        :pswitch_307  #00000003
        :pswitch_30c  #00000004
        :pswitch_3b7  #00000005
        :pswitch_3bc  #00000006
        :pswitch_3c1  #00000007
        :pswitch_469  #00000008
        :pswitch_4c3  #00000009
        :pswitch_4be  #0000000a
        :pswitch_4d8  #0000000b
        :pswitch_76e  #0000000c
        :pswitch_4dd  #0000000d
        :pswitch_678  #0000000e
        :pswitch_67d  #0000000f
        :pswitch_682  #00000010
        :pswitch_71e  #00000011
        :pswitch_30c  #00000012
        :pswitch_6d7  #00000013
        :pswitch_773  #00000014
        :pswitch_80f  #00000015
        :pswitch_682  #00000016
        :pswitch_7b4  #00000017
        :pswitch_682  #00000018
        :pswitch_5b3  #00000019
        :pswitch_67d  #0000001a
        :pswitch_307  #0000001b
        :pswitch_3b7  #0000001c
    .end packed-switch

    :pswitch_data_12e2
    .packed-switch 0x0
        :pswitch_885  #00000000
        :pswitch_8d3  #00000001
        :pswitch_8d8  #00000002
        :pswitch_8dd  #00000003
        :pswitch_8e2  #00000004
        :pswitch_927  #00000005
        :pswitch_92c  #00000006
        :pswitch_931  #00000007
        :pswitch_936  #00000008
        :pswitch_93b  #00000009
        :pswitch_9ea  #0000000a
        :pswitch_9ef  #0000000b
        :pswitch_a97  #0000000c
        :pswitch_9f4  #0000000d
        :pswitch_a5a  #0000000e
        :pswitch_a5f  #0000000f
        :pswitch_a86  #00000010
        :pswitch_a92  #00000011
        :pswitch_8e2  #00000012
        :pswitch_a8b  #00000013
        :pswitch_a9c  #00000014
        :pswitch_a86  #00000015
        :pswitch_9ef  #00000016
        :pswitch_a64  #00000017
        :pswitch_a5f  #00000018
        :pswitch_9f4  #00000019
        :pswitch_a5f  #0000001a
        :pswitch_8dd  #0000001b
        :pswitch_927  #0000001c
    .end packed-switch

    :pswitch_data_1320
    .packed-switch 0x0
        :pswitch_ad4  #00000000
        :pswitch_ad9  #00000001
        :pswitch_afc  #00000002
        :pswitch_b7d  #00000003
        :pswitch_b82  #00000004
        :pswitch_bff  #00000005
        :pswitch_c04  #00000006
        :pswitch_c47  #00000007
        :pswitch_c4c  #00000008
        :pswitch_c56  #00000009
        :pswitch_c51  #0000000a
        :pswitch_c89  #0000000b
        :pswitch_e7b  #0000000c
        :pswitch_c8e  #0000000d
        :pswitch_d60  #0000000e
        :pswitch_d65  #0000000f
        :pswitch_d6a  #00000010
        :pswitch_d6f  #00000011
        :pswitch_b82  #00000012
        :pswitch_d74  #00000013
        :pswitch_e93  #00000014
        :pswitch_bff  #00000015
        :pswitch_bff  #00000016
        :pswitch_bff  #00000017
        :pswitch_bff  #00000018
        :pswitch_c8e  #00000019
        :pswitch_c89  #0000001a
        :pswitch_b7d  #0000001b
        :pswitch_bff  #0000001c
    .end packed-switch

    :sswitch_data_135e
    .sparse-switch
        0x3 -> :sswitch_11dc
        0x7 -> :sswitch_11dc
        0xa -> :sswitch_11dc
        0xd -> :sswitch_11dc
        0x17 -> :sswitch_1205
        0x18 -> :sswitch_11b3
        0x19 -> :sswitch_11dc
        0x1b -> :sswitch_11dc
    .end sparse-switch
.end method

.method private static b(I)V
    .registers 8

    const/4 v2, 0x0

    sget-object v0, La;->E:[I

    aget v0, v0, p0

    const/16 v1, 0x1e

    if-le v0, v1, :cond_49

    sget-object v0, La;->k:[I

    aget v0, v0, p0

    if-lez v0, :cond_4a

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    :goto_13
    sget-object v1, La;->k:[I

    aget v1, v1, p0

    if-ltz v1, :cond_54

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v3, La;->F:[I

    aget v3, v3, p0

    add-int/2addr v1, v3

    :goto_22
    sget-object v3, La;->f:[I

    aget v3, v3, p0

    sget-object v4, La;->G:[I

    aget v4, v4, p0

    sub-int/2addr v3, v4

    sget-object v4, La;->f:[I

    aget v4, v4, p0

    sget-object v5, La;->G:[I

    aget v5, v5, p0

    add-int/2addr v4, v5

    sget v5, Lg;->ax:I

    const/4 v6, 0x6

    if-ne v5, v6, :cond_59

    move v0, v2

    :goto_3a
    if-eqz v0, :cond_49

    sget-object v0, La;->E:[I

    aput v2, v0, p0

    sget-object v0, La;->i:[I

    const/4 v1, 0x4

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aput v2, v0, p0

    :cond_49
    return-void

    :cond_4a
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->F:[I

    aget v1, v1, p0

    sub-int/2addr v0, v1

    goto :goto_13

    :cond_54
    sget-object v1, La;->e:[I

    aget v1, v1, p0

    goto :goto_22

    :cond_59
    sget-boolean v5, Lg;->ba:Z

    if-eqz v5, :cond_5f

    move v0, v2

    goto :goto_3a

    :cond_5f
    sget v5, Lg;->at:I

    if-ge v5, v0, :cond_65

    move v0, v2

    goto :goto_3a

    :cond_65
    sget v0, Lg;->at:I

    if-le v0, v1, :cond_6b

    move v0, v2

    goto :goto_3a

    :cond_6b
    sget v0, Lg;->au:I

    if-ge v0, v3, :cond_71

    move v0, v2

    goto :goto_3a

    :cond_71
    sget v0, Lg;->au:I

    if-le v0, v4, :cond_77

    move v0, v2

    goto :goto_3a

    :cond_77
    const/4 v0, 0x1

    goto :goto_3a
.end method

.method private static b(II)V
    .registers 10

    const/16 v7, 0x12

    const/4 v1, 0x0

    move v0, v1

    :goto_4
    sget v2, La;->c:I

    if-lt v0, v2, :cond_d

    :cond_8
    sget v2, La;->c:I

    if-ne v0, v2, :cond_17

    :cond_c
    return-void

    :cond_d
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_8

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_17
    move v2, v0

    :goto_18
    add-int v3, v0, p1

    if-ge v2, v3, :cond_c

    sget-object v3, La;->J:[I

    aput p0, v3, v2

    sget-object v3, La;->d:[I

    const/4 v4, 0x2

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    aput v7, v3, v2

    sget-object v3, La;->h:[I

    aput v7, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, 0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x3

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    aput v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_18
.end method

.method public static final b(III)Z
    .registers 9

    const/4 v5, 0x3

    const/4 v1, -0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    sget-object v3, La;->i:[I

    aget v3, v3, p0

    const/4 v4, 0x2

    if-eq v3, v4, :cond_18

    sget-object v3, La;->i:[I

    aget v3, v3, p0

    if-eq v3, v5, :cond_18

    sget-object v3, La;->i:[I

    aget v3, v3, p0

    const/4 v4, 0x4

    if-ne v3, v4, :cond_61

    :cond_18
    sget-object v3, La;->l:[I

    aget v4, v3, p0

    sub-int/2addr v4, p2

    aput v4, v3, p0

    sget-object v3, La;->l:[I

    aget v3, v3, p0

    if-gtz v3, :cond_46

    sget-object v1, La;->l:[I

    aput v2, v1, p0

    sget-object v1, La;->j:[I

    const/4 v3, -0x5

    aput v3, v1, p0

    sget-object v1, La;->y:[I

    sget-object v3, Lq;->ai:[I

    aget v3, v3, p1

    aput v3, v1, p0

    sget-object v1, La;->z:[I

    aput v2, v1, p0

    sget-object v1, La;->t:[I

    aput v2, v1, p0

    sget-object v1, La;->i:[I

    aput v0, v1, p0

    invoke-static {p0}, La;->d(I)V

    :goto_45
    return v0

    :cond_46
    sget-object v3, La;->j:[I

    aput v2, v3, p0

    sget-object v3, La;->k:[I

    sget-object v4, Lq;->ai:[I

    aget v4, v4, p1

    if-gez v4, :cond_63

    :goto_52
    aput v0, v3, p0

    sget-object v0, La;->i:[I

    const/4 v3, 0x6

    aput v3, v0, p0

    sget-object v0, La;->B:[I

    aput v5, v0, p0

    sget-object v0, Lq;->ah:[I

    aput v1, v0, p1

    :cond_61
    move v0, v2

    goto :goto_45

    :cond_63
    move v0, v1

    goto :goto_52
.end method

.method private static c()V
    .registers 1

    sget-object v0, La;->O:[I

    array-length v0, v0

    new-array v0, v0, [[I

    sput-object v0, La;->L:[[I

    sget-object v0, La;->O:[I

    array-length v0, v0

    new-array v0, v0, [[I

    sput-object v0, La;->M:[[I

    sget-object v0, La;->O:[I

    array-length v0, v0

    new-array v0, v0, [[Z

    sput-object v0, La;->N:[[Z

    return-void
.end method

.method private static c(I)V
    .registers 8

    const/4 v3, 0x1

    const/4 v2, 0x0

    sget-object v0, La;->E:[I

    aget v0, v0, p0

    const/16 v1, 0x1e

    if-le v0, v1, :cond_4d

    sget-object v0, La;->k:[I

    aget v0, v0, p0

    if-lez v0, :cond_4e

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    :goto_14
    sget-object v1, La;->k:[I

    aget v1, v1, p0

    if-ltz v1, :cond_58

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v4, La;->F:[I

    aget v4, v4, p0

    add-int/2addr v1, v4

    :goto_23
    sget-object v4, La;->f:[I

    aget v4, v4, p0

    sget-object v5, La;->G:[I

    aget v5, v5, p0

    sub-int/2addr v4, v5

    sget-object v5, La;->f:[I

    aget v5, v5, p0

    sget-object v6, La;->G:[I

    aget v6, v6, p0

    add-int/2addr v5, v6

    sget v6, Lg;->R:I

    if-ge v6, v0, :cond_5d

    move v0, v2

    :goto_3a
    if-eqz v0, :cond_4d

    sget-object v0, La;->E:[I

    aput v2, v0, p0

    sget-object v0, La;->i:[I

    const/4 v1, 0x4

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aput v2, v0, p0

    sget-object v0, La;->K:[Z

    aput-boolean v3, v0, p0

    :cond_4d
    return-void

    :cond_4e
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->F:[I

    aget v1, v1, p0

    sub-int/2addr v0, v1

    goto :goto_14

    :cond_58
    sget-object v1, La;->e:[I

    aget v1, v1, p0

    goto :goto_23

    :cond_5d
    sget v0, Lg;->R:I

    if-le v0, v1, :cond_63

    move v0, v2

    goto :goto_3a

    :cond_63
    sget v0, Lg;->S:I

    if-ge v0, v4, :cond_69

    move v0, v2

    goto :goto_3a

    :cond_69
    sget v0, Lg;->S:I

    if-le v0, v5, :cond_6f

    move v0, v2

    goto :goto_3a

    :cond_6f
    move v0, v3

    goto :goto_3a
.end method

.method private static c(II)V
    .registers 10

    const/4 v7, 0x1

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, La;->c:I

    if-lt v0, v2, :cond_c

    :cond_7
    sget v2, La;->c:I

    if-ne v0, v2, :cond_16

    :cond_b
    return-void

    :cond_c
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_16
    move v2, v0

    :goto_17
    add-int v3, v0, p1

    if-ge v2, v3, :cond_b

    sget-object v3, La;->J:[I

    aput v7, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0x9

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x1e

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0x14

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    aput v7, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x2

    aput v4, v3, v2

    sget-object v3, La;->A:[I

    add-int v4, v2, p1

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    aput v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_17
.end method

.method private static d()V
    .registers 6

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    sget-object v2, La;->O:[I

    array-length v2, v2

    if-lt v0, v2, :cond_e

    move v0, v1

    :goto_8
    sget-object v2, La;->L:[[I

    array-length v2, v2

    if-lt v0, v2, :cond_1c

    return-void

    :cond_e
    sget-object v2, La;->N:[[Z

    sget-object v3, La;->L:[[I

    aget-object v3, v3, v0

    array-length v3, v3

    new-array v3, v3, [Z

    aput-object v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_1c
    move v2, v1

    :goto_1d
    sget-object v3, La;->L:[[I

    aget-object v3, v3, v0

    array-length v3, v3

    if-lt v2, v3, :cond_27

    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    :cond_27
    sget-object v3, La;->L:[[I

    aget-object v3, v3, v0

    sget-object v4, La;->L:[[I

    aget-object v4, v4, v0

    aget v4, v4, v2

    sget v5, Lj;->f:I

    mul-int/2addr v4, v5

    add-int/lit8 v4, v4, 0xc

    aput v4, v3, v2

    sget-object v3, La;->M:[[I

    aget-object v3, v3, v0

    sget-object v4, La;->M:[[I

    aget-object v4, v4, v0

    aget v4, v4, v2

    sget v5, Lj;->f:I

    mul-int/2addr v4, v5

    aput v4, v3, v2

    const/16 v3, 0x8

    if-ne v0, v3, :cond_55

    sget-object v3, La;->M:[[I

    aget-object v3, v3, v0

    aget v4, v3, v2

    add-int/lit8 v4, v4, -0xc

    aput v4, v3, v2

    :cond_55
    add-int/lit8 v2, v2, 0x1

    goto :goto_1d
.end method

.method private static d(I)V
    .registers 8

    const/16 v2, 0xf

    const/4 v6, -0x1

    sget-object v0, La;->q:[I

    sget-object v1, La;->d:[I

    aget v1, v1, p0

    aget v0, v0, v1

    invoke-static {v0}, Lg;->c(I)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x14

    if-le v0, v2, :cond_cc

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->f:[I

    aget v1, v1, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x3

    neg-int v2, v2

    const/4 v3, -0x5

    sget-object v4, La;->D:[I

    aget v4, v4, p0

    shl-int/lit8 v4, v4, 0x2

    sget v5, Lq;->at:I

    add-int/lit8 v5, v5, 0x1

    rem-int/lit8 v5, v5, 0x2

    invoke-static/range {v0 .. v5}, Lq;->a(IIIIII)V

    :goto_33
    sget v0, Lg;->bc:I

    if-eq v0, v6, :cond_a1

    sget v0, Lg;->bc:I

    const/16 v1, 0x9

    if-ge v0, v1, :cond_a1

    sget-object v0, Lc;->g:[I

    sget v1, Lg;->bc:I

    aget v0, v0, v1

    sget-object v1, La;->d:[I

    aget v1, v1, p0

    if-ne v0, v1, :cond_a1

    sget v0, Lg;->bh:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->bh:I

    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, La;->n:[Ljava/lang/String;

    sget-object v2, Lc;->g:[I

    sget v3, Lg;->bc:I

    aget v2, v2, v3

    aget-object v1, v1, v2

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget v1, Lg;->bh:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "#"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget-object v1, Lc;->h:[I

    sget v2, Lg;->bc:I

    aget v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sget v0, Lq;->as:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_a1

    sget v0, Lg;->bh:I

    sget-object v1, Lc;->h:[I

    sget v2, Lg;->bc:I

    aget v1, v1, v2

    if-ne v0, v1, :cond_a1

    sget v0, Lg;->bc:I

    const/4 v1, 0x4

    if-ne v0, v1, :cond_a1

    sput v6, Lg;->bc:I

    const/16 v0, 0x2f

    invoke-static {v0}, Lq;->g(I)V

    :cond_a1
    sget-object v0, La;->d:[I

    aget v0, v0, p0

    sget v1, Lg;->bd:I

    add-int/lit8 v1, v1, -0x64

    if-ne v0, v1, :cond_cb

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    sget v1, Lg;->be:I

    if-ge v0, v1, :cond_cb

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->f:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lq;->a(II)V

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, -0x1c

    invoke-static {v0, v1}, Lq;->b(II)V

    :cond_cb
    return-void

    :cond_cc
    if-ne v0, v2, :cond_ee

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->f:[I

    aget v1, v1, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x2

    neg-int v2, v2

    const/4 v3, -0x4

    sget-object v4, La;->I:[I

    aget v4, v4, p0

    shl-int/lit8 v4, v4, 0x3

    sget v5, Lq;->at:I

    rem-int/lit8 v5, v5, 0xa

    add-int/2addr v4, v5

    invoke-static {v0, v1, v2, v3, v4}, Lq;->a(IIIII)V

    goto/16 :goto_33

    :cond_ee
    sget-object v0, La;->d:[I

    aget v0, v0, p0

    shl-int/lit8 v0, v0, 0x2

    div-int/lit8 v0, v0, 0xa

    add-int/lit8 v0, v0, 0x1

    mul-int/lit8 v0, v0, 0xa

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v2, La;->f:[I

    aget v2, v2, p0

    sget-object v3, La;->k:[I

    aget v3, v3, p0

    shl-int/lit8 v3, v3, 0x1

    neg-int v3, v3

    const/4 v4, -0x6

    invoke-static {v1, v2, v3, v4, v0}, Lq;->a(IIIII)V

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v2, La;->f:[I

    aget v2, v2, p0

    sget-object v3, La;->k:[I

    aget v3, v3, p0

    shl-int/lit8 v3, v3, 0x4

    neg-int v3, v3

    const/4 v4, -0x3

    invoke-static {v1, v2, v3, v4, v0}, Lq;->a(IIIII)V

    goto/16 :goto_33
.end method

.method private static d(II)V
    .registers 8

    const/4 v0, 0x0

    :goto_1
    sget v1, La;->c:I

    if-lt v0, v1, :cond_a

    :cond_5
    sget v1, La;->c:I

    if-ne v0, v1, :cond_14

    :cond_9
    return-void

    :cond_a
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_5

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_14
    move v1, v0

    :goto_15
    add-int v2, v0, p1

    if-ge v1, v2, :cond_9

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0xa

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x50

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x18

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    const/16 v3, 0x14

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    mul-int/lit8 v3, v1, 0x5

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x28

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_15
.end method

.method private static e(I)V
    .registers 4

    const/4 v2, -0x1

    sput p0, La;->c:I

    const/16 v0, 0x46

    sput v0, La;->s:I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->d:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->J:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->e:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->f:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->i:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->u:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->v:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->w:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->x:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->j:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->y:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->z:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->A:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->B:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->k:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->l:[I

    sget v0, La;->c:I

    new-array v0, v0, [Z

    sput-object v0, La;->K:[Z

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->C:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->D:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->E:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->g:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->h:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->h:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->t:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->F:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->G:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->H:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->I:[I

    sget v0, La;->c:I

    new-array v0, v0, [I

    sput-object v0, La;->m:[I

    const/4 v0, 0x0

    :goto_b6
    sget v1, La;->c:I

    if-lt v0, v1, :cond_bb

    return-void

    :cond_bb
    sget-object v1, La;->d:[I

    aput v2, v1, v0

    sget-object v1, La;->m:[I

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_b6
.end method

.method private static e(II)V
    .registers 10

    const/16 v7, 0x14

    const/4 v6, -0x1

    const/4 v0, 0x0

    :goto_4
    sget v1, La;->c:I

    if-lt v0, v1, :cond_d

    :cond_8
    sget v1, La;->c:I

    if-ne v0, v1, :cond_16

    :cond_c
    return-void

    :cond_d
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    if-eq v1, v6, :cond_8

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_16
    move v1, v0

    :goto_17
    add-int v2, v0, p1

    if-ge v1, v2, :cond_c

    sget-object v2, La;->J:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0x11

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x24

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0xa

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    aput v7, v2, v1

    sget-object v2, La;->h:[I

    aput v7, v2, v1

    sget-object v2, La;->k:[I

    aput v6, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    add-int/lit8 v3, v1, 0x3c

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->w:[I

    const/4 v3, 0x2

    aput v3, v2, v1

    sget-object v2, La;->x:[I

    const/4 v3, 0x3

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_17
.end method

.method private static f(I)V
    .registers 6

    const/4 v4, 0x0

    const/4 v3, 0x2

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->w:[I

    aget v2, v2, p0

    shr-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->f:[I

    aget v1, v0, p0

    sget-object v2, La;->x:[I

    aget v2, v2, p0

    shr-int/lit8 v2, v2, 0x3

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->w:[I

    aget v0, v0, p0

    if-nez v0, :cond_2e

    sget-object v0, La;->w:[I

    aput v3, v0, p0

    :cond_2e
    sget-object v0, La;->x:[I

    aget v0, v0, p0

    if-nez v0, :cond_38

    sget-object v0, La;->x:[I

    aput v3, v0, p0

    :cond_38
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/4 v1, 0x5

    if-ne v0, v1, :cond_55

    sget-object v0, La;->i:[I

    aput v3, v0, p0

    sget-object v0, La;->j:[I

    aput v4, v0, p0

    sget-object v0, La;->w:[I

    sget-object v1, La;->x:[I

    aput v4, v1, p0

    aput v4, v0, p0

    sget-object v0, La;->E:[I

    const/16 v1, 0xa

    aput v1, v0, p0

    :cond_55
    return-void
.end method

.method private static f(II)V
    .registers 10

    const/16 v7, 0x14

    const/4 v6, -0x1

    const/4 v0, 0x0

    :goto_4
    sget v1, La;->c:I

    if-lt v0, v1, :cond_d

    :cond_8
    sget v1, La;->c:I

    if-ne v0, v1, :cond_16

    :cond_c
    return-void

    :cond_d
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    if-eq v1, v6, :cond_8

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_16
    move v1, v0

    :goto_17
    add-int v2, v0, p1

    if-ge v1, v2, :cond_c

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0x10

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x18

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0xa

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    aput v7, v2, v1

    sget-object v2, La;->h:[I

    aput v7, v2, v1

    sget-object v2, La;->k:[I

    aput v6, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    add-int/lit8 v3, v1, 0x3c

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->w:[I

    const/4 v3, 0x2

    aput v3, v2, v1

    sget-object v2, La;->x:[I

    const/4 v3, 0x3

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_17
.end method

.method private static g(I)V
    .registers 5

    const/4 v3, 0x4

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->B:[I

    const/4 v1, 0x2

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/4 v1, 0x6

    if-ne v0, v1, :cond_47

    sget-object v0, La;->f:[I

    sget-object v1, La;->M:[[I

    sget-object v2, La;->J:[I

    aget v2, v2, p0

    aget-object v1, v1, v2

    sget-object v2, La;->H:[I

    aget v2, v2, p0

    aget v1, v1, v2

    aput v1, v0, p0

    sget-object v0, La;->i:[I

    aput v3, v0, p0

    sget-object v0, La;->j:[I

    aput v3, v0, p0

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x3

    add-int/2addr v1, v2

    aput v1, v0, p0

    :cond_47
    return-void
.end method

.method private static g(II)V
    .registers 9

    const/4 v6, -0x1

    const/4 v0, 0x0

    :goto_2
    sget v1, La;->c:I

    if-lt v0, v1, :cond_b

    :cond_6
    sget v1, La;->c:I

    if-ne v0, v1, :cond_14

    :cond_a
    return-void

    :cond_b
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    if-eq v1, v6, :cond_6

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_14
    move v1, v0

    :goto_15
    add-int v2, v0, p1

    if-ge v1, v2, :cond_a

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0x16

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x20

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0xa

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x18

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    const/16 v3, 0x10

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    aput v6, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    add-int/lit8 v3, v1, 0x3c

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->w:[I

    const/4 v3, 0x2

    aput v3, v2, v1

    sget-object v2, La;->x:[I

    const/4 v3, 0x3

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_15
.end method

.method private static h(I)V
    .registers 6

    const/4 v4, 0x3

    const/4 v3, 0x0

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_26

    sget-object v0, La;->K:[Z

    aget-boolean v0, v0, p0

    if-eqz v0, :cond_50

    sget-object v0, La;->K:[Z

    aput-boolean v3, v0, p0

    sget-object v0, La;->D:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lg;->b(II)V

    :cond_26
    :goto_26
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    shr-int/lit8 v0, v0, 0x2

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_5c

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    add-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->B:[I

    aput v4, v0, p0

    :goto_3f
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/16 v1, 0xc

    if-ne v0, v1, :cond_4f

    sget-object v0, La;->i:[I

    aput v4, v0, p0

    sget-object v0, La;->j:[I

    aput v3, v0, p0

    :cond_4f
    return-void

    :cond_50
    sget-object v0, La;->D:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lg;->a(II)V

    goto :goto_26

    :cond_5c
    sget-object v0, La;->B:[I

    aput v3, v0, p0

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    aput v1, v0, p0

    goto :goto_3f
.end method

.method private static h(II)V
    .registers 10

    const/4 v7, 0x1

    const/4 v1, 0x0

    move v0, v1

    :goto_3
    sget v2, La;->c:I

    if-lt v0, v2, :cond_c

    :cond_7
    sget v2, La;->c:I

    if-ne v0, v2, :cond_16

    :cond_b
    return-void

    :cond_c
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_16
    move v2, v0

    :goto_17
    add-int v3, v0, p1

    if-ge v2, v3, :cond_b

    sget-object v3, La;->J:[I

    aput p0, v3, v2

    sget-object v3, La;->d:[I

    aput v7, v3, v2

    sget-object v3, La;->F:[I

    const/16 v4, 0x19

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x1b

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0xf

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    aput v7, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    mul-int/lit8 v4, v2, 0x7

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    aput v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_17
.end method

.method private static i(I)V
    .registers 6

    const/16 v4, 0xc

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ge v0, v2, :cond_3f

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x2

    add-int/2addr v1, v2

    aput v1, v0, p0

    :cond_1f
    :goto_1f
    sget-object v0, La;->B:[I

    const/4 v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-le v0, v3, :cond_3e

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/16 v1, 0x9

    if-ge v0, v1, :cond_3e

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_3e

    sget-object v0, La;->B:[I

    aput v3, v0, p0

    :cond_3e
    return-void

    :cond_3f
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ne v0, v2, :cond_69

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lg;->aB:I

    add-int/lit8 v1, v1, 0xd

    if-ge v0, v1, :cond_1f

    sget-object v0, La;->D:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lg;->a(II)V

    goto :goto_1f

    :cond_69
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ge v0, v4, :cond_7d

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    aput v1, v0, p0

    goto :goto_1f

    :cond_7d
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ne v0, v4, :cond_1f

    sget-object v0, La;->f:[I

    sget-object v1, La;->M:[[I

    sget-object v2, La;->J:[I

    aget v2, v2, p0

    aget-object v1, v1, v2

    sget-object v2, La;->H:[I

    aget v2, v2, p0

    aget v1, v1, v2

    aput v1, v0, p0

    sget-object v0, La;->i:[I

    aput v3, v0, p0

    sget-object v0, La;->y:[I

    const/4 v1, -0x4

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    goto/16 :goto_1f
.end method

.method private static i(II)V
    .registers 8

    const/4 v0, 0x0

    :goto_1
    sget v1, La;->c:I

    if-lt v0, v1, :cond_a

    :cond_5
    sget v1, La;->c:I

    if-ne v0, v1, :cond_14

    :cond_9
    return-void

    :cond_a
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_5

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_14
    move v1, v0

    :goto_15
    add-int v2, v0, p1

    if-ge v1, v2, :cond_9

    sget-object v2, La;->J:[I

    const/4 v3, 0x2

    aput v3, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0xb

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x24

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0x14

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x22

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    const/16 v3, 0x20

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    mul-int/lit8 v3, v1, 0x6

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_15
.end method

.method private static j(I)V
    .registers 5

    const/4 v3, 0x1

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    if-nez v0, :cond_25

    sget-object v0, La;->B:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->B:[I

    aget v0, v0, p0

    if-le v0, v3, :cond_1a

    sget-object v0, La;->B:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    :cond_1a
    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    add-int/2addr v1, v2

    aput v1, v0, p0

    :cond_25
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->v:[I

    aget v1, v1, p0

    if-le v0, v1, :cond_41

    sget-object v0, La;->k:[I

    const/4 v1, -0x1

    aput v1, v0, p0

    :cond_34
    :goto_34
    invoke-static {p0}, La;->b(I)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x9

    if-nez v0, :cond_40

    invoke-static {p0}, La;->c(I)V

    :cond_40
    return-void

    :cond_41
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->u:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_34

    sget-object v0, La;->k:[I

    aput v3, v0, p0

    goto :goto_34
.end method

.method private static j(II)V
    .registers 11

    const/16 v8, 0x3c

    const/16 v7, 0x10

    const/4 v6, 0x3

    const/4 v0, 0x0

    :goto_6
    sget v1, La;->c:I

    if-lt v0, v1, :cond_f

    :cond_a
    sget v1, La;->c:I

    if-ne v0, v1, :cond_19

    :cond_e
    return-void

    :cond_f
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_a

    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_19
    move v1, v0

    :goto_1a
    add-int v2, v0, p1

    if-ge v1, v2, :cond_e

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    aput v6, v2, v1

    sget-object v2, La;->F:[I

    aput v8, v2, v1

    sget-object v2, La;->G:[I

    aput v8, v2, v1

    sget-object v2, La;->g:[I

    aput v7, v2, v1

    sget-object v2, La;->h:[I

    aput v7, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    sget v3, La;->s:I

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->w:[I

    const/4 v3, 0x2

    aput v3, v2, v1

    sget-object v2, La;->x:[I

    aput v6, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1a
.end method

.method private static k(I)V
    .registers 5

    const/4 v3, 0x1

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    if-ne v0, v3, :cond_36

    sget-object v0, La;->B:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->B:[I

    aget v0, v0, p0

    if-le v0, v3, :cond_1a

    sget-object v0, La;->B:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    :cond_1a
    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x1

    add-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->v:[I

    aget v1, v1, p0

    if-le v0, v1, :cond_3a

    sget-object v0, La;->k:[I

    const/4 v1, -0x1

    aput v1, v0, p0

    :cond_36
    :goto_36
    invoke-static {p0}, La;->b(I)V

    return-void

    :cond_3a
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->u:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_36

    sget-object v0, La;->k:[I

    aput v3, v0, p0

    goto :goto_36
.end method

.method private static k(II)V
    .registers 10

    const/16 v7, 0x3c

    const/16 v6, 0x10

    const/4 v0, 0x0

    :goto_5
    sget v1, La;->c:I

    if-lt v0, v1, :cond_e

    :cond_9
    sget v1, La;->c:I

    if-ne v0, v1, :cond_18

    :cond_d
    return-void

    :cond_e
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_9

    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_18
    move v1, v0

    :goto_19
    add-int v2, v0, p1

    if-ge v1, v2, :cond_d

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0x1b

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    aput v7, v2, v1

    sget-object v2, La;->G:[I

    aput v7, v2, v1

    sget-object v2, La;->g:[I

    aput v6, v2, v1

    sget-object v2, La;->h:[I

    aput v6, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    sget v3, La;->s:I

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->w:[I

    const/4 v3, 0x2

    aput v3, v2, v1

    sget-object v2, La;->x:[I

    const/4 v3, 0x3

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_19
.end method

.method private static l(I)V
    .registers 7

    const/16 v2, 0x14

    const/16 v5, 0xa

    const/4 v4, 0x1

    const/4 v3, 0x0

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget v1, Lg;->at:I

    if-ge v0, v1, :cond_a1

    sget-object v0, La;->w:[I

    sget v1, Lq;->at:I

    add-int/2addr v1, p0

    rem-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, 0x3

    aput v1, v0, p0

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-le v0, v2, :cond_2a

    sget-object v0, La;->k:[I

    aput v4, v0, p0

    :cond_2a
    :goto_2a
    sget v0, Lq;->at:I

    add-int/2addr v0, p0

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_43

    sget-object v0, La;->f:[I

    aget v0, v0, p0

    sget v1, Lg;->au:I

    if-ge v0, v1, :cond_c9

    sget-object v0, La;->x:[I

    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, 0x3

    aput v1, v0, p0

    :cond_43
    :goto_43
    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->w:[I

    aget v2, v2, p0

    add-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->f:[I

    aget v1, v0, p0

    sget-object v2, La;->x:[I

    aget v2, v2, p0

    add-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->B:[I

    aget v0, v0, p0

    if-ne v0, v4, :cond_de

    sget-object v0, La;->B:[I

    const/4 v1, 0x3

    aput v1, v0, p0

    :goto_64
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v5, :cond_a0

    sget-object v0, La;->f:[I

    aget v0, v0, p0

    sget v1, Lg;->au:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v5, :cond_a0

    sget-object v0, La;->E:[I

    aput v3, v0, p0

    sget-object v0, La;->K:[Z

    aget-boolean v0, v0, p0

    if-eqz v0, :cond_e3

    sget-object v0, La;->K:[Z

    aput-boolean v3, v0, p0

    sget-object v0, La;->D:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lg;->b(II)V

    :goto_97
    sget-object v0, La;->j:[I

    aput v3, v0, p0

    sget-object v0, La;->i:[I

    const/4 v1, 0x2

    aput v1, v0, p0

    :cond_a0
    return-void

    :cond_a1
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget v1, Lg;->at:I

    if-le v0, v1, :cond_2a

    sget-object v0, La;->w:[I

    sget v1, Lq;->at:I

    sub-int/2addr v1, p0

    neg-int v1, v1

    rem-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, -0x3

    aput v1, v0, p0

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-le v0, v2, :cond_2a

    sget-object v0, La;->k:[I

    const/4 v1, -0x1

    aput v1, v0, p0

    goto/16 :goto_2a

    :cond_c9
    sget-object v0, La;->f:[I

    aget v0, v0, p0

    sget v1, Lg;->au:I

    if-le v0, v1, :cond_43

    sget-object v0, La;->x:[I

    sget v1, Lq;->at:I

    neg-int v1, v1

    rem-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, -0x3

    aput v1, v0, p0

    goto/16 :goto_43

    :cond_de
    sget-object v0, La;->B:[I

    aput v4, v0, p0

    goto :goto_64

    :cond_e3
    sget-object v0, La;->D:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lg;->a(II)V

    goto :goto_97
.end method

.method private static l(II)V
    .registers 11

    const/16 v8, 0x14

    const/16 v7, 0xf

    const/4 v1, 0x0

    move v0, v1

    :goto_6
    sget v2, La;->c:I

    if-lt v0, v2, :cond_f

    :cond_a
    sget v2, La;->c:I

    if-ne v0, v2, :cond_19

    :cond_e
    return-void

    :cond_f
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_a

    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_19
    move v2, v0

    :goto_1a
    add-int v3, v0, p1

    if-ge v2, v3, :cond_e

    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    aput v7, v3, v2

    sget-object v3, La;->F:[I

    aput v8, v3, v2

    sget-object v3, La;->G:[I

    aput v8, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    aput v7, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, 0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x1

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    aput v1, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1a
.end method

.method private static m(I)V
    .registers 6

    const/4 v4, 0x0

    const/4 v3, 0x2

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->w:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->f:[I

    aget v1, v0, p0

    sget-object v2, La;->x:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->w:[I

    aget v0, v0, p0

    if-nez v0, :cond_2a

    sget-object v0, La;->w:[I

    aput v3, v0, p0

    :cond_2a
    sget-object v0, La;->x:[I

    aget v0, v0, p0

    if-nez v0, :cond_34

    sget-object v0, La;->x:[I

    aput v3, v0, p0

    :cond_34
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/4 v1, 0x5

    if-ne v0, v1, :cond_4f

    sget-object v0, La;->i:[I

    aput v3, v0, p0

    sget-object v0, La;->j:[I

    aput v4, v0, p0

    sget-object v0, La;->w:[I

    sget-object v1, La;->x:[I

    aput v4, v1, p0

    aput v4, v0, p0

    sget-object v0, La;->E:[I

    aput v4, v0, p0

    :cond_4f
    sget-object v0, La;->B:[I

    aput v3, v0, p0

    return-void
.end method

.method private static m(II)V
    .registers 9

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    sget v2, La;->c:I

    if-lt v0, v2, :cond_b

    :cond_6
    sget v2, La;->c:I

    if-ne v0, v2, :cond_15

    :cond_a
    return-void

    :cond_b
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_6

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_15
    move v2, v0

    :goto_16
    add-int v3, v0, p1

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    aput v1, v3, v2

    sget-object v3, La;->F:[I

    const/4 v4, 0x7

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0xf

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, 0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x3

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_16
.end method

.method private static n(I)V
    .registers 9

    const/4 v7, 0x3

    const/16 v6, -0x28

    const/16 v5, 0x28

    const/4 v0, 0x1

    const/4 v4, 0x0

    sget-object v1, La;->e:[I

    aget v2, v1, p0

    sget-object v3, La;->w:[I

    aget v3, v3, p0

    add-int/2addr v2, v3

    aput v2, v1, p0

    sget-object v1, La;->f:[I

    aget v2, v1, p0

    sget-object v3, La;->x:[I

    aget v3, v3, p0

    add-int/2addr v2, v3

    aput v2, v1, p0

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    if-gez v1, :cond_27

    sget-object v1, La;->e:[I

    aput v4, v1, p0

    :cond_27
    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget v2, Lj;->c:I

    add-int/lit8 v2, v2, -0xa

    if-le v1, v2, :cond_39

    sget-object v1, La;->e:[I

    sget v2, Lj;->c:I

    add-int/lit8 v2, v2, -0xa

    aput v2, v1, p0

    :cond_39
    sget-object v1, La;->f:[I

    aget v1, v1, p0

    if-gez v1, :cond_43

    sget-object v1, La;->f:[I

    aput v4, v1, p0

    :cond_43
    sget-object v1, La;->f:[I

    aget v1, v1, p0

    sget v2, Lj;->d:I

    add-int/lit8 v2, v2, -0x14

    if-le v1, v2, :cond_55

    sget-object v1, La;->f:[I

    sget v2, Lj;->d:I

    add-int/lit8 v2, v2, -0x14

    aput v2, v1, p0

    :cond_55
    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v2, La;->u:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    if-le v1, v5, :cond_6b

    sget-object v1, La;->w:[I

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    add-int/lit8 v2, v2, 0x1

    neg-int v2, v2

    aput v2, v1, p0

    :cond_6b
    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v2, La;->u:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    if-ge v1, v6, :cond_80

    sget-object v1, La;->w:[I

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, p0

    :cond_80
    sget-object v1, La;->f:[I

    aget v1, v1, p0

    sget-object v2, La;->v:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    if-le v1, v5, :cond_96

    sget-object v1, La;->x:[I

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    add-int/lit8 v2, v2, 0x1

    neg-int v2, v2

    aput v2, v1, p0

    :cond_96
    sget-object v1, La;->f:[I

    aget v1, v1, p0

    sget-object v2, La;->v:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    if-ge v1, v6, :cond_ab

    sget-object v1, La;->x:[I

    sget v2, Lq;->at:I

    rem-int/lit8 v2, v2, 0x2

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, p0

    :cond_ab
    sget v1, Lq;->at:I

    add-int/lit8 v2, p0, 0x1f

    rem-int/2addr v1, v2

    if-nez v1, :cond_112

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget v2, Lg;->at:I

    sub-int/2addr v1, v2

    invoke-static {v1}, Lq;->a(I)I

    move-result v1

    if-le v1, v5, :cond_fb

    sget-object v1, La;->e:[I

    aget v1, v1, p0

    sget-object v2, La;->f:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, 0x6

    const/4 v3, 0x2

    invoke-static {v1, v2, v3}, Lj;->a(III)Z

    move-result v1

    if-eqz v1, :cond_fb

    sget v1, Lq;->at:I

    rem-int/lit8 v1, v1, 0x2

    if-nez v1, :cond_fb

    sget-object v1, La;->i:[I

    aput v7, v1, p0

    sget-object v1, La;->k:[I

    sget v2, Lg;->at:I

    sget-object v3, La;->e:[I

    aget v3, v3, p0

    if-le v2, v3, :cond_f9

    :goto_e4
    aput v0, v1, p0

    sget-object v0, La;->j:[I

    aput v4, v0, p0

    sget-object v0, La;->f:[I

    sget-object v1, La;->f:[I

    aget v1, v1, p0

    add-int/lit8 v1, v1, 0x6

    invoke-static {v1}, Lj;->d(I)I

    move-result v1

    aput v1, v0, p0

    :cond_f8
    :goto_f8
    return-void

    :cond_f9
    const/4 v0, -0x1

    goto :goto_e4

    :cond_fb
    sget-object v1, La;->w:[I

    sget v2, Lq;->at:I

    add-int/2addr v2, p0

    rem-int/lit8 v2, v2, 0x3

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, p0

    sget-object v1, La;->x:[I

    sget v2, Lq;->at:I

    shr-int/lit8 v2, v2, 0x1

    rem-int/lit8 v2, v2, 0x3

    add-int/lit8 v2, v2, -0x1

    aput v2, v1, p0

    :cond_112
    sget-object v1, La;->B:[I

    aget v1, v1, p0

    if-ne v1, v0, :cond_129

    sget-object v0, La;->B:[I

    aput v7, v0, p0

    :goto_11c
    invoke-static {p0}, La;->b(I)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_f8

    invoke-static {p0}, La;->c(I)V

    goto :goto_f8

    :cond_129
    sget-object v1, La;->B:[I

    aput v0, v1, p0

    goto :goto_11c
.end method

.method private static n(II)V
    .registers 8

    const/4 v0, 0x0

    :goto_1
    sget v1, La;->c:I

    if-lt v0, v1, :cond_a

    :cond_5
    sget v1, La;->c:I

    if-ne v0, v1, :cond_14

    :cond_9
    return-void

    :cond_a
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_5

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_14
    move v1, v0

    :goto_15
    add-int v2, v0, p1

    if-ge v1, v2, :cond_9

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    const/16 v3, 0x13

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x50

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x16

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    const/16 v3, 0x10

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    const/16 v3, 0x3e

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x46

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_15
.end method

.method private static o(I)V
    .registers 4

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/4 v1, 0x5

    if-ne v0, v1, :cond_1f

    sget-object v0, La;->i:[I

    const/4 v1, 0x2

    aput v1, v0, p0

    :cond_1f
    return-void
.end method

.method private static o(II)V
    .registers 8

    const/4 v0, 0x0

    :goto_1
    sget v1, La;->c:I

    if-lt v0, v1, :cond_a

    :cond_5
    sget v1, La;->c:I

    if-ne v0, v1, :cond_14

    :cond_9
    return-void

    :cond_a
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_5

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_14
    move v1, v0

    :goto_15
    add-int v2, v0, p1

    if-ge v1, v2, :cond_9

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    const/4 v3, 0x6

    aput v3, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x50

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0xa

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x16

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    const/16 v3, 0x18

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    const/4 v3, 0x5

    aput v3, v2, v1

    sget-object v2, La;->j:[I

    shl-int/lit8 v3, v1, 0x1

    add-int/lit8 v3, v3, 0x32

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x1f4

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_15
.end method

.method private static p(I)V
    .registers 6

    const/16 v4, 0xc

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ge v0, v2, :cond_24

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x2

    add-int/2addr v1, v2

    aput v1, v0, p0

    :cond_1f
    :goto_1f
    sget-object v0, La;->B:[I

    aput v3, v0, p0

    return-void

    :cond_24
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ne v0, v2, :cond_4e

    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sget v1, Lg;->aB:I

    add-int/lit8 v1, v1, 0xd

    if-ge v0, v1, :cond_1f

    sget-object v0, La;->D:[I

    aget v0, v0, p0

    sget-object v1, La;->k:[I

    aget v1, v1, p0

    invoke-static {v0, v1}, Lg;->a(II)V

    goto :goto_1f

    :cond_4e
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ge v0, v4, :cond_62

    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    shl-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    aput v1, v0, p0

    goto :goto_1f

    :cond_62
    sget-object v0, La;->j:[I

    aget v0, v0, p0

    if-ne v0, v4, :cond_1f

    sget-object v0, La;->f:[I

    sget-object v1, La;->M:[[I

    sget-object v2, La;->J:[I

    aget v2, v2, p0

    aget-object v1, v1, v2

    sget-object v2, La;->H:[I

    aget v2, v2, p0

    aget v1, v1, v2

    aput v1, v0, p0

    sget-object v0, La;->i:[I

    aput v3, v0, p0

    sget-object v0, La;->y:[I

    const/4 v1, -0x4

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    goto :goto_1f
.end method

.method private static p(II)V
    .registers 9

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    sget v2, La;->c:I

    if-lt v0, v2, :cond_b

    :cond_6
    sget v2, La;->c:I

    if-ne v0, v2, :cond_15

    :cond_a
    return-void

    :cond_b
    sget-object v2, La;->d:[I

    aget v2, v2, v0

    const/4 v3, -0x1

    if-eq v2, v3, :cond_6

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_15
    move v2, v0

    :goto_16
    add-int v3, v0, p1

    if-ge v2, v3, :cond_a

    sget-object v3, La;->J:[I

    aput v1, v3, v2

    sget-object v3, La;->d:[I

    const/16 v4, 0xc

    aput v4, v3, v2

    sget-object v3, La;->F:[I

    const/4 v4, 0x7

    aput v4, v3, v2

    sget-object v3, La;->G:[I

    const/16 v4, 0xa

    aput v4, v3, v2

    sget-object v3, La;->g:[I

    const/16 v4, 0x10

    aput v4, v3, v2

    sget-object v3, La;->h:[I

    const/16 v4, 0xf

    aput v4, v3, v2

    sget-object v3, La;->k:[I

    const/4 v4, 0x1

    aput v4, v3, v2

    sget-object v3, La;->i:[I

    const/4 v4, 0x5

    aput v4, v3, v2

    sget-object v3, La;->j:[I

    shl-int/lit8 v4, v2, 0x3

    aput v4, v3, v2

    sget-object v3, La;->l:[I

    sget-object v4, La;->C:[I

    sget-object v5, La;->o:[I

    sget-object v6, La;->d:[I

    aget v6, v6, v2

    aget v5, v5, v6

    aput v5, v4, v2

    aput v5, v3, v2

    sget-object v3, La;->D:[I

    sget-object v4, La;->a:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->I:[I

    sget-object v4, La;->p:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v2

    aget v4, v4, v5

    aput v4, v3, v2

    sget-object v3, La;->E:[I

    const/16 v4, 0x64

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_16
.end method

.method private static q(I)V
    .registers 4

    const/4 v2, 0x2

    sget-object v0, La;->j:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->j:[I

    aget v0, v0, p0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_19

    sget-object v0, La;->i:[I

    aput v2, v0, p0

    sget-object v0, La;->j:[I

    const/4 v1, 0x1

    aput v1, v0, p0

    :cond_19
    sget-object v0, La;->B:[I

    aput v2, v0, p0

    return-void
.end method

.method private static q(II)V
    .registers 9

    const/4 v6, 0x5

    const/4 v0, 0x0

    :goto_2
    sget v1, La;->c:I

    if-lt v0, v1, :cond_b

    :cond_6
    sget v1, La;->c:I

    if-ne v0, v1, :cond_15

    :cond_a
    return-void

    :cond_b
    sget-object v1, La;->d:[I

    aget v1, v1, v0

    const/4 v2, -0x1

    if-eq v1, v2, :cond_6

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_15
    move v1, v0

    :goto_16
    add-int v2, v0, p1

    if-ge v1, v2, :cond_a

    sget-object v2, La;->J:[I

    aput p0, v2, v1

    sget-object v2, La;->d:[I

    aput v6, v2, v1

    sget-object v2, La;->F:[I

    const/16 v3, 0x24

    aput v3, v2, v1

    sget-object v2, La;->G:[I

    const/16 v3, 0x14

    aput v3, v2, v1

    sget-object v2, La;->g:[I

    const/16 v3, 0x16

    aput v3, v2, v1

    sget-object v2, La;->h:[I

    const/16 v3, 0x18

    aput v3, v2, v1

    sget-object v2, La;->k:[I

    const/4 v3, 0x1

    aput v3, v2, v1

    sget-object v2, La;->i:[I

    aput v6, v2, v1

    sget-object v2, La;->j:[I

    mul-int/lit8 v3, v1, 0x6

    aput v3, v2, v1

    sget-object v2, La;->l:[I

    sget-object v3, La;->C:[I

    sget-object v4, La;->o:[I

    sget-object v5, La;->d:[I

    aget v5, v5, v1

    aget v4, v4, v5

    aput v4, v3, v1

    aput v4, v2, v1

    sget-object v2, La;->D:[I

    sget-object v3, La;->a:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->I:[I

    sget-object v3, La;->p:[I

    sget-object v4, La;->d:[I

    aget v4, v4, v1

    aget v3, v3, v4

    aput v3, v2, v1

    sget-object v2, La;->E:[I

    const/16 v3, 0x64

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_16
.end method

.method private static r(I)V
    .registers 5

    const/4 v3, 0x1

    sget v0, Lq;->at:I

    add-int/2addr v0, p0

    rem-int/lit8 v0, v0, 0x4

    if-nez v0, :cond_26

    sget-object v0, La;->B:[I

    aget v1, v0, p0

    add-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, La;->B:[I

    aget v0, v0, p0

    if-le v0, v3, :cond_1b

    sget-object v0, La;->B:[I

    const/4 v1, 0x0

    aput v1, v0, p0

    :cond_1b
    sget-object v0, La;->e:[I

    aget v1, v0, p0

    sget-object v2, La;->k:[I

    aget v2, v2, p0

    add-int/2addr v1, v2

    aput v1, v0, p0

    :cond_26
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->v:[I

    aget v1, v1, p0

    if-le v0, v1, :cond_42

    sget-object v0, La;->k:[I

    const/4 v1, -0x1

    aput v1, v0, p0

    :cond_35
    :goto_35
    invoke-static {p0}, La;->b(I)V

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_41

    invoke-static {p0}, La;->c(I)V

    :cond_41
    return-void

    :cond_42
    sget-object v0, La;->e:[I

    aget v0, v0, p0

    sget-object v1, La;->u:[I

    aget v1, v1, p0

    if-ge v0, v1, :cond_35

    sget-object v0, La;->k:[I

    aput v3, v0, p0

    goto :goto_35
.end method
