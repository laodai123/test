.class public final Li;
.super Ljava/lang/Object;


# static fields
.field public static a:I

.field public static b:I

.field private static c:Z

.field private static d:I

.field private static e:I

.field private static f:Ljavax/microedition/lcdui/Image;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x1

    sput-boolean v0, Li;->c:Z

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 3

    const/4 v0, 0x0

    sget-boolean v1, Li;->c:Z

    if-nez v1, :cond_6

    :goto_5
    return-void

    :cond_6
    sget v1, Li;->e:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Li;->e:I

    const/16 v2, 0xa

    if-le v1, v2, :cond_12

    sput v0, Li;->e:I

    :cond_12
    sget v1, Li;->e:I

    const/4 v2, 0x5

    if-le v1, v2, :cond_1a

    :goto_17
    sput v0, Li;->d:I

    goto :goto_5

    :cond_1a
    const/4 v0, 0x1

    goto :goto_17
.end method

.method public static a(I)V
    .registers 3

    const/4 v1, 0x1

    const/4 v0, 0x0

    sput-boolean v0, Li;->c:Z

    const/4 v0, 0x2

    if-ne p0, v0, :cond_25

    sget v0, Lg;->bc:I

    if-ne v0, v1, :cond_25

    sget-boolean v0, Lg;->h:Z

    if-nez v0, :cond_25

    sget-boolean v0, Lg;->bf:Z

    if-nez v0, :cond_25

    sput-boolean v1, Li;->c:Z

    :try_start_15
    const-string v0, "/cp/girlbath.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Li;->f:Ljavax/microedition/lcdui/Image;
    :try_end_1d
    .catch Ljava/io/IOException; {:try_start_15 .. :try_end_1d} :catch_26

    :goto_1d
    const/16 v0, 0x150

    sput v0, Li;->a:I

    const/16 v0, 0x228

    sput v0, Li;->b:I

    :cond_25
    return-void

    :catch_26
    move-exception v0

    goto :goto_1d
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 11

    const/4 v2, 0x0

    sget-boolean v0, Li;->c:Z

    if-nez v0, :cond_6

    :goto_5
    return-void

    :cond_6
    sget-object v1, Li;->f:Ljavax/microedition/lcdui/Image;

    sget v0, Li;->d:I

    shl-int/lit8 v3, v0, 0x5

    const/16 v4, 0x18

    const/16 v5, 0x20

    sget v7, Li;->a:I

    sget v8, Li;->b:I

    const/16 v9, 0x21

    move-object v0, p0

    move v6, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_5
.end method
