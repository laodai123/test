.class public final Lj;
.super Ljava/lang/Object;


# static fields
.field private static A:Ljavax/microedition/lcdui/Image;

.field private static B:Ljavax/microedition/lcdui/Image;

.field private static C:Ljavax/microedition/lcdui/Image;

.field private static D:[Ljavax/microedition/lcdui/Image;

.field private static E:I

.field private static F:[I

.field private static G:[I

.field private static H:[I

.field private static I:[I

.field private static J:[I

.field private static K:Ljavax/microedition/lcdui/Image;

.field private static L:I

.field private static M:I

.field private static N:I

.field private static O:I

.field private static P:[Ljava/lang/String;

.field private static Q:[I

.field private static R:[I

.field private static S:[I

.field private static T:I

.field public static a:I

.field public static b:I

.field public static c:I

.field public static d:I

.field public static e:Ljavax/microedition/lcdui/Image;

.field public static f:I

.field public static g:I

.field public static h:I

.field public static i:I

.field public static j:I

.field public static k:I

.field public static l:I

.field public static m:I

.field public static n:I

.field public static o:I

.field public static p:I

.field public static q:I

.field public static r:I

.field public static s:I

.field public static t:I

.field public static u:I

.field public static v:I

.field private static w:[C

.field private static x:[I

.field private static y:[Z

.field private static z:Ljavax/microedition/lcdui/Image;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x18

    sput v0, Lj;->f:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final a(II)I
    .registers 4

    :try_start_0
    sget-object v0, Lj;->x:[I

    sget v1, Lj;->a:I

    mul-int/2addr v1, p1

    add-int/2addr v1, p0

    aget v0, v0, v1
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9

    :goto_8
    return v0

    :catch_9
    move-exception v0

    const/16 v0, 0x3e8

    goto :goto_8
.end method

.method public static a()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    return-void
.end method

.method public static a(I)V
    .registers 9

    const/16 v7, 0x155

    const/16 v6, 0xad

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    sput v3, Lj;->T:I

    if-nez p0, :cond_58

    const/16 v0, 0x8

    sput v0, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Bộ môn Khí"

    const/16 v1, 0x414

    const/16 v2, 0x150

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Cô Ayumi"

    const/16 v1, 0x414

    const/16 v2, 0x15b

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Bộ môn Lực"

    const/16 v1, 0x414

    const/16 v2, 0xd8

    invoke-static {v5, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const/4 v0, 0x3

    const-string v1, "Thầy Hiroyaki"

    const/16 v2, 0x414

    const/16 v3, 0xe3

    invoke-static {v0, v1, v2, v3}, Lj;->a(ILjava/lang/String;II)V

    const/4 v0, 0x4

    const-string v1, "Kí Túc Xá"

    const/16 v2, 0x1bc

    invoke-static {v0, v1, v2, v7}, Lj;->a(ILjava/lang/String;II)V

    const/4 v0, 0x5

    const-string v1, "* Khu luyện tập"

    const/16 v2, 0x48

    invoke-static {v0, v1, v2, v7}, Lj;->a(ILjava/lang/String;II)V

    const/4 v0, 0x6

    const-string v1, "Bán HP-MP"

    const/16 v2, 0x264

    invoke-static {v0, v1, v2, v7}, Lj;->a(ILjava/lang/String;II)V

    const/4 v0, 0x7

    const-string v1, "Bán đồ tiền thật"

    const/16 v2, 0x114

    invoke-static {v0, v1, v2, v7}, Lj;->a(ILjava/lang/String;II)V

    :cond_57
    :goto_57
    return-void

    :cond_58
    if-ne p0, v4, :cond_6e

    sput v5, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Trường /"

    const/16 v1, 0x54c

    invoke-static {v3, v0, v1, v6}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "* Thác nước"

    const/16 v1, 0x30

    invoke-static {v4, v0, v1, v6}, Lj;->a(ILjava/lang/String;II)V

    goto :goto_57

    :cond_6e
    if-ne p0, v5, :cond_88

    sput v5, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Trường /"

    const/16 v1, 0x1a4

    const/16 v2, 0x4d

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "* Thôn Suzuya"

    const/16 v1, 0x78

    const/16 v2, 0x35

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto :goto_57

    :cond_88
    const/4 v0, 0x4

    if-ne p0, v0, :cond_a9

    const/4 v0, 0x3

    sput v0, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Làng mỹ nghệ"

    const/16 v1, 0x6d8

    invoke-static {v3, v0, v1, v6}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "T O N E"

    const/16 v1, 0x6d8

    const/16 v2, 0xdd

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "* Vách Ichidai"

    const/16 v1, 0x1b0

    invoke-static {v5, v0, v1, v6}, Lj;->a(ILjava/lang/String;II)V

    goto :goto_57

    :cond_a9
    const/4 v0, 0x5

    if-ne p0, v0, :cond_ce

    const/4 v0, 0x3

    sput v0, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Làng Tone /"

    const/16 v1, 0x270

    const/16 v2, 0x70d

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Vách đá Ichidai"

    const/16 v1, 0x150

    const/16 v2, 0x6dd

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "đỉnh núi /"

    const/16 v1, 0x258

    const/16 v2, 0x35

    invoke-static {v5, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto :goto_57

    :cond_ce
    const/4 v0, 0x6

    if-ne p0, v0, :cond_ea

    sput v5, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Nơi phóng diều lượn /"

    const/16 v1, 0x240

    const/16 v2, 0x4d

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "đồi Kokoro /"

    const/16 v1, 0x6f0

    const/16 v2, 0x10d

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_ea
    const/4 v0, 0x7

    if-ne p0, v0, :cond_104

    sput v5, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Cánh đồng Fuki /"

    const/16 v1, 0x828

    invoke-static {v3, v0, v1, v6}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Mua đồ tiền thật"

    const/16 v1, 0x6a8

    const/16 v2, 0x95

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_104
    const/16 v0, 0x8

    if-ne p0, v0, :cond_121

    sput v5, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Trường học Haruna /"

    const/16 v1, 0xb94

    const/16 v2, 0x95

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Về làng Suzuya"

    const/16 v1, 0xbb8

    const/16 v2, 0xf5

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_121
    const/16 v0, 0x9

    if-ne p0, v0, :cond_146

    const/4 v0, 0x3

    sput v0, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Trường Ninja"

    const/16 v1, 0x354

    const/16 v2, 0x12a

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "H A R U N A"

    const/16 v1, 0x354

    const/16 v2, 0x13d

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Ký túc xá /"

    const/16 v1, 0x96c

    invoke-static {v5, v0, v1, v7}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_146
    const/16 v0, 0xa

    if-ne p0, v0, :cond_158

    sput v4, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Ký túc xá"

    const/16 v1, 0x1e0

    invoke-static {v3, v0, v1, v6}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_158
    const/16 v0, 0xc

    if-ne p0, v0, :cond_17f

    const/4 v0, 0x3

    sput v0, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Suối nước nóng AKAGI"

    const/16 v1, 0x228

    const/16 v2, 0x7d

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Bán đồ tiền thật"

    const/16 v1, 0x168

    const/16 v2, 0x7d

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Bờ biển /"

    const/16 v1, 0xaa6

    const/16 v2, 0xdd

    invoke-static {v5, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_17f
    const/16 v0, 0xe

    if-ne p0, v0, :cond_19a

    sput v5, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Làng chài Kora"

    const/16 v1, 0x150

    invoke-static {v3, v0, v1, v7}, Lj;->a(ILjava/lang/String;II)V

    const-string v0, "Bán HP-MP"

    const/16 v1, 0x36c

    const/16 v2, 0x10d

    invoke-static {v4, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_19a
    const/16 v0, 0xf

    if-ne p0, v0, :cond_1ae

    sput v4, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "đảo Sasayaku"

    const/16 v1, 0xd50

    const/16 v2, 0x95

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57

    :cond_1ae
    const/16 v0, 0x13

    if-ne p0, v0, :cond_57

    sput v4, Lj;->T:I

    invoke-static {}, Lj;->d()V

    const-string v0, "Miếu Chakumi /"

    const/16 v1, 0x900

    const/16 v2, 0x22d

    invoke-static {v3, v0, v1, v2}, Lj;->a(ILjava/lang/String;II)V

    goto/16 :goto_57
.end method

.method private static a(IIII)V
    .registers 6

    sget-object v0, Lj;->F:[I

    aput p1, v0, p0

    sget-object v0, Lj;->G:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p2

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Lj;->H:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p3

    aput v1, v0, p0

    sget-object v0, Lj;->I:[I

    sget-object v1, Lj;->D:[Ljavax/microedition/lcdui/Image;

    aget-object v1, v1, p1

    invoke-virtual {v1}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v1

    shr-int/lit8 v1, v1, 0x1

    aput v1, v0, p0

    sget-object v0, Lj;->J:[I

    sget-object v1, Lj;->D:[Ljavax/microedition/lcdui/Image;

    aget-object v1, v1, p1

    invoke-virtual {v1}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v1

    aput v1, v0, p0

    return-void
.end method

.method private static a(ILjava/lang/String;II)V
    .registers 7

    sget-object v0, Lj;->P:[Ljava/lang/String;

    aput-object p1, v0, p0

    sget-object v0, Lj;->Q:[I

    aput p2, v0, p0

    sget-object v0, Lj;->R:[I

    aput p3, v0, p0

    sget-object v0, Lj;->Q:[I

    aget v1, v0, p0

    invoke-static {p1}, LMidlet;->a(Ljava/lang/String;)I

    move-result v2

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    aput v1, v0, p0

    sget-object v0, Lj;->S:[I

    invoke-static {p1}, LMidlet;->a(Ljava/lang/String;)I

    move-result v1

    aput v1, v0, p0

    return-void
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 6

    const/4 v1, 0x0

    move v0, v1

    :goto_2
    sget v2, Lj;->T:I

    if-lt v0, v2, :cond_7

    return-void

    :cond_7
    sget-object v2, Lj;->Q:[I

    aget v2, v2, v0

    sget-object v3, Lj;->S:[I

    aget v3, v3, v0

    add-int/2addr v2, v3

    sget v3, Lq;->ay:I

    if-lt v2, v3, :cond_43

    sget-object v2, Lj;->Q:[I

    aget v2, v2, v0

    sget v3, Lq;->ay:I

    sget v4, Lq;->ab:I

    add-int/2addr v3, v4

    if-gt v2, v3, :cond_43

    sget-object v2, Lj;->R:[I

    aget v2, v2, v0

    sget v3, Lq;->az:I

    if-lt v2, v3, :cond_43

    sget-object v2, Lj;->R:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xe

    sget v3, Lq;->az:I

    sget v4, Lq;->ac:I

    add-int/2addr v3, v4

    if-gt v2, v3, :cond_43

    sget-object v2, Lj;->P:[Ljava/lang/String;

    aget-object v2, v2, v0

    sget-object v3, Lj;->Q:[I

    aget v3, v3, v0

    sget-object v4, Lj;->R:[I

    aget v4, v4, v0

    invoke-static {p0, v2, v3, v4, v1}, LMidlet;->a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V

    :cond_43
    add-int/lit8 v0, v0, 0x1

    goto :goto_2
.end method

.method public static final a(III)Z
    .registers 7

    const/4 v0, 0x0

    :try_start_1
    sget-object v1, Lj;->x:[I

    sget v2, Lj;->f:I

    div-int v2, p1, v2

    sget v3, Lj;->a:I

    mul-int/2addr v2, v3

    sget v3, Lj;->f:I

    div-int v3, p0, v3

    add-int/2addr v2, v3

    aget v1, v1, v2
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_11} :catch_16

    and-int/2addr v1, p2

    if-ne v1, p2, :cond_15

    const/4 v0, 0x1

    :cond_15
    :goto_15
    return v0

    :catch_16
    move-exception v1

    goto :goto_15
.end method

.method public static final b(II)I
    .registers 5

    :try_start_0
    sget-object v0, Lj;->x:[I

    sget v1, Lj;->f:I

    div-int v1, p1, v1

    sget v2, Lj;->a:I

    mul-int/2addr v1, v2

    sget v2, Lj;->f:I

    div-int v2, p0, v2

    add-int/2addr v1, v2

    aget v0, v0, v1
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_10} :catch_11

    :goto_10
    return v0

    :catch_11
    move-exception v0

    const/16 v0, 0x3e8

    goto :goto_10
.end method

.method public static b()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lj;->e:Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->A:Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->C:Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->w:[C

    sput-object v0, Lj;->x:[I

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method public static b(I)V
    .registers 9

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/16 v5, 0xb

    const/4 v4, 0x1

    const/4 v3, 0x0

    sput v3, Lj;->E:I

    const/16 v0, 0x63

    if-ne p0, v0, :cond_e

    const/16 p0, 0xd

    :cond_e
    if-ne p0, v7, :cond_5f

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_39

    new-array v0, v7, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    :try_start_18
    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/t/h0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    const-string v2, "/t/h1.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    const-string v2, "/t/h2.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_39
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_39} :catch_148

    :cond_39
    :goto_39
    const/4 v0, 0x5

    sput v0, Lj;->E:I

    invoke-static {}, Lj;->e()V

    const/16 v0, 0x41

    const/16 v1, 0x13

    invoke-static {v3, v3, v0, v1}, Lj;->a(IIII)V

    const/16 v0, 0x34

    const/16 v1, 0x11

    invoke-static {v4, v4, v0, v1}, Lj;->a(IIII)V

    const/16 v0, 0x39

    const/16 v1, 0x11

    invoke-static {v6, v6, v0, v1}, Lj;->a(IIII)V

    const/16 v0, 0x2b

    const/16 v1, 0xd

    invoke-static {v7, v4, v0, v1}, Lj;->a(IIII)V

    const/4 v0, 0x4

    invoke-static {v0, v6, v3, v3}, Lj;->a(IIII)V

    :cond_5f
    const/16 v0, 0xd

    if-ne p0, v0, :cond_bf

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_76

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    :try_start_6b
    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/t/h3.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_76
    .catch Ljava/lang/Exception; {:try_start_6b .. :try_end_76} :catch_145

    :cond_76
    :goto_76
    sput v5, Lj;->E:I

    invoke-static {}, Lj;->e()V

    const/16 v0, 0x9

    invoke-static {v3, v3, v0, v5}, Lj;->a(IIII)V

    const/16 v0, 0x11

    invoke-static {v4, v3, v0, v5}, Lj;->a(IIII)V

    const/16 v0, 0x18

    invoke-static {v6, v3, v0, v5}, Lj;->a(IIII)V

    const/16 v0, 0x2c

    const/16 v1, 0x9

    invoke-static {v7, v3, v0, v1}, Lj;->a(IIII)V

    const/4 v0, 0x4

    const/16 v1, 0x2e

    invoke-static {v0, v3, v1, v5}, Lj;->a(IIII)V

    const/4 v0, 0x5

    const/16 v1, 0x49

    const/4 v2, 0x6

    invoke-static {v0, v3, v1, v2}, Lj;->a(IIII)V

    const/4 v0, 0x6

    const/16 v1, 0x32

    invoke-static {v0, v3, v1, v5}, Lj;->a(IIII)V

    const/4 v0, 0x7

    const/16 v1, 0x34

    invoke-static {v0, v3, v1, v5}, Lj;->a(IIII)V

    const/16 v0, 0x8

    const/16 v1, 0x3f

    invoke-static {v0, v3, v1, v5}, Lj;->a(IIII)V

    const/16 v0, 0x9

    const/16 v1, 0x44

    invoke-static {v0, v3, v1, v5}, Lj;->a(IIII)V

    const/16 v0, 0xa

    const/16 v1, 0x5f

    invoke-static {v0, v3, v1, v5}, Lj;->a(IIII)V

    :cond_bf
    const/16 v0, 0xf

    if-ne p0, v0, :cond_fb

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_e1

    new-array v0, v6, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    :try_start_cb
    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/t/h1.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    const-string v2, "/t/h3.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_e1
    .catch Ljava/lang/Exception; {:try_start_cb .. :try_end_e1} :catch_143

    :cond_e1
    :goto_e1
    sput v7, Lj;->E:I

    invoke-static {}, Lj;->e()V

    const/16 v0, 0x40

    const/16 v1, 0x8

    invoke-static {v3, v3, v0, v1}, Lj;->a(IIII)V

    const/16 v0, 0x43

    const/16 v1, 0x8

    invoke-static {v4, v3, v0, v1}, Lj;->a(IIII)V

    const/16 v0, 0x63

    const/16 v1, 0x8

    invoke-static {v6, v4, v0, v1}, Lj;->a(IIII)V

    :cond_fb
    const/16 v0, 0x10

    if-ne p0, v0, :cond_11c

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_112

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    :try_start_107
    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/t/h3.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_112
    .catch Ljava/lang/Exception; {:try_start_107 .. :try_end_112} :catch_141

    :cond_112
    :goto_112
    sput v4, Lj;->E:I

    invoke-static {}, Lj;->e()V

    const/16 v0, 0x2b

    invoke-static {v3, v3, v0, v5}, Lj;->a(IIII)V

    :cond_11c
    const/16 v0, 0x8

    if-ne p0, v0, :cond_13e

    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_13e

    new-array v0, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    :try_start_128
    sget-object v0, Lj;->D:[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    const-string v2, "/t/h4.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_133
    .catch Ljava/lang/Exception; {:try_start_128 .. :try_end_133} :catch_13f

    :goto_133
    sput v4, Lj;->E:I

    invoke-static {}, Lj;->e()V

    const/16 v0, 0x58

    const/4 v1, 0x7

    invoke-static {v3, v3, v0, v1}, Lj;->a(IIII)V

    :cond_13e
    return-void

    :catch_13f
    move-exception v0

    goto :goto_133

    :catch_141
    move-exception v0

    goto :goto_112

    :catch_143
    move-exception v0

    goto :goto_e1

    :catch_145
    move-exception v0

    goto/16 :goto_76

    :catch_148
    move-exception v0

    goto/16 :goto_39
.end method

.method public static final b(III)V
    .registers 6

    sget-object v0, Lj;->x:[I

    sget v1, Lj;->f:I

    div-int v1, p1, v1

    sget v2, Lj;->a:I

    mul-int/2addr v1, v2

    sget v2, Lj;->f:I

    div-int v2, p0, v2

    add-int/2addr v1, v2

    aget v2, v0, v1

    or-int/lit16 v2, v2, 0x400

    aput v2, v0, v1

    return-void
.end method

.method public static b(Ljavax/microedition/lcdui/Graphics;)V
    .registers 6

    const/16 v4, 0x21

    const/4 v0, 0x0

    :goto_3
    sget v1, Lj;->E:I

    if-lt v0, v1, :cond_8

    return-void

    :cond_8
    sget-object v1, Lj;->G:[I

    aget v1, v1, v0

    sget-object v2, Lj;->I:[I

    aget v2, v2, v0

    add-int/2addr v1, v2

    sget v2, Lq;->ay:I

    if-lt v1, v2, :cond_76

    sget-object v1, Lj;->G:[I

    aget v1, v1, v0

    sget-object v2, Lj;->I:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    sget v2, Lq;->ay:I

    sget v3, Lq;->ab:I

    add-int/2addr v2, v3

    if-gt v1, v2, :cond_76

    sget-object v1, Lj;->H:[I

    aget v1, v1, v0

    sget v2, Lq;->az:I

    if-lt v1, v2, :cond_76

    sget-object v1, Lj;->H:[I

    aget v1, v1, v0

    sget-object v2, Lj;->J:[I

    aget v2, v2, v0

    sub-int/2addr v1, v2

    sget v2, Lq;->az:I

    sget v3, Lq;->ac:I

    add-int/2addr v2, v3

    if-gt v1, v2, :cond_76

    sget-object v1, Lj;->G:[I

    aget v1, v1, v0

    sget v2, Lq;->ay:I

    sub-int/2addr v1, v2

    sput v1, Lj;->L:I

    sget v2, Lq;->ad:I

    sub-int/2addr v1, v2

    sput v1, Lj;->M:I

    sget v1, Lj;->f:I

    add-int/lit8 v1, v1, -0x2

    sget v2, Lj;->M:I

    mul-int/2addr v1, v2

    sget v2, Lj;->f:I

    div-int/2addr v1, v2

    sput v1, Lj;->O:I

    sget v2, Lq;->ad:I

    add-int/2addr v1, v2

    sput v1, Lj;->N:I

    sget v1, Lq;->as:I

    const/16 v2, 0x8

    if-eq v1, v2, :cond_79

    sget-object v1, Lj;->D:[Ljavax/microedition/lcdui/Image;

    sget-object v2, Lj;->F:[I

    aget v2, v2, v0

    aget-object v1, v1, v2

    sget v2, Lq;->ay:I

    sget v3, Lj;->N:I

    add-int/2addr v2, v3

    sget-object v3, Lj;->H:[I

    aget v3, v3, v0

    invoke-virtual {p0, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_76
    :goto_76
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_79
    sget-object v1, Lj;->D:[Ljavax/microedition/lcdui/Image;

    sget-object v2, Lj;->F:[I

    aget v2, v2, v0

    aget-object v1, v1, v2

    sget-object v2, Lj;->G:[I

    aget v2, v2, v0

    sget-object v3, Lj;->H:[I

    aget v3, v3, v0

    invoke-virtual {p0, v1, v2, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto :goto_76
.end method

.method private static c(II)I
    .registers 4

    :try_start_0
    sget-object v0, Lj;->w:[C

    sget v1, Lj;->a:I

    mul-int/2addr v1, p1

    add-int/2addr v1, p0

    aget-char v0, v0, v1
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_9

    :goto_8
    return v0

    :catch_9
    move-exception v0

    const/16 v0, 0x3e8

    goto :goto_8
.end method

.method static final c()V
    .registers 1

    :try_start_0
    sget-object v0, Lj;->e:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_c

    const-string v0, "/t/t.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->e:Ljavax/microedition/lcdui/Image;

    :cond_c
    sget-object v0, Lj;->z:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_1c

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_58

    const-string v0, "/t/uwt_hi.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->z:Ljavax/microedition/lcdui/Image;

    :cond_1c
    :goto_1c
    sget-object v0, Lj;->A:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_28

    const-string v0, "/t/wtf.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->A:Ljavax/microedition/lcdui/Image;

    :cond_28
    sget-object v0, Lj;->B:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_34

    const-string v0, "/t/twtf.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->B:Ljavax/microedition/lcdui/Image;

    :cond_34
    sget-object v0, Lj;->C:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_44

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_68

    const-string v0, "/t/wts_hi.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->C:Ljavax/microedition/lcdui/Image;

    :cond_44
    :goto_44
    sget-object v0, Lj;->K:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_54

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_54

    const-string v0, "/t/tb.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->K:Ljavax/microedition/lcdui/Image;

    :cond_54
    invoke-static {}, Ljava/lang/System;->gc()V

    :goto_57
    return-void

    :cond_58
    const-string v0, "/t/uwt.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->z:Ljavax/microedition/lcdui/Image;
    :try_end_60
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_60} :catch_61

    goto :goto_1c

    :catch_61
    move-exception v0

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, LMidlet;->b()V

    goto :goto_57

    :cond_68
    :try_start_68
    const-string v0, "/t/wts.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lj;->C:Ljavax/microedition/lcdui/Image;
    :try_end_70
    .catch Ljava/lang/Exception; {:try_start_68 .. :try_end_70} :catch_61

    goto :goto_44
.end method

.method public static c(I)V
    .registers 10

    const/16 v8, 0x64

    const/16 v7, 0x14

    const/16 v6, 0xe

    const/4 v5, 0x3

    const/4 v1, -0x1

    const/16 v0, 0xc8

    new-array v0, v0, [Z

    sput-object v0, Lj;->y:[Z

    const/16 v0, 0x63

    if-ne p0, v0, :cond_14

    const/16 p0, 0xd

    :cond_14
    const/16 v0, 0x6d

    if-ne p0, v0, :cond_2a

    const/16 v0, 0x42

    sput v0, Lj;->a:I

    const/16 v0, 0x10

    sput v0, Lj;->b:I

    sput v1, Lj;->g:I

    sput v1, Lj;->h:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_2a
    const/16 v0, 0x6c

    if-ne p0, v0, :cond_47

    const/16 v0, 0x78

    sput v0, Lj;->a:I

    sput v6, Lj;->b:I

    sput v1, Lj;->g:I

    const/4 v0, 0x0

    sput v0, Lj;->h:I

    const/16 v0, 0x360

    sput v0, Lj;->n:I

    const/16 v0, 0x168

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_47
    const/16 v0, 0x6b

    if-ne p0, v0, :cond_62

    sput v7, Lj;->a:I

    sput v6, Lj;->b:I

    sput v1, Lj;->g:I

    const/4 v0, 0x0

    sput v0, Lj;->h:I

    const/16 v0, 0x360

    sput v0, Lj;->n:I

    const/16 v0, 0x168

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_62
    const/16 v0, 0x6a

    if-ne p0, v0, :cond_81

    const/16 v0, 0x32

    sput v0, Lj;->a:I

    const/16 v0, 0xd

    sput v0, Lj;->b:I

    sput v1, Lj;->g:I

    const/4 v0, 0x0

    sput v0, Lj;->h:I

    const/16 v0, 0x360

    sput v0, Lj;->n:I

    const/16 v0, 0x168

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_81
    const/16 v0, 0x69

    if-ne p0, v0, :cond_a0

    const/16 v0, 0x28

    sput v0, Lj;->a:I

    const/16 v0, 0xc

    sput v0, Lj;->b:I

    sput v1, Lj;->g:I

    const/4 v0, 0x0

    sput v0, Lj;->h:I

    const/16 v0, 0x360

    sput v0, Lj;->n:I

    const/16 v0, 0x168

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_a0
    if-nez p0, :cond_cb

    const/16 v0, 0x2e

    sput v0, Lj;->a:I

    const/16 v0, 0x13

    sput v0, Lj;->b:I

    const/4 v0, 0x1

    sput v0, Lj;->g:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x3b

    sput v0, Lj;->l:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x9

    sput v0, Lj;->m:I

    const/16 v0, 0x69

    sput v0, Lj;->h:I

    const/16 v0, 0x24

    sput v0, Lj;->n:I

    const/16 v0, 0xf0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_cb
    const/4 v0, 0x1

    if-ne p0, v0, :cond_f4

    const/16 v0, 0x3c

    sput v0, Lj;->a:I

    sput v6, Lj;->b:I

    const/4 v0, 0x2

    sput v0, Lj;->g:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x13

    sput v0, Lj;->l:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lj;->m:I

    const/4 v0, 0x0

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x10

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_f4
    const/4 v0, 0x2

    if-ne p0, v0, :cond_124

    sput v7, Lj;->a:I

    const/16 v0, 0x28

    sput v0, Lj;->b:I

    sput v5, Lj;->g:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x44

    sput v0, Lj;->l:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x13

    sput v0, Lj;->m:I

    const/4 v0, 0x1

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x9

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    const/16 v0, 0x67

    sput v0, Lj;->k:I

    const/16 v0, 0xa8

    sput v0, Lj;->t:I

    sput v5, Lj;->u:I

    :cond_124
    const/16 v0, 0x67

    if-ne p0, v0, :cond_13f

    sput v7, Lj;->a:I

    sput v6, Lj;->b:I

    sput v1, Lj;->g:I

    sput v1, Lj;->h:I

    sput v1, Lj;->i:I

    const/4 v0, 0x2

    sput v0, Lj;->j:I

    const/16 v0, 0xe4

    sput v0, Lj;->r:I

    const/16 v0, 0x390

    sput v0, Lj;->s:I

    sput v1, Lj;->k:I

    :cond_13f
    if-ne p0, v5, :cond_16f

    const/16 v0, 0x46

    sput v0, Lj;->a:I

    const/16 v0, 0x1a

    sput v0, Lj;->b:I

    sput v1, Lj;->g:I

    const/4 v0, 0x2

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    const/16 v0, 0x8

    sput v0, Lj;->j:I

    const/16 v0, 0xb70

    sput v0, Lj;->r:I

    const/16 v0, 0xf0

    sput v0, Lj;->s:I

    const/4 v0, 0x4

    sput v0, Lj;->k:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x73

    sput v0, Lj;->t:I

    sput v5, Lj;->u:I

    :cond_16f
    const/4 v0, 0x4

    if-ne p0, v0, :cond_19b

    const/16 v0, 0x78

    sput v0, Lj;->a:I

    sput v6, Lj;->b:I

    const/4 v0, 0x5

    sput v0, Lj;->g:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x1d

    sput v0, Lj;->l:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x4d

    sput v0, Lj;->m:I

    sput v1, Lj;->h:I

    sput v1, Lj;->i:I

    sput v5, Lj;->j:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x12

    sput v0, Lj;->r:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x18

    sput v0, Lj;->s:I

    sput v1, Lj;->k:I

    :cond_19b
    const/4 v0, 0x5

    if-ne p0, v0, :cond_1c3

    const/16 v0, 0x1e

    sput v0, Lj;->a:I

    const/16 v0, 0x50

    sput v0, Lj;->b:I

    sput v1, Lj;->g:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    const/16 v0, 0x65

    sput v0, Lj;->h:I

    const/4 v0, 0x4

    sput v0, Lj;->i:I

    const/16 v0, 0x120

    sput v0, Lj;->v:I

    sput v5, Lj;->n:I

    const/16 v0, 0x90

    sput v0, Lj;->o:I

    sput v5, Lj;->p:I

    const/16 v0, 0xa8

    sput v0, Lj;->q:I

    :cond_1c3
    const/16 v0, 0x65

    if-ne p0, v0, :cond_1e9

    sput v7, Lj;->a:I

    sput v6, Lj;->b:I

    const/4 v0, 0x5

    sput v0, Lj;->g:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x1d

    sput v0, Lj;->l:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lj;->m:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    const/4 v0, 0x6

    sput v0, Lj;->h:I

    sput v1, Lj;->i:I

    sput v5, Lj;->n:I

    const/16 v0, 0x1b0

    sput v0, Lj;->o:I

    :cond_1e9
    const/4 v0, 0x6

    if-ne p0, v0, :cond_210

    const/16 v0, 0x50

    sput v0, Lj;->a:I

    sput v7, Lj;->b:I

    const/4 v0, 0x5

    sput v0, Lj;->g:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x1d

    sput v0, Lj;->l:I

    sget v0, Lj;->f:I

    mul-int/lit8 v0, v0, 0x5

    sput v0, Lj;->m:I

    const/4 v0, 0x7

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xa8

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_210
    const/4 v0, 0x7

    if-ne p0, v0, :cond_232

    sput v8, Lj;->a:I

    sput v6, Lj;->b:I

    const/4 v0, 0x6

    sput v0, Lj;->g:I

    const/16 v0, 0x768

    sput v0, Lj;->l:I

    const/16 v0, 0x120

    sput v0, Lj;->m:I

    const/16 v0, 0x8

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xf0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_232
    const/16 v0, 0x8

    if-ne p0, v0, :cond_25f

    const/16 v0, 0x96

    sput v0, Lj;->a:I

    const/16 v0, 0xd

    sput v0, Lj;->b:I

    const/4 v0, 0x7

    sput v0, Lj;->g:I

    const/16 v0, 0x948

    sput v0, Lj;->l:I

    const/16 v0, 0x108

    sput v0, Lj;->m:I

    const/16 v0, 0x9

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x198

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v5, Lj;->k:I

    const/16 v0, 0x30

    sput v0, Lj;->t:I

    sput v5, Lj;->u:I

    :cond_25f
    const/16 v0, 0x9

    if-ne p0, v0, :cond_285

    const/16 v0, 0x78

    sput v0, Lj;->a:I

    sput v7, Lj;->b:I

    const/16 v0, 0x8

    sput v0, Lj;->g:I

    const/16 v0, 0xdf8

    sput v0, Lj;->l:I

    const/16 v0, 0xf0

    sput v0, Lj;->m:I

    const/16 v0, 0xa

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x120

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_285
    const/16 v0, 0xa

    if-ne p0, v0, :cond_2a9

    const/16 v0, 0x32

    sput v0, Lj;->a:I

    sput v6, Lj;->b:I

    const/16 v0, 0x9

    sput v0, Lj;->g:I

    const/16 v0, 0xb28

    sput v0, Lj;->l:I

    const/16 v0, 0x180

    sput v0, Lj;->m:I

    sput v8, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x78

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_2a9
    if-ne p0, v8, :cond_2cd

    sput v7, Lj;->a:I

    const/16 v0, 0xf

    sput v0, Lj;->b:I

    const/16 v0, 0xa

    sput v0, Lj;->g:I

    const/16 v0, 0x498

    sput v0, Lj;->l:I

    const/16 v0, 0x48

    sput v0, Lj;->m:I

    const/16 v0, 0xb

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x390

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_2cd
    const/16 v0, 0xb

    if-ne p0, v0, :cond_2f3

    const/16 v0, 0x40

    sput v0, Lj;->a:I

    const/16 v0, 0x28

    sput v0, Lj;->b:I

    sput v8, Lj;->g:I

    const/16 v0, 0x1c8

    sput v0, Lj;->l:I

    const/16 v0, 0x108

    sput v0, Lj;->m:I

    const/16 v0, 0xc

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xf0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_2f3
    const/16 v0, 0xc

    if-ne p0, v0, :cond_31b

    const/16 v0, 0x78

    sput v0, Lj;->a:I

    const/16 v0, 0xf

    sput v0, Lj;->b:I

    const/16 v0, 0xb

    sput v0, Lj;->g:I

    const/16 v0, 0x5e8

    sput v0, Lj;->l:I

    const/16 v0, 0x378

    sput v0, Lj;->m:I

    const/16 v0, 0xd

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x108

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_31b
    const/16 v0, 0xd

    if-ne p0, v0, :cond_33f

    sput v8, Lj;->a:I

    const/16 v0, 0xd

    sput v0, Lj;->b:I

    const/16 v0, 0xc

    sput v0, Lj;->g:I

    const/16 v0, 0xb28

    sput v0, Lj;->l:I

    const/16 v0, 0x120

    sput v0, Lj;->m:I

    sput v6, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x180

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_33f
    if-ne p0, v6, :cond_363

    const/16 v0, 0x78

    sput v0, Lj;->a:I

    sput v7, Lj;->b:I

    const/16 v0, 0xd

    sput v0, Lj;->g:I

    const/16 v0, 0x948

    sput v0, Lj;->l:I

    const/16 v0, 0x108

    sput v0, Lj;->m:I

    const/16 v0, 0x66

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xc0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_363
    const/16 v0, 0x66

    if-ne p0, v0, :cond_387

    const/16 v0, 0x18

    sput v0, Lj;->a:I

    sput v6, Lj;->b:I

    sput v6, Lj;->g:I

    const/16 v0, 0xb28

    sput v0, Lj;->l:I

    const/16 v0, 0x1b0

    sput v0, Lj;->m:I

    const/16 v0, 0xf

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xd8

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_387
    const/16 v0, 0xf

    if-ne p0, v0, :cond_3af

    const/16 v0, 0x96

    sput v0, Lj;->a:I

    const/16 v0, 0xb

    sput v0, Lj;->b:I

    const/16 v0, 0x66

    sput v0, Lj;->g:I

    const/16 v0, 0x210

    sput v0, Lj;->l:I

    const/16 v0, 0xf0

    sput v0, Lj;->m:I

    const/16 v0, 0x10

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xc0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_3af
    const/16 v0, 0x10

    if-ne p0, v0, :cond_3d3

    sput v8, Lj;->a:I

    sput v6, Lj;->b:I

    const/16 v0, 0xf

    sput v0, Lj;->g:I

    const/16 v0, 0xde0

    sput v0, Lj;->l:I

    const/16 v0, 0xa8

    sput v0, Lj;->m:I

    const/16 v0, 0x11

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x2a0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_3d3
    const/16 v0, 0x11

    if-ne p0, v0, :cond_3fb

    const/16 v0, 0x50

    sput v0, Lj;->a:I

    const/16 v0, 0x1e

    sput v0, Lj;->b:I

    const/16 v0, 0x10

    sput v0, Lj;->g:I

    const/16 v0, 0x948

    sput v0, Lj;->l:I

    const/16 v0, 0xc0

    sput v0, Lj;->m:I

    const/16 v0, 0x12

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0xf0

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_3fb
    const/16 v0, 0x12

    if-ne p0, v0, :cond_421

    sput v8, Lj;->a:I

    const/16 v0, 0xf

    sput v0, Lj;->b:I

    const/16 v0, 0x11

    sput v0, Lj;->g:I

    const/16 v0, 0x768

    sput v0, Lj;->l:I

    const/16 v0, 0x60

    sput v0, Lj;->m:I

    const/16 v0, 0x13

    sput v0, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x288

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_421
    const/16 v0, 0x13

    if-ne p0, v0, :cond_445

    sput v8, Lj;->a:I

    const/16 v0, 0x1e

    sput v0, Lj;->b:I

    const/16 v0, 0x12

    sput v0, Lj;->g:I

    const/16 v0, 0x948

    sput v0, Lj;->l:I

    const/16 v0, 0xc0

    sput v0, Lj;->m:I

    sput v7, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x120

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_445
    if-ne p0, v7, :cond_469

    const/16 v0, 0x50

    sput v0, Lj;->a:I

    const/16 v0, 0x10

    sput v0, Lj;->b:I

    const/16 v0, 0x13

    sput v0, Lj;->g:I

    const/16 v0, 0x948

    sput v0, Lj;->l:I

    const/16 v0, 0x288

    sput v0, Lj;->m:I

    sput v1, Lj;->h:I

    sput v5, Lj;->n:I

    const/16 v0, 0x108

    sput v0, Lj;->o:I

    sput v1, Lj;->i:I

    sput v1, Lj;->j:I

    sput v1, Lj;->k:I

    :cond_469
    sget v0, Lj;->a:I

    sget v1, Lj;->f:I

    mul-int/2addr v0, v1

    sput v0, Lj;->c:I

    sget v0, Lj;->b:I

    sget v1, Lj;->f:I

    mul-int/2addr v0, v1

    sput v0, Lj;->d:I

    :try_start_477
    const-string v0, ""

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "/m/"

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v1

    sget v0, Lj;->a:I

    sget v2, Lj;->b:I

    mul-int/2addr v0, v2

    new-array v0, v0, [C

    sput-object v0, Lj;->w:[C

    sget v0, Lj;->a:I

    sget v2, Lj;->b:I

    mul-int/2addr v0, v2

    new-array v0, v0, [I

    sput-object v0, Lj;->x:[I

    const/4 v0, 0x0

    :goto_4a3
    sget v2, Lj;->a:I

    sget v3, Lj;->b:I
    :try_end_4a7
    .catch Ljava/lang/Exception; {:try_start_477 .. :try_end_4a7} :catch_859

    mul-int/2addr v2, v3

    if-lt v0, v2, :cond_4e4

    :goto_4aa
    invoke-static {}, Lj;->c()V

    sget v0, Lq;->as:I

    if-ne v0, v6, :cond_4be

    sget-boolean v0, Lq;->o:Z

    if-nez v0, :cond_4be

    sput v5, Lq;->bi:I

    const/16 v0, 0x738

    const/16 v1, 0xf0

    invoke-static {v0, v1}, Lq;->a(II)V

    :cond_4be
    sget v0, Lq;->as:I

    const/16 v1, 0x13

    if-ne v0, v1, :cond_4e3

    sget-boolean v0, Lg;->B:Z

    if-nez v0, :cond_4e3

    const/4 v0, 0x7

    sput v0, Lq;->bi:I

    const/16 v0, 0x270

    const/16 v1, 0x60

    invoke-static {v0, v1}, Lq;->a(II)V

    sget-boolean v0, Lg;->u:Z

    if-eqz v0, :cond_4e3

    sget-boolean v0, Lg;->s:Z

    if-eqz v0, :cond_4e3

    sget-boolean v0, Lg;->t:Z

    if-eqz v0, :cond_4e3

    const/4 v0, 0x1

    :goto_4df
    const/16 v1, 0x8

    if-le v0, v1, :cond_86b

    :cond_4e3
    return-void

    :cond_4e4
    :try_start_4e4
    sget-object v2, Lj;->w:[C

    invoke-virtual {v1}, Ljava/io/InputStream;->read()I

    move-result v3

    int-to-char v3, v3

    aput-char v3, v2, v0

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    if-eqz v2, :cond_4fe

    sget-object v2, Lj;->y:[Z

    sget-object v3, Lj;->w:[C

    aget-char v3, v3, v0

    add-int/lit8 v3, v3, -0x1

    const/4 v4, 0x1

    aput-boolean v4, v2, v3

    :cond_4fe
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x1

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x2

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    if-eq v2, v5, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x4

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x5

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x6

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x7

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x24

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x25

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x36

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x3d

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x49

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x4a

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x4c

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x4d

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x4e

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x4f

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x52

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x53

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x62

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x63

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    if-eq v2, v8, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x66

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x67

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x6c

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x6d

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x6e

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x70

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x71

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x74

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x75

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7d

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7e

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7f

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x81

    if-eq v2, v3, :cond_614

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x82

    if-ne v2, v3, :cond_61c

    :cond_614
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x2

    aput v3, v2, v0

    :cond_61c
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x1

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    if-eq v2, v5, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x4

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x5

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x6

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    if-eq v2, v7, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x15

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x16

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x17

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x24

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x25

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x26

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x27

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x37

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x6d

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x6f

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x70

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x71

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x72

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x73

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x74

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7f

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x81

    if-eq v2, v3, :cond_6d4

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x82

    if-ne v2, v3, :cond_6dc

    :cond_6d4
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x2000

    aput v3, v2, v0

    :cond_6dc
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x8

    if-eq v2, v3, :cond_712

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x9

    if-eq v2, v3, :cond_712

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0xa

    if-eq v2, v3, :cond_712

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0xc

    if-eq v2, v3, :cond_712

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0xd

    if-eq v2, v3, :cond_712

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    if-eq v2, v6, :cond_712

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x1e

    if-ne v2, v3, :cond_71a

    :cond_712
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x10

    aput v3, v2, v0

    :cond_71a
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x11

    if-ne v2, v3, :cond_72a

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x20

    aput v3, v2, v0

    :cond_72a
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x12

    if-ne v2, v3, :cond_73a

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x80

    aput v3, v2, v0

    :cond_73a
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x3d

    if-eq v2, v3, :cond_76a

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x25

    if-eq v2, v3, :cond_76a

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x26

    if-eq v2, v3, :cond_76a

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7f

    if-eq v2, v3, :cond_76a

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x82

    if-eq v2, v3, :cond_76a

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x83

    if-ne v2, v3, :cond_772

    :cond_76a
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x4

    aput v3, v2, v0

    :cond_772
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x3d

    if-eq v2, v3, :cond_7a2

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x24

    if-eq v2, v3, :cond_7a2

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x27

    if-eq v2, v3, :cond_7a2

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7f

    if-eq v2, v3, :cond_7a2

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x81

    if-eq v2, v3, :cond_7a2

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x84

    if-ne v2, v3, :cond_7aa

    :cond_7a2
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x8

    aput v3, v2, v0

    :cond_7aa
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x13

    if-ne v2, v3, :cond_7d0

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x40

    aput v3, v2, v0

    sget-object v2, Lj;->x:[I

    sget v3, Lj;->a:I

    sub-int v3, v0, v3

    aget v2, v2, v3

    and-int/lit16 v2, v2, 0x2000

    const/16 v3, 0x2000

    if-ne v2, v3, :cond_7d0

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x2000

    aput v3, v2, v0

    :cond_7d0
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x86

    if-ne v2, v3, :cond_7f6

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit8 v3, v3, 0x40

    aput v3, v2, v0

    sget-object v2, Lj;->x:[I

    sget v3, Lj;->a:I

    sub-int v3, v0, v3

    aget v2, v2, v3

    and-int/lit16 v2, v2, 0x2000

    const/16 v3, 0x2000

    if-ne v2, v3, :cond_7f6

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x2000

    aput v3, v2, v0

    :cond_7f6
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x23

    if-ne v2, v3, :cond_806

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x1000

    aput v3, v2, v0

    :cond_806
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x20

    if-ne v2, v3, :cond_816

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x100

    aput v3, v2, v0

    :cond_816
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/4 v3, 0x7

    if-ne v2, v3, :cond_825

    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x800

    aput v3, v2, v0

    :cond_825
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x21

    if-eq v2, v3, :cond_835

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x22

    if-ne v2, v3, :cond_83d

    :cond_835
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x200

    aput v3, v2, v0

    :cond_83d
    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x3d

    if-eq v2, v3, :cond_84d

    sget-object v2, Lj;->w:[C

    aget-char v2, v2, v0

    const/16 v3, 0x7f

    if-ne v2, v3, :cond_855

    :cond_84d
    sget-object v2, Lj;->x:[I

    aget v3, v2, v0

    or-int/lit16 v3, v3, 0x4000

    aput v3, v2, v0
    :try_end_855
    .catch Ljava/lang/Exception; {:try_start_4e4 .. :try_end_855} :catch_859

    :cond_855
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_4a3

    :catch_859
    move-exception v0

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v2, "Error Load Map"

    invoke-virtual {v1, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, LMidlet;->b()V

    goto/16 :goto_4aa

    :cond_86b
    sget-object v1, Lo;->b:Lo;

    new-instance v2, Lh;

    const/16 v3, 0x270

    const/16 v4, 0x52

    add-int/lit8 v5, v0, 0xd

    invoke-direct {v2, v3, v4, v5}, Lh;-><init>(III)V

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_4df
.end method

.method public static final c(III)V
    .registers 6

    sget-object v0, Lj;->x:[I

    sget v1, Lj;->f:I

    div-int v1, p1, v1

    sget v2, Lj;->a:I

    mul-int/2addr v1, v2

    sget v2, Lj;->f:I

    div-int v2, p0, v2

    add-int/2addr v1, v2

    aget v2, v0, v1

    and-int/lit16 v2, v2, -0x401

    aput v2, v0, v1

    return-void
.end method

.method public static final c(Ljavax/microedition/lcdui/Graphics;)V
    .registers 16

    const/16 v14, 0x2000

    const/16 v13, 0x1f8

    const/16 v12, 0x20

    const/16 v4, 0x18

    const/4 v2, 0x0

    sget v0, Lq;->W:I

    move v10, v0

    :goto_c
    sget v0, Lq;->Y:I

    if-lt v10, v0, :cond_11

    return-void

    :cond_11
    sget v0, Lq;->X:I

    move v11, v0

    :goto_14
    sget v0, Lq;->Z:I

    if-lt v11, v0, :cond_1c

    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto :goto_c

    :cond_1c
    sget-object v0, Lj;->w:[C

    sget v1, Lj;->a:I

    mul-int/2addr v1, v11

    add-int/2addr v1, v10

    aget-char v0, v0, v1

    add-int/lit8 v0, v0, -0x1

    const/4 v1, -0x1

    if-eq v0, v1, :cond_3d

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v3, Lj;->f:I

    mul-int/2addr v3, v0

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_3d
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x20

    if-ne v0, v12, :cond_aa

    sget-object v1, Lj;->A:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_5c
    :goto_5c
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x1000

    const/16 v1, 0x1000

    if-ne v0, v1, :cond_a5

    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->a(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x20

    if-ne v0, v12, :cond_10d

    sget-object v1, Lj;->A:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_87
    :goto_87
    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget-object v0, Lj;->w:[C

    sget v3, Lj;->a:I

    mul-int/2addr v3, v11

    add-int/2addr v3, v10

    aget-char v0, v0, v3

    add-int/lit8 v0, v0, -0x1

    sget v3, Lj;->f:I

    mul-int/2addr v3, v0

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_a5
    add-int/lit8 v0, v11, 0x1

    move v11, v0

    goto/16 :goto_14

    :cond_aa
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x40

    const/16 v1, 0x40

    if-ne v0, v1, :cond_5c

    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->a(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x20

    if-ne v0, v12, :cond_f0

    sget-object v1, Lj;->A:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_d5
    :goto_d5
    sget-object v1, Lj;->C:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    shr-int/lit8 v0, v0, 0x2

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_5c

    :cond_f0
    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x2000

    if-ne v0, v14, :cond_d5

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v3, v13

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_d5

    :cond_10d
    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x2000

    if-ne v0, v14, :cond_87

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v3, v13

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_87
.end method

.method public static final d(I)I
    .registers 3

    sget v0, Lj;->f:I

    div-int v0, p0, v0

    sget v1, Lj;->f:I

    mul-int/2addr v0, v1

    return v0
.end method

.method private static d()V
    .registers 1

    sget v0, Lj;->T:I

    new-array v0, v0, [Ljava/lang/String;

    sput-object v0, Lj;->P:[Ljava/lang/String;

    sget v0, Lj;->T:I

    new-array v0, v0, [I

    sput-object v0, Lj;->Q:[I

    sget v0, Lj;->T:I

    new-array v0, v0, [I

    sput-object v0, Lj;->R:[I

    sget v0, Lj;->T:I

    new-array v0, v0, [I

    sput-object v0, Lj;->S:[I

    return-void
.end method

.method public static final d(Ljavax/microedition/lcdui/Graphics;)V
    .registers 14

    const/16 v12, 0x20

    const/16 v4, 0x18

    const/4 v2, 0x0

    sget v0, Lq;->W:I

    move v10, v0

    :goto_8
    sget v0, Lq;->Y:I

    if-lt v10, v0, :cond_d

    return-void

    :cond_d
    sget v0, Lq;->X:I

    move v11, v0

    :goto_10
    sget v0, Lq;->Z:I

    if-lt v11, v0, :cond_18

    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto :goto_8

    :cond_18
    sget-object v0, Lj;->w:[C

    sget v1, Lj;->a:I

    mul-int/2addr v1, v11

    add-int/2addr v1, v10

    aget-char v0, v0, v1

    add-int/lit8 v0, v0, -0x1

    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x10

    const/16 v3, 0x10

    if-ne v1, v3, :cond_64

    sget v1, Lj;->f:I

    mul-int/2addr v1, v10

    sget v3, Lq;->ay:I

    sub-int/2addr v1, v3

    sput v1, Lj;->L:I

    sget v3, Lq;->ad:I

    sub-int/2addr v1, v3

    sput v1, Lj;->M:I

    sget v1, Lj;->f:I

    add-int/lit8 v1, v1, -0x2

    sget v3, Lj;->M:I

    mul-int/2addr v1, v3

    sget v3, Lj;->f:I

    div-int/2addr v1, v3

    sput v1, Lj;->O:I

    sget v3, Lq;->ad:I

    add-int/2addr v1, v3

    sput v1, Lj;->N:I

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v3, Lj;->f:I

    mul-int/2addr v3, v0

    sget v0, Lj;->N:I

    sget v5, Lq;->ay:I

    add-int v7, v0, v5

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_60
    :goto_60
    add-int/lit8 v0, v11, 0x1

    move v11, v0

    goto :goto_10

    :cond_64
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit16 v1, v1, 0x100

    const/16 v3, 0x100

    if-eq v1, v3, :cond_60

    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit16 v1, v1, 0x200

    const/16 v3, 0x200

    if-eq v1, v3, :cond_60

    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x20

    if-ne v1, v12, :cond_9a

    sget-object v1, Lj;->A:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    shr-int/lit8 v0, v0, 0x1

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_60

    :cond_9a
    const/16 v1, 0x11

    if-ne v0, v1, :cond_b8

    sget-object v1, Lj;->B:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    shr-int/lit8 v0, v0, 0x1

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_60

    :cond_b8
    const/16 v1, 0x85

    if-ne v0, v1, :cond_d2

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v0, Lj;->f:I

    mul-int/lit16 v3, v0, 0x84

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto :goto_60

    :cond_d2
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x40

    const/16 v3, 0x40

    if-eq v1, v3, :cond_e6

    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit16 v1, v1, 0x1000

    const/16 v3, 0x1000

    if-ne v1, v3, :cond_140

    :cond_e6
    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->a(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x20

    if-ne v0, v12, :cond_109

    sget-object v1, Lj;->A:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_60

    :cond_109
    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x2000

    const/16 v1, 0x2000

    if-ne v0, v1, :cond_60

    add-int/lit8 v0, v11, -0x1

    invoke-static {v10, v0}, Lj;->c(II)I

    move-result v0

    const/16 v1, 0x37

    if-ne v0, v1, :cond_136

    const/16 v0, 0x36

    :goto_121
    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_60

    :cond_136
    const/16 v1, 0x28

    if-ge v0, v1, :cond_13d

    const/16 v0, 0x15

    goto :goto_121

    :cond_13d
    const/16 v0, 0x6e

    goto :goto_121

    :cond_140
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v1

    and-int/lit16 v1, v1, 0x400

    const/16 v3, 0x400

    if-ne v1, v3, :cond_161

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v3, Lj;->f:I

    mul-int/2addr v3, v0

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int/2addr v0, v11

    add-int/lit8 v8, v0, 0x1

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_60

    :cond_161
    const/4 v1, -0x1

    if-eq v0, v1, :cond_60

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget v3, Lj;->f:I

    mul-int/2addr v3, v0

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_60
.end method

.method public static final e(I)I
    .registers 3

    sget v0, Lj;->f:I

    div-int v0, p0, v0

    sget v1, Lj;->f:I

    mul-int/2addr v0, v1

    return v0
.end method

.method private static e()V
    .registers 1

    sget v0, Lj;->E:I

    new-array v0, v0, [I

    sput-object v0, Lj;->F:[I

    sget v0, Lj;->E:I

    new-array v0, v0, [I

    sput-object v0, Lj;->G:[I

    sget v0, Lj;->E:I

    new-array v0, v0, [I

    sput-object v0, Lj;->H:[I

    sget v0, Lj;->E:I

    new-array v0, v0, [I

    sput-object v0, Lj;->I:[I

    sget v0, Lj;->E:I

    new-array v0, v0, [I

    sput-object v0, Lj;->J:[I

    return-void
.end method

.method public static final e(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/16 v4, 0x18

    const/4 v2, 0x0

    sget-boolean v0, Lq;->b:Z

    if-eqz v0, :cond_8

    :cond_7
    return-void

    :cond_8
    sget v0, Lq;->W:I

    move v10, v0

    :goto_b
    sget v0, Lq;->Y:I

    if-ge v10, v0, :cond_7

    sget v0, Lq;->X:I

    move v11, v0

    :goto_12
    sget v0, Lq;->Z:I

    if-lt v11, v0, :cond_1a

    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto :goto_b

    :cond_1a
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit8 v0, v0, 0x40

    const/16 v1, 0x40

    if-ne v0, v1, :cond_7f

    sget-object v1, Lj;->C:Ljavax/microedition/lcdui/Image;

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x8

    shr-int/lit8 v0, v0, 0x2

    mul-int/lit8 v3, v0, 0x18

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int v8, v11, v0

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_3d
    :goto_3d
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x200

    const/16 v1, 0x200

    if-ne v0, v1, :cond_66

    sget-object v1, Lj;->e:Ljavax/microedition/lcdui/Image;

    sget-object v0, Lj;->w:[C

    sget v3, Lj;->a:I

    mul-int/2addr v3, v11

    add-int/2addr v3, v10

    aget-char v0, v0, v3

    add-int/lit8 v0, v0, -0x1

    sget v3, Lj;->f:I

    mul-int/2addr v3, v0

    sget v0, Lj;->f:I

    mul-int v7, v10, v0

    sget v0, Lj;->f:I

    mul-int/2addr v0, v11

    add-int/lit8 v8, v0, 0x2

    move-object v0, p0

    move v5, v4

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_66
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x1000

    const/16 v1, 0x1000

    if-ne v0, v1, :cond_7b

    sget-object v0, Lj;->z:Ljavax/microedition/lcdui/Image;

    sget v1, Lj;->f:I

    mul-int/2addr v1, v10

    sget v3, Lj;->f:I

    mul-int/2addr v3, v11

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_7b
    add-int/lit8 v0, v11, 0x1

    move v11, v0

    goto :goto_12

    :cond_7f
    invoke-static {v10, v11}, Lj;->a(II)I

    move-result v0

    and-int/lit16 v0, v0, 0x100

    const/16 v1, 0x100

    if-ne v0, v1, :cond_3d

    sget v0, Lj;->f:I

    mul-int/2addr v0, v10

    sget v1, Lq;->ay:I

    sub-int/2addr v0, v1

    sput v0, Lj;->L:I

    sget v1, Lq;->ad:I

    sub-int/2addr v0, v1

    sput v0, Lj;->M:I

    sget v0, Lj;->f:I

    add-int/lit8 v0, v0, -0x1

    sget v1, Lj;->M:I

    mul-int/2addr v0, v1

    sget v1, Lj;->f:I

    div-int/2addr v0, v1

    sput v0, Lj;->O:I

    sget v1, Lq;->ad:I

    add-int/2addr v0, v1

    sput v0, Lj;->N:I

    sget-object v0, Lj;->K:Ljavax/microedition/lcdui/Image;

    sget v1, Lj;->N:I

    sget v3, Lq;->ay:I

    add-int/2addr v1, v3

    add-int/lit8 v1, v1, -0x2

    add-int v3, v10, v11

    rem-int/lit8 v3, v3, 0x5

    add-int/2addr v1, v3

    sget v3, Lj;->f:I

    mul-int/2addr v3, v11

    add-int/lit8 v3, v3, -0x3

    rem-int/lit8 v5, v11, 0x5

    add-int/2addr v3, v5

    invoke-virtual {p0, v0, v1, v3, v2}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_3d
.end method
