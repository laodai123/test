.class public final Lm;
.super Ljava/lang/Object;


# static fields
.field public static a:Z

.field public static b:I

.field public static c:I

.field public static d:I

.field public static e:I

.field public static f:I

.field public static g:Z

.field private static h:[Ljavax/microedition/lcdui/Image;

.field private static i:I

.field private static j:I

.field private static k:I

.field private static l:I

.field private static m:I

.field private static n:I

.field private static o:I

.field private static p:I

.field private static q:I

.field private static r:I

.field private static s:I

.field private static t:I

.field private static u:I

.field private static v:I

.field private static w:[[I

.field private static x:[I

.field private static y:I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x5

    new-array v0, v0, [[I

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v4, v1, v4

    const/16 v2, 0x1e

    aput v2, v1, v5

    aput v5, v1, v3

    const/16 v2, -0xf

    aput v2, v1, v6

    aput-object v1, v0, v7

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v5, v1, v7

    aput v3, v1, v4

    const/16 v2, 0x1c

    aput v2, v1, v5

    aput v3, v1, v3

    const/16 v2, -0xc

    aput v2, v1, v6

    aput-object v1, v0, v4

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v6, v1, v7

    aput v3, v1, v4

    const/16 v2, 0x19

    aput v2, v1, v5

    aput v3, v1, v3

    const/16 v2, -0xc

    aput v2, v1, v6

    aput-object v1, v0, v5

    const/4 v1, 0x6

    new-array v1, v1, [I

    const/4 v2, 0x5

    aput v2, v1, v7

    aput v3, v1, v4

    const/16 v2, 0x1a

    aput v2, v1, v5

    aput v3, v1, v3

    const/16 v2, -0xc

    aput v2, v1, v6

    aput-object v1, v0, v3

    const/4 v1, 0x6

    new-array v1, v1, [I

    const/4 v2, 0x5

    aput v2, v1, v7

    aput v4, v1, v4

    const/16 v2, 0x1f

    aput v2, v1, v5

    aput v3, v1, v3

    const/16 v2, -0xc

    aput v2, v1, v6

    aput-object v1, v0, v6

    sput-object v0, Lm;->w:[[I

    new-array v0, v6, [I

    aput v3, v0, v4

    aput v4, v0, v5

    aput v6, v0, v3

    sput-object v0, Lm;->x:[I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method public static a(I)V
    .registers 7

    const/4 v5, 0x6

    const/4 v1, 0x0

    sput-boolean v1, Lm;->a:Z

    sget-boolean v0, Lm;->g:Z

    if-eqz v0, :cond_9

    :cond_8
    :goto_8
    return-void

    :cond_9
    const/16 v0, 0x66

    if-ne p0, v0, :cond_8

    const/4 v0, 0x1

    sput-boolean v0, Lm;->a:Z

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_1b

    new-array v0, v5, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    move v0, v1

    :goto_19
    if-lt v0, v5, :cond_48

    :cond_1b
    const/16 v0, 0xc0

    sput v0, Lm;->b:I

    const/16 v0, 0x138

    sput v0, Lm;->c:I

    sput v0, Lm;->i:I

    const/16 v0, 0x60

    sput v0, Lm;->l:I

    const/16 v0, 0x1b0

    sput v0, Lm;->m:I

    const/4 v0, -0x1

    sput v0, Lm;->p:I

    sput v1, Lm;->q:I

    const/16 v0, 0x32

    sput v0, Lm;->d:I

    const/16 v0, 0x40

    sput v0, Lm;->r:I

    sput v1, Lm;->n:I

    const/4 v0, 0x3

    sput v0, Lm;->s:I

    const/16 v0, 0x50

    sput v0, Lm;->t:I

    const/16 v0, 0x120

    sput v0, Lm;->v:I

    goto :goto_8

    :cond_48
    :try_start_48
    sget-object v2, Lm;->h:[Ljavax/microedition/lcdui/Image;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "/mob/b3"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    const-string v4, ".png"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v3

    aput-object v3, v2, v0
    :try_end_65
    .catch Ljava/io/IOException; {:try_start_48 .. :try_end_65} :catch_68

    :goto_65
    add-int/lit8 v0, v0, 0x1

    goto :goto_19

    :catch_68
    move-exception v2

    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v3, "Shr ERR"

    invoke-virtual {v2, v3}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_65
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/16 v9, 0x21

    const/4 v11, 0x3

    const/4 v6, 0x2

    const/4 v10, 0x1

    const/4 v2, 0x0

    sget-boolean v0, Lm;->a:Z

    if-nez v0, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    sget v0, Lm;->p:I

    if-ne v0, v10, :cond_bb

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lm;->w:[[I

    sget v3, Lm;->q:I

    aget-object v1, v1, v3

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lm;->b:I

    sget-object v2, Lm;->w:[[I

    sget v3, Lm;->q:I

    aget-object v2, v2, v3

    aget v2, v2, v6

    add-int/2addr v1, v2

    sget v2, Lm;->c:I

    sget-object v3, Lm;->w:[[I

    sget v4, Lm;->q:I

    aget-object v3, v3, v4

    aget v3, v3, v11

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lm;->w:[[I

    sget v2, Lm;->q:I

    aget-object v1, v1, v2

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget v1, Lm;->b:I

    sget-object v2, Lm;->w:[[I

    sget v3, Lm;->q:I

    aget-object v2, v2, v3

    const/4 v3, 0x4

    aget v2, v2, v3

    add-int/2addr v1, v2

    sget v2, Lm;->c:I

    sget-object v3, Lm;->w:[[I

    sget v4, Lm;->q:I

    aget-object v3, v3, v4

    const/4 v4, 0x5

    aget v3, v3, v4

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :goto_5b
    sget v0, Lm;->y:I

    if-eqz v0, :cond_a

    const v0, 0x330011

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lm;->b:I

    sget v1, Lm;->r:I

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    sget v1, Lm;->c:I

    sget v2, Lm;->d:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, -0x7

    sget v2, Lm;->r:I

    add-int/lit8 v2, v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lm;->e:I

    sget v1, Lm;->r:I

    mul-int/2addr v0, v1

    sget v1, Lm;->f:I

    div-int/2addr v0, v1

    const/high16 v1, 0xee0000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lm;->b:I

    sget v2, Lm;->r:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    sget v2, Lm;->c:I

    sget v3, Lm;->d:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x6

    invoke-virtual {p0, v1, v2, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0x440022

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lm;->b:I

    sget v2, Lm;->r:I

    shr-int/lit8 v2, v2, 0x1

    sub-int/2addr v1, v2

    add-int/2addr v1, v0

    sget v2, Lm;->c:I

    sget v3, Lm;->d:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x6

    sget v3, Lm;->r:I

    sub-int v0, v3, v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v1, v2, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    goto/16 :goto_a

    :cond_bb
    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lm;->w:[[I

    sget v3, Lm;->q:I

    aget-object v1, v1, v3

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lm;->w:[[I

    sget v4, Lm;->q:I

    aget-object v3, v3, v4

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lm;->w:[[I

    sget v5, Lm;->q:I

    aget-object v3, v3, v5

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lm;->b:I

    sget-object v3, Lm;->w:[[I

    sget v7, Lm;->q:I

    aget-object v3, v3, v7

    aget v3, v3, v6

    sub-int v7, v0, v3

    sget v0, Lm;->c:I

    sget-object v3, Lm;->w:[[I

    sget v8, Lm;->q:I

    aget-object v3, v3, v8

    aget v3, v3, v11

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lm;->w:[[I

    sget v3, Lm;->q:I

    aget-object v1, v1, v3

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lm;->w:[[I

    sget v4, Lm;->q:I

    aget-object v3, v3, v4

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lm;->h:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lm;->w:[[I

    sget v5, Lm;->q:I

    aget-object v3, v3, v5

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lm;->b:I

    sget-object v3, Lm;->w:[[I

    sget v7, Lm;->q:I

    aget-object v3, v3, v7

    const/4 v7, 0x4

    aget v3, v3, v7

    sub-int v7, v0, v3

    sget v0, Lm;->c:I

    sget-object v3, Lm;->w:[[I

    sget v8, Lm;->q:I

    aget-object v3, v3, v8

    const/4 v8, 0x5

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_5b
.end method

.method public static b()V
    .registers 7

    const/16 v6, 0x8

    const/4 v5, 0x3

    const/4 v4, -0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-boolean v0, Lm;->a:Z

    if-nez v0, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    sget v0, Lm;->s:I

    packed-switch v0, :pswitch_data_2c2

    :pswitch_10  #0x5, 0x8, 0x9, 0xa, 0xb
    goto :goto_a

    :pswitch_11  #0x1
    sget-boolean v0, Lg;->y:Z

    if-nez v0, :cond_26

    sput-boolean v2, Lm;->g:Z

    const/4 v0, 0x4

    sput v0, Lq;->bi:I

    invoke-static {}, Lq;->f()V

    sget v0, Lm;->b:I

    sget v1, Lm;->c:I

    invoke-static {v0, v1}, Lq;->a(II)V

    sput-boolean v2, Lg;->y:Z

    :cond_26
    sget v0, Lm;->o:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->o:I

    const/4 v0, 0x2

    sput v0, Lm;->q:I

    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    sget v1, Lm;->l:I

    if-ge v0, v1, :cond_a8

    sget v0, Lm;->l:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lm;->b:I

    sput v2, Lm;->p:I

    :cond_44
    :goto_44
    sget v0, Lm;->c:I

    sget v1, Lm;->u:I

    add-int/2addr v0, v1

    sput v0, Lm;->c:I

    sget v0, Lm;->u:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->u:I

    sget v0, Lm;->c:I

    const/16 v1, 0x2d0

    if-le v0, v1, :cond_97

    sget v0, Lq;->as:I

    const/16 v1, 0x66

    if-ne v0, v1, :cond_94

    sget-boolean v0, Lg;->y:Z

    if-eqz v0, :cond_94

    sget v0, Lg;->aW:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lg;->aW:I

    sget v0, Lg;->aM:I

    sget-object v1, Lg;->d:[I

    sget v2, Lg;->aW:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aM:I

    sput v0, Lg;->aL:I

    sget v0, Lg;->aO:I

    sget-object v1, Lg;->e:[I

    sget v2, Lg;->aW:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aO:I

    sput v0, Lg;->aN:I

    sget v0, Lg;->aJ:I

    sget-object v1, Lg;->b:[I

    sget v2, Lg;->aW:I

    aget v1, v1, v2

    add-int/2addr v0, v1

    sput v0, Lg;->aJ:I

    sput v3, Lg;->aX:I

    invoke-static {v6}, Lq;->h(I)V

    const/4 v0, 0x7

    sput v0, Lq;->K:I

    :cond_94
    const/4 v0, 0x5

    sput v0, Lm;->s:I

    :cond_97
    sget v0, Lm;->c:I

    sget v1, Lm;->v:I

    if-le v0, v1, :cond_a

    sget v0, Lm;->b:I

    sget v1, Lm;->v:I

    add-int/lit8 v1, v1, -0xc

    invoke-static {v0, v1}, Lq;->c(II)Z

    goto/16 :goto_a

    :cond_a8
    sget v0, Lm;->b:I

    sget v1, Lm;->m:I

    if-le v0, v1, :cond_44

    sget v0, Lm;->m:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lm;->b:I

    sput v4, Lm;->p:I

    goto :goto_44

    :pswitch_b7  #0x6
    sget v0, Lm;->o:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->o:I

    const/4 v0, 0x2

    sput v0, Lm;->q:I

    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    sget v1, Lm;->l:I

    if-ge v0, v1, :cond_105

    sget v0, Lm;->l:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lm;->b:I

    sput v2, Lm;->p:I

    :cond_d5
    :goto_d5
    sget v0, Lm;->c:I

    sget v1, Lm;->u:I

    add-int/2addr v0, v1

    sput v0, Lm;->c:I

    sget v0, Lm;->u:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->u:I

    sget v0, Lm;->c:I

    sget v1, Lm;->i:I

    if-le v0, v1, :cond_f4

    sget v0, Lm;->i:I

    sput v0, Lm;->c:I

    invoke-static {}, Lm;->d()V

    sget v0, Lm;->p:I

    neg-int v0, v0

    sput v0, Lm;->p:I

    :cond_f4
    sget v0, Lm;->c:I

    sget v1, Lm;->v:I

    if-le v0, v1, :cond_a

    sget v0, Lm;->b:I

    sget v1, Lm;->v:I

    add-int/lit8 v1, v1, -0xc

    invoke-static {v0, v1}, Lq;->c(II)Z

    goto/16 :goto_a

    :cond_105
    sget v0, Lm;->b:I

    sget v1, Lm;->m:I

    if-le v0, v1, :cond_d5

    sget v0, Lm;->m:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lm;->b:I

    sput v4, Lm;->p:I

    goto :goto_d5

    :pswitch_114  #0xc
    sget v0, Lm;->n:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->n:I

    if-lt v0, v6, :cond_11e

    sput v3, Lm;->n:I

    :cond_11e
    sget-object v0, Lm;->x:[I

    sget v1, Lm;->n:I

    shr-int/lit8 v1, v1, 0x1

    aget v0, v0, v1

    sput v0, Lm;->q:I

    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    sget v0, Lm;->c:I

    sget v1, Lm;->v:I

    if-le v0, v1, :cond_13d

    sget v0, Lm;->c:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lm;->c:I

    :cond_13d
    sget v0, Lm;->b:I

    sget v1, Lm;->l:I

    if-ge v0, v1, :cond_168

    sget v0, Lm;->l:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lm;->b:I

    sput v2, Lm;->p:I

    sput v3, Lm;->o:I

    sput v3, Lm;->n:I

    sput v5, Lm;->s:I

    sget v0, Lm;->i:I

    sput v0, Lm;->c:I

    :cond_155
    :goto_155
    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x4

    sub-int/2addr v0, v1

    sget v1, Lm;->v:I

    add-int/lit8 v1, v1, -0xc

    invoke-static {v0, v1}, Lq;->c(II)Z

    invoke-static {}, Lm;->c()V

    goto/16 :goto_a

    :cond_168
    sget v0, Lm;->b:I

    sget v1, Lm;->m:I

    if-le v0, v1, :cond_155

    sget v0, Lm;->m:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lm;->b:I

    sput v4, Lm;->p:I

    sput v3, Lm;->o:I

    sput v3, Lm;->n:I

    const/4 v0, 0x2

    sput v0, Lm;->s:I

    const/16 v0, 0x14

    sput v0, Lm;->j:I

    sget v0, Lm;->i:I

    sput v0, Lm;->c:I

    goto :goto_155

    :pswitch_186  #0x4
    sget v0, Lm;->o:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->o:I

    const/4 v1, 0x4

    if-le v0, v1, :cond_1eb

    sput v5, Lm;->q:I

    :goto_191
    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    sget v0, Lm;->j:I

    if-lez v0, :cond_1ad

    sget v0, Lm;->j:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lm;->j:I

    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    :cond_1ad
    sget v0, Lm;->b:I

    sget v1, Lm;->l:I

    add-int/lit8 v1, v1, 0xa

    if-ge v0, v1, :cond_1ee

    sget v0, Lm;->l:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lm;->b:I

    sput v2, Lm;->p:I

    :cond_1bd
    :goto_1bd
    sget v0, Lm;->c:I

    sget v1, Lm;->u:I

    add-int/2addr v0, v1

    sput v0, Lm;->c:I

    sget v0, Lm;->u:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->u:I

    sget v0, Lm;->c:I

    sget v1, Lm;->i:I

    if-le v0, v1, :cond_1d7

    sget v0, Lm;->i:I

    sput v0, Lm;->c:I

    invoke-static {}, Lm;->d()V

    :cond_1d7
    sget v0, Lm;->c:I

    sget v1, Lm;->v:I

    if-le v0, v1, :cond_1e6

    sget v0, Lm;->b:I

    sget v1, Lm;->v:I

    add-int/lit8 v1, v1, -0xc

    invoke-static {v0, v1}, Lq;->c(II)Z

    :cond_1e6
    invoke-static {}, Lm;->c()V

    goto/16 :goto_a

    :cond_1eb
    sput v2, Lm;->q:I

    goto :goto_191

    :cond_1ee
    sget v0, Lm;->b:I

    sget v1, Lm;->m:I

    add-int/lit8 v1, v1, -0xa

    if-le v0, v1, :cond_1bd

    sget v0, Lm;->m:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lm;->b:I

    sput v4, Lm;->p:I

    goto :goto_1bd

    :pswitch_1ff  #0x3
    sput v2, Lm;->q:I

    sget v0, Lm;->n:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->n:I

    sget v0, Lm;->o:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->o:I

    const/16 v1, 0x14

    if-ne v0, v1, :cond_216

    invoke-static {}, Lm;->d()V

    goto/16 :goto_a

    :cond_216
    sget v0, Lm;->n:I

    if-le v0, v6, :cond_21c

    sput v3, Lm;->n:I

    :cond_21c
    sget v0, Lm;->n:I

    if-le v0, v5, :cond_a

    sput v3, Lm;->q:I

    goto/16 :goto_a

    :pswitch_224  #0x2
    sput v2, Lm;->q:I

    sget v0, Lm;->n:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->n:I

    if-le v0, v6, :cond_230

    sput v3, Lm;->n:I

    :cond_230
    sget v0, Lm;->n:I

    if-le v0, v5, :cond_236

    sput v3, Lm;->q:I

    :cond_236
    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    sget v0, Lm;->j:I

    if-lez v0, :cond_252

    sget v0, Lm;->j:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lm;->j:I

    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Lm;->b:I

    :cond_252
    sget v0, Lm;->b:I

    sget v1, Lm;->l:I

    if-ge v0, v1, :cond_283

    sget v0, Lm;->l:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lm;->b:I

    sput v2, Lm;->p:I

    :cond_260
    :goto_260
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x4

    if-nez v0, :cond_a

    sget v0, Lg;->at:I

    sget v1, Lm;->b:I

    sub-int/2addr v0, v1

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x6

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-ge v0, v1, :cond_a

    sget v0, Lm;->k:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->k:I

    invoke-static {}, Lm;->d()V

    goto/16 :goto_a

    :cond_283
    sget v0, Lm;->b:I

    sget v1, Lm;->m:I

    if-le v0, v1, :cond_260

    sget v0, Lm;->m:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lm;->b:I

    sput v4, Lm;->p:I

    goto :goto_260

    :pswitch_292  #0x7
    sput v2, Lm;->q:I

    sget v0, Lm;->n:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->n:I

    if-le v0, v6, :cond_29e

    sput v3, Lm;->n:I

    :cond_29e
    sget v0, Lm;->n:I

    if-le v0, v5, :cond_2a4

    sput v3, Lm;->q:I

    :cond_2a4
    sget v0, Lm;->b:I

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x2

    sub-int/2addr v0, v1

    sput v0, Lm;->b:I

    sget v1, Lm;->l:I

    if-lt v0, v1, :cond_2b7

    sget v0, Lm;->b:I

    sget v1, Lm;->m:I

    if-le v0, v1, :cond_a

    :cond_2b7
    sput v3, Lm;->o:I

    sput v3, Lm;->n:I

    const/16 v0, 0xc

    sput v0, Lm;->s:I

    goto/16 :goto_a

    nop

    :pswitch_data_2c2
    .packed-switch 0x1
        :pswitch_11  #00000001
        :pswitch_224  #00000002
        :pswitch_1ff  #00000003
        :pswitch_186  #00000004
        :pswitch_10  #00000005
        :pswitch_b7  #00000006
        :pswitch_292  #00000007
        :pswitch_10  #00000008
        :pswitch_10  #00000009
        :pswitch_10  #0000000a
        :pswitch_10  #0000000b
        :pswitch_114  #0000000c
    .end packed-switch
.end method

.method public static b(I)Z
    .registers 10

    const/4 v0, 0x1

    const/4 v8, -0x5

    const/16 v7, -0xa

    const/16 v6, 0x32

    const/4 v1, 0x0

    sget v2, Lm;->e:I

    sub-int/2addr v2, p0

    sput v2, Lm;->e:I

    if-gtz v2, :cond_4b

    sput v1, Lm;->e:I

    sput v8, Lm;->n:I

    sget v2, Lm;->p:I

    shl-int/lit8 v2, v2, 0x3

    neg-int v2, v2

    sput v2, Lm;->o:I

    sput v1, Lm;->y:I

    sput v0, Lm;->s:I

    sput v7, Lm;->u:I

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    const/4 v4, 0x4

    const/4 v5, -0x6

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    const/4 v4, -0x7

    invoke-static {v2, v3, v8, v4, v6}, Lq;->a(IIIII)V

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    const/4 v4, -0x4

    const/4 v5, -0x8

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    const/4 v4, 0x5

    const/16 v5, -0x9

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lm;->b:I

    sget v3, Lm;->c:I

    invoke-static {v2, v3, v1, v7, v6}, Lq;->a(IIIII)V

    :goto_4a
    return v0

    :cond_4b
    sget v0, Lm;->k:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lm;->k:I

    const/16 v0, 0xa

    sput v0, Lm;->j:I

    sput v1, Lm;->n:I

    sput v1, Lm;->o:I

    const/4 v0, 0x6

    sput v0, Lm;->s:I

    const/16 v0, 0xa

    sput v0, Lm;->y:I

    move v0, v1

    goto :goto_4a
.end method

.method private static c()V
    .registers 2

    sget v0, Lg;->au:I

    sget v1, Lm;->c:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_2b

    sget v0, Lg;->at:I

    sget v1, Lm;->b:I

    sub-int/2addr v0, v1

    sget v1, Lm;->p:I

    shl-int/lit8 v1, v1, 0x5

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x14

    if-ge v0, v1, :cond_2b

    sget v0, Lg;->ax:I

    const/4 v1, 0x7

    if-eq v0, v1, :cond_2b

    sget v0, Lm;->t:I

    sget v1, Lm;->p:I

    invoke-static {v0, v1}, Lg;->a(II)V

    :cond_2b
    return-void
.end method

.method private static d()V
    .registers 4

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x0

    sget v1, Lm;->k:I

    if-lez v1, :cond_18

    sget v1, Lm;->k:I

    add-int/lit8 v1, v1, -0x1

    sput v1, Lm;->k:I

    sput v3, Lm;->s:I

    sget v1, Lm;->k:I

    if-le v1, v0, :cond_44

    :goto_13
    rsub-int/lit8 v0, v0, -0xa

    sput v0, Lm;->u:I

    :goto_17
    return-void

    :cond_18
    sget v0, Lm;->p:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_23

    sget v0, Lm;->b:I

    sget v1, Lg;->at:I

    if-gt v0, v1, :cond_2e

    :cond_23
    sget v0, Lm;->p:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_3c

    sget v0, Lm;->b:I

    sget v1, Lg;->at:I

    if-ge v0, v1, :cond_3c

    :cond_2e
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    if-le v0, v3, :cond_3c

    sput v2, Lm;->o:I

    sput v2, Lm;->n:I

    const/4 v0, 0x7

    sput v0, Lm;->s:I

    goto :goto_17

    :cond_3c
    sput v2, Lm;->o:I

    sput v2, Lm;->n:I

    const/4 v0, 0x2

    sput v0, Lm;->s:I

    goto :goto_17

    :cond_44
    move v0, v1

    goto :goto_13
.end method
