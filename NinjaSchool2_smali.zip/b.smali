.class public final Lb;
.super Ljava/lang/Object;


# static fields
.field public static a:Z

.field public static b:Ljava/lang/String;

.field static c:[[Ljava/lang/String;

.field public static d:[[Ljava/lang/String;

.field public static e:Ljava/lang/String;

.field public static f:[Ljava/lang/String;

.field public static g:I

.field public static h:I

.field public static i:Ljavax/microedition/lcdui/Font;

.field static j:Z

.field private static k:[Ljava/lang/String;

.field private static l:I

.field private static m:Ljavax/microedition/lcdui/Font;

.field private static n:I

.field private static o:Ljava/lang/String;

.field private static p:Ljava/lang/String;

.field private static q:I

.field private static r:Ljava/lang/String;

.field private static s:[I

.field private static t:I

.field private static u:I

.field private static v:Ljava/lang/String;

.field private static w:I

.field private static x:I


# direct methods
.method static constructor <clinit>()V
    .registers 10

    const/4 v9, 0x5

    const/4 v6, 0x4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v0, 0x0

    const-string v1, "sms://8724"

    sput-object v1, Lb;->b:Ljava/lang/String;

    new-array v1, v8, [[Ljava/lang/String;

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "BinhHP_Nho(50)"

    aput-object v3, v2, v0

    const-string v3, "BinhHP_Vua(50)"

    aput-object v3, v2, v7

    const-string v3, "BinhHP_To(30)"

    aput-object v3, v2, v8

    const/4 v3, 0x3

    const-string v4, "BinhMP_Nho(50)"

    aput-object v4, v2, v3

    const-string v3, "BinhMP_Vua(50)"

    aput-object v3, v2, v6

    const-string v3, "BinhMP_To(30)"

    aput-object v3, v2, v9

    aput-object v2, v1, v0

    new-array v2, v6, [Ljava/lang/String;

    const-string v3, "Thuoc"

    aput-object v3, v2, v0

    const-string v3, "ThuyLinhKiem"

    aput-object v3, v2, v7

    const-string v3, "HoaGiacKiem"

    aput-object v3, v2, v8

    const/4 v3, 0x3

    const-string v4, "LongGiaoKiem"

    aput-object v4, v2, v3

    aput-object v2, v1, v7

    sput-object v1, Lb;->c:[[Ljava/lang/String;

    new-array v1, v8, [[Ljava/lang/String;

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v0

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v9

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v7

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v9

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v8

    const/4 v3, 0x3

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "sms://"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v5, Lq;->bj:[Ljava/lang/String;

    aget-object v5, v5, v6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v9

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v6

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v9

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v9

    aput-object v2, v1, v0

    new-array v2, v6, [Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v0

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v7

    new-instance v3, Ljava/lang/StringBuffer;

    const-string v4, "sms://"

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lq;->bj:[Ljava/lang/String;

    aget-object v4, v4, v9

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v8

    const/4 v3, 0x3

    new-instance v4, Ljava/lang/StringBuffer;

    const-string v5, "sms://"

    invoke-direct {v4, v5}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v5, Lq;->bj:[Ljava/lang/String;

    const/4 v6, 0x6

    aget-object v5, v5, v6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    aput-object v2, v1, v7

    sput-object v1, Lb;->d:[[Ljava/lang/String;

    const-string v1, "TD15"

    sput-object v1, Lb;->e:Ljava/lang/String;

    const/4 v1, 0x3

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "1. Tiep tuc"

    aput-object v2, v1, v0

    const-string v2, "2. Kich hoat"

    aput-object v2, v1, v7

    const-string v2, "3. Nhap ma kich hoat"

    aput-object v2, v1, v8

    sput-object v1, Lb;->k:[Ljava/lang/String;

    new-array v1, v8, [Ljava/lang/String;

    const-string v2, "1. Kich hoat"

    aput-object v2, v1, v0

    const-string v2, "2. Nhap ma kich hoat"

    aput-object v2, v1, v7

    sput-object v1, Lb;->f:[Ljava/lang/String;

    invoke-static {v0, v0, v0}, Ljavax/microedition/lcdui/Font;->getFont(III)Ljavax/microedition/lcdui/Font;

    move-result-object v1

    sput-object v1, Lb;->i:Ljavax/microedition/lcdui/Font;

    invoke-static {v0, v7, v0}, Ljavax/microedition/lcdui/Font;->getFont(III)Ljavax/microedition/lcdui/Font;

    move-result-object v1

    sput-object v1, Lb;->m:Ljavax/microedition/lcdui/Font;

    sget-object v1, Lb;->i:Ljavax/microedition/lcdui/Font;

    invoke-virtual {v1}, Ljavax/microedition/lcdui/Font;->getHeight()I

    move-result v1

    add-int/lit8 v1, v1, 0x6

    sput v1, Lb;->n:I

    sput-boolean v0, Lb;->j:Z

    const-string v1, "oplj"

    sput-object v1, Lb;->o:Ljava/lang/String;

    const-string v1, "12345678"

    sput-object v1, Lb;->p:Ljava/lang/String;

    const/16 v1, 0x9

    new-array v1, v1, [I

    sput-object v1, Lb;->s:[I

    const/4 v1, 0x3

    sput v1, Lb;->t:I

    sput v0, Lb;->u:I

    const-string v1, ""

    sput-object v1, Lb;->v:Ljava/lang/String;

    :goto_172
    const/16 v1, 0x9

    if-lt v0, v1, :cond_177

    return-void

    :cond_177
    sget-object v1, Lb;->s:[I

    shl-int/lit8 v2, v0, 0x1

    add-int/lit8 v2, v2, 0x1

    aput v2, v1, v0

    sget-object v1, Lb;->s:[I

    aget v2, v1, v0

    sget v3, Lq;->G:I

    add-int/2addr v2, v3

    aput v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_172
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x4

    invoke-virtual {p0, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    add-int/2addr v3, v2

    rem-int/lit8 v3, v3, 0xa

    add-int/2addr v2, v1

    rem-int/lit8 v2, v2, 0xa

    add-int/2addr v1, v0

    rem-int/lit8 v1, v1, 0xa

    add-int/2addr v0, v3

    rem-int/lit8 v0, v0, 0xa

    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static a()V
    .registers 10

    const/4 v1, -0x1

    const-wide/16 v8, 0x2197

    const-wide/16 v6, 0x3e8

    const/4 v2, 0x0

    const/16 v0, 0x1e

    sput v0, Lb;->q:I

    invoke-static {}, Lb;->h()V

    const-string v0, "np"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v0

    if-nez v0, :cond_a0

    move v0, v1

    :goto_16
    sput v0, Lb;->t:I

    if-ne v0, v1, :cond_55

    sget v0, Lb;->q:I

    div-int/lit8 v0, v0, 0xa

    sput v0, Lb;->t:I

    invoke-static {v0}, Lb;->b(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lb;->e:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " PAY "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    rem-long/2addr v4, v8

    add-long/2addr v4, v6

    long-to-int v1, v4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "110"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lb;->e(Ljava/lang/String;)V

    invoke-static {v2}, Lb;->c(I)V

    :cond_55
    invoke-static {}, Lq;->b()V

    const-string v0, "phone.imei"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_68

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6e

    :cond_68
    const-string v0, "com.nokia.IMEI"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_6e
    if-eqz v0, :cond_7a

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7a

    sput-object v0, Lb;->p:Ljava/lang/String;

    :cond_7a
    const-string v0, "im"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v1

    if-nez v1, :cond_a4

    const/4 v0, 0x0

    :goto_83
    if-nez v0, :cond_aa

    sget-object v0, Lb;->p:Ljava/lang/String;

    const-string v1, "im"

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-static {v1, v0}, Lb;->a(Ljava/lang/String;[B)V

    :cond_90
    :goto_90
    const/16 v0, 0xd

    sput v0, Lq;->K:I

    const-string v0, "r"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v0

    if-nez v0, :cond_eb

    move v0, v2

    :goto_9d
    sput v0, Lb;->g:I

    return-void

    :cond_a0
    aget-byte v0, v0, v2

    goto/16 :goto_16

    :cond_a4
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    goto :goto_83

    :cond_aa
    sget-object v1, Lb;->p:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_90

    const/4 v0, 0x2

    sput v0, Lb;->t:I

    invoke-static {v0}, Lb;->b(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lb;->e:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " PAY "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    rem-long/2addr v4, v8

    add-long/2addr v4, v6

    long-to-int v1, v4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "110"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lb;->e(Ljava/lang/String;)V

    invoke-static {v2}, Lb;->c(I)V

    goto :goto_90

    :cond_eb
    aget-byte v0, v0, v2

    goto :goto_9d
.end method

.method private static a(I)V
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    int-to-byte v2, p0

    aput-byte v2, v0, v1

    const-string v1, "bc"

    invoke-static {v1, v0}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 5

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lf;

    invoke-direct {v1, p1, p0, p2}, Lf;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static a(Ljava/lang/String;[B)V
    .registers 6

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "NINJASCHOOL"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    :try_start_10
    invoke-static {v0, v1}, Ljavax/microedition/rms/RecordStore;->openRecordStore(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;

    move-result-object v0

    invoke-virtual {v0}, Ljavax/microedition/rms/RecordStore;->getNumRecords()I

    move-result v1

    if-lez v1, :cond_24

    const/4 v1, 0x1

    const/4 v2, 0x0

    array-length v3, p1

    invoke-virtual {v0, v1, p1, v2, v3}, Ljavax/microedition/rms/RecordStore;->setRecord(I[BII)V

    :goto_20
    invoke-virtual {v0}, Ljavax/microedition/rms/RecordStore;->closeRecordStore()V

    :goto_23
    return-void

    :cond_24
    const/4 v1, 0x0

    array-length v2, p1

    invoke-virtual {v0, p1, v1, v2}, Ljavax/microedition/rms/RecordStore;->addRecord([BII)I
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_29} :catch_2a

    goto :goto_20

    :catch_2a
    move-exception v0

    goto :goto_23
.end method

.method protected static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, 0x2

    const/16 v10, 0x14

    const v0, 0x6d6d6d

    const/4 v2, 0x0

    const/16 v9, 0x11

    const v1, 0xeaeaea

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->E:I

    sget v3, Lq;->F:I

    invoke-virtual {p0, v2, v2, v1, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0xb3e150

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lq;->E:I

    sget v3, Lb;->n:I

    invoke-virtual {p0, v2, v2, v1, v3}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget v1, Lq;->F:I

    sget v3, Lb;->n:I

    sub-int/2addr v1, v3

    sget v3, Lq;->E:I

    sget v4, Lb;->n:I

    invoke-virtual {p0, v2, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0xffffff

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v1, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v1, "Ninja School 2"

    sget v3, Lq;->G:I

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    sget-object v1, Lb;->i:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    sget v1, Lb;->g:I

    packed-switch v1, :pswitch_data_3c2

    :goto_4c
    :pswitch_4c  #0x3
    return-void

    :pswitch_4d  #0x0
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v1, Lb;->s:[I

    const/4 v3, 0x1

    aget v1, v1, v3

    sget-object v3, Lb;->s:[I

    const/4 v4, 0x5

    aget v3, v3, v4

    if-eq v1, v3, :cond_83

    sget-object v1, Lb;->s:[I

    aget v1, v1, v11

    sget-object v3, Lb;->s:[I

    const/4 v4, 0x6

    aget v3, v3, v4

    if-eq v1, v3, :cond_83

    sget-object v1, Lb;->s:[I

    const/4 v3, 0x3

    aget v1, v1, v3

    sget-object v3, Lb;->s:[I

    const/4 v4, 0x7

    aget v3, v3, v4

    if-eq v1, v3, :cond_83

    sget-object v1, Lb;->s:[I

    const/4 v3, 0x4

    aget v1, v1, v3

    sget-object v3, Lb;->s:[I

    const/16 v4, 0x8

    aget v3, v3, v4

    if-eq v1, v3, :cond_83

    const/4 v1, 0x7

    sput v1, Lb;->g:I

    :cond_83
    const v1, 0xb3e150

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const/4 v1, 0x3

    sget v3, Lq;->H:I

    add-int/lit8 v3, v3, -0x8

    sget v4, Lb;->u:I

    sget v5, Lb;->n:I

    mul-int/2addr v4, v5

    add-int/2addr v3, v4

    sget v4, Lq;->E:I

    add-int/lit8 v4, v4, -0x6

    sget v5, Lb;->n:I

    invoke-virtual {p0, v1, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const/4 v1, 0x4

    sget v3, Lq;->H:I

    add-int/lit8 v3, v3, -0x8

    sget v4, Lb;->u:I

    sget v5, Lb;->n:I

    mul-int/2addr v4, v5

    add-int/2addr v3, v4

    add-int/lit8 v3, v3, 0x1

    sget v4, Lq;->E:I

    add-int/lit8 v4, v4, -0x8

    sget v5, Lb;->n:I

    add-int/lit8 v5, v5, -0x2

    invoke-virtual {p0, v1, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    const v1, 0x32e58

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lb;->t:I

    if-lez v1, :cond_11c

    sget-object v1, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v1, "VeChai321"

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    sget v5, Lb;->n:I

    shl-int/lit8 v5, v5, 0x1

    sub-int/2addr v4, v5

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    sget-object v1, Lb;->i:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    :goto_d7
    const/4 v1, 0x3

    if-lt v2, v1, :cond_105

    :cond_da
    const v0, 0xffffff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v0, "Chon"

    sget v1, Lq;->F:I

    sget v2, Lb;->n:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    invoke-virtual {p0, v0, v11, v1, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "Thoat"

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, -0x2

    sget v2, Lq;->F:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, 0x3

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :cond_105
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v1, Lb;->k:[Ljava/lang/String;

    aget-object v1, v1, v2

    sget v3, Lb;->h:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0x5

    sget v5, Lb;->n:I

    mul-int/2addr v5, v2

    add-int/2addr v4, v5

    invoke-virtual {p0, v1, v3, v4, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_d7

    :cond_11c
    const-string v1, "Da het han dung thu"

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    sget v5, Lb;->n:I

    shl-int/lit8 v5, v5, 0x1

    sub-int/2addr v4, v5

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v1, "Moi ban kich hoat."

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    sget v5, Lb;->n:I

    sub-int/2addr v4, v5

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    :goto_136
    if-ge v2, v11, :cond_da

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v1, Lb;->f:[Ljava/lang/String;

    aget-object v1, v1, v2

    sget v3, Lb;->h:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0x5

    sget v5, Lb;->n:I

    mul-int/2addr v5, v2

    add-int/2addr v4, v5

    invoke-virtual {p0, v1, v3, v4, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_136

    :pswitch_14f  #0x2
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const-string v0, "Gui tin kich hoat ton phi"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    shl-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "15.000đ. Ban se nhan"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "duoc ma kich hoat trong"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "tin nhan tra loi."

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    add-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const v0, 0xffffff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v0, "Dong y"

    sget v1, Lq;->F:I

    sget v2, Lb;->n:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    invoke-virtual {p0, v0, v11, v1, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "Khong"

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, -0x2

    sget v2, Lq;->F:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, 0x3

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :pswitch_1ac  #0x1
    sget v1, Lb;->l:I

    rem-int/lit8 v1, v1, 0xa

    const/4 v2, 0x5

    if-le v1, v2, :cond_1b6

    const v0, 0xffffff

    :cond_1b6
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const-string v0, "Dang gui tin"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "kich hoat..."

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :pswitch_1d0  #0x5
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const-string v0, "Da gui tin kich hoat."

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    shl-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "Xin thoat game va"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "cho giay lat. Ban se"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "nhan duoc ma kich hoat."

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    add-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const v0, 0xffffff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v0, "OK"

    sget v1, Lq;->F:I

    sget v2, Lb;->n:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    invoke-virtual {p0, v0, v11, v1, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :pswitch_21b  #0x6
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const-string v0, "Khong the gui SMS"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    shl-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "Xin hay thu lai. Vao"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "http://vechai321.xtgem.com"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "de biet them thong tin."

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    add-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const v0, 0xffffff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v0, "OK"

    sget v1, Lq;->F:I

    sget v2, Lb;->n:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    invoke-virtual {p0, v0, v11, v1, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :pswitch_266  #0x4
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const-string v1, "Nhap ma kich hoat:"

    sget v3, Lq;->G:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0x3c

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const v1, 0xb3e150

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lb;->w:I

    mul-int/lit8 v1, v1, 0x14

    sget v3, Lq;->G:I

    add-int/2addr v1, v3

    add-int/lit8 v1, v1, -0x32

    sget v3, Lb;->x:I

    mul-int/lit8 v3, v3, 0x19

    sget v4, Lq;->H:I

    add-int/2addr v3, v4

    const/16 v4, 0x12

    const/16 v5, 0x17

    invoke-virtual {p0, v1, v3, v4, v5}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    move v5, v2

    move v1, v2

    :goto_293
    if-lt v5, v11, :cond_2ea

    sget-object v1, Lb;->v:Ljava/lang/String;

    sget v2, Lb;->l:I

    rem-int/lit8 v2, v2, 0xa

    const/4 v3, 0x5

    if-le v2, v3, :cond_2b1

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, "|"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_2b1
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->G:I

    add-int/lit8 v0, v0, -0x14

    sget v2, Lq;->H:I

    add-int/lit8 v2, v2, -0x28

    invoke-virtual {p0, v1, v0, v2, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const v0, 0xffffff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v0, "OK"

    sget v1, Lq;->F:I

    sget v2, Lb;->n:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    invoke-virtual {p0, v0, v11, v1, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "Xoa"

    sget v1, Lq;->E:I

    add-int/lit8 v1, v1, -0x2

    sget v2, Lq;->F:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, 0x3

    const/16 v3, 0x18

    invoke-virtual {p0, v0, v1, v2, v3}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :cond_2ea
    move v3, v2

    move v4, v1

    :goto_2ec
    const/4 v1, 0x5

    if-lt v3, v1, :cond_2f4

    add-int/lit8 v3, v5, 0x1

    move v5, v3

    move v1, v4

    goto :goto_293

    :cond_2f4
    const v1, 0xb3e150

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    mul-int/lit8 v1, v3, 0x14

    sget v6, Lq;->G:I

    add-int/2addr v1, v6

    add-int/lit8 v1, v1, -0x32

    mul-int/lit8 v6, v5, 0x19

    sget v7, Lq;->H:I

    add-int/2addr v6, v7

    const/16 v7, 0x12

    const/16 v8, 0x17

    invoke-virtual {p0, v1, v6, v7, v8}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v1, Lb;->w:I

    if-ne v3, v1, :cond_341

    sget v1, Lb;->x:I

    if-ne v5, v1, :cond_341

    const v1, 0xffffff

    :goto_318
    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v1, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    mul-int/lit8 v6, v3, 0x14

    sget v7, Lq;->G:I

    add-int/2addr v6, v7

    add-int/lit8 v6, v6, -0x32

    add-int/lit8 v6, v6, 0xa

    mul-int/lit8 v7, v5, 0x19

    sget v8, Lq;->H:I

    add-int/2addr v7, v8

    add-int/lit8 v7, v7, 0x3

    invoke-virtual {p0, v1, v6, v7, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    add-int/lit8 v4, v4, 0x1

    add-int/lit8 v1, v3, 0x1

    move v3, v1

    goto :goto_2ec

    :cond_341
    move v1, v0

    goto :goto_318

    :pswitch_343  #0x7
    invoke-virtual {p0, v2}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lq;->E:I

    sget v1, Lq;->F:I

    invoke-virtual {p0, v2, v2, v0, v1}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    sget-object v0, Lb;->v:Ljava/lang/String;

    sget v1, Lb;->l:I

    rem-int/lit8 v1, v1, 0xa

    const/4 v3, 0x5

    if-le v1, v3, :cond_369

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v0, "|"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_369
    sget v1, Lq;->G:I

    add-int/lit8 v1, v1, -0x14

    sget v3, Lq;->H:I

    add-int/lit8 v3, v3, -0x28

    invoke-virtual {p0, v0, v1, v3, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const/4 v0, 0x7

    invoke-static {v0}, Lb;->c(I)V

    invoke-static {}, Lq;->u()V

    const/4 v0, 0x4

    sput v0, Lq;->K:I

    invoke-static {}, Lb;->f()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_38a

    const/4 v0, 0x1

    :goto_386
    sput-boolean v0, Lb;->a:Z

    goto/16 :goto_4c

    :cond_38a
    move v0, v2

    goto :goto_386

    :pswitch_38c  #0x8
    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    const-string v0, "Xin vui long"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    shl-int/lit8 v3, v3, 0x1

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const-string v0, "Bat Bluetooth"

    sget v1, Lq;->G:I

    sget v2, Lq;->H:I

    sget v3, Lb;->n:I

    sub-int/2addr v2, v3

    invoke-virtual {p0, v0, v1, v2, v9}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    const v0, 0xffffff

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget-object v0, Lb;->m:Ljavax/microedition/lcdui/Font;

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setFont(Ljavax/microedition/lcdui/Font;)V

    const-string v0, "OK"

    sget v1, Lq;->F:I

    sget v2, Lb;->n:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x3

    invoke-virtual {p0, v0, v11, v1, v10}, Ljavax/microedition/lcdui/Graphics;->drawString(Ljava/lang/String;III)V

    goto/16 :goto_4c

    :pswitch_data_3c2
    .packed-switch 0x0
        :pswitch_4d  #00000000
        :pswitch_1ac  #00000001
        :pswitch_14f  #00000002
        :pswitch_4c  #00000003
        :pswitch_266  #00000004
        :pswitch_1d0  #00000005
        :pswitch_21b  #00000006
        :pswitch_343  #00000007
        :pswitch_38c  #00000008
    .end packed-switch
.end method

.method public static b()V
    .registers 10

    const/16 v9, 0x8

    const/4 v8, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x0

    sget v0, Lb;->l:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lb;->l:I

    const/16 v4, 0x2710

    if-le v0, v4, :cond_12

    sput v3, Lb;->l:I

    :cond_12
    sget-object v0, Lq;->x:Lq;

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Displayable;->getWidth()I

    move-result v0

    sput v0, Lq;->E:I

    sget-object v0, Lq;->x:Lq;

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Displayable;->getHeight()I

    move-result v0

    sput v0, Lq;->F:I

    sget-boolean v0, Lq;->z:Z

    if-eqz v0, :cond_3c

    sget v0, Lq;->B:I

    sget v4, Lq;->F:I

    add-int/lit8 v4, v4, -0x14

    if-le v0, v4, :cond_3c

    sget v0, Lq;->A:I

    sget v4, Lq;->G:I

    if-ge v0, v4, :cond_42

    sget-object v0, Lq;->D:[Z

    const/16 v4, 0xc

    aput-boolean v1, v0, v4

    :goto_3a
    sput-boolean v3, Lq;->z:Z

    :cond_3c
    sget v0, Lb;->g:I

    packed-switch v0, :pswitch_data_2e4

    :cond_41
    :goto_41
    :pswitch_41  #0x1, 0x3
    return-void

    :cond_42
    sget-object v0, Lq;->D:[Z

    const/16 v4, 0xd

    aput-boolean v1, v0, v4

    goto :goto_3a

    :pswitch_49  #0x0
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v2

    if-eqz v0, :cond_61

    sget v0, Lb;->u:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lb;->u:I

    if-gez v0, :cond_5e

    sget v0, Lb;->t:I

    if-nez v0, :cond_ca

    move v0, v1

    :goto_5c
    sput v0, Lb;->u:I

    :cond_5e
    invoke-static {}, Lq;->c()V

    :cond_61
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v9

    if-eqz v0, :cond_78

    sget v0, Lb;->u:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lb;->u:I

    sget v4, Lb;->t:I

    if-nez v4, :cond_cc

    :goto_71
    if-le v0, v1, :cond_75

    sput v3, Lb;->u:I

    :cond_75
    invoke-static {}, Lq;->c()V

    :cond_78
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v8

    if-nez v0, :cond_86

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_8c

    :cond_86
    invoke-static {}, Lb;->n()V

    invoke-static {}, Lq;->c()V

    :cond_8c
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_99

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    :cond_99
    sget-boolean v0, Lq;->z:Z

    if-eqz v0, :cond_41

    move v0, v3

    :goto_9e
    sget v1, Lb;->t:I

    if-nez v1, :cond_d5

    move v1, v2

    :goto_a3
    if-ge v0, v1, :cond_41

    sget v1, Lq;->B:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0x5

    sget v5, Lb;->n:I

    mul-int/2addr v5, v0

    add-int/2addr v4, v5

    if-le v1, v4, :cond_d2

    sget v1, Lq;->B:I

    sget v4, Lq;->H:I

    add-int/lit8 v4, v4, -0x5

    sget v5, Lb;->n:I

    mul-int/2addr v5, v0

    add-int/2addr v4, v5

    sget v5, Lb;->n:I

    add-int/2addr v4, v5

    if-ge v1, v4, :cond_d2

    sget v1, Lb;->u:I

    if-eq v1, v0, :cond_ce

    sput v0, Lb;->u:I

    :goto_c6
    sput-boolean v3, Lq;->z:Z

    goto/16 :goto_41

    :cond_ca
    move v0, v2

    goto :goto_5c

    :cond_cc
    move v1, v2

    goto :goto_71

    :cond_ce
    invoke-static {}, Lb;->n()V

    goto :goto_c6

    :cond_d2
    add-int/lit8 v0, v0, 0x1

    goto :goto_9e

    :cond_d5
    const/4 v1, 0x3

    goto :goto_a3

    :pswitch_d7  #0x2
    invoke-static {}, Lb;->m()V

    goto/16 :goto_41

    :pswitch_dc  #0x5
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v8

    if-nez v0, :cond_ea

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_41

    :cond_ea
    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    goto/16 :goto_41

    :pswitch_f1  #0x6
    invoke-static {}, Lb;->l()V

    goto/16 :goto_41

    :pswitch_f6  #0x4
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v2

    if-eqz v0, :cond_109

    sget v0, Lb;->x:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lb;->x:I

    if-gez v0, :cond_106

    sput v1, Lb;->x:I

    :cond_106
    invoke-static {}, Lq;->c()V

    :cond_109
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v9

    if-eqz v0, :cond_11c

    sget v0, Lb;->x:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lb;->x:I

    if-le v0, v1, :cond_119

    sput v3, Lb;->x:I

    :cond_119
    invoke-static {}, Lq;->c()V

    :cond_11c
    sget-object v0, Lq;->D:[Z

    const/4 v4, 0x4

    aget-boolean v0, v0, v4

    if-eqz v0, :cond_131

    sget v0, Lb;->w:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lb;->w:I

    if-gez v0, :cond_12e

    const/4 v0, 0x4

    sput v0, Lb;->w:I

    :cond_12e
    invoke-static {}, Lq;->c()V

    :cond_131
    sget-object v0, Lq;->D:[Z

    const/4 v4, 0x6

    aget-boolean v0, v0, v4

    if-eqz v0, :cond_146

    sget v0, Lb;->w:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lb;->w:I

    const/4 v4, 0x4

    if-le v0, v4, :cond_143

    sput v3, Lb;->w:I

    :cond_143
    invoke-static {}, Lq;->c()V

    :cond_146
    sget-object v0, Lq;->D:[Z

    aget-boolean v0, v0, v8

    if-eqz v0, :cond_152

    invoke-static {}, Lb;->k()V

    invoke-static {}, Lq;->c()V

    :cond_152
    sget-object v0, Lq;->D:[Z

    const/16 v4, 0xc

    aget-boolean v0, v0, v4

    if-eqz v0, :cond_1b2

    sget-object v0, Lb;->e:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, 0x5

    sget-object v4, Lb;->s:[I

    sget-object v5, Lb;->r:Ljava/lang/String;

    add-int/lit8 v6, v0, 0x1

    invoke-virtual {v5, v0, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    aput v0, v4, v8

    sget-object v0, Lb;->s:[I

    const/4 v4, 0x6

    sget-object v5, Lb;->r:Ljava/lang/String;

    add-int/lit8 v7, v6, 0x1

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    aput v5, v0, v4

    sget-object v0, Lb;->s:[I

    const/4 v4, 0x7

    sget-object v5, Lb;->r:Ljava/lang/String;

    add-int/lit8 v6, v7, 0x1

    invoke-virtual {v5, v7, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    aput v5, v0, v4

    sget-object v0, Lb;->s:[I

    sget-object v4, Lb;->r:Ljava/lang/String;

    add-int/lit8 v5, v6, 0x1

    invoke-virtual {v4, v6, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    aput v4, v0, v9

    sget-object v0, Lb;->v:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x4

    if-ge v0, v4, :cond_1ce

    sput v3, Lb;->g:I

    :cond_1af
    invoke-static {}, Lq;->c()V

    :cond_1b2
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_1c0

    invoke-static {}, Lb;->h()V

    invoke-static {}, Lq;->c()V

    :cond_1c0
    sget-boolean v0, Lq;->z:Z

    if-eqz v0, :cond_41

    move v1, v3

    :goto_1c5
    if-ge v1, v2, :cond_41

    move v0, v3

    :goto_1c8
    if-lt v0, v8, :cond_281

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1c5

    :cond_1ce
    sget-object v0, Lb;->s:[I

    sget-object v4, Lb;->v:Ljava/lang/String;

    invoke-virtual {v4, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    aput v4, v0, v1

    sget-object v0, Lb;->s:[I

    sget-object v4, Lb;->v:Ljava/lang/String;

    invoke-virtual {v4, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    aput v4, v0, v2

    sget-object v0, Lb;->s:[I

    const/4 v4, 0x3

    sget-object v5, Lb;->v:Ljava/lang/String;

    const/4 v6, 0x3

    invoke-virtual {v5, v2, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    aput v5, v0, v4

    sget-object v0, Lb;->s:[I

    const/4 v4, 0x4

    sget-object v5, Lb;->v:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    aput v5, v0, v4

    sget-object v0, Lb;->s:[I

    sget-object v4, Lb;->s:[I

    aget v4, v4, v9

    sget-object v5, Lb;->s:[I

    const/4 v6, 0x7

    aget v5, v5, v6

    add-int/2addr v4, v5

    rem-int/lit8 v4, v4, 0xa

    aput v4, v0, v9

    sget-object v0, Lb;->s:[I

    const/4 v4, 0x7

    sget-object v5, Lb;->s:[I

    const/4 v6, 0x7

    aget v5, v5, v6

    sget-object v6, Lb;->s:[I

    const/4 v7, 0x6

    aget v6, v6, v7

    add-int/2addr v5, v6

    rem-int/lit8 v5, v5, 0xa

    aput v5, v0, v4

    sget-object v0, Lb;->s:[I

    const/4 v4, 0x6

    sget-object v5, Lb;->s:[I

    const/4 v6, 0x6

    aget v5, v5, v6

    sget-object v6, Lb;->s:[I

    aget v6, v6, v8

    add-int/2addr v5, v6

    rem-int/lit8 v5, v5, 0xa

    aput v5, v0, v4

    sget-object v0, Lb;->s:[I

    sget-object v4, Lb;->s:[I

    aget v4, v4, v8

    sget-object v5, Lb;->s:[I

    aget v5, v5, v9

    add-int/2addr v4, v5

    rem-int/lit8 v4, v4, 0xa

    aput v4, v0, v8

    :goto_24d
    if-ge v1, v9, :cond_1af

    sget-object v0, Lb;->s:[I

    add-int/lit8 v4, v1, -0x1

    aget v0, v0, v4

    sget-object v4, Lb;->s:[I

    aget v4, v4, v1

    if-eq v0, v4, :cond_261

    invoke-static {}, Lb;->i()V

    :goto_25e
    add-int/lit8 v1, v1, 0x1

    goto :goto_24d

    :cond_261
    sget-object v0, Lb;->s:[I

    aget v0, v0, v1

    sget-object v4, Lb;->s:[I

    aget v4, v4, v1

    add-int/lit8 v4, v4, 0x1

    if-eq v0, v4, :cond_271

    invoke-static {}, Lb;->j()V

    goto :goto_25e

    :cond_271
    invoke-static {}, Lq;->c()V

    invoke-static {}, Lb;->m()V

    invoke-static {}, Lb;->j()V

    invoke-static {}, Lb;->g()V

    invoke-static {}, Lq;->c()V

    goto :goto_25e

    :cond_281
    sget v4, Lq;->A:I

    mul-int/lit8 v5, v0, 0x14

    sget v6, Lq;->G:I

    add-int/2addr v5, v6

    add-int/lit8 v5, v5, -0x32

    if-le v4, v5, :cond_2b6

    sget v4, Lq;->A:I

    mul-int/lit8 v5, v0, 0x14

    sget v6, Lq;->G:I

    add-int/2addr v5, v6

    add-int/lit8 v5, v5, -0x32

    add-int/lit8 v5, v5, 0x14

    if-ge v4, v5, :cond_2b6

    sget v4, Lq;->B:I

    mul-int/lit8 v5, v1, 0x19

    sget v6, Lq;->H:I

    add-int/2addr v5, v6

    if-le v4, v5, :cond_2b6

    sget v4, Lq;->B:I

    mul-int/lit8 v5, v1, 0x19

    sget v6, Lq;->H:I

    add-int/2addr v5, v6

    add-int/lit8 v5, v5, 0x19

    if-ge v4, v5, :cond_2b6

    sput v0, Lb;->w:I

    sput v1, Lb;->x:I

    invoke-static {}, Lb;->k()V

    sput-boolean v3, Lq;->z:Z

    :cond_2b6
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_1c8

    :pswitch_2ba  #0x7
    invoke-static {}, Lb;->g()V

    goto/16 :goto_41

    :pswitch_2bf  #0x8
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_41

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    goto/16 :goto_41

    :pswitch_2ce  #0x9
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_41

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aput-boolean v3, v0, v1

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    goto/16 :goto_41

    nop

    :pswitch_data_2e4
    .packed-switch 0x0
        :pswitch_49  #00000000
        :pswitch_41  #00000001
        :pswitch_d7  #00000002
        :pswitch_41  #00000003
        :pswitch_f6  #00000004
        :pswitch_dc  #00000005
        :pswitch_f1  #00000006
        :pswitch_2ba  #00000007
        :pswitch_2bf  #00000008
        :pswitch_2ce  #00000009
    .end packed-switch
.end method

.method private static b(I)V
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    int-to-byte v2, p0

    aput-byte v2, v0, v1

    const-string v1, "np"

    invoke-static {v1, v0}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method private static b(Ljava/lang/String;)V
    .registers 3

    const-string v0, "girl"

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    invoke-static {v0, v1}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method public static c()V
    .registers 6

    const/4 v2, 0x0

    const/4 v1, 0x0

    const-string v0, "microedition.platform"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v4, ""

    if-nez v0, :cond_e

    const-string v0, "TeaMobile"

    :cond_e
    sget-boolean v3, Lb;->a:Z

    if-eqz v3, :cond_10f

    const-string v3, "lv"

    invoke-static {v3}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v5

    if-nez v5, :cond_27

    move-object v3, v2

    :goto_1b
    if-nez v3, :cond_2d

    invoke-static {v1}, Lb;->c(I)V

    invoke-static {v1}, Lb;->d(I)V

    invoke-static {v0}, Lb;->c(Ljava/lang/String;)V

    :cond_26
    :goto_26
    return-void

    :cond_27
    new-instance v3, Ljava/lang/String;

    invoke-direct {v3, v5}, Ljava/lang/String;-><init>([B)V

    goto :goto_1b

    :cond_2d
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3d

    invoke-static {v1}, Lb;->c(I)V

    invoke-static {v1}, Lb;->d(I)V

    invoke-static {v0}, Lb;->c(Ljava/lang/String;)V

    goto :goto_26

    :cond_3d
    move v3, v1

    :goto_3e
    const/4 v5, 0x4

    if-lt v3, v5, :cond_90

    new-instance v3, Ljava/lang/StringBuffer;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const/16 v4, 0x61

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v3, -0x1

    if-eq v0, v3, :cond_26

    const/16 v0, 0xd

    sput v0, Lq;->K:I

    const-string v0, "bc"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v0

    if-nez v0, :cond_ad

    move v0, v1

    :goto_6c
    sget-object v3, Lb;->o:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    if-lt v0, v3, :cond_108

    const-string v0, "girl"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v3

    if-nez v3, :cond_b0

    move-object v0, v2

    :goto_7f
    :try_start_7f
    invoke-static {}, Ljavax/bluetooth/LocalDevice;->getLocalDevice()Ljavax/bluetooth/LocalDevice;

    move-result-object v3

    invoke-virtual {v3}, Ljavax/bluetooth/LocalDevice;->getBluetoothAddress()Ljava/lang/String;
    :try_end_86
    .catch Ljava/lang/Exception; {:try_start_7f .. :try_end_86} :catch_114

    move-result-object v2

    :goto_87
    if-nez v2, :cond_b8

    sget-boolean v0, Lq;->y:Z

    if-eqz v0, :cond_b6

    :goto_8d
    sput-boolean v1, Lq;->y:Z

    goto :goto_26

    :cond_90
    new-instance v5, Ljava/lang/StringBuffer;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v5, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v4, Lb;->o:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    add-int/lit8 v4, v4, -0x1

    int-to-char v4, v4

    invoke-virtual {v5, v4}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    add-int/lit8 v3, v3, 0x1

    goto :goto_3e

    :cond_ad
    aget-byte v0, v0, v1

    goto :goto_6c

    :cond_b0
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v3}, Ljava/lang/String;-><init>([B)V

    goto :goto_7f

    :cond_b6
    const/4 v1, 0x1

    goto :goto_8d

    :cond_b8
    if-nez v0, :cond_bf

    invoke-static {v2}, Lb;->b(Ljava/lang/String;)V

    goto/16 :goto_26

    :cond_bf
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_103

    invoke-static {v1}, Lb;->c(I)V

    invoke-static {v1}, Lb;->d(I)V

    invoke-static {v2}, Lb;->b(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lb;->e:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " PAY "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const-wide/16 v4, 0x2197

    rem-long/2addr v2, v4

    const-wide/16 v4, 0x3e8

    add-long/2addr v2, v4

    long-to-int v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "110"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lb;->e(Ljava/lang/String;)V

    goto/16 :goto_26

    :cond_103
    invoke-static {v1}, Lb;->a(I)V

    goto/16 :goto_26

    :cond_108
    add-int/lit8 v0, v0, 0x1

    invoke-static {v0}, Lb;->a(I)V

    goto/16 :goto_26

    :cond_10f
    invoke-static {v0}, Lb;->c(Ljava/lang/String;)V

    goto/16 :goto_26

    :catch_114
    move-exception v3

    goto/16 :goto_87
.end method

.method private static c(I)V
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    int-to-byte v2, p0

    aput-byte v2, v0, v1

    const-string v1, "r"

    invoke-static {v1, v0}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method private static c(Ljava/lang/String;)V
    .registers 3

    const-string v0, "lv"

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    invoke-static {v0, v1}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method public static d()V
    .registers 4

    const/4 v3, 0x7

    invoke-static {}, Lg;->e()V

    invoke-static {}, Lq;->i()V

    invoke-static {v3}, Lq;->h(I)V

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "Xin chúc mừng. Bạn đã có vũ khí mới: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget-object v1, Lq;->bq:[[Ljava/lang/String;

    sget v2, Lq;->bo:I

    aget-object v1, v1, v2

    sget v2, Lq;->bn:I

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "!"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq;->b(Ljava/lang/String;)V

    sget v0, Lq;->bm:I

    sput v0, Lq;->bv:I

    sput v3, Lq;->K:I

    return-void
.end method

.method private static d(I)V
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    int-to-byte v2, p0

    aput-byte v2, v0, v1

    const-string v1, "g"

    invoke-static {v1, v0}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method private static d(Ljava/lang/String;)[B
    .registers 3

    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "NINJASCHOOL"

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    :try_start_10
    invoke-static {v0, v1}, Ljavax/microedition/rms/RecordStore;->openRecordStore(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;

    move-result-object v1

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Ljavax/microedition/rms/RecordStore;->getRecord(I)[B

    move-result-object v0

    invoke-virtual {v1}, Ljavax/microedition/rms/RecordStore;->closeRecordStore()V
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_1c} :catch_1d

    :goto_1c
    return-object v0

    :catch_1d
    move-exception v0

    const/4 v0, 0x0

    goto :goto_1c
.end method

.method public static e()Ljava/lang/String;
    .registers 2

    const-string v0, "xxx"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v1

    if-nez v1, :cond_a

    const/4 v0, 0x0

    :goto_9
    return-object v0

    :cond_a
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    goto :goto_9
.end method

.method private static e(Ljava/lang/String;)V
    .registers 3

    const-string v0, "xxx"

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    invoke-static {v0, v1}, Lb;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method public static f()I
    .registers 2

    const/4 v0, 0x0

    const-string v1, "g"

    invoke-static {v1}, Lb;->d(Ljava/lang/String;)[B

    move-result-object v1

    if-nez v1, :cond_a

    :goto_9
    return v0

    :cond_a
    aget-byte v0, v1, v0

    goto :goto_9
.end method

.method private static g()V
    .registers 3

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_d

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    :cond_d
    const/4 v0, 0x1

    invoke-static {v0}, Lb;->d(I)V

    sget-object v0, Lb;->s:[I

    const/4 v1, 0x0

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    return-void
.end method

.method private static h()V
    .registers 3

    sget-object v0, Lb;->v:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :cond_19

    sget-object v0, Lb;->v:Ljava/lang/String;

    const/4 v1, 0x0

    sget-object v2, Lb;->v:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb;->v:Ljava/lang/String;

    :cond_19
    return-void
.end method

.method private static i()V
    .registers 1

    invoke-static {}, Lq;->c()V

    const/4 v0, 0x0

    sput v0, Lb;->g:I

    invoke-static {}, Lb;->l()V

    invoke-static {}, Lq;->c()V

    return-void
.end method

.method private static j()V
    .registers 1

    invoke-static {}, Lq;->c()V

    invoke-static {}, Lb;->m()V

    const/4 v0, 0x4

    sput v0, Lb;->g:I

    invoke-static {}, Lb;->i()V

    invoke-static {}, Lq;->c()V

    return-void
.end method

.method private static k()V
    .registers 3

    sget-object v0, Lb;->v:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x4

    if-ge v0, v1, :cond_25

    sget-object v0, Lb;->v:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    sget v0, Lb;->x:I

    mul-int/lit8 v0, v0, 0x5

    sget v2, Lb;->w:I

    add-int/2addr v0, v2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb;->v:Ljava/lang/String;

    :cond_25
    return-void
.end method

.method private static l()V
    .registers 2

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_f

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_15

    :cond_f
    invoke-static {}, Lq;->c()V

    const/4 v0, 0x0

    sput v0, Lb;->g:I

    :cond_15
    return-void
.end method

.method private static m()V
    .registers 7

    const/4 v6, 0x0

    sget-object v0, Lq;->D:[Z

    const/4 v1, 0x5

    aget-boolean v0, v0, v1

    if-nez v0, :cond_10

    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xc

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_5b

    :cond_10
    invoke-static {}, Lb;->e()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1e

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_50

    :cond_1e
    new-instance v0, Ljava/lang/StringBuffer;

    sget-object v1, Lb;->e:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const-string v1, " PAY "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const-wide/16 v4, 0x1f40

    rem-long/2addr v2, v4

    const-wide/16 v4, 0x3e8

    add-long/2addr v2, v4

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuffer;->append(J)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "110"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "000"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lb;->e(Ljava/lang/String;)V

    :cond_50
    const/4 v1, 0x1

    sput v1, Lb;->g:I

    sget-object v1, Lb;->b:Ljava/lang/String;

    invoke-static {v0, v1, v6}, Lb;->a(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-static {}, Lq;->c()V

    :cond_5b
    sget-object v0, Lq;->D:[Z

    const/16 v1, 0xd

    aget-boolean v0, v0, v1

    if-eqz v0, :cond_68

    sput v6, Lb;->g:I

    invoke-static {}, Lq;->c()V

    :cond_68
    return-void
.end method

.method private static n()V
    .registers 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x1

    sget v0, Lb;->u:I

    if-nez v0, :cond_1c

    sget v0, Lb;->t:I

    if-lez v0, :cond_1c

    sget v0, Lb;->t:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lb;->t:I

    invoke-static {v0}, Lb;->b(I)V

    sput v3, Lq;->K:I

    invoke-static {}, Lq;->u()V

    invoke-static {}, Ljava/lang/System;->gc()V

    :cond_1c
    sget v0, Lb;->u:I

    if-ne v0, v1, :cond_24

    sget v0, Lb;->t:I

    if-gtz v0, :cond_2c

    :cond_24
    sget v0, Lb;->u:I

    if-nez v0, :cond_2e

    sget v0, Lb;->t:I

    if-nez v0, :cond_2e

    :cond_2c
    sput v2, Lb;->g:I

    :cond_2e
    sget v0, Lb;->u:I

    if-ne v0, v2, :cond_36

    sget v0, Lb;->t:I

    if-gtz v0, :cond_3e

    :cond_36
    sget v0, Lb;->u:I

    if-ne v0, v1, :cond_46

    sget v0, Lb;->t:I

    if-nez v0, :cond_46

    :cond_3e
    invoke-static {}, Lb;->e()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lb;->r:Ljava/lang/String;

    sput v3, Lb;->g:I

    :cond_46
    return-void
.end method
