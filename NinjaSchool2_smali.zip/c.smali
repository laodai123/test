.class public final Lc;
.super Ljava/lang/Object;


# static fields
.field public static a:[[Ljavax/microedition/lcdui/Image;

.field public static b:Ljavax/microedition/lcdui/Image;

.field public static c:I

.field public static d:[I

.field public static e:[I

.field public static f:[I

.field public static final g:[I

.field public static final h:[I

.field public static final i:[I

.field public static j:I

.field public static k:I

.field public static l:I

.field public static m:I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v5, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    new-array v0, v3, [I

    const/4 v1, 0x1

    aput v5, v0, v1

    aput v5, v0, v6

    aput v3, v0, v7

    const/16 v1, 0xf

    aput v1, v0, v4

    sput-object v0, Lc;->g:[I

    new-array v0, v3, [I

    const/4 v1, 0x0

    const/16 v2, 0xa

    aput v2, v0, v1

    const/16 v1, 0x14

    aput v1, v0, v7

    const/16 v1, 0x14

    aput v1, v0, v4

    sput-object v0, Lc;->h:[I

    const/16 v0, 0xe

    new-array v0, v0, [I

    const/4 v1, 0x0

    const/4 v2, 0x7

    aput v2, v0, v1

    const/4 v1, 0x1

    const/4 v2, 0x6

    aput v2, v0, v1

    const/4 v1, 0x6

    aput v1, v0, v6

    aput v3, v0, v7

    aput v6, v0, v4

    aput v4, v0, v3

    const/16 v1, 0x8

    aput v3, v0, v1

    const/16 v1, 0x9

    const/16 v2, -0x24

    aput v2, v0, v1

    const/16 v1, 0xa

    aput v3, v0, v1

    const/16 v1, 0xc

    const/16 v2, 0x9

    aput v2, v0, v1

    const/16 v1, 0xd

    aput v3, v0, v1

    sput-object v0, Lc;->i:[I

    sput v5, Lc;->j:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->b:Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method public static a(I)V
    .registers 9

    const/16 v7, 0x9

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, -0x1

    sget-object v0, Lc;->f:[I

    aget v0, v0, p0

    packed-switch v0, :pswitch_data_4c6

    :cond_d
    :goto_d
    sget v0, Lq;->as:I

    sget v1, Lq;->aE:I

    if-ne v0, v1, :cond_19

    sget v0, Lq;->aF:I

    if-ne p0, v0, :cond_19

    sput v4, Lq;->aE:I

    :cond_19
    return-void

    :pswitch_1a  #0x0
    sget-boolean v0, Lg;->C:Z

    if-eqz v0, :cond_36

    sget-boolean v0, Lq;->t:Z

    if-nez v0, :cond_36

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0xe

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto :goto_d

    :cond_36
    sget-boolean v0, Lg;->i:Z

    if-nez v0, :cond_d

    sget-boolean v0, Lq;->d:Z

    if-eqz v0, :cond_52

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0xd

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto :goto_d

    :cond_52
    sget v0, Lg;->bc:I

    if-ne v0, v6, :cond_a2

    sget-boolean v0, Lg;->bm:Z

    if-eqz v0, :cond_8d

    sget v0, Lg;->bn:I

    if-nez v0, :cond_8d

    sget v0, Lg;->aW:I

    const/4 v1, 0x6

    if-lt v0, v1, :cond_79

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0xb

    aget-object v0, v0, v1

    const/16 v1, 0x8

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto :goto_d

    :cond_79
    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto :goto_d

    :cond_8d
    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0xc

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_a2
    sget-boolean v0, Lg;->f:Z

    if-eqz v0, :cond_10c

    sget-boolean v0, Lg;->g:Z

    if-nez v0, :cond_10c

    sget v0, Lg;->bc:I

    if-ne v0, v5, :cond_df

    sget-boolean v0, Lg;->O:Z

    if-eqz v0, :cond_ca

    sget v0, Lg;->Q:I

    if-nez v0, :cond_ca

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    aget-object v0, v0, v7

    const/4 v1, 0x6

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_ca
    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0x8

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_df
    sget v0, Lg;->bc:I

    if-ne v0, v4, :cond_f8

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/4 v1, 0x7

    aget-object v0, v0, v1

    const/4 v1, 0x5

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_f8
    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/4 v1, 0x6

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v5, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_10c
    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_123

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_123
    sget-object v0, Ll;->n:[[Ljava/lang/String;

    aget-object v0, v0, v5

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_136  #0x1
    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_1b0

    sget v0, Lg;->bc:I

    if-nez v0, :cond_183

    sget v0, Lg;->bh:I

    sget-object v1, Lc;->h:[I

    aget v1, v1, v3

    if-ge v0, v1, :cond_15a

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_15a
    sget v0, Lq;->as:I

    sput v0, Lc;->j:I

    sput v3, Lc;->m:I

    sget-object v0, Lc;->d:[I

    aget v0, v0, v3

    sput v0, Lc;->k:I

    sget-object v0, Lc;->e:[I

    aget v0, v0, v3

    add-int/lit8 v0, v0, -0x2c

    sput v0, Lc;->l:I

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x4

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_183
    sget v0, Lg;->bc:I

    if-ne v0, v4, :cond_19c

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    const/4 v1, 0x3

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_19c
    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/4 v1, 0x6

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v5, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_1b0
    sget-object v0, Ll;->n:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_1c3  #0x2
    sget-object v0, Ll;->n:[[Ljava/lang/String;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_1d7  #0x3
    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_1ee

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    aget-object v0, v0, v5

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_1ee
    sget-object v0, Ll;->n:[[Ljava/lang/String;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_202  #0x4
    sget-boolean v0, Lg;->f:Z

    if-nez v0, :cond_219

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_219
    sget-object v0, Ll;->n:[[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_22c  #0x5
    sget v0, Lq;->as:I

    if-nez v0, :cond_23a

    const/4 v0, 0x3

    if-ne p0, v0, :cond_23a

    invoke-static {}, Lq;->v()V

    sput v7, Lq;->K:I

    sput v3, Lq;->bp:I

    :cond_23a
    sget v0, Lq;->as:I

    const/4 v1, 0x7

    if-ne v0, v1, :cond_248

    if-nez p0, :cond_248

    invoke-static {}, Lq;->v()V

    sput v7, Lq;->K:I

    sput v5, Lq;->bp:I

    :cond_248
    sget v0, Lq;->as:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_260

    if-nez p0, :cond_260

    sget-object v0, Ll;->m:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    :cond_260
    sget v0, Lq;->as:I

    const/16 v1, 0xe

    if-ne v0, v1, :cond_d

    if-ne p0, v5, :cond_d

    invoke-static {}, Lq;->v()V

    sput v7, Lq;->K:I

    sput v3, Lq;->bp:I

    goto/16 :goto_d

    :pswitch_271  #0x6
    sget-boolean v0, Lg;->o:Z

    if-nez v0, :cond_d

    sget v0, Lg;->bh:I

    if-nez v0, :cond_28c

    sget-object v0, Ll;->k:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_28c
    sget-boolean v0, Lg;->j:Z

    if-nez v0, :cond_2b1

    sget v0, Lg;->bh:I

    if-eq v0, v4, :cond_2b1

    sget v0, Lg;->bh:I

    sget-object v1, Lc;->h:[I

    sget v2, Lg;->bc:I

    aget v1, v1, v2

    if-ge v0, v1, :cond_2b1

    sget-object v0, Ll;->k:[[Ljava/lang/String;

    aget-object v0, v0, v5

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_2b1
    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_2de

    sget v0, Lg;->bh:I

    if-eq v0, v4, :cond_2de

    sget v0, Lg;->bh:I

    sget-object v1, Lc;->h:[I

    sget v2, Lg;->bc:I

    aget v1, v1, v2

    if-lt v0, v1, :cond_2de

    sput-boolean v5, Lg;->j:Z

    sput v3, Lg;->a:I

    sget-object v0, Ll;->k:[[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v7, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    sput v4, Lg;->bh:I

    sput v4, Lg;->bc:I

    goto/16 :goto_d

    :cond_2de
    sget-boolean v0, Lg;->j:Z

    if-eqz v0, :cond_2fa

    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_2fa

    sget-object v0, Ll;->k:[[Ljava/lang/String;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_2fa
    sget-boolean v0, Lg;->k:Z

    if-eqz v0, :cond_d

    sget-boolean v0, Lg;->m:Z

    if-nez v0, :cond_d

    sget v0, Lg;->aW:I

    const/16 v1, 0xa

    if-lt v0, v1, :cond_322

    sget-object v0, Ll;->k:[[Ljava/lang/String;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    const/16 v1, 0xa

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    sput-boolean v5, Lg;->m:Z

    sput v5, Lg;->a:I

    goto/16 :goto_d

    :cond_322
    sget-object v0, Ll;->k:[[Ljava/lang/String;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    const/16 v0, 0x8

    sput v0, Lg;->a:I

    goto/16 :goto_d

    :pswitch_33a  #0x7
    sget v0, Lq;->as:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_d

    if-nez p0, :cond_d

    invoke-static {}, Lq;->v()V

    sput v7, Lq;->K:I

    sput v3, Lq;->bp:I

    goto/16 :goto_d

    :pswitch_34b  #0x8
    sget v0, Lq;->as:I

    if-ne v0, v7, :cond_d

    if-ne p0, v5, :cond_d

    sget-boolean v0, Lg;->o:Z

    if-eqz v0, :cond_d

    sget-boolean v0, Lg;->r:Z

    if-nez v0, :cond_37f

    sget-object v0, Ll;->h:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    sput v5, Lq;->av:I

    sput v6, Lq;->bi:I

    invoke-static {}, Lq;->f()V

    const/16 v0, 0x888

    const/16 v1, 0x78

    invoke-static {v0, v1}, Lq;->a(II)V

    const/16 v0, 0x888

    const/16 v1, 0x5b

    invoke-static {v0, v1}, Lq;->b(II)V

    :cond_37f
    sget-boolean v0, Lg;->s:Z

    if-eqz v0, :cond_d

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_d

    sget-object v0, Ll;->h:[[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_39a  #0x9
    sget v0, Lg;->D:I

    if-ne v0, v5, :cond_3ba

    sget-boolean v0, Lg;->v:Z

    if-nez v0, :cond_3ba

    sget-object v0, Ll;->g:[[Ljava/lang/String;

    aget-object v0, v0, v5

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    sput-boolean v5, Lg;->v:Z

    const/4 v0, 0x6

    sput v0, Lg;->a:I

    goto/16 :goto_d

    :cond_3ba
    sget v0, Lg;->D:I

    if-ne v0, v6, :cond_3da

    sget-boolean v0, Lg;->w:Z

    if-nez v0, :cond_3da

    sget-object v0, Ll;->g:[[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    sput-boolean v5, Lg;->w:Z

    const/4 v0, 0x7

    sput v0, Lg;->a:I

    goto/16 :goto_d

    :cond_3da
    sget v0, Lg;->D:I

    if-lt v0, v5, :cond_3ee

    sget v0, Lg;->D:I

    if-ne v0, v5, :cond_3e6

    sget-boolean v0, Lg;->w:Z

    if-eqz v0, :cond_3ee

    :cond_3e6
    sget v0, Lg;->D:I

    if-ne v0, v6, :cond_d

    sget-boolean v0, Lg;->x:Z

    if-nez v0, :cond_d

    :cond_3ee
    sget-object v0, Ll;->g:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_401  #0xa
    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_d

    sget-boolean v0, Lg;->A:Z

    if-nez v0, :cond_41a

    sget-object v0, Ll;->d:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    :cond_41a
    sget-boolean v0, Lg;->u:Z

    if-eqz v0, :cond_d

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_d

    sget-object v0, Ll;->d:[[Ljava/lang/String;

    aget-object v0, v0, v5

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_435  #0xb
    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_d

    sget-boolean v0, Lg;->z:Z

    if-nez v0, :cond_450

    sget-object v0, Ll;->e:[[Ljava/lang/String;

    aget-object v0, v0, v3

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_450
    sget-boolean v0, Lg;->z:Z

    if-eqz v0, :cond_46d

    sget-boolean v0, Lg;->A:Z

    if-nez v0, :cond_46d

    sget-object v0, Ll;->e:[[Ljava/lang/String;

    aget-object v0, v0, v5

    const/16 v1, 0xc

    sget-object v2, Lc;->d:[I

    aget v2, v2, p0

    sget-object v3, Lc;->e:[I

    aget v3, v3, p0

    add-int/lit8 v3, v3, -0x28

    invoke-static {v0, v1, v2, v3}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :cond_46d
    sget-boolean v0, Lg;->A:Z

    if-eqz v0, :cond_d

    sget-object v0, Ll;->e:[[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    goto/16 :goto_d

    :pswitch_484  #0xc
    sget v0, Lq;->as:I

    if-nez v0, :cond_4a8

    const/4 v0, 0x4

    if-ne p0, v0, :cond_4a8

    sget v0, Lg;->aW:I

    const/16 v1, 0x1e

    if-ne v0, v1, :cond_4be

    sget-boolean v0, Lg;->j:Z

    if-nez v0, :cond_4be

    sget-object v0, Ll;->l:[[Ljava/lang/String;

    const/16 v1, 0xf

    aget-object v0, v0, v1

    sget-object v1, Lc;->d:[I

    aget v1, v1, p0

    sget-object v2, Lc;->e:[I

    aget v2, v2, p0

    add-int/lit8 v2, v2, -0x28

    invoke-static {v0, v4, v1, v2}, Lq;->a([Ljava/lang/String;III)V

    :cond_4a8
    :goto_4a8
    sget v0, Lq;->as:I

    const/4 v1, 0x7

    if-eq v0, v1, :cond_4b3

    sget v0, Lq;->as:I

    const/16 v1, 0xc

    if-ne v0, v1, :cond_d

    :cond_4b3
    if-nez p0, :cond_d

    invoke-static {}, Lq;->v()V

    sput v7, Lq;->K:I

    sput v5, Lq;->bp:I

    goto/16 :goto_d

    :cond_4be
    invoke-static {}, Lq;->v()V

    sput v7, Lq;->K:I

    sput v5, Lq;->bp:I

    goto :goto_4a8

    :pswitch_data_4c6
    .packed-switch 0x0
        :pswitch_1a  #00000000
        :pswitch_136  #00000001
        :pswitch_1c3  #00000002
        :pswitch_1d7  #00000003
        :pswitch_202  #00000004
        :pswitch_22c  #00000005
        :pswitch_271  #00000006
        :pswitch_33a  #00000007
        :pswitch_34b  #00000008
        :pswitch_39a  #00000009
        :pswitch_401  #0000000a
        :pswitch_435  #0000000b
        :pswitch_484  #0000000c
    .end packed-switch
.end method

.method private static a(IIII)V
    .registers 6

    sget-object v0, Lc;->f:[I

    aput p1, v0, p0

    sget-object v0, Lc;->d:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p2

    add-int/lit8 v1, v1, 0xc

    aput v1, v0, p0

    sget-object v0, Lc;->e:[I

    sget v1, Lj;->f:I

    mul-int/2addr v1, p3

    aput v1, v0, p0

    return-void
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 11

    const/4 v9, 0x4

    const/16 v8, 0x21

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v0, v1

    :goto_6
    sget v2, Lc;->c:I

    if-lt v0, v2, :cond_32

    sget v0, Lq;->as:I

    const/16 v2, 0x9

    if-ne v0, v2, :cond_31

    sget-object v0, Lc;->b:Ljavax/microedition/lcdui/Image;

    if-eqz v0, :cond_31

    sget-object v0, Lc;->b:Ljavax/microedition/lcdui/Image;

    sget-object v2, Lc;->d:[I

    aget v2, v2, v3

    add-int/lit8 v2, v2, -0x2

    sget-object v4, Lc;->e:[I

    aget v4, v4, v3

    add-int/lit8 v4, v4, -0x6

    sget v5, Lq;->at:I

    sget-object v6, Lc;->f:[I

    aget v6, v6, v3

    add-int/lit8 v6, v6, 0xf

    rem-int/2addr v5, v6

    if-le v5, v9, :cond_df

    :goto_2d
    add-int/2addr v1, v4

    invoke-virtual {p0, v0, v2, v1, v8}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_31
    return-void

    :cond_32
    sget-object v2, Lc;->d:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, 0xa

    sget v4, Lq;->ay:I

    if-lt v2, v4, :cond_a6

    sget-object v2, Lc;->d:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xa

    sget v4, Lq;->ay:I

    sget v5, Lq;->ab:I

    add-int/2addr v4, v5

    if-gt v2, v4, :cond_a6

    sget-object v2, Lc;->e:[I

    aget v2, v2, v0

    sget v4, Lq;->az:I

    if-lt v2, v4, :cond_a6

    sget-object v2, Lc;->e:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0x20

    sget v4, Lq;->az:I

    sget v5, Lq;->ac:I

    add-int/2addr v4, v5

    if-gt v2, v4, :cond_a6

    sget-object v2, Lc;->f:[I

    aget v2, v2, v0

    const/4 v4, 0x7

    if-eq v2, v4, :cond_ac

    sget-object v2, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    sget-object v4, Lc;->f:[I

    aget v4, v4, v0

    aget-object v2, v2, v4

    aget-object v2, v2, v3

    sget-object v4, Lc;->d:[I

    aget v4, v4, v0

    sget-object v5, Lc;->e:[I

    aget v5, v5, v0

    invoke-virtual {p0, v2, v4, v5, v8}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v2, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    sget-object v4, Lc;->f:[I

    aget v4, v4, v0

    aget-object v2, v2, v4

    aget-object v4, v2, v1

    sget-object v2, Lc;->d:[I

    aget v5, v2, v0

    sget-object v2, Lc;->e:[I

    aget v2, v2, v0

    sget-object v6, Lc;->i:[I

    sget-object v7, Lc;->f:[I

    aget v7, v7, v0

    aget v6, v6, v7

    sub-int v6, v2, v6

    sget v2, Lq;->at:I

    sget-object v7, Lc;->f:[I

    aget v7, v7, v0

    add-int/lit8 v7, v7, 0xf

    rem-int/2addr v2, v7

    if-le v2, v9, :cond_aa

    move v2, v1

    :goto_a2
    add-int/2addr v2, v6

    invoke-virtual {p0, v4, v5, v2, v8}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_a6
    :goto_a6
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_6

    :cond_aa
    move v2, v3

    goto :goto_a2

    :cond_ac
    sget-object v2, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    sget-object v4, Lc;->f:[I

    aget v4, v4, v0

    aget-object v2, v2, v4

    aget-object v4, v2, v1

    sget-object v2, Lc;->d:[I

    aget v2, v2, v0

    add-int/lit8 v5, v2, 0x6

    sget-object v2, Lc;->e:[I

    aget v2, v2, v0

    add-int/lit8 v2, v2, -0xc

    sget-object v6, Lc;->i:[I

    sget-object v7, Lc;->f:[I

    aget v7, v7, v0

    aget v6, v6, v7

    sub-int v6, v2, v6

    sget v2, Lq;->at:I

    sget-object v7, Lc;->f:[I

    aget v7, v7, v0

    add-int/lit8 v7, v7, 0xf

    rem-int/2addr v2, v7

    if-le v2, v9, :cond_dd

    move v2, v1

    :goto_d8
    add-int/2addr v2, v6

    invoke-virtual {p0, v4, v5, v2, v8}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto :goto_a6

    :cond_dd
    move v2, v3

    goto :goto_d8

    :cond_df
    move v1, v3

    goto/16 :goto_2d
.end method

.method private static b()V
    .registers 1

    sget v0, Lc;->c:I

    new-array v0, v0, [I

    sput-object v0, Lc;->d:[I

    sget v0, Lc;->c:I

    new-array v0, v0, [I

    sput-object v0, Lc;->e:[I

    sget v0, Lc;->c:I

    new-array v0, v0, [I

    sput-object v0, Lc;->f:[I

    return-void
.end method

.method public static b(I)V
    .registers 10

    const/16 v8, 0x8

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    sput v4, Lc;->c:I

    const/4 v0, 0x3

    if-ne p0, v0, :cond_40

    const/4 v0, 0x6

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_1a
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/50.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/51.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_36} :catch_518

    :goto_36
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0x17

    invoke-static {v4, v7, v0, v7}, Lc;->a(IIII)V

    :cond_40
    const/16 v0, 0x9

    if-ne p0, v0, :cond_b1

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_34e

    const/16 v0, 0x9

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_58
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/20.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/21.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x8

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/70.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x8

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/71.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-boolean v0, Lg;->s:Z

    if-nez v0, :cond_9e

    const-string v0, "/i/t.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lc;->b:Ljavax/microedition/lcdui/Image;
    :try_end_9e
    .catch Ljava/lang/Exception; {:try_start_58 .. :try_end_9e} :catch_515

    :cond_9e
    :goto_9e
    sput v6, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0x66

    const/16 v1, 0x10

    invoke-static {v4, v6, v0, v1}, Lc;->a(IIII)V

    const/16 v0, 0x47

    const/16 v1, 0xf

    invoke-static {v5, v8, v0, v1}, Lc;->a(IIII)V

    :cond_b1
    :goto_b1
    const/16 v0, 0xe

    if-ne p0, v0, :cond_114

    const/16 v0, 0xa

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_c5
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x9

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/80.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x9

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/81.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/50.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/51.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_ff
    .catch Ljava/lang/Exception; {:try_start_c5 .. :try_end_ff} :catch_50f

    :goto_ff
    sput v6, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0x9

    const/16 v1, 0x6c

    const/16 v2, 0x11

    invoke-static {v4, v0, v1, v2}, Lc;->a(IIII)V

    const/16 v0, 0x24

    const/16 v1, 0xe

    invoke-static {v5, v7, v0, v1}, Lc;->a(IIII)V

    :cond_114
    const/16 v0, 0xf

    if-ne p0, v0, :cond_15a

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_15a

    const/16 v0, 0xb

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_12c
    sget-boolean v0, Lg;->u:Z

    if-nez v0, :cond_3f9

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/90.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/91.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_14e
    .catch Ljava/lang/Exception; {:try_start_12c .. :try_end_14e} :catch_420

    :goto_14e
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0xa

    const/16 v1, 0x48

    invoke-static {v4, v0, v1, v8}, Lc;->a(IIII)V

    :cond_15a
    const/16 v0, 0x10

    if-ne p0, v0, :cond_1af

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_1af

    sget-boolean v0, Lg;->u:Z

    if-nez v0, :cond_1af

    const/16 v0, 0xc

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_176
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xb

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/100.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xb

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/101.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_194
    .catch Ljava/lang/Exception; {:try_start_176 .. :try_end_194} :catch_50c

    :goto_194
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0xb

    const/16 v1, 0x15

    const/16 v2, 0x9

    invoke-static {v4, v0, v1, v2}, Lc;->a(IIII)V

    const/4 v0, 0x6

    sput v0, Lq;->bi:I

    invoke-static {}, Lq;->f()V

    const/16 v0, 0x20f

    const/16 v1, 0xc9

    invoke-static {v0, v1}, Lq;->a(II)V

    :cond_1af
    const/16 v0, 0x63

    if-ne p0, v0, :cond_1eb

    const/4 v0, 0x6

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_1c2
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/40.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/41.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_1de
    .catch Ljava/lang/Exception; {:try_start_1c2 .. :try_end_1de} :catch_509

    :goto_1de
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/4 v0, 0x4

    const/16 v1, 0x2e

    const/16 v2, 0xa

    invoke-static {v4, v0, v1, v2}, Lc;->a(IIII)V

    :cond_1eb
    const/4 v0, 0x4

    if-ne p0, v0, :cond_226

    const/4 v0, 0x7

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_1fd
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x6

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/60.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x6

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/61.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_219
    .catch Ljava/io/IOException; {:try_start_1fd .. :try_end_219} :catch_506

    :goto_219
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/4 v0, 0x6

    const/16 v1, 0x16

    const/16 v2, 0x9

    invoke-static {v4, v0, v1, v2}, Lc;->a(IIII)V

    :cond_226
    if-ne p0, v8, :cond_250

    filled-new-array {v8, v5}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_236
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x7

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/t/k0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_244
    .catch Ljava/io/IOException; {:try_start_236 .. :try_end_244} :catch_503

    :goto_244
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/4 v0, 0x7

    const/16 v1, 0x57

    const/4 v2, 0x7

    invoke-static {v4, v0, v1, v2}, Lc;->a(IIII)V

    :cond_250
    const/4 v0, 0x7

    if-ne p0, v0, :cond_28a

    const/4 v0, 0x6

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_262
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/50.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/51.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_27e
    .catch Ljava/io/IOException; {:try_start_262 .. :try_end_27e} :catch_500

    :goto_27e
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0x46

    const/16 v1, 0x9

    invoke-static {v4, v7, v0, v1}, Lc;->a(IIII)V

    :cond_28a
    const/16 v0, 0xc

    if-ne p0, v0, :cond_2c8

    const/16 v0, 0xd

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_29e
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xc

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/110.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xc

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/111.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_2bc
    .catch Ljava/io/IOException; {:try_start_29e .. :try_end_2bc} :catch_4fd

    :goto_2bc
    sput v5, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0xc

    const/16 v1, 0xf

    invoke-static {v4, v0, v1, v8}, Lc;->a(IIII)V

    :cond_2c8
    if-nez p0, :cond_34d

    sget-boolean v0, Lq;->f:Z

    if-eqz v0, :cond_423

    const/4 v0, 0x6

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_2dd
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/00.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/01.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/40.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x4

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/41.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/10.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/11.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_331
    .catch Ljava/lang/Exception; {:try_start_2dd .. :try_end_331} :catch_4fa

    :goto_331
    const/4 v0, 0x3

    sput v0, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0x13

    const/16 v1, 0x11

    invoke-static {v4, v4, v0, v1}, Lc;->a(IIII)V

    const/4 v0, 0x4

    const/16 v1, 0x11

    const/16 v2, 0x11

    invoke-static {v5, v0, v1, v2}, Lc;->a(IIII)V

    const/16 v0, 0x29

    const/16 v1, 0x10

    invoke-static {v6, v5, v0, v1}, Lc;->a(IIII)V

    :cond_34d
    :goto_34d
    return-void

    :cond_34e
    const/16 v0, 0xe

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_35e
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/20.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/21.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x8

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/70.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x8

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/71.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/00.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/01.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xd

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/120.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xd

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/121.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_3d2
    .catch Ljava/lang/Exception; {:try_start_35e .. :try_end_3d2} :catch_512

    :goto_3d2
    const/4 v0, 0x4

    sput v0, Lc;->c:I

    invoke-static {}, Lc;->b()V

    const/16 v0, 0x66

    const/16 v1, 0x10

    invoke-static {v4, v6, v0, v1}, Lc;->a(IIII)V

    const/16 v0, 0x4b

    const/16 v1, 0xf

    invoke-static {v5, v8, v0, v1}, Lc;->a(IIII)V

    const/16 v0, 0x32

    const/16 v1, 0xf

    invoke-static {v6, v4, v0, v1}, Lc;->a(IIII)V

    const/4 v0, 0x3

    const/16 v1, 0xd

    const/16 v2, 0x33

    const/16 v3, 0xf

    invoke-static {v0, v1, v2, v3}, Lc;->a(IIII)V

    goto/16 :goto_b1

    :cond_3f9
    :try_start_3f9
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/100.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xa

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/101.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->i:[I

    const/16 v1, 0xa

    const/4 v2, 0x0

    aput v2, v0, v1
    :try_end_41e
    .catch Ljava/lang/Exception; {:try_start_3f9 .. :try_end_41e} :catch_420

    goto/16 :goto_14e

    :catch_420
    move-exception v0

    goto/16 :goto_14e

    :cond_423
    const/16 v0, 0xd

    filled-new-array {v0, v6}, [I

    move-result-object v0

    const-class v1, Ljavax/microedition/lcdui/Image;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljavax/microedition/lcdui/Image;

    sput-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    :try_start_433
    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_453

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/00.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/01.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    :cond_453
    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/30.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x3

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/31.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/10.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/11.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/50.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/4 v1, 0x5

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/51.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xc

    aget-object v0, v0, v1

    const/4 v1, 0x0

    const-string v2, "/npc/110.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1

    sget-object v0, Lc;->a:[[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0xc

    aget-object v0, v0, v1

    const/4 v1, 0x1

    const-string v2, "/npc/111.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_4c5
    .catch Ljava/lang/Exception; {:try_start_433 .. :try_end_4c5} :catch_4f8

    :goto_4c5
    sput v7, Lc;->c:I

    invoke-static {}, Lc;->b()V

    sget-boolean v0, Lg;->C:Z

    if-nez v0, :cond_4d5

    const/16 v0, 0x22

    const/16 v1, 0xd

    invoke-static {v4, v4, v0, v1}, Lc;->a(IIII)V

    :cond_4d5
    const/4 v0, 0x3

    const/16 v1, 0x23

    const/16 v2, 0xd

    invoke-static {v5, v0, v1, v2}, Lc;->a(IIII)V

    const/16 v0, 0x2b

    const/16 v1, 0x11

    invoke-static {v6, v5, v0, v1}, Lc;->a(IIII)V

    const/4 v0, 0x3

    const/16 v1, 0x19

    const/16 v2, 0x11

    invoke-static {v0, v7, v1, v2}, Lc;->a(IIII)V

    const/4 v0, 0x4

    const/16 v1, 0xc

    const/16 v2, 0xb

    const/16 v3, 0x11

    invoke-static {v0, v1, v2, v3}, Lc;->a(IIII)V

    goto/16 :goto_34d

    :catch_4f8
    move-exception v0

    goto :goto_4c5

    :catch_4fa
    move-exception v0

    goto/16 :goto_331

    :catch_4fd
    move-exception v0

    goto/16 :goto_2bc

    :catch_500
    move-exception v0

    goto/16 :goto_27e

    :catch_503
    move-exception v0

    goto/16 :goto_244

    :catch_506
    move-exception v0

    goto/16 :goto_219

    :catch_509
    move-exception v0

    goto/16 :goto_1de

    :catch_50c
    move-exception v0

    goto/16 :goto_194

    :catch_50f
    move-exception v0

    goto/16 :goto_ff

    :catch_512
    move-exception v0

    goto/16 :goto_3d2

    :catch_515
    move-exception v0

    goto/16 :goto_9e

    :catch_518
    move-exception v0

    goto/16 :goto_36
.end method
