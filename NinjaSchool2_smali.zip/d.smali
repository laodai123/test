.class public final Ld;
.super Ljava/lang/Object;


# static fields
.field static a:Z

.field static b:Ljavax/microedition/lcdui/Image;

.field static c:I

.field static d:I

.field static e:I

.field static f:I

.field static g:I


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
