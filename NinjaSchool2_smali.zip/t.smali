.class public final Lt;
.super Ljava/lang/Object;


# static fields
.field public static a:Z

.field public static b:[Ljavax/microedition/lcdui/Image;

.field public static c:I

.field public static d:I

.field public static e:I

.field public static f:I

.field public static g:I

.field public static h:I

.field public static i:I

.field public static j:I

.field public static k:I

.field public static l:I

.field public static m:Z

.field public static n:I

.field public static o:Ljava/util/Vector;

.field private static p:I

.field private static q:I

.field private static r:I

.field private static s:I

.field private static t:I

.field private static u:I

.field private static v:I

.field private static w:[[I

.field private static x:[[I

.field private static y:[[I

.field private static z:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    sput-object v0, Lt;->o:Ljava/util/Vector;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()V
    .registers 1

    const/4 v0, 0x0

    sput-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    invoke-static {}, Ljava/lang/System;->gc()V

    return-void
.end method

.method public static a(I)V
    .registers 11

    const/4 v9, -0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    sput-boolean v7, Lt;->a:Z

    const/16 v0, 0x65

    if-ne p0, v0, :cond_90

    sget-boolean v0, Lg;->k:Z

    if-nez v0, :cond_90

    sget-boolean v0, Lg;->j:Z

    if-eqz v0, :cond_90

    sput v7, Lt;->n:I

    invoke-static {v7}, Lt;->c(I)V

    sput-boolean v5, Lt;->a:Z

    const/16 v0, 0xd8

    sput v0, Lt;->c:I

    const/16 v0, 0x108

    sput v0, Lt;->d:I

    const/16 v0, 0x48

    sput v0, Lt;->q:I

    const/16 v0, 0x1b0

    sput v0, Lt;->r:I

    sput v9, Lt;->e:I

    sput v7, Lt;->f:I

    const/16 v0, 0x20

    sput v0, Lt;->h:I

    const/16 v0, 0x32

    sput v0, Lt;->u:I

    sput v7, Lt;->s:I

    sput v6, Lt;->p:I

    const/16 v0, 0x28

    sput v0, Lt;->g:I

    const/4 v0, 0x5

    new-array v0, v0, [[I

    const/4 v1, 0x7

    new-array v1, v1, [I

    aput v9, v1, v5

    aput v8, v1, v8

    const/16 v2, -0xb

    aput v2, v1, v6

    aput-object v1, v0, v7

    const/4 v1, 0x7

    new-array v1, v1, [I

    aput v5, v1, v7

    aput v9, v1, v5

    aput v8, v1, v8

    const/16 v2, -0x9

    aput v2, v1, v6

    aput-object v1, v0, v5

    const/4 v1, 0x7

    new-array v1, v1, [I

    aput v5, v1, v7

    aput v9, v1, v5

    aput v6, v1, v8

    const/16 v2, -0xc

    aput v2, v1, v6

    aput-object v1, v0, v8

    const/4 v1, 0x7

    new-array v1, v1, [I

    aput v5, v1, v7

    aput v9, v1, v5

    const/4 v2, 0x4

    aput v2, v1, v8

    const/16 v2, -0x18

    aput v2, v1, v6

    aput-object v1, v0, v6

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-array v2, v2, [I

    aput v5, v2, v7

    const/4 v3, 0x5

    aput v3, v2, v5

    aput v9, v2, v8

    const/4 v3, 0x5

    const/16 v4, -0xa

    aput v4, v2, v3

    aput-object v2, v0, v1

    sput-object v0, Lt;->w:[[I

    :cond_90
    const/16 v0, 0x64

    if-ne p0, v0, :cond_16d

    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_16d

    sput v5, Lt;->n:I

    invoke-static {v5}, Lt;->c(I)V

    sput-boolean v5, Lt;->a:Z

    const/16 v0, 0x138

    sput v0, Lt;->c:I

    const/16 v0, 0x108

    sput v0, Lt;->d:I

    const/16 v0, 0xc0

    sput v0, Lt;->q:I

    const/16 v0, 0x180

    sput v0, Lt;->r:I

    sput v9, Lt;->e:I

    sput v7, Lt;->f:I

    const/16 v0, 0x20

    sput v0, Lt;->h:I

    const/16 v0, 0x32

    sput v0, Lt;->u:I

    sput v7, Lt;->s:I

    sput v6, Lt;->p:I

    const/16 v0, 0x37

    sput v0, Lt;->g:I

    const/4 v0, 0x6

    new-array v0, v0, [[I

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v8, v1, v7

    const/16 v2, -0x42

    aput v2, v1, v5

    aput v9, v1, v8

    const/4 v2, 0x4

    const/16 v3, -0x12

    aput v3, v1, v2

    aput-object v1, v0, v7

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v8, v1, v7

    const/16 v2, -0x37

    aput v2, v1, v5

    aput v9, v1, v8

    const/4 v2, 0x4

    const/16 v3, -0x12

    aput v3, v1, v2

    aput-object v1, v0, v5

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v8, v1, v7

    const/16 v2, -0x42

    aput v2, v1, v5

    aput v9, v1, v8

    const/4 v2, 0x4

    const/16 v3, -0xf

    aput v3, v1, v2

    aput-object v1, v0, v8

    const/4 v1, 0x6

    new-array v1, v1, [I

    aput v8, v1, v7

    const/16 v2, -0x13

    aput v2, v1, v5

    aput v9, v1, v6

    aput-object v1, v0, v6

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-array v2, v2, [I

    const/4 v3, 0x4

    aput v3, v2, v6

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-array v2, v2, [I

    fill-array-data v2, :array_16e

    aput-object v2, v0, v1

    sput-object v0, Lt;->w:[[I

    const/4 v0, 0x6

    new-array v0, v0, [[I

    new-array v1, v6, [I

    fill-array-data v1, :array_17e

    aput-object v1, v0, v7

    new-array v1, v6, [I

    fill-array-data v1, :array_188

    aput-object v1, v0, v5

    new-array v1, v6, [I

    const/4 v2, 0x6

    aput v2, v1, v7

    aput v5, v1, v8

    aput-object v1, v0, v8

    new-array v1, v6, [I

    fill-array-data v1, :array_192

    aput-object v1, v0, v6

    const/4 v1, 0x4

    new-array v2, v6, [I

    fill-array-data v2, :array_19c

    aput-object v2, v0, v1

    const/4 v1, 0x5

    new-array v2, v6, [I

    fill-array-data v2, :array_1a6

    aput-object v2, v0, v1

    sput-object v0, Lt;->x:[[I

    new-array v0, v6, [[I

    const/4 v1, 0x4

    new-array v1, v1, [I

    aput v5, v1, v8

    aput v5, v1, v6

    aput-object v1, v0, v7

    new-array v1, v6, [I

    fill-array-data v1, :array_1b0

    aput-object v1, v0, v5

    const/16 v1, 0x8

    new-array v1, v1, [I

    fill-array-data v1, :array_1ba

    aput-object v1, v0, v8

    sput-object v0, Lt;->y:[[I

    :cond_16d
    return-void

    :array_16e
    .array-data 4
        0x2
        -0x34
        -0x1
        -0x2
        -0x7
        -0x2
    .end array-data

    :array_17e
    .array-data 4
        0x6
        0x2
        0x1
    .end array-data

    :array_188
    .array-data 4
        0x6
        0x2
        0x3
    .end array-data

    :array_192
    .array-data 4
        0x6
        0x5
        0x8
    .end array-data

    :array_19c
    .array-data 4
        0x6
        0x8
        0x8
    .end array-data

    :array_1a6
    .array-data 4
        0x6
        0x4
        0x3
    .end array-data

    :array_1b0
    .array-data 4
        0x3
        0x4
        0x4
    .end array-data

    :array_1ba
    .array-data 4
        0x3
        0x3
        0x4
        0x4
        0x1
        0x1
        0x3
        0x3
    .end array-data
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;)V
    .registers 13

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/16 v9, 0x21

    const/4 v6, 0x2

    const/4 v2, 0x0

    sget-boolean v0, Lt;->a:Z

    if-nez v0, :cond_b

    :cond_a
    return-void

    :cond_b
    sget v0, Lt;->e:I

    if-ne v0, v10, :cond_175

    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_296

    :cond_14
    :goto_14
    sget v0, Lt;->z:I

    if-eqz v0, :cond_76

    const v0, 0x330011

    invoke-virtual {p0, v0}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v0, Lt;->c:I

    sget v1, Lt;->u:I

    shr-int/lit8 v1, v1, 0x1

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    sget v1, Lt;->d:I

    sget v3, Lt;->h:I

    sub-int/2addr v1, v3

    add-int/lit8 v1, v1, -0x7

    sget v3, Lt;->u:I

    add-int/lit8 v3, v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, v0, v1, v3, v4}, Ljavax/microedition/lcdui/Graphics;->drawRect(IIII)V

    sget v0, Lt;->n:I

    if-nez v0, :cond_28b

    sget v0, Lt;->i:I

    sget v1, Lt;->u:I

    mul-int/2addr v0, v1

    sget v1, Lt;->j:I

    div-int/2addr v0, v1

    :goto_42
    const/high16 v1, 0xee0000

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lt;->c:I

    sget v3, Lt;->u:I

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v1, v3

    sget v3, Lt;->d:I

    sget v4, Lt;->h:I

    sub-int/2addr v3, v4

    add-int/lit8 v3, v3, -0x6

    invoke-virtual {p0, v1, v3, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    const v1, 0x440022

    invoke-virtual {p0, v1}, Ljavax/microedition/lcdui/Graphics;->setColor(I)V

    sget v1, Lt;->c:I

    sget v3, Lt;->u:I

    shr-int/lit8 v3, v3, 0x1

    sub-int/2addr v1, v3

    add-int/2addr v1, v0

    sget v3, Lt;->d:I

    sget v4, Lt;->h:I

    sub-int/2addr v3, v4

    add-int/lit8 v3, v3, -0x6

    sget v4, Lt;->u:I

    sub-int v0, v4, v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v1, v3, v0, v11}, Ljavax/microedition/lcdui/Graphics;->fillRect(IIII)V

    :cond_76
    move v10, v2

    :goto_77
    sget-object v0, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v10, v0, :cond_a

    sget-object v0, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v0, v10}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lk;

    sget-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x7

    aget-object v1, v1, v3

    if-eqz v1, :cond_a6

    sget-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x7

    aget-object v1, v1, v3

    iget v3, v0, Lk;->c:I

    iget v4, v0, Lk;->e:I

    mul-int/2addr v3, v4

    iget v4, v0, Lk;->d:I

    iget v5, v0, Lk;->e:I

    iget v7, v0, Lk;->a:I

    iget v8, v0, Lk;->b:I

    move-object v0, p0

    move v6, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_a6
    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto :goto_77

    :pswitch_aa  #0x0
    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v2

    aget-object v0, v0, v1

    sget v1, Lt;->c:I

    sget v3, Lt;->d:I

    invoke-virtual {p0, v0, v1, v3, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v0, v0, v10

    const/4 v1, -0x1

    if-eq v0, v1, :cond_ef

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v10

    aget-object v0, v0, v1

    sget v1, Lt;->c:I

    sget-object v3, Lt;->w:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    const/4 v4, 0x5

    aget v3, v3, v4

    sub-int/2addr v1, v3

    sget v3, Lt;->d:I

    sget-object v4, Lt;->w:[[I

    sget v5, Lt;->f:I

    aget-object v4, v4, v5

    const/4 v5, 0x6

    aget v4, v4, v5

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    :cond_ef
    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v0, v0, v6

    const/4 v1, -0x1

    if-eq v0, v1, :cond_14

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v6

    aget-object v0, v0, v1

    sget v1, Lt;->c:I

    sget-object v3, Lt;->w:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v11

    sub-int/2addr v1, v3

    sget v3, Lt;->d:I

    sget-object v4, Lt;->w:[[I

    sget v5, Lt;->f:I

    aget-object v4, v4, v5

    const/4 v5, 0x4

    aget v4, v4, v5

    sub-int/2addr v3, v4

    invoke-virtual {p0, v0, v1, v3, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    goto/16 :goto_14

    :pswitch_122  #0x1
    move v10, v2

    :goto_123
    if-ge v10, v11, :cond_14

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->x:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->x:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->x:[[I

    sget v5, Lt;->f:I

    aget-object v3, v3, v5

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget-object v0, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v0, v0, v3

    aget v0, v0, v10

    neg-int v0, v0

    sget v3, Lt;->c:I

    add-int v7, v0, v3

    sget-object v0, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v0, v0, v3

    add-int/lit8 v3, v10, 0x3

    aget v0, v0, v3

    sget v3, Lt;->d:I

    add-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    add-int/lit8 v0, v10, 0x1

    move v10, v0

    goto :goto_123

    :cond_175
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_29e

    goto/16 :goto_14

    :pswitch_17c  #0x0
    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v2

    aget-object v1, v0, v1

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->w:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->w:[[I

    sget v5, Lt;->f:I

    aget-object v3, v3, v5

    aget v3, v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v7, Lt;->c:I

    sget v8, Lt;->d:I

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v0, v0, v10

    const/4 v1, -0x1

    if-eq v0, v1, :cond_207

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v10

    aget-object v1, v0, v1

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->w:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->w:[[I

    sget v5, Lt;->f:I

    aget-object v3, v3, v5

    aget v3, v3, v10

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lt;->c:I

    sget-object v3, Lt;->w:[[I

    sget v7, Lt;->f:I

    aget-object v3, v3, v7

    const/4 v7, 0x5

    aget v3, v3, v7

    add-int v7, v0, v3

    sget v0, Lt;->d:I

    sget-object v3, Lt;->w:[[I

    sget v8, Lt;->f:I

    aget-object v3, v3, v8

    const/4 v8, 0x6

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_207
    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v0, v0, v6

    const/4 v1, -0x1

    if-eq v0, v1, :cond_14

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v1, Lt;->w:[[I

    sget v3, Lt;->f:I

    aget-object v1, v1, v3

    aget v1, v1, v6

    aget-object v1, v0, v1

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->w:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v6

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v4

    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->w:[[I

    sget v5, Lt;->f:I

    aget-object v3, v3, v5

    aget v3, v3, v6

    aget-object v0, v0, v3

    invoke-virtual {v0}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v5

    sget v0, Lt;->c:I

    sget-object v3, Lt;->w:[[I

    sget v7, Lt;->f:I

    aget-object v3, v3, v7

    aget v3, v3, v11

    add-int v7, v0, v3

    sget v0, Lt;->d:I

    sget-object v3, Lt;->w:[[I

    sget v8, Lt;->f:I

    aget-object v3, v3, v8

    const/4 v8, 0x4

    aget v3, v3, v8

    sub-int v8, v0, v3

    move-object v0, p0

    move v3, v2

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    goto/16 :goto_14

    :pswitch_25e  #0x1
    move v0, v2

    :goto_25f
    if-ge v0, v11, :cond_14

    sget-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    sget-object v3, Lt;->x:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v0

    aget-object v1, v1, v3

    sget-object v3, Lt;->w:[[I

    sget v4, Lt;->f:I

    aget-object v3, v3, v4

    aget v3, v3, v0

    sget v4, Lt;->c:I

    add-int/2addr v3, v4

    sget-object v4, Lt;->w:[[I

    sget v5, Lt;->f:I

    aget-object v4, v4, v5

    add-int/lit8 v5, v0, 0x3

    aget v4, v4, v5

    sget v5, Lt;->d:I

    add-int/2addr v4, v5

    invoke-virtual {p0, v1, v3, v4, v9}, Ljavax/microedition/lcdui/Graphics;->drawImage(Ljavax/microedition/lcdui/Image;III)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_25f

    :cond_28b
    sget v0, Lt;->k:I

    sget v1, Lt;->u:I

    mul-int/2addr v0, v1

    sget v1, Lt;->l:I

    div-int/2addr v0, v1

    goto/16 :goto_42

    nop

    :pswitch_data_296
    .packed-switch 0x0
        :pswitch_aa  #00000000
        :pswitch_122  #00000001
    .end packed-switch

    :pswitch_data_29e
    .packed-switch 0x0
        :pswitch_17c  #00000000
        :pswitch_25e  #00000001
    .end packed-switch
.end method

.method public static b()V
    .registers 9

    const/16 v8, 0xa

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x0

    sget-boolean v0, Lt;->a:Z

    if-nez v0, :cond_b

    :cond_a
    :goto_a
    return-void

    :cond_b
    move v1, v2

    :goto_c
    sget-object v0, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-lt v1, v0, :cond_47

    sget v0, Lt;->p:I

    packed-switch v0, :pswitch_data_562

    :pswitch_19  #0x5, 0x8, 0x9, 0xa, 0xb
    goto :goto_a

    :pswitch_1a  #0x1
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_57e

    goto :goto_a

    :pswitch_20  #0x0
    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    sub-int/2addr v0, v1

    sput v0, Lt;->c:I

    const/4 v0, 0x4

    sput v0, Lt;->f:I

    sget v0, Lt;->d:I

    sget v1, Lt;->v:I

    add-int/2addr v0, v1

    sput v0, Lt;->d:I

    sget v0, Lt;->v:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->v:I

    sget v0, Lt;->d:I

    const/16 v1, 0x168

    if-le v0, v1, :cond_a

    sput-boolean v3, Lg;->k:Z

    const-string v0, "Quay về gặp già làng"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sput v7, Lt;->p:I

    goto :goto_a

    :cond_47
    sget-object v0, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lk;

    iget v4, v0, Lk;->a:I

    sget v5, Lt;->e:I

    mul-int/lit8 v5, v5, 0x4

    add-int/2addr v4, v5

    iput v4, v0, Lk;->a:I

    iget v4, v0, Lk;->b:I

    iget v5, v0, Lk;->f:I

    add-int/2addr v4, v5

    iput v4, v0, Lk;->b:I

    sget v4, Lq;->at:I

    rem-int/lit8 v4, v4, 0xa

    if-nez v4, :cond_6b

    iget v4, v0, Lk;->c:I

    add-int/lit8 v4, v4, 0x1

    iput v4, v0, Lk;->c:I

    :cond_6b
    iget v4, v0, Lk;->c:I

    const/4 v5, 0x4

    if-lt v4, v5, :cond_75

    sget-object v4, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v4, v0}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    :cond_75
    sget v4, Lg;->at:I

    iget v5, v0, Lk;->a:I

    sub-int/2addr v4, v5

    invoke-static {v4}, Lq;->a(I)I

    move-result v4

    const/16 v5, 0x14

    if-ge v4, v5, :cond_9d

    sget v4, Lg;->au:I

    iget v5, v0, Lk;->b:I

    sub-int/2addr v4, v5

    invoke-static {v4}, Lq;->a(I)I

    move-result v4

    if-ge v4, v8, :cond_9d

    sget v4, Lg;->ax:I

    if-eq v4, v7, :cond_a2

    sget v4, Lt;->g:I

    sget v5, Lt;->e:I

    invoke-static {v4, v5}, Lg;->a(II)V

    sget-object v4, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v4, v0}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    :cond_9d
    :goto_9d
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto/16 :goto_c

    :cond_a2
    sget-object v0, Lt;->o:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    goto :goto_9d

    :pswitch_a8  #0x1
    sput v7, Lt;->f:I

    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v1, v0, v6

    sget v4, Lt;->t:I

    add-int/2addr v1, v4

    aput v1, v0, v6

    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    const/4 v1, 0x4

    aget v4, v0, v1

    sget v5, Lt;->s:I

    add-int/2addr v4, v5

    aput v4, v0, v1

    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v1, v0, v7

    sget v4, Lt;->v:I

    add-int/2addr v1, v4

    aput v1, v0, v7

    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    sget v0, Lt;->t:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->t:I

    sget v0, Lt;->v:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->v:I

    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v0, v0, v7

    const/16 v1, 0x168

    if-le v0, v1, :cond_113

    sput-boolean v2, Lt;->a:Z

    sput-boolean v3, Lg;->bm:Z

    sput-boolean v3, Lg;->O:Z

    sget v0, Lq;->as:I

    invoke-static {v0}, Lg;->b(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lg;->d(I)V

    sput v2, Lg;->bL:I

    const/16 v0, 0x78

    sput v0, Lg;->bp:I

    sput v0, Lg;->S:I

    sput v2, Lg;->R:I

    sput v2, Lg;->bo:I

    const/16 v0, 0x34

    invoke-static {v0}, Lq;->g(I)V

    goto/16 :goto_a

    :cond_113
    sget-object v0, Lt;->w:[[I

    sget v1, Lt;->f:I

    aget-object v0, v0, v1

    aget v0, v0, v7

    const/16 v1, 0xa8

    if-lt v0, v1, :cond_a

    sget-boolean v0, Lt;->m:Z

    if-nez v0, :cond_a

    const-string v0, "Cửa hang đã được mở"

    invoke-static {v0}, Lq;->a(Ljava/lang/String;)V

    sget v0, Lq;->aO:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lq;->aO:I

    sput-boolean v3, Lt;->m:Z

    goto/16 :goto_a

    :pswitch_132  #0x6
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_586

    goto/16 :goto_a

    :pswitch_139  #0x0
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    const/4 v0, 0x4

    sput v0, Lt;->f:I

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    sub-int/2addr v0, v1

    sput v0, Lt;->c:I

    sget v0, Lt;->s:I

    if-le v0, v7, :cond_a

    sget v0, Lt;->d:I

    sget v1, Lg;->au:I

    if-ne v0, v1, :cond_16e

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v1, 0x7

    if-le v0, v1, :cond_16e

    const/4 v0, 0x4

    sput v0, Lt;->p:I

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    sget v0, Lt;->c:I

    sget v1, Lg;->at:I

    if-le v0, v1, :cond_16c

    const/4 v0, -0x1

    :goto_168
    sput v0, Lt;->e:I

    goto/16 :goto_a

    :cond_16c
    move v0, v3

    goto :goto_168

    :cond_16e
    sget v0, Lt;->q:I

    sget v1, Lq;->at:I

    sget v4, Lt;->r:I

    sget v5, Lt;->q:I

    sub-int/2addr v4, v5

    add-int/lit8 v4, v4, -0x28

    rem-int/2addr v1, v4

    add-int/2addr v0, v1

    sput v0, Lt;->t:I

    sget v1, Lt;->c:I

    if-le v0, v1, :cond_18a

    sput v3, Lt;->e:I

    :goto_183
    sput v2, Lt;->s:I

    const/4 v0, 0x7

    sput v0, Lt;->p:I

    goto/16 :goto_a

    :cond_18a
    const/4 v0, -0x1

    sput v0, Lt;->e:I

    goto :goto_183

    :pswitch_18e  #0x1
    sput v7, Lt;->f:I

    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    sget v0, Lt;->c:I

    sget v1, Lg;->aF:I

    shl-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    sget v0, Lt;->s:I

    if-le v0, v7, :cond_1aa

    const/4 v0, 0x4

    sput v0, Lt;->p:I

    sput v2, Lt;->s:I

    sput v8, Lt;->t:I

    :cond_1aa
    invoke-static {}, Lt;->d()V

    goto/16 :goto_a

    :pswitch_1af  #0xc
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_58e

    goto/16 :goto_a

    :pswitch_1b6  #0x0
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    const/16 v1, 0x14

    if-le v0, v1, :cond_1e0

    sget v0, Lt;->q:I

    sget v1, Lq;->at:I

    sget v4, Lt;->r:I

    sget v5, Lt;->q:I

    sub-int/2addr v4, v5

    add-int/lit8 v4, v4, -0x28

    rem-int/2addr v1, v4

    add-int/2addr v0, v1

    sput v0, Lt;->t:I

    sget v1, Lt;->c:I

    if-le v0, v1, :cond_1dc

    sput v3, Lt;->e:I

    :goto_1d5
    sput v2, Lt;->s:I

    const/4 v0, 0x7

    sput v0, Lt;->p:I

    goto/16 :goto_a

    :cond_1dc
    const/4 v0, -0x1

    sput v0, Lt;->e:I

    goto :goto_1d5

    :cond_1e0
    sget v0, Lt;->s:I

    rem-int/lit8 v0, v0, 0xa

    const/4 v1, 0x7

    if-le v0, v1, :cond_20a

    sput v6, Lt;->f:I

    :goto_1e9
    sget v0, Lt;->s:I

    shr-int/lit8 v0, v0, 0x1

    rem-int/lit8 v0, v0, 0xa

    if-nez v0, :cond_a

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sget v1, Lt;->d:I

    add-int/lit8 v1, v1, -0x10

    sget v2, Lt;->e:I

    shl-int/lit8 v2, v2, 0x3

    sget v3, Lt;->g:I

    shr-int/lit8 v3, v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0, v1, v2, v3, v4}, Lq;->b(IIIII)V

    goto/16 :goto_a

    :cond_20a
    sput v2, Lt;->f:I

    goto :goto_1e9

    :pswitch_20d  #0x1
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_21f

    sget v0, Lt;->f:I

    if-nez v0, :cond_268

    :goto_21d
    sput v3, Lt;->f:I

    :cond_21f
    sget v0, Lt;->s:I

    const/16 v1, 0x8

    if-ge v0, v1, :cond_26a

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    mul-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    :goto_22e
    sget v0, Lt;->c:I

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    sget v1, Lt;->e:I

    mul-int/lit8 v1, v1, 0x32

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x82

    if-ge v0, v1, :cond_a

    sget v0, Lg;->au:I

    sget v1, Lt;->d:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v8, :cond_a

    sget v0, Lt;->c:I

    sget v1, Lg;->at:I

    sub-int/2addr v0, v1

    sget v1, Lt;->e:I

    mul-int/lit8 v1, v1, 0x32

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x46

    if-le v0, v1, :cond_a

    sget v0, Lt;->g:I

    div-int/lit8 v0, v0, 0x2

    sget v1, Lt;->e:I

    invoke-static {v0, v1}, Lg;->a(II)V

    goto/16 :goto_a

    :cond_268
    move v3, v2

    goto :goto_21d

    :cond_26a
    sget v0, Lt;->s:I

    const/16 v1, 0x10

    if-ge v0, v1, :cond_27a

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    mul-int/lit8 v1, v1, 0x4

    sub-int/2addr v0, v1

    sput v0, Lt;->c:I

    goto :goto_22e

    :cond_27a
    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    sput v6, Lt;->p:I

    goto :goto_22e

    :pswitch_281  #0x4
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_596

    goto/16 :goto_a

    :pswitch_288  #0x0
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    if-le v0, v8, :cond_296

    sput v6, Lt;->p:I

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    :cond_296
    sget v0, Lt;->s:I

    if-eq v0, v7, :cond_2a0

    sget v0, Lt;->s:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_2c3

    :cond_2a0
    sget v0, Lt;->d:I

    sget v1, Lg;->au:I

    sub-int/2addr v0, v1

    const/16 v1, 0x1e

    if-ge v0, v1, :cond_2c3

    sget v0, Lg;->at:I

    sget v1, Lt;->c:I

    sget v3, Lt;->e:I

    shl-int/lit8 v3, v3, 0x4

    add-int/2addr v1, v3

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x28

    if-ge v0, v1, :cond_2c3

    sget v0, Lt;->g:I

    sget v1, Lt;->e:I

    neg-int v1, v1

    invoke-static {v0, v1}, Lg;->a(II)V

    :cond_2c3
    sget v0, Lt;->s:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_2d8

    sget v0, Lt;->s:I

    if-eq v0, v7, :cond_2d8

    sget v0, Lt;->s:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_2d8

    sget v0, Lt;->s:I

    const/16 v1, 0x9

    if-ne v0, v1, :cond_2e5

    :cond_2d8
    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    sput v6, Lt;->f:I

    goto/16 :goto_a

    :cond_2e5
    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    sub-int/2addr v0, v1

    sput v0, Lt;->c:I

    sput v2, Lt;->f:I

    goto/16 :goto_a

    :pswitch_2f0  #0x1
    sget v0, Lt;->t:I

    if-ne v0, v8, :cond_345

    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_33d

    sget-object v0, Lt;->y:[[I

    const/4 v1, 0x2

    aget-object v0, v0, v1

    sget v1, Lt;->s:I

    aget v0, v0, v1

    sput v0, Lt;->f:I

    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    sget v0, Lt;->s:I

    sget-object v1, Lt;->y:[[I

    const/4 v4, 0x2

    aget-object v1, v1, v4

    array-length v1, v1

    if-lt v0, v1, :cond_324

    sput v2, Lt;->t:I

    sput v2, Lt;->s:I

    sput v6, Lt;->p:I

    :cond_324
    sget v0, Lt;->c:I

    sget v1, Lt;->q:I

    if-ge v0, v1, :cond_330

    sget v0, Lt;->q:I

    sput v0, Lt;->c:I

    sput v3, Lt;->e:I

    :cond_330
    sget v0, Lt;->c:I

    sget v1, Lt;->r:I

    if-le v0, v1, :cond_33d

    sget v0, Lt;->r:I

    sput v0, Lt;->c:I

    const/4 v0, -0x1

    sput v0, Lt;->e:I

    :cond_33d
    sput v2, Lt;->t:I

    sput v2, Lt;->s:I

    const/16 v0, 0xc

    sput v0, Lt;->p:I

    :cond_345
    sget v0, Lt;->t:I

    const/16 v1, 0xf

    if-ne v0, v1, :cond_a

    const/4 v0, 0x2

    sput v0, Lt;->f:I

    sput v2, Lt;->s:I

    sput v6, Lt;->p:I

    sget-object v0, Lt;->o:Ljava/util/Vector;

    new-instance v1, Lk;

    sget v4, Lt;->c:I

    sget-object v5, Lt;->w:[[I

    sget v6, Lt;->f:I

    aget-object v5, v5, v6

    aget v3, v5, v3

    sget v5, Lt;->e:I

    mul-int/2addr v3, v5

    sub-int v3, v4, v3

    sget v4, Lt;->d:I

    sget-object v5, Lt;->w:[[I

    sget v6, Lt;->f:I

    aget-object v5, v5, v6

    const/4 v6, 0x4

    aget v5, v5, v6

    add-int/2addr v4, v5

    add-int/lit8 v4, v4, -0x7

    invoke-direct {v1, v3, v4, v2}, Lk;-><init>(III)V

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto/16 :goto_a

    :pswitch_37b  #0x3
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_59e

    goto/16 :goto_a

    :pswitch_382  #0x0
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    sget v0, Lt;->t:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->t:I

    const/16 v1, 0x1e

    if-ne v0, v1, :cond_39b

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    invoke-static {}, Lt;->d()V

    goto/16 :goto_a

    :cond_39b
    sget v0, Lt;->s:I

    if-le v0, v8, :cond_3a1

    sput v2, Lt;->s:I

    :cond_3a1
    sget v0, Lt;->s:I

    const/4 v1, 0x7

    if-le v0, v1, :cond_3aa

    sput v2, Lt;->f:I

    goto/16 :goto_a

    :cond_3aa
    sput v3, Lt;->f:I

    goto/16 :goto_a

    :pswitch_3ae  #0x1
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    sget v0, Lt;->t:I

    const/16 v1, 0xf

    if-ne v0, v1, :cond_3d8

    sget v0, Lt;->s:I

    const/16 v1, 0x28

    if-le v0, v1, :cond_3c7

    sput v2, Lt;->t:I

    sput v2, Lt;->s:I

    :cond_3c4
    const/4 v0, 0x2

    sput v0, Lt;->p:I

    :cond_3c7
    :goto_3c7
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x7

    if-nez v0, :cond_3d3

    sget v0, Lt;->f:I

    if-nez v0, :cond_3ec

    :goto_3d1
    sput v3, Lt;->f:I

    :cond_3d3
    invoke-static {}, Lt;->d()V

    goto/16 :goto_a

    :cond_3d8
    sget v0, Lt;->s:I

    const/16 v1, 0x1e

    if-le v0, v1, :cond_3c7

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    invoke-static {v2, v8}, Lq;->e(II)I

    move-result v0

    if-nez v0, :cond_3c4

    const/4 v0, 0x7

    sput v0, Lt;->p:I

    goto :goto_3c7

    :cond_3ec
    move v3, v2

    goto :goto_3d1

    :pswitch_3ee  #0x2
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_5a6

    goto/16 :goto_a

    :pswitch_3f5  #0x0
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    if-le v0, v7, :cond_3ff

    sput v2, Lt;->s:I

    :cond_3ff
    sget v0, Lt;->s:I

    if-le v0, v6, :cond_421

    sput v2, Lt;->f:I

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    :goto_40e
    sget v0, Lt;->t:I

    sget v1, Lt;->c:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v8, :cond_425

    sput v2, Lt;->t:I

    sput v2, Lt;->s:I

    sput v6, Lt;->p:I

    goto/16 :goto_a

    :cond_421
    const/4 v0, 0x2

    sput v0, Lt;->f:I

    goto :goto_40e

    :cond_425
    sget v0, Lt;->c:I

    sget v1, Lt;->q:I

    if-ge v0, v1, :cond_431

    sget v0, Lt;->q:I

    sput v0, Lt;->c:I

    sput v3, Lt;->e:I

    :cond_431
    sget v0, Lt;->c:I

    sget v1, Lt;->r:I

    if-le v0, v1, :cond_43e

    sget v0, Lt;->r:I

    sput v0, Lt;->c:I

    const/4 v0, -0x1

    sput v0, Lt;->e:I

    :cond_43e
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_a

    invoke-static {}, Lt;->c()V

    goto/16 :goto_a

    :pswitch_449  #0x1
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    if-nez v0, :cond_456

    sget v0, Lt;->f:I

    if-nez v0, :cond_48a

    move v0, v3

    :goto_454
    sput v0, Lt;->f:I

    :cond_456
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x3

    if-nez v0, :cond_465

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x1

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    :cond_465
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    const/16 v1, 0x14

    if-lt v0, v1, :cond_479

    sput v2, Lt;->s:I

    invoke-static {v2, v6}, Lq;->e(II)I

    move-result v0

    if-nez v0, :cond_479

    sput v6, Lt;->p:I

    :cond_479
    sget v0, Lt;->c:I

    sget v1, Lt;->q:I

    if-lt v0, v1, :cond_48c

    sget v0, Lt;->c:I

    sget v1, Lt;->r:I

    if-gt v0, v1, :cond_48c

    invoke-static {}, Lt;->c()V

    goto/16 :goto_a

    :cond_48a
    move v0, v2

    goto :goto_454

    :cond_48c
    sget v0, Lt;->c:I

    sget v1, Lt;->q:I

    if-ge v0, v1, :cond_49a

    sget v0, Lt;->q:I

    sput v0, Lt;->c:I

    sput v3, Lt;->e:I

    goto/16 :goto_a

    :cond_49a
    sget v0, Lt;->c:I

    sget v1, Lt;->r:I

    if-le v0, v1, :cond_a

    sget v0, Lt;->r:I

    sput v0, Lt;->c:I

    const/4 v0, -0x1

    sput v0, Lt;->e:I

    goto/16 :goto_a

    :pswitch_4a9  #0x7
    sget v0, Lt;->n:I

    packed-switch v0, :pswitch_data_5ae

    goto/16 :goto_a

    :pswitch_4b0  #0x0
    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    if-le v0, v6, :cond_4ba

    sput v2, Lt;->s:I

    :cond_4ba
    sget v0, Lt;->s:I

    if-le v0, v3, :cond_4e7

    sput v2, Lt;->f:I

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x3

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    :goto_4c9
    sget v0, Lt;->t:I

    sget v1, Lt;->c:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-ge v0, v8, :cond_4f4

    sput v2, Lt;->t:I

    sput v2, Lt;->s:I

    sget v0, Lt;->c:I

    sget v1, Lg;->at:I

    if-le v0, v1, :cond_4df

    const/4 v3, -0x1

    :cond_4df
    sput v3, Lt;->e:I

    const/16 v0, 0xc

    sput v0, Lt;->p:I

    goto/16 :goto_a

    :cond_4e7
    const/4 v0, 0x2

    sput v0, Lt;->f:I

    sget v0, Lt;->c:I

    sget v1, Lt;->e:I

    shl-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    sput v0, Lt;->c:I

    goto :goto_4c9

    :cond_4f4
    sget v0, Lt;->c:I

    sget v1, Lt;->q:I

    if-ge v0, v1, :cond_50a

    sget v0, Lt;->q:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lt;->c:I

    sput v3, Lt;->e:I

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    const/16 v0, 0xc

    sput v0, Lt;->p:I

    :cond_50a
    sget v0, Lt;->c:I

    sget v1, Lt;->r:I

    if-le v0, v1, :cond_521

    sget v0, Lt;->r:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lt;->c:I

    const/4 v0, -0x1

    sput v0, Lt;->e:I

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    const/16 v0, 0xc

    sput v0, Lt;->p:I

    :cond_521
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x5

    if-nez v0, :cond_a

    invoke-static {}, Lt;->c()V

    goto/16 :goto_a

    :pswitch_52c  #0x1
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_a

    sget-object v0, Lt;->y:[[I

    aget-object v0, v0, v3

    sget v1, Lt;->s:I

    aget v0, v0, v1

    sput v0, Lt;->f:I

    sget v0, Lt;->t:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->t:I

    sget v0, Lt;->s:I

    sget-object v1, Lt;->y:[[I

    aget-object v1, v1, v3

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    if-ge v0, v1, :cond_553

    sget v0, Lt;->s:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lt;->s:I

    :cond_553
    sget v0, Lt;->t:I

    const/16 v1, 0x14

    if-lt v0, v1, :cond_a

    sput v2, Lt;->s:I

    sput v2, Lt;->t:I

    sput v6, Lt;->p:I

    goto/16 :goto_a

    nop

    :pswitch_data_562
    .packed-switch 0x1
        :pswitch_1a  #00000001
        :pswitch_3ee  #00000002
        :pswitch_37b  #00000003
        :pswitch_281  #00000004
        :pswitch_19  #00000005
        :pswitch_132  #00000006
        :pswitch_4a9  #00000007
        :pswitch_19  #00000008
        :pswitch_19  #00000009
        :pswitch_19  #0000000a
        :pswitch_19  #0000000b
        :pswitch_1af  #0000000c
    .end packed-switch

    :pswitch_data_57e
    .packed-switch 0x0
        :pswitch_20  #00000000
        :pswitch_a8  #00000001
    .end packed-switch

    :pswitch_data_586
    .packed-switch 0x0
        :pswitch_139  #00000000
        :pswitch_18e  #00000001
    .end packed-switch

    :pswitch_data_58e
    .packed-switch 0x0
        :pswitch_1b6  #00000000
        :pswitch_20d  #00000001
    .end packed-switch

    :pswitch_data_596
    .packed-switch 0x0
        :pswitch_288  #00000000
        :pswitch_2f0  #00000001
    .end packed-switch

    :pswitch_data_59e
    .packed-switch 0x0
        :pswitch_382  #00000000
        :pswitch_3ae  #00000001
    .end packed-switch

    :pswitch_data_5a6
    .packed-switch 0x0
        :pswitch_3f5  #00000000
        :pswitch_449  #00000001
    .end packed-switch

    :pswitch_data_5ae
    .packed-switch 0x0
        :pswitch_4b0  #00000000
        :pswitch_52c  #00000001
    .end packed-switch
.end method

.method public static b(I)Z
    .registers 10

    const/16 v8, -0xa

    const/4 v0, 0x1

    const/4 v7, -0x5

    const/4 v1, 0x0

    const/16 v6, 0x32

    sget v2, Lt;->p:I

    const/4 v3, 0x3

    if-eq v2, v3, :cond_16

    sget v2, Lt;->p:I

    const/4 v3, 0x2

    if-eq v2, v3, :cond_16

    sget v2, Lt;->p:I

    const/4 v3, 0x7

    if-ne v2, v3, :cond_1b

    :cond_16
    sget v2, Lt;->n:I

    packed-switch v2, :pswitch_data_c6

    :cond_1b
    :goto_1b
    move v0, v1

    :goto_1c
    return v0

    :pswitch_1d  #0x0
    sget v2, Lt;->i:I

    sub-int/2addr v2, p0

    sput v2, Lt;->i:I

    if-gtz v2, :cond_61

    sput v1, Lt;->i:I

    sget v2, Lt;->e:I

    shl-int/lit8 v2, v2, 0x3

    neg-int v2, v2

    sput v2, Lt;->t:I

    sput v1, Lt;->z:I

    sput v0, Lt;->p:I

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, 0x4

    const/4 v5, -0x6

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, -0x7

    invoke-static {v2, v3, v7, v4, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, -0x4

    const/4 v5, -0x8

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, 0x5

    const/16 v5, -0x9

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    invoke-static {v2, v3, v1, v8, v6}, Lq;->a(IIIII)V

    sput v7, Lt;->s:I

    sput v8, Lt;->v:I

    goto :goto_1c

    :cond_61
    sput v1, Lt;->s:I

    sput v1, Lt;->t:I

    const/4 v0, 0x6

    sput v0, Lt;->p:I

    const/16 v0, 0xa

    sput v0, Lt;->z:I

    goto :goto_1b

    :pswitch_6d  #0x1
    sget v2, Lt;->k:I

    sub-int/2addr v2, p0

    sput v2, Lt;->k:I

    if-gtz v2, :cond_b8

    sput v1, Lt;->k:I

    sget v2, Lt;->e:I

    shl-int/lit8 v2, v2, 0x3

    neg-int v2, v2

    sput v2, Lt;->t:I

    sput v1, Lt;->z:I

    sput v0, Lt;->p:I

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, 0x4

    const/4 v5, -0x6

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, -0x7

    invoke-static {v2, v3, v7, v4, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, -0x4

    const/4 v5, -0x8

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    const/4 v4, 0x5

    const/16 v5, -0x9

    invoke-static {v2, v3, v4, v5, v6}, Lq;->a(IIIII)V

    sget v2, Lt;->c:I

    sget v3, Lt;->d:I

    invoke-static {v2, v3, v1, v8, v6}, Lq;->a(IIIII)V

    sput v7, Lt;->s:I

    const/16 v1, -0x9

    sput v1, Lt;->v:I

    const/16 v1, -0xe

    sput v1, Lt;->t:I

    goto/16 :goto_1c

    :cond_b8
    sput v1, Lt;->s:I

    sput v1, Lt;->t:I

    const/4 v0, 0x6

    sput v0, Lt;->p:I

    const/16 v0, 0xa

    sput v0, Lt;->z:I

    goto/16 :goto_1b

    nop

    :pswitch_data_c6
    .packed-switch 0x0
        :pswitch_1d  #00000000
        :pswitch_6d  #00000001
    .end packed-switch
.end method

.method private static c()V
    .registers 7

    const/16 v6, 0x14

    const/4 v0, -0x1

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x0

    sget v2, Lt;->n:I

    packed-switch v2, :pswitch_data_c6

    :cond_b
    :goto_b
    return-void

    :pswitch_c  #0x0
    sget v0, Lt;->d:I

    sget v2, Lg;->au:I

    sub-int/2addr v0, v2

    if-ge v0, v6, :cond_2c

    sget v0, Lg;->at:I

    sget v2, Lt;->c:I

    sget v3, Lt;->e:I

    shl-int/lit8 v3, v3, 0x4

    add-int/2addr v2, v3

    sub-int/2addr v0, v2

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v2, 0x28

    if-ge v0, v2, :cond_2c

    sput v5, Lt;->p:I

    sput v4, Lt;->t:I

    sput v4, Lt;->s:I

    goto :goto_b

    :cond_2c
    sget v0, Lq;->at:I

    rem-int/lit8 v0, v0, 0xa

    if-ne v0, v1, :cond_b

    sget v0, Lt;->d:I

    sget v1, Lg;->au:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    if-le v0, v6, :cond_b

    sget v0, Lt;->d:I

    sget v1, Lg;->au:I

    sub-int/2addr v0, v1

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    const/16 v1, 0x28

    if-ge v0, v1, :cond_b

    const/16 v0, 0xc

    sput v0, Lt;->p:I

    sput v4, Lt;->t:I

    sput v4, Lt;->s:I

    goto :goto_b

    :pswitch_53  #0x1
    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    sget v3, Lt;->e:I

    mul-int/lit8 v3, v3, 0x5

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x64

    if-ge v2, v3, :cond_92

    sget v2, Lt;->d:I

    sget v3, Lg;->au:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x1e

    if-ge v2, v3, :cond_92

    const/4 v2, 0x3

    invoke-static {v4, v2}, Lq;->e(II)I

    move-result v2

    if-nez v2, :cond_81

    const/4 v0, 0x7

    sput v0, Lt;->p:I

    sput v4, Lt;->t:I

    :goto_7e
    sput v4, Lt;->s:I

    goto :goto_b

    :cond_81
    sput v5, Lt;->p:I

    const/16 v2, 0xa

    sput v2, Lt;->t:I

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    if-le v2, v3, :cond_90

    :goto_8d
    sput v0, Lt;->e:I

    goto :goto_7e

    :cond_90
    move v0, v1

    goto :goto_8d

    :cond_92
    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    sget v3, Lt;->e:I

    mul-int/lit8 v3, v3, 0x5

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0xc8

    if-ge v2, v3, :cond_b

    sget v2, Lt;->d:I

    sget v3, Lg;->au:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x1e

    if-ge v2, v3, :cond_b

    sput v5, Lt;->p:I

    sput v4, Lt;->s:I

    const/16 v2, 0xf

    sput v2, Lt;->t:I

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    if-le v2, v3, :cond_c3

    :goto_bf
    sput v0, Lt;->e:I

    goto/16 :goto_b

    :cond_c3
    move v0, v1

    goto :goto_bf

    nop

    :pswitch_data_c6
    .packed-switch 0x0
        :pswitch_c  #00000000
        :pswitch_53  #00000001
    .end packed-switch
.end method

.method private static c(I)V
    .registers 7

    const/16 v5, 0x8

    const/4 v4, 0x6

    const/4 v0, 0x0

    sget-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    if-nez v1, :cond_b

    packed-switch p0, :pswitch_data_7a

    :cond_b
    :goto_b
    return-void

    :pswitch_c  #0x0
    new-array v1, v4, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    :goto_10
    if-ge v0, v4, :cond_b

    :try_start_12
    sget-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/mob/b2"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_2f
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_2f} :catch_32

    :goto_2f
    add-int/lit8 v0, v0, 0x1

    goto :goto_10

    :catch_32
    move-exception v1

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v2, "Bos ERR"

    invoke-virtual {v1, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_2f

    :pswitch_3b  #0x1
    const/16 v1, 0x9

    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    :goto_41
    if-lt v0, v5, :cond_59

    :try_start_43
    sget-object v0, Lt;->b:[Ljavax/microedition/lcdui/Image;

    const/16 v1, 0x8

    const-string v2, "/cp/cb0.png"

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v0, v1
    :try_end_4f
    .catch Ljava/io/IOException; {:try_start_43 .. :try_end_4f} :catch_50

    goto :goto_b

    :catch_50
    move-exception v0

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "Bos ERR"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_b

    :cond_59
    :try_start_59
    sget-object v1, Lt;->b:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/mob/s"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_76
    .catch Ljava/io/IOException; {:try_start_59 .. :try_end_76} :catch_50

    add-int/lit8 v0, v0, 0x1

    goto :goto_41

    nop

    :pswitch_data_7a
    .packed-switch 0x0
        :pswitch_c  #00000000
        :pswitch_3b  #00000001
    .end packed-switch
.end method

.method private static d()V
    .registers 8

    const/16 v4, 0x14

    const/4 v7, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x0

    const/4 v1, -0x1

    sget v2, Lt;->n:I

    packed-switch v2, :pswitch_data_e6

    :cond_b
    :goto_b
    return-void

    :pswitch_c  #0x0
    sget v2, Lt;->c:I

    sget v3, Lt;->q:I

    sub-int/2addr v2, v3

    if-ge v2, v4, :cond_29

    sput v0, Lt;->e:I

    sput v6, Lt;->s:I

    sget v0, Lt;->q:I

    sget v1, Lq;->at:I

    sget v2, Lt;->r:I

    sget v3, Lt;->q:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x28

    rem-int/2addr v1, v2

    add-int/2addr v0, v1

    sput v0, Lt;->t:I

    sput v7, Lt;->p:I

    goto :goto_b

    :cond_29
    sget v2, Lt;->r:I

    sget v3, Lt;->c:I

    sub-int/2addr v2, v3

    if-ge v2, v4, :cond_46

    sput v1, Lt;->e:I

    sput v6, Lt;->s:I

    sget v0, Lt;->q:I

    sget v1, Lq;->at:I

    sget v2, Lt;->r:I

    sget v3, Lt;->q:I

    sub-int/2addr v2, v3

    add-int/lit8 v2, v2, -0x28

    rem-int/2addr v1, v2

    add-int/2addr v0, v1

    sput v0, Lt;->t:I

    sput v7, Lt;->p:I

    goto :goto_b

    :cond_46
    sget v2, Lt;->e:I

    if-ne v2, v1, :cond_50

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    if-gt v2, v3, :cond_5a

    :cond_50
    sget v2, Lt;->e:I

    if-ne v2, v0, :cond_63

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    if-ge v2, v3, :cond_63

    :cond_5a
    const/16 v0, 0xc

    sput v0, Lt;->p:I

    sput v6, Lt;->t:I

    sput v6, Lt;->s:I

    goto :goto_b

    :cond_63
    sget v2, Lt;->d:I

    sget v3, Lg;->au:I

    sub-int/2addr v2, v3

    const/16 v3, 0x18

    if-ge v2, v3, :cond_a8

    sget v2, Lt;->c:I

    sget v3, Lg;->at:I

    sub-int/2addr v2, v3

    invoke-static {v2}, Lq;->a(I)I

    move-result v2

    const/16 v3, 0x18

    if-le v2, v3, :cond_a8

    sget v2, Lg;->at:I

    sput v2, Lt;->t:I

    sget v3, Lt;->q:I

    add-int/lit8 v3, v3, 0x5

    if-ge v2, v3, :cond_89

    sget v2, Lt;->q:I

    add-int/lit8 v2, v2, 0x5

    sput v2, Lt;->t:I

    :cond_89
    sget v2, Lt;->t:I

    sget v3, Lt;->r:I

    add-int/lit8 v3, v3, -0x5

    if-le v2, v3, :cond_97

    sget v2, Lt;->r:I

    add-int/lit8 v2, v2, -0x5

    sput v2, Lt;->t:I

    :cond_97
    sget v2, Lt;->t:I

    sget v3, Lt;->c:I

    if-le v2, v3, :cond_a6

    :goto_9d
    sput v0, Lt;->e:I

    sput v6, Lt;->s:I

    const/4 v0, 0x7

    sput v0, Lt;->p:I

    goto/16 :goto_b

    :cond_a6
    move v0, v1

    goto :goto_9d

    :cond_a8
    sget v2, Lt;->q:I

    sget v3, Lq;->at:I

    sget v4, Lt;->r:I

    sget v5, Lt;->q:I

    sub-int/2addr v4, v5

    add-int/lit8 v4, v4, -0x28

    rem-int/2addr v3, v4

    add-int/2addr v2, v3

    sput v2, Lt;->t:I

    sget v3, Lt;->c:I

    if-le v2, v3, :cond_c3

    sput v0, Lt;->e:I

    :goto_bd
    sput v6, Lt;->s:I

    sput v7, Lt;->p:I

    goto/16 :goto_b

    :cond_c3
    sput v1, Lt;->e:I

    goto :goto_bd

    :pswitch_c6  #0x1
    sget v2, Lt;->c:I

    sget v3, Lt;->q:I

    if-ge v2, v3, :cond_d6

    sput v0, Lt;->e:I

    sget v0, Lt;->q:I

    add-int/lit8 v0, v0, 0xa

    sput v0, Lt;->c:I

    goto/16 :goto_b

    :cond_d6
    sget v0, Lt;->c:I

    sget v2, Lt;->r:I

    if-le v0, v2, :cond_b

    sput v1, Lt;->e:I

    sget v0, Lt;->r:I

    add-int/lit8 v0, v0, -0xa

    sput v0, Lt;->c:I

    goto/16 :goto_b

    :pswitch_data_e6
    .packed-switch 0x0
        :pswitch_c  #00000000
        :pswitch_c6  #00000001
    .end packed-switch
.end method
