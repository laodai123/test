.class public LMidlet;
.super Ljavax/microedition/midlet/MIDlet;

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field static a:Lq;

.field static b:LMidlet;

.field static c:Z

.field public static d:I

.field public static e:Z

.field public static f:Z

.field public static g:I

.field public static h:Z

.field private static i:[Ljavax/microedition/lcdui/Image;

.field private static final j:[I

.field private static k:I

.field private static l:Ljavax/microedition/lcdui/Image;

.field private static final m:[I

.field private static n:I

.field private static o:Ljavax/microedition/lcdui/Image;

.field private static final p:[I

.field private static q:I

.field private static r:Ljavax/microedition/media/Player;

.field private static s:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x0

    sput-boolean v4, LMidlet;->c:Z

    const/16 v1, 0x29

    new-array v1, v1, [I

    fill-array-data v1, :array_72

    sput-object v1, LMidlet;->j:[I

    const/16 v1, 0x8

    sput v1, LMidlet;->k:I

    const/16 v1, 0x8d

    new-array v1, v1, [I

    fill-array-data v1, :array_c8

    sput-object v1, LMidlet;->m:[I

    const/16 v1, 0xc

    sput v1, LMidlet;->n:I

    const/16 v1, 0xd3

    new-array v1, v1, [I

    fill-array-data v1, :array_1e6

    sput-object v1, LMidlet;->p:[I

    const/16 v1, 0xd

    sput v1, LMidlet;->q:I

    sput v0, LMidlet;->g:I

    const/4 v1, 0x3

    :try_start_2f
    new-array v1, v1, [Ljavax/microedition/lcdui/Image;

    sput-object v1, LMidlet;->i:[Ljavax/microedition/lcdui/Image;
    :try_end_33
    .catch Ljava/lang/Exception; {:try_start_2f .. :try_end_33} :catch_6f

    :goto_33
    if-lt v0, v5, :cond_4b

    :goto_35
    :try_start_35
    const-string v0, "/fr.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, LMidlet;->l:Ljavax/microedition/lcdui/Image;
    :try_end_3d
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_3d} :catch_6d

    :goto_3d
    :try_start_3d
    const-string v0, "/fb.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, LMidlet;->o:Ljavax/microedition/lcdui/Image;
    :try_end_45
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_45} :catch_6b

    :goto_45
    const/4 v0, -0x1

    sput v0, LMidlet;->s:I

    sput-boolean v4, LMidlet;->h:Z

    return-void

    :cond_4b
    :try_start_4b
    sget-object v1, LMidlet;->i:[Ljavax/microedition/lcdui/Image;

    new-instance v2, Ljava/lang/StringBuffer;

    const-string v3, "/fs"

    invoke-direct {v2, v3}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v2

    aput-object v2, v1, v0
    :try_end_68
    .catch Ljava/lang/Exception; {:try_start_4b .. :try_end_68} :catch_6f

    add-int/lit8 v0, v0, 0x1

    goto :goto_33

    :catch_6b
    move-exception v0

    goto :goto_45

    :catch_6d
    move-exception v0

    goto :goto_3d

    :catch_6f
    move-exception v0

    goto :goto_35

    nop

    :array_72
    .array-data 4
        0x5
        0x3
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x7
        0x5
        0x3
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x7
        0x6
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x7
        0x5
        0x5
        0x5
    .end array-data

    :array_c8
    .array-data 4
        0x2
        0x6
        0x3
        0x5
        0x6
        0x6
        0x6
        0x5
        0x6
        0x6
        0x6
        0x3
        0x3
        0x3
        0x2
        0x6
        0x4
        0x4
        0x5
        0x3
        0x6
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x3
        0x8
        0x8
        0x8
        0xa
        0x8
        0x8
        0x8
        0x8
        0x8
        0x7
        0x8
        0x8
        0x8
        0xa
        0x8
        0x8
        0x8
        0x6
        0x6
        0x6
        0x6
        0x6
        0x5
        0x6
        0x6
        0x3
        0x5
        0x6
        0x3
        0x8
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x5
        0x6
        0x6
        0x8
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x3
        0x3
        0x3
        0x3
        0x3
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
    .end array-data

    :array_1e6
    .array-data 4
        0x3
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x4
        0x3
        0x3
        0x3
        0x6
        0x7
        0x7
        0x8
        0x5
        0xb
        0xb
        0x7
        0x6
        0xa
        0x6
        0x7
        0x5
        0x7
        0x6
        0x5
        0x7
        0x7
        0x3
        0x3
        0x6
        0x3
        0x9
        0x7
        0x7
        0x7
        0x7
        0x4
        0x5
        0x4
        0x8
        0x6
        0x9
        0x7
        0x6
        0x5
        0x6
        0x6
        0x6
        0x6
        0x6
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x8
        0x7
        0x8
        0x7
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x4
        0x3
        0x3
        0x3
        0x3
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x7
        0x8
        0x7
        0x7
        0x7
        0x8
        0x7
        0x8
        0x8
        0x8
        0x7
        0x7
        0x8
        0x7
        0x6
        0x7
        0x8
        0x8
        0x8
        0x8
        0x8
        0x6
        0x6
        0x6
        0x6
        0x6
        0x7
        0x8
        0x7
        0x7
        0x8
        0x6
        0x6
        0x8
        0x8
        0x3
        0x6
        0x7
        0x6
        0xb
        0x9
        0x8
        0x7
        0x8
        0x7
        0x5
        0x6
        0x8
        0x7
        0xb
        0x7
        0x7
        0x7
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x7
        0x6
        0x6
        0x6
        0x6
        0x5
        0x5
        0x5
        0x6
        0x5
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0xa
        0xa
        0xa
        0xa
        0xa
        0xa
        0x8
        0x8
        0x8
        0x8
        0x8
        0x9
        0x9
        0x9
        0x9
        0x9
        0x9
        0x7
        0x7
        0x7
        0x7
        0x7
        0x9
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljavax/microedition/midlet/MIDlet;-><init>()V

    sput-object p0, LMidlet;->b:LMidlet;

    invoke-static {}, Lq;->t()V

    return-void
.end method

.method public static a(Ljava/lang/String;)I
    .registers 6

    const/4 v1, 0x0

    move v0, v1

    move v2, v1

    :goto_3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-lt v0, v3, :cond_a

    return v2

    :cond_a
    const-string v3, " 0123456789.,:!?()+-*/#$%abcdefghijklmnopqrstuvwxyzáàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđABCDEFGHIJKLMNOPQRSTUVWXYZ"

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_18

    move v3, v1

    :cond_18
    sget-object v4, LMidlet;->p:[I

    aget v3, v4, v3

    add-int/2addr v2, v3

    add-int/lit8 v0, v0, 0x1

    goto :goto_3
.end method

.method public static a(I)V
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    int-to-byte v2, p0

    aput-byte v2, v0, v1

    const-string v1, "bg"

    invoke-static {v1, v0}, LMidlet;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method public static a(Ljava/lang/String;[B)V
    .registers 6

    const/4 v0, 0x1

    :try_start_1
    invoke-static {p0, v0}, Ljavax/microedition/rms/RecordStore;->openRecordStore(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;

    move-result-object v0

    invoke-virtual {v0}, Ljavax/microedition/rms/RecordStore;->getNumRecords()I

    move-result v1

    if-lez v1, :cond_15

    const/4 v1, 0x1

    const/4 v2, 0x0

    array-length v3, p1

    invoke-virtual {v0, v1, p1, v2, v3}, Ljavax/microedition/rms/RecordStore;->setRecord(I[BII)V

    :goto_11
    invoke-virtual {v0}, Ljavax/microedition/rms/RecordStore;->closeRecordStore()V

    :goto_14
    return-void

    :cond_15
    const/4 v1, 0x0

    array-length v2, p1

    invoke-virtual {v0, p1, v1, v2}, Ljavax/microedition/rms/RecordStore;->addRecord([BII)I
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1a} :catch_1b

    goto :goto_11

    :catch_1b
    move-exception v0

    goto :goto_14
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V
    .registers 19

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v13

    if-nez p4, :cond_d

    :goto_6
    const/4 v1, 0x0

    move v12, v1

    move/from16 v8, p2

    :goto_a
    if-lt v12, v13, :cond_22

    return-void

    :cond_d
    const/4 v1, 0x1

    move/from16 v0, p4

    if-ne v0, v1, :cond_19

    invoke-static {p1}, LMidlet;->a(Ljava/lang/String;)I

    move-result v1

    sub-int p2, p2, v1

    goto :goto_6

    :cond_19
    invoke-static {p1}, LMidlet;->a(Ljava/lang/String;)I

    move-result v1

    shr-int/lit8 v1, v1, 0x1

    sub-int p2, p2, v1

    goto :goto_6

    :cond_22
    const-string v1, " 0123456789.,:!?()+-*/#$%abcdefghijklmnopqrstuvwxyzáàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđABCDEFGHIJKLMNOPQRSTUVWXYZ"

    invoke-virtual {p1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, v2, :cond_56

    const/4 v1, 0x0

    move v11, v1

    :goto_31
    const/4 v1, -0x1

    if-le v11, v1, :cond_4d

    sget-object v2, LMidlet;->o:Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x0

    sget v1, LMidlet;->q:I

    mul-int/2addr v1, v11

    add-int/lit8 v4, v1, 0x1

    sget-object v1, LMidlet;->p:[I

    aget v5, v1, v11

    sget v1, LMidlet;->q:I

    add-int/lit8 v6, v1, -0x1

    const/4 v7, 0x0

    const/16 v10, 0x14

    move-object v1, p0

    move/from16 v9, p3

    invoke-virtual/range {v1 .. v10}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_4d
    sget-object v1, LMidlet;->p:[I

    aget v1, v1, v11

    add-int/2addr v8, v1

    add-int/lit8 v1, v12, 0x1

    move v12, v1

    goto :goto_a

    :cond_56
    move v11, v1

    goto :goto_31
.end method

.method public static a(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIII)V
    .registers 20

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v13

    if-nez p5, :cond_d

    :goto_6
    const/4 v1, 0x0

    move v12, v1

    move/from16 v8, p3

    :goto_a
    if-lt v12, v13, :cond_22

    return-void

    :cond_d
    const/4 v1, 0x1

    move/from16 v0, p5

    if-ne v0, v1, :cond_19

    invoke-static {p1}, LMidlet;->d(Ljava/lang/String;)I

    move-result v1

    sub-int p3, p3, v1

    goto :goto_6

    :cond_19
    invoke-static {p1}, LMidlet;->d(Ljava/lang/String;)I

    move-result v1

    shr-int/lit8 v1, v1, 0x1

    sub-int p3, p3, v1

    goto :goto_6

    :cond_22
    const-string v1, "0123456789+-%$:abcdefghijklmnopqrstuvwxyz"

    invoke-virtual {p1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, v2, :cond_57

    const/4 v1, 0x0

    move v11, v1

    :goto_31
    const/4 v1, -0x1

    if-le v11, v1, :cond_4c

    sget-object v1, LMidlet;->i:[Ljavax/microedition/lcdui/Image;

    aget-object v2, v1, p2

    const/4 v3, 0x0

    sget v1, LMidlet;->k:I

    mul-int v4, v11, v1

    sget-object v1, LMidlet;->j:[I

    aget v5, v1, v11

    sget v6, LMidlet;->k:I

    const/4 v7, 0x0

    const/16 v10, 0x14

    move-object v1, p0

    move/from16 v9, p4

    invoke-virtual/range {v1 .. v10}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_4c
    sget-object v1, LMidlet;->j:[I

    aget v1, v1, v11

    add-int/lit8 v1, v1, -0x1

    add-int/2addr v8, v1

    add-int/lit8 v1, v12, 0x1

    move v12, v1

    goto :goto_a

    :cond_57
    move v11, v1

    goto :goto_31
.end method

.method public static a(Z)V
    .registers 4

    const/4 v2, 0x1

    new-array v0, v2, [B

    const/4 v1, 0x0

    aput-byte v2, v0, v1

    const-string v1, "saved"

    invoke-static {v1, v0}, LMidlet;->a(Ljava/lang/String;[B)V

    return-void
.end method

.method public static a()Z
    .registers 3

    const/4 v1, 0x1

    const/4 v0, 0x0

    const-string v2, "saved"

    invoke-static {v2}, LMidlet;->b(Ljava/lang/String;)[B

    move-result-object v2

    if-nez v2, :cond_b

    :cond_a
    :goto_a
    return v0

    :cond_b
    aget-byte v2, v2, v0

    if-ne v2, v1, :cond_a

    move v0, v1

    goto :goto_a
.end method

.method public static a(Ljava/lang/String;I)[Ljava/lang/String;
    .registers 11

    const/16 v8, 0xa

    const/4 v0, 0x1

    const/16 v7, 0x20

    const/4 v1, 0x0

    new-instance v5, Ljava/util/Vector;

    invoke-direct {v5}, Ljava/util/Vector;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v6

    if-gt v6, v0, :cond_16

    new-array v0, v0, [Ljava/lang/String;

    aput-object p0, v0, v1

    :goto_15
    return-object v0

    :cond_16
    const-string v2, ""

    move v0, v1

    move v3, v1

    move-object v4, v2

    :goto_1b
    invoke-static {v4}, LMidlet;->a(Ljava/lang/String;)I

    move-result v2

    if-lt v2, p1, :cond_4a

    :cond_21
    move v2, v0

    :goto_22
    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_71

    add-int/lit8 v0, v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-eq v0, v7, :cond_71

    move v0, v2

    :goto_2f
    add-int/lit8 v4, v0, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-eq v4, v8, :cond_6f

    add-int/lit8 v4, v0, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v7, :cond_45

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v7, :cond_6f

    :cond_45
    if-eq v0, v3, :cond_6f

    add-int/lit8 v0, v0, -0x1

    goto :goto_2f

    :cond_4a
    new-instance v2, Ljava/lang/StringBuffer;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-eq v4, v8, :cond_21

    add-int/lit8 v4, v6, -0x1

    if-lt v0, v4, :cond_b2

    add-int/lit8 v0, v6, -0x1

    move v2, v0

    goto :goto_22

    :cond_6f
    if-ne v0, v3, :cond_b0

    :cond_71
    :goto_71
    add-int/lit8 v0, v2, 0x1

    invoke-virtual {p0, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_96

    add-int/lit8 v2, v2, 0x1

    :goto_80
    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_8a

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-eq v0, v7, :cond_93

    :cond_8a
    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_96

    const-string v4, ""

    move v0, v2

    move v3, v2

    goto :goto_1b

    :cond_93
    add-int/lit8 v2, v2, 0x1

    goto :goto_80

    :cond_96
    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v0

    new-array v2, v0, [Ljava/lang/String;

    :goto_9c
    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v0

    if-lt v1, v0, :cond_a5

    move-object v0, v2

    goto/16 :goto_15

    :cond_a5
    invoke-virtual {v5, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    aput-object v0, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_9c

    :cond_b0
    move v2, v0

    goto :goto_71

    :cond_b2
    move-object v4, v2

    goto/16 :goto_1b
.end method

.method private static b(I)V
    .registers 4

    sget v0, LMidlet;->s:I

    if-ne p0, v0, :cond_5

    :goto_4
    return-void

    :cond_5
    :try_start_5
    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    if-eqz v0, :cond_19

    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->stop()V

    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->deallocate()V

    const/4 v0, 0x0

    sput-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-static {}, Ljava/lang/System;->gc()V

    :cond_19
    const-string v0, ""

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuffer;

    const-string v2, "/s/"

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    const-string v2, ".mid"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    const-string v1, "audio/midi"

    invoke-static {v0, v1}, Ljavax/microedition/media/Manager;->createPlayer(Ljava/io/InputStream;Ljava/lang/String;)Ljavax/microedition/media/Player;

    move-result-object v0

    sput-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->realize()V

    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    const-string v1, "VolumeControl"

    invoke-interface {v0, v1}, Ljavax/microedition/media/Controllable;->getControl(Ljava/lang/String;)Ljavax/microedition/media/Control;

    move-result-object v0

    check-cast v0, Ljavax/microedition/media/control/VolumeControl;

    sget v1, Lq;->bu:I

    mul-int/lit8 v1, v1, 0xa

    invoke-interface {v0, v1}, Ljavax/microedition/media/control/VolumeControl;->setLevel(I)I

    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->prefetch()V

    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    const/16 v1, 0x3e8

    invoke-interface {v0, v1}, Ljavax/microedition/media/Player;->setLoopCount(I)V

    sput p0, LMidlet;->s:I
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_62} :catch_63

    goto :goto_4

    :catch_63
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    invoke-static {}, Ljava/lang/System;->gc()V

    const/4 v0, 0x1

    sput-boolean v0, LMidlet;->h:Z

    goto :goto_4
.end method

.method public static b(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V
    .registers 18

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v12

    invoke-static {p1}, LMidlet;->c(Ljava/lang/String;)I

    move-result v0

    shr-int/lit8 v0, v0, 0x1

    sub-int v7, p2, v0

    const/4 v0, 0x0

    move v11, v0

    :goto_e
    if-lt v11, v12, :cond_11

    return-void

    :cond_11
    const-string v0, " 0123456789.,:!?()-\'/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzáàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđĐ"

    invoke-virtual {p1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_45

    const/4 v0, 0x0

    move v10, v0

    :goto_20
    const/4 v0, -0x1

    if-le v10, v0, :cond_3c

    sget-object v1, LMidlet;->l:Ljavax/microedition/lcdui/Image;

    const/4 v2, 0x0

    sget v0, LMidlet;->n:I

    mul-int/2addr v0, v10

    add-int/lit8 v3, v0, 0x1

    sget-object v0, LMidlet;->m:[I

    aget v4, v0, v10

    sget v0, LMidlet;->n:I

    add-int/lit8 v5, v0, -0x1

    const/4 v6, 0x0

    const/16 v9, 0x14

    move-object v0, p0

    move/from16 v8, p3

    invoke-virtual/range {v0 .. v9}, Ljavax/microedition/lcdui/Graphics;->drawRegion(Ljavax/microedition/lcdui/Image;IIIIIIII)V

    :cond_3c
    sget-object v0, LMidlet;->m:[I

    aget v0, v0, v10

    add-int/2addr v7, v0

    add-int/lit8 v0, v11, 0x1

    move v11, v0

    goto :goto_e

    :cond_45
    move v10, v0

    goto :goto_20
.end method

.method public static b(Ljava/lang/String;)[B
    .registers 3

    const/4 v0, 0x0

    :try_start_1
    invoke-static {p0, v0}, Ljavax/microedition/rms/RecordStore;->openRecordStore(Ljava/lang/String;Z)Ljavax/microedition/rms/RecordStore;

    move-result-object v1

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Ljavax/microedition/rms/RecordStore;->getRecord(I)[B

    move-result-object v0

    invoke-virtual {v1}, Ljavax/microedition/rms/RecordStore;->closeRecordStore()V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_d} :catch_e

    :goto_d
    return-object v0

    :catch_e
    move-exception v0

    const/4 v0, 0x0

    goto :goto_d
.end method

.method public static b(Ljava/lang/String;I)[Ljava/lang/String;
    .registers 10

    const/4 v1, 0x0

    const/16 v7, 0x20

    new-instance v5, Ljava/util/Vector;

    invoke-direct {v5}, Ljava/util/Vector;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v6

    const-string v2, ""

    move v0, v1

    move v3, v1

    move-object v4, v2

    :goto_11
    invoke-static {v4}, LMidlet;->c(Ljava/lang/String;)I

    move-result v2

    if-lt v2, p1, :cond_38

    :cond_17
    move v2, v0

    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_57

    add-int/lit8 v0, v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-eq v0, v7, :cond_57

    move v0, v2

    :goto_25
    add-int/lit8 v4, v0, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v7, :cond_33

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v7, :cond_55

    :cond_33
    if-eq v0, v3, :cond_55

    add-int/lit8 v0, v0, -0x1

    goto :goto_25

    :cond_38
    new-instance v2, Ljava/lang/StringBuffer;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    add-int/lit8 v4, v6, -0x1

    if-eq v0, v4, :cond_17

    move-object v4, v2

    goto :goto_11

    :cond_55
    if-ne v0, v3, :cond_94

    :cond_57
    :goto_57
    add-int/lit8 v0, v2, 0x1

    invoke-virtual {p0, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_7c

    add-int/lit8 v2, v2, 0x1

    :goto_66
    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_70

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    if-eq v0, v7, :cond_79

    :cond_70
    add-int/lit8 v0, v6, -0x1

    if-eq v2, v0, :cond_7c

    const-string v4, ""

    move v0, v2

    move v3, v2

    goto :goto_11

    :cond_79
    add-int/lit8 v2, v2, 0x1

    goto :goto_66

    :cond_7c
    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v0

    new-array v2, v0, [Ljava/lang/String;

    :goto_82
    invoke-virtual {v5}, Ljava/util/Vector;->size()I

    move-result v0

    if-lt v1, v0, :cond_89

    return-object v2

    :cond_89
    invoke-virtual {v5, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    aput-object v0, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_82

    :cond_94
    move v2, v0

    goto :goto_57
.end method

.method private static c(Ljava/lang/String;)I
    .registers 6

    const/4 v1, 0x0

    move v0, v1

    move v2, v1

    :goto_3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-lt v0, v3, :cond_a

    return v2

    :cond_a
    const-string v3, " 0123456789.,:!?()-\'/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzáàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđĐ"

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_18

    move v3, v1

    :cond_18
    sget-object v4, LMidlet;->m:[I

    aget v3, v4, v3

    add-int/2addr v2, v3

    add-int/lit8 v0, v0, 0x1

    goto :goto_3
.end method

.method private static c()V
    .registers 7

    const/4 v0, 0x3

    const/4 v6, 0x2

    const/4 v5, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    sput-boolean v4, Lq;->c:Z

    sput-boolean v3, Lq;->d:Z

    sput-boolean v3, Lq;->e:Z

    sput-boolean v3, Lq;->f:Z

    sput-boolean v3, Lq;->g:Z

    sput-boolean v3, Lq;->h:Z

    sput-boolean v3, Lg;->g:Z

    sput v4, Lg;->as:I

    const/16 v1, 0x46

    sput v1, Lg;->aJ:I

    const/16 v1, 0x28

    sput v1, Lg;->aK:I

    sput-boolean v4, Lg;->f:Z

    const/16 v1, 0xfa0

    sput v1, Lg;->aM:I

    sput v1, Lg;->aL:I

    const/16 v1, 0x5dc

    sput v1, Lg;->aO:I

    sput v1, Lg;->aN:I

    const/16 v1, 0x1194

    sput v1, Lm;->e:I

    sput v1, Lm;->f:I

    const/16 v1, 0x320

    sput v1, Lq;->aL:I

    sput v1, Lq;->aK:I

    const/16 v1, 0x1f40

    sput v1, Le;->f:I

    const/16 v1, 0x3e8

    sput v1, Lt;->i:I

    sput v1, Lt;->j:I

    const/16 v1, 0x7d0

    sput v1, Lt;->k:I

    sput v1, Lt;->l:I

    sput v5, Lg;->bc:I

    const/4 v1, 0x5

    sput v1, Lq;->aC:I

    const/4 v1, 0x5

    sput v1, Lg;->aP:I

    sput v6, Lg;->aQ:I

    const/16 v1, 0x8

    sput v1, Lq;->aD:I

    const/4 v1, 0x4

    sput v1, Lg;->ax:I

    sput v4, Lg;->av:I

    sput v4, Lg;->aw:I

    sput v3, Lg;->ay:I

    sput v3, Lg;->aH:I

    sput v3, Lg;->aG:I

    const/16 v1, 0x1e

    sput v1, Lg;->aW:I

    sput v3, Lg;->aX:I

    const/16 v1, 0x18

    sput v1, Lg;->at:I

    const/16 v1, 0x18

    sput v1, Lg;->au:I

    sput v4, Lg;->aF:I

    sput v5, Lq;->am:I

    const/16 v1, 0x15

    new-array v1, v1, [Z

    sput-object v1, Lq;->bt:[Z

    sput-boolean v3, Lg;->bm:Z

    sput-boolean v3, Lg;->O:Z

    sput-boolean v3, Lq;->a:Z

    sput v3, Lq;->aj:I

    sput-boolean v3, Lg;->H:Z

    sput v5, Lg;->Q:I

    sput v5, Lq;->aQ:I

    sput-boolean v3, Lg;->i:Z

    sput-boolean v3, Lg;->h:Z

    sput-boolean v3, Lq;->au:Z

    sput-boolean v3, Lg;->ba:Z

    sput-boolean v3, Lg;->bb:Z

    sput-boolean v3, Lq;->i:Z

    sput-boolean v3, Lq;->j:Z

    sput-boolean v3, Lq;->k:Z

    sput-boolean v3, Lq;->l:Z

    sput-boolean v3, Lq;->m:Z

    sput-boolean v3, Lq;->n:Z

    sput-boolean v3, Lq;->o:Z

    sput-boolean v3, Lq;->p:Z

    sput-boolean v3, Lq;->q:Z

    sput-boolean v3, Lq;->r:Z

    sput-boolean v3, Lq;->s:Z

    sput-boolean v3, Lq;->t:Z

    sput-boolean v3, Lg;->j:Z

    sput-boolean v3, Lg;->k:Z

    sput-boolean v3, Lg;->l:Z

    sput-boolean v3, Lt;->m:Z

    sput-boolean v3, Lg;->m:Z

    sput-boolean v3, Lg;->n:Z

    sput-boolean v3, Lg;->o:Z

    sput-boolean v4, Lg;->p:Z

    sput-boolean v3, Lg;->r:Z

    sput-boolean v3, Lg;->s:Z

    sput-boolean v3, Lg;->t:Z

    sput-boolean v3, Lg;->u:Z

    sput-boolean v4, Lg;->q:Z

    sput-boolean v3, Lg;->v:Z

    sput-boolean v3, Lg;->w:Z

    sput-boolean v3, Lg;->x:Z

    sput-boolean v3, Lg;->y:Z

    sput-boolean v3, Lg;->z:Z

    sput-boolean v3, Lg;->A:Z

    sput-boolean v3, Lg;->B:Z

    sput-boolean v3, Lg;->C:Z

    sput-boolean v3, Lm;->g:Z

    sput v5, Lg;->D:I

    sput v3, Lg;->bL:I

    sput v5, Lg;->bn:I

    sput-boolean v3, Lg;->ap:Z

    sput v5, Lg;->a:I

    sput v5, Lq;->bi:I

    sput-boolean v3, Lq;->aA:Z

    sput-boolean v3, Lq;->aN:Z

    sget-object v1, Lq;->bf:[I

    aput v3, v1, v3

    sget-object v1, Lq;->bf:[I

    const/16 v2, 0x64

    aput v2, v1, v4

    sget-object v1, Lq;->bf:[I

    aput v4, v1, v6

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, "Gươm tre"

    aput-object v2, v1, v3

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, "Phi tiêu"

    aput-object v2, v1, v4

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, "Gươm sét"

    aput-object v2, v1, v6

    sget-object v1, Lq;->bs:[I

    aput v3, v1, v3

    sget-object v1, Lq;->bs:[I

    aput v4, v1, v4

    sget-object v1, Lq;->bs:[I

    aput v6, v1, v6

    sput v0, Lq;->bh:I

    :goto_114
    const/4 v1, 0x6

    if-lt v0, v1, :cond_118

    return-void

    :cond_118
    sget-object v1, Lq;->bf:[I

    aput v5, v1, v0

    sget-object v1, Lq;->bg:[Ljava/lang/String;

    const-string v2, ""

    aput-object v2, v1, v0

    sget-object v1, Lq;->bs:[I

    aput v5, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_114
.end method

.method private static d(Ljava/lang/String;)I
    .registers 6

    const/4 v1, 0x0

    move v0, v1

    move v2, v1

    :goto_3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-lt v0, v3, :cond_a

    return v2

    :cond_a
    const-string v3, "0123456789+-%$:abcdefghijklmnopqrstuvwxyz"

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_18

    move v3, v1

    :cond_18
    sget-object v4, LMidlet;->j:[I

    aget v3, v4, v3

    add-int/lit8 v3, v3, 0x1

    add-int/2addr v2, v3

    add-int/lit8 v0, v0, 0x1

    goto :goto_3
.end method


# virtual methods
.method public final b()V
    .registers 2

    const/4 v0, 0x0

    sput-boolean v0, Lq;->y:Z

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-virtual {p0}, Ljavax/microedition/midlet/MIDlet;->notifyDestroyed()V

    return-void
.end method

.method protected destroyApp(Z)V
    .registers 3

    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    if-eqz v0, :cond_e

    :try_start_4
    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->stop()V
    :try_end_9
    .catch Ljavax/microedition/media/MediaException; {:try_start_4 .. :try_end_9} :catch_f

    :goto_9
    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->deallocate()V

    :cond_e
    return-void

    :catch_f
    move-exception v0

    goto :goto_9
.end method

.method protected pauseApp()V
    .registers 1

    invoke-static {}, Lq;->b()V

    invoke-static {}, Lq;->c()V

    return-void
.end method

.method public run()V
    .registers 10

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v1, 0x0

    const-wide/16 v2, 0xc8

    :try_start_5
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    invoke-static {}, Ljava/lang/Thread;->yield()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    long-to-int v0, v2

    rem-int/lit16 v0, v0, 0x3e8

    invoke-static {v0}, Lq;->a(I)I

    move-result v0

    sput v0, Lq;->at:I

    const/16 v0, 0x1e

    sput v0, Lq;->bk:I

    invoke-static {}, Ljava/lang/Thread;->yield()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lj;->c(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lj;->b(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lj;->a(I)V

    const/16 v0, 0x32

    sput v0, Lq;->bk:I

    invoke-static {}, Ljava/lang/Thread;->yield()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lc;->b(I)V

    invoke-static {}, Lg;->d()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lg;->b(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lg;->a(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lg;->d(I)V

    const/16 v0, 0x41

    sput v0, Lq;->bk:I

    sget v0, Lq;->as:I

    invoke-static {v0}, Ln;->a(I)V

    invoke-static {}, Ljava/lang/Thread;->yield()V

    sget v0, Lq;->as:I

    invoke-static {v0}, La;->a(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lt;->a(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lm;->a(I)V

    const/16 v0, 0x46

    sput v0, Lq;->bk:I

    invoke-static {}, Ljava/lang/Thread;->yield()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lq;->e(I)V

    const/16 v0, 0x4b

    sput v0, Lq;->bk:I

    invoke-static {}, Lq;->j()V

    invoke-static {}, Lo;->a()V

    invoke-static {}, Lq;->p()V

    const/16 v0, 0x4e

    sput v0, Lq;->bk:I

    invoke-static {}, Ljava/lang/Thread;->yield()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lq;->d(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lq;->c(I)V

    sget v0, Lq;->as:I

    invoke-static {v0}, Lp;->a(I)V

    const/16 v0, 0x50

    sput v0, Lq;->bk:I

    invoke-static {}, Lq;->k()V

    invoke-static {}, Lq;->r()V

    const/16 v0, 0x52

    sput v0, Lq;->bk:I

    invoke-static {}, Ljava/lang/Thread;->yield()V

    invoke-static {}, Lq;->q()V

    invoke-static {}, Lq;->m()V

    invoke-static {}, Lq;->l()V

    const/16 v0, 0x55

    sput v0, Lq;->bk:I

    sget v0, Lq;->as:I

    const/4 v2, 0x0

    sput-boolean v2, Ld;->a:Z

    if-nez v0, :cond_dd

    sget-boolean v0, Lq;->c:Z

    if-eqz v0, :cond_dd

    const/4 v0, 0x1

    sput-boolean v0, Ld;->a:Z
    :try_end_c2
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_c2} :catch_2c5

    :try_start_c2
    const-string v0, "/i/ftfong.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Ld;->b:Ljavax/microedition/lcdui/Image;
    :try_end_ca
    .catch Ljava/io/IOException; {:try_start_c2 .. :try_end_ca} :catch_2bf
    .catch Ljava/lang/Exception; {:try_start_c2 .. :try_end_ca} :catch_2c5

    :goto_ca
    const/4 v0, 0x0

    :try_start_cb
    sput v0, Ld;->c:I

    const/16 v0, 0x414

    sput v0, Ld;->d:I

    const/16 v0, 0x108

    sput v0, Ld;->e:I

    const/16 v0, -0xc

    sput v0, Ld;->f:I

    const/16 v0, 0x30c

    sput v0, Ld;->g:I

    :cond_dd
    sget v0, Lq;->as:I

    invoke-static {v0}, Le;->a(I)V

    sget v0, Lq;->as:I

    const/4 v2, 0x0

    sput-boolean v2, Ls;->a:Z

    if-nez v0, :cond_106

    sget-boolean v0, Lq;->c:Z

    if-eqz v0, :cond_106

    const/4 v0, 0x1

    sput-boolean v0, Ls;->a:Z
    :try_end_f0
    .catch Ljava/lang/Exception; {:try_start_cb .. :try_end_f0} :catch_2c5

    :try_start_f0
    const-string v0, "/i/wind.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Ls;->b:Ljavax/microedition/lcdui/Image;
    :try_end_f8
    .catch Ljava/io/IOException; {:try_start_f0 .. :try_end_f8} :catch_2cf
    .catch Ljava/lang/Exception; {:try_start_f0 .. :try_end_f8} :catch_2c5

    :goto_f8
    const/4 v0, 0x0

    :try_start_f9
    sput v0, Ls;->c:I

    const/16 v0, 0x30c

    sput v0, Ls;->d:I

    const/16 v0, 0x114

    sput v0, Ls;->e:I

    const/4 v0, 0x0

    sput v0, Ls;->f:I

    :cond_106
    sget v0, Lq;->as:I

    invoke-static {v0}, Lq;->b(I)V

    invoke-static {}, Lq;->e()V

    invoke-static {}, Lq;->n()V

    invoke-static {}, Lq;->o()V

    sget v0, Lq;->as:I

    invoke-static {v0}, Li;->a(I)V

    const/16 v0, 0x57

    sput v0, Lq;->bk:I

    invoke-static {}, Lq;->d()V

    invoke-static {}, Lq;->g()V

    invoke-static {}, Lq;->h()V

    const/16 v0, 0x5f

    sput v0, Lq;->bk:I

    invoke-static {}, Ljava/lang/Thread;->yield()V

    sget v0, Lq;->as:I

    sparse-switch v0, :sswitch_data_3a0

    move v2, v1

    move v3, v1

    :goto_134
    const/4 v0, 0x5

    new-array v0, v0, [I

    const/4 v4, 0x0

    const v5, 0x55aaee

    aput v5, v0, v4

    const/4 v4, 0x1

    const v5, 0xaa0ee

    aput v5, v0, v4

    const/4 v4, 0x2

    const v5, 0xaa0ee

    aput v5, v0, v4

    const/4 v4, 0x4

    const v5, 0xa0d8f8

    aput v5, v0, v4

    sget v4, LMidlet;->g:I

    aget v0, v0, v4

    sput v0, Lq;->P:I
    :try_end_155
    .catch Ljava/lang/Exception; {:try_start_f9 .. :try_end_155} :catch_2c5

    :try_start_155
    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_186

    sget-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_16a

    const/4 v0, 0x4

    new-array v0, v0, [Ljavax/microedition/lcdui/Image;

    sput-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x4

    new-array v0, v0, [I

    sput-object v0, Lq;->ap:[I

    move v0, v1

    :goto_168
    if-lt v0, v7, :cond_324

    :cond_16a
    sget v0, LMidlet;->g:I

    if-eq v0, v8, :cond_35d

    sget-object v0, Lq;->aq:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_17a

    const-string v0, "/bg/cl0.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->aq:Ljavax/microedition/lcdui/Image;

    :cond_17a
    sget-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;

    if-nez v0, :cond_186

    const-string v0, "/bg/sun0.png"

    invoke-static {v0}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v0

    sput-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;
    :try_end_186
    .catch Ljava/lang/Exception; {:try_start_155 .. :try_end_186} :catch_365

    :cond_186
    :goto_186
    const/4 v0, 0x0

    :try_start_187
    sput-boolean v0, Lq;->I:Z

    sget-boolean v0, Lq;->b:Z

    if-nez v0, :cond_1dd

    const/4 v0, 0x1

    sput-boolean v0, Lq;->I:Z

    sget v0, Lq;->ac:I

    sget-object v4, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v5, 0x0

    aget-object v4, v4, v5

    invoke-virtual {v4}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v4

    sub-int/2addr v0, v4

    sput v0, Lq;->Q:I

    sget-object v4, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v5, 0x1

    aget-object v4, v4, v5

    if-eqz v4, :cond_1b0

    sget-object v4, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v5, 0x1

    aget-object v4, v4, v5

    invoke-virtual {v4}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v4

    sub-int/2addr v0, v4

    add-int/2addr v0, v3

    :cond_1b0
    sput v0, Lq;->R:I

    sget-object v3, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v4, 0x3

    aget-object v3, v3, v4

    if-eqz v3, :cond_1c3

    sget-object v3, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v4, 0x3

    aget-object v3, v3, v4

    invoke-virtual {v3}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v3

    sub-int/2addr v0, v3

    :cond_1c3
    sput v0, Lq;->T:I

    sput v0, Lq;->aa:I

    sget-object v0, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v3, 0x2

    aget-object v0, v0, v3

    if-eqz v0, :cond_1dd

    sget v0, Lq;->R:I

    sget-object v3, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    const/4 v4, 0x2

    aget-object v3, v3, v4

    invoke-virtual {v3}, Ljavax/microedition/lcdui/Image;->getHeight()I

    move-result v3

    sub-int/2addr v0, v3

    add-int/2addr v0, v2

    sput v0, Lq;->S:I

    :cond_1dd
    sget v0, Lq;->ac:I

    mul-int/lit8 v0, v0, 0x2

    div-int/lit8 v0, v0, 0x3

    sget v2, Lq;->R:I

    sub-int/2addr v0, v2

    if-gez v0, :cond_1e9

    move v0, v1

    :cond_1e9
    sget v1, Lq;->as:I

    sget-object v2, Lq;->bt:[Z

    array-length v2, v2

    if-ge v1, v2, :cond_1f7

    sget-object v1, Lq;->bt:[Z

    sget v2, Lq;->as:I

    const/4 v3, 0x1

    aput-boolean v3, v1, v2

    :cond_1f7
    sget v1, Lq;->as:I

    const/16 v2, 0x6a

    if-ne v1, v2, :cond_203

    sget-object v1, Lq;->bt:[Z

    const/4 v2, 0x0

    const/4 v3, 0x0

    aput-boolean v3, v1, v2

    :cond_203
    sget v1, Lq;->aa:I

    add-int/2addr v1, v0

    sput v1, Lq;->aa:I

    sget v1, Lq;->as:I

    const/16 v2, 0xb

    if-eq v1, v2, :cond_219

    sget v1, Lq;->as:I

    const/16 v2, 0x11

    if-eq v1, v2, :cond_219

    sget v1, Lq;->Q:I

    add-int/2addr v1, v0

    sput v1, Lq;->Q:I

    :cond_219
    sget v1, Lq;->R:I

    add-int/2addr v1, v0

    sput v1, Lq;->R:I

    sget v1, Lq;->S:I

    add-int/2addr v1, v0

    sput v1, Lq;->S:I

    sget v1, Lq;->T:I

    add-int/2addr v0, v1

    sput v0, Lq;->T:I

    sget v0, Lq;->ab:I

    mul-int/lit8 v0, v0, 0x3

    div-int/lit8 v0, v0, 0x4

    sput v0, Lq;->N:I

    sget v0, Lq;->aa:I

    div-int/lit8 v0, v0, 0x3

    sput v0, Lq;->O:I

    const/4 v0, 0x2

    new-array v0, v0, [I

    sput-object v0, Lq;->L:[I

    const/4 v0, 0x2

    new-array v0, v0, [I

    sput-object v0, Lq;->M:[I

    sget-object v0, Lq;->L:[I

    const/4 v1, 0x0

    sget v2, Lq;->ab:I

    div-int/lit8 v2, v2, 0x3

    aput v2, v0, v1

    sget-object v0, Lq;->M:[I

    const/4 v1, 0x0

    sget v2, Lq;->aa:I

    div-int/lit8 v2, v2, 0x2

    add-int/lit8 v2, v2, -0x8

    aput v2, v0, v1

    sget-object v0, Lq;->L:[I

    const/4 v1, 0x1

    sget v2, Lq;->ab:I

    mul-int/lit8 v2, v2, 0x2

    div-int/lit8 v2, v2, 0x3

    aput v2, v0, v1

    sget-object v0, Lq;->M:[I

    const/4 v1, 0x1

    sget v2, Lq;->aa:I

    div-int/lit8 v2, v2, 0x2

    add-int/lit8 v2, v2, 0x8

    aput v2, v0, v1

    const/4 v0, 0x1

    sput-boolean v0, Lq;->J:Z

    const-string v0, "Menu"

    sput-object v0, Lq;->U:Ljava/lang/String;

    const-string v0, " "

    sput-object v0, Lq;->V:Ljava/lang/String;

    const/4 v0, 0x0

    sput-boolean v0, La;->b:Z

    sget v0, Lq;->as:I

    invoke-static {v0}, Lq;->f(I)V

    invoke-static {}, Lq;->f()V

    const/16 v0, 0x64

    sput v0, Lq;->bk:I

    sget-boolean v0, LMidlet;->c:Z

    if-eqz v0, :cond_28e

    const/4 v0, 0x0

    sput-boolean v0, LMidlet;->c:Z

    invoke-static {}, LMidlet;->c()V

    :cond_28e
    invoke-static {}, Lq;->c()V

    sget-boolean v0, LMidlet;->e:Z

    if-eqz v0, :cond_36f

    const/4 v0, 0x0

    invoke-static {v0}, Lq;->a(Z)V

    const/4 v0, 0x0

    sput-boolean v0, LMidlet;->e:Z

    :cond_29c
    :goto_29c
    sget v0, Lq;->as:I

    sparse-switch v0, :sswitch_data_41e

    const/4 v0, 0x0

    invoke-static {v0}, LMidlet;->b(I)V

    :goto_2a5
    sget-boolean v0, LMidlet;->h:Z
    :try_end_2a7
    .catch Ljava/lang/Exception; {:try_start_187 .. :try_end_2a7} :catch_2c5

    if-nez v0, :cond_2ae

    :try_start_2a9
    sget-object v0, LMidlet;->r:Ljavax/microedition/media/Player;

    invoke-interface {v0}, Ljavax/microedition/media/Player;->start()V
    :try_end_2ae
    .catch Ljava/lang/Exception; {:try_start_2a9 .. :try_end_2ae} :catch_393

    :cond_2ae
    :goto_2ae
    sget v0, Lq;->bl:I

    const/16 v1, 0x5a

    if-lt v0, v1, :cond_399

    invoke-static {}, Lq;->b()V

    invoke-static {}, Lq;->c()V

    sget v0, LMidlet;->d:I

    sput v0, Lq;->K:I

    return-void

    :catch_2bf
    move-exception v0

    :try_start_2c0
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2c3
    .catch Ljava/lang/Exception; {:try_start_2c0 .. :try_end_2c3} :catch_2c5

    goto/16 :goto_ca

    :catch_2c5
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    sget-object v0, LMidlet;->b:LMidlet;

    invoke-virtual {v0}, LMidlet;->b()V

    goto :goto_2ae

    :catch_2cf
    move-exception v0

    :try_start_2d0
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto/16 :goto_f8

    :sswitch_2d5
    const/4 v0, 0x0

    sput v0, LMidlet;->g:I

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_468

    sput-object v0, Lq;->be:[I

    move v2, v1

    move v3, v1

    goto/16 :goto_134

    :sswitch_2e4
    const/4 v0, 0x1

    sput v0, LMidlet;->g:I

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_474

    sput-object v0, Lq;->be:[I

    move v2, v1

    move v3, v1

    goto/16 :goto_134

    :sswitch_2f3
    const/4 v0, 0x2

    sput v0, LMidlet;->g:I

    const/16 v3, 0x9

    const/4 v0, 0x6

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_480

    sput-object v2, Lq;->be:[I

    move v2, v0

    goto/16 :goto_134

    :sswitch_304
    const/4 v0, 0x3

    sput v0, LMidlet;->g:I

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_48c

    sput-object v0, Lq;->be:[I

    move v2, v1

    move v3, v1

    goto/16 :goto_134

    :sswitch_313
    const/4 v0, 0x4

    sput v0, LMidlet;->g:I

    const/16 v0, 0xc

    const/4 v2, 0x4

    new-array v2, v2, [I

    fill-array-data v2, :array_498

    sput-object v2, Lq;->be:[I
    :try_end_320
    .catch Ljava/lang/Exception; {:try_start_2d0 .. :try_end_320} :catch_2c5

    move v2, v1

    move v3, v0

    goto/16 :goto_134

    :cond_324
    :try_start_324
    sget-object v4, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    new-instance v5, Ljava/lang/StringBuffer;

    const-string v6, "/bg/bg"

    invoke-direct {v5, v6}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v5

    sget v6, LMidlet;->g:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v5

    const-string v6, ".png"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljavax/microedition/lcdui/Image;->createImage(Ljava/lang/String;)Ljavax/microedition/lcdui/Image;

    move-result-object v5

    aput-object v5, v4, v0
    :try_end_347
    .catch Ljava/lang/Exception; {:try_start_324 .. :try_end_347} :catch_39e

    :goto_347
    :try_start_347
    sget-object v4, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v4, v4, v0

    if-eqz v4, :cond_359

    sget-object v4, Lq;->ap:[I

    sget-object v5, Lq;->ao:[Ljavax/microedition/lcdui/Image;

    aget-object v5, v5, v0

    invoke-virtual {v5}, Ljavax/microedition/lcdui/Image;->getWidth()I

    move-result v5

    aput v5, v4, v0

    :cond_359
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_168

    :cond_35d
    const/4 v0, 0x0

    sput-object v0, Lq;->aq:Ljavax/microedition/lcdui/Image;

    const/4 v0, 0x0

    sput-object v0, Lq;->ar:Ljavax/microedition/lcdui/Image;
    :try_end_363
    .catch Ljava/lang/Exception; {:try_start_347 .. :try_end_363} :catch_365

    goto/16 :goto_186

    :catch_365
    move-exception v0

    :try_start_366
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v4, "BG ERR"

    invoke-virtual {v0, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_186

    :cond_36f
    sget-boolean v0, LMidlet;->f:Z

    if-eqz v0, :cond_29c

    invoke-static {}, Lq;->a()V

    const/4 v0, 0x0

    sput-boolean v0, LMidlet;->f:Z

    goto/16 :goto_29c

    :sswitch_37b
    const/4 v0, 0x0

    invoke-static {v0}, LMidlet;->b(I)V

    goto/16 :goto_2a5

    :sswitch_381
    const/4 v0, 0x3

    invoke-static {v0}, LMidlet;->b(I)V

    goto/16 :goto_2a5

    :sswitch_387
    const/4 v0, 0x1

    invoke-static {v0}, LMidlet;->b(I)V

    goto/16 :goto_2a5

    :sswitch_38d
    const/4 v0, 0x2

    invoke-static {v0}, LMidlet;->b(I)V

    goto/16 :goto_2a5

    :catch_393
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_397
    .catch Ljava/lang/Exception; {:try_start_366 .. :try_end_397} :catch_2c5

    goto/16 :goto_2ae

    :cond_399
    invoke-static {}, Ljava/lang/Thread;->yield()V

    goto/16 :goto_2ae

    :catch_39e
    move-exception v4

    goto :goto_347

    :sswitch_data_3a0
    .sparse-switch
        0x0 -> :sswitch_2d5
        0x1 -> :sswitch_2d5
        0x2 -> :sswitch_2d5
        0x3 -> :sswitch_2d5
        0x4 -> :sswitch_2d5
        0x5 -> :sswitch_2e4
        0x6 -> :sswitch_2e4
        0x7 -> :sswitch_2f3
        0x8 -> :sswitch_2f3
        0x9 -> :sswitch_2f3
        0xa -> :sswitch_2f3
        0xb -> :sswitch_304
        0xc -> :sswitch_313
        0xd -> :sswitch_313
        0xe -> :sswitch_313
        0xf -> :sswitch_313
        0x10 -> :sswitch_313
        0x11 -> :sswitch_304
        0x12 -> :sswitch_2e4
        0x13 -> :sswitch_2e4
        0x14 -> :sswitch_2d5
        0x63 -> :sswitch_313
        0x64 -> :sswitch_2f3
        0x65 -> :sswitch_2e4
        0x66 -> :sswitch_313
        0x67 -> :sswitch_2d5
        0x69 -> :sswitch_2d5
        0x6a -> :sswitch_2f3
        0x6b -> :sswitch_2d5
        0x6c -> :sswitch_2d5
        0x6d -> :sswitch_2f3
    .end sparse-switch

    :sswitch_data_41e
    .sparse-switch
        0x0 -> :sswitch_387
        0x1 -> :sswitch_387
        0x2 -> :sswitch_38d
        0x3 -> :sswitch_38d
        0x4 -> :sswitch_38d
        0x9 -> :sswitch_387
        0xa -> :sswitch_387
        0xe -> :sswitch_387
        0x14 -> :sswitch_38d
        0x63 -> :sswitch_37b
        0x64 -> :sswitch_381
        0x65 -> :sswitch_381
        0x66 -> :sswitch_381
        0x67 -> :sswitch_381
        0x69 -> :sswitch_38d
        0x6a -> :sswitch_38d
        0x6b -> :sswitch_387
        0x6c -> :sswitch_381
    .end sparse-switch

    :array_468
    .array-data 4
        0x1
        0x2
        0x3
        0x4
    .end array-data

    :array_474
    .array-data 4
        0x1
        0x2
        0x3
        0x4
    .end array-data

    :array_480
    .array-data 4
        0x1
        0x2
        0x3
        0x4
    .end array-data

    :array_48c
    .array-data 4
        0x1
        0x1
        0x1
        0x1
    .end array-data

    :array_498
    .array-data 4
        0x1
        0x2
        0x3
        0x4
    .end array-data
.end method

.method protected startApp()V
    .registers 3

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "9100"

    invoke-static {v1}, Lb;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method
